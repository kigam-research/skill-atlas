# Offline adapters and handoff contract

Run from a project environment containing numpy, rasterio, pyproj, shapely and matplotlib:

```bash
uv run python skills/geo-data-intake-validator/scripts/intake.py \
  --input /path/to/immutable-data --handoff /path/to/handoff.json --output /path/to/new-report-dir
```

`--output` must be a NEW directory outside the input. The CLI does not reproject, resample, rewrite headers or normalize. A nonzero inspection status is reported as a disagreement or an unreadable/unverified file, not silently repaired. Process exit 0 means the report was written, not that the handoff passed.

## JSON handoff

```json
{
  "reference": "dem.tif",
  "files": [
    {"path": "dem.tif", "declared": {"crs": "EPSG:4326", "units": "m", "resolution": [0.01, 0.01], "nodata": -9999}},
    {"path": "magnetic.tif", "capability": "metadata/describe.xml"},
    {"path": "samples.csv", "coordinate_columns": ["longitude", "latitude"]}
  ]
}
```

Paths are input-relative and may not escape the input tree. `declared` is the independent handoff specification, not a value guessed from file names. Explicit handoff fields take precedence over capability fields; both remain in report.json so conflicts are inspectable. Scalar variable-unit/nodata handoff declarations apply to every band; lists specify per-band declarations. A single WCS range field cannot verify additional bands. CRS identifiers should use canonical authority strings (e.g. EPSG:4326); text differences are conservatively reported rather than normalized without review. `nominal_lonlat: true` permits a clearly conditional coordinate-bbox diagnostic for geographic CRSs, not exact cross-datum physical overlap.

## Supported scope

- **GeoTIFF:** embedded CRS, affine, extent, pixel spacing, band units, per-band declared nodata, nonfinite counts and GDAL mask counts. Blockwise reads bound raster memory. Sentinel and mask counts can legitimately differ (alpha/internal mask); report and investigate, do not erase the mask.
- **GeoJSON:** measured geometry bounds, feature count and explicit legacy CRS when present. Without a CRS member, retain RFC7946 longitude/latitude as a stated assumption, not independently verified EPSG metadata. Empty/missing geometries remain visible. Full geometry validity is not certified.
- **GeoPackage:** read-only SQLite reads of feature-layer CRS and declared header bounds. Header bounds are NOT independently recomputed geometry bounds. Multi-layer selection, geometry validity and attributes remain unverified; select/extract layers with a suitable vector tool for deeper checks.
- **CSV:** only explicitly named coordinate columns; nonfinite and nonnumeric rows counted separately. CRS and variable units cannot be independently verified from bare CSV. Readable coordinate extent is not proof of CRS.
- **NetCDF:** GDAL-readable single raster variable only. Multi-variable subdatasets are listed and remain unverified pending variable/time/level selection. CF coordinates, calendar, vertical datum, grid_mapping and packing conventions require a dedicated CF review; do not claim generic NetCDF validation from this adapter.
- **Metadata:** WCS DescribeCoverage with explicit axis labels, EPSG URI, axis-aligned offset vectors, SWE nodata and unit declarations. JSON/Markdown/PDF documents are read by the agent and transcribed into the handoff; the script does not infer scientific units from prose or map-server horizontal units. Ambiguous WCS axes remain unverified.

## Decision interpretation

`agree` means the observed declaration agrees with the stated comparator, not that a file is scientifically correct or acceptable for the intended analysis. `disagree` means a concrete declaration or chosen-grid mismatch. `unverified` means absent, unsupported or not independently established. CRS/resolution summary status combines independent-declaration and reference-file diagnostics conservatively: a declaration disagreement cannot be overwritten by agreement with the reference. Both component comparisons remain in report.json. File status is conservative across the six fields; non-raster resolution/alignment fields remain unverified rather than a fabricated pass.

Grid alignment is defined only for equal-CRS, north-up affine grids with equal pixel size and integer origin offsets. Different resolutions do not imply invalid data; the researcher chooses target support and resampling based on variable semantics (continuous field vs categories). Bounds are closed coordinate envelopes, not footprints, valid-cell intersections or geodesic areas. Point/line envelope intersections can be nonempty with zero area; do not infer disjointness from area zero.

Before any OPTIONAL normalized copy, obtain explicit choices for target CRS/datum operation and epoch, AOI, target lattice and resolution, continuous/categorical resampling, variable unit conversion and nodata policy. Preserve original hashes, write only to a separate output, then recheck transformed control points, extent, counts and value ranges. This skill's CLI does not perform that copy.

## Kambalda example

`references/kambalda-handoff.json` maps six TIFFs to independently delivered WCS XMLs. `scripts/kambalda_case.py` executes the predeclared `references/kambalda-check-plan.json` against this specific case; these assertions do not generalize to other datasets. The before/after pair shows new **handoff knowledge** on the same nine-file/six-check matrix. It does not show transformed data or improved positional accuracy.
