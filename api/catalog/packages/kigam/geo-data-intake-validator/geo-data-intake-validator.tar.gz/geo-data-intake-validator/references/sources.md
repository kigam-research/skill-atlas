Staged GA WCS DescribeCoverage XML and MapServer JSON: compare declarations without downloading new data.
Geoscience Australia magnetic grid eCat 131505 DOI 10.26186/5e9cf3f2c0f1d; OZMIN eCat 144672.
Local rasterio/GDAL and pyproj/PROJ metadata readings are implementation evidence, not domain review.
RFC 7946 GeoJSON uses WGS84 longitude/latitude; legacy CRS must be declared and checked.