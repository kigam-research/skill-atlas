---
name: geo-data-intake-validator
description: GeoTIFF, GeoJSON/GPKG, 좌표 CSV, NetCDF와 메타데이터를 분석 전에 인계받을 때 사용합니다.
  CRS·datum·단위·범위 겹침·해상도·격자 정합·nodata 선언을 확인하고 일치·불일치·미확인 보고서와 필요한 연구자 결정을
  작성합니다. 분석 정확도 인증이나 자동 재투영에는 쓰지 않습니다.
metadata:
  version: "0.1.0"
license: MIT
---
# 공간자료 인계 점검: 좌표계·단위·격자 정합

## 업무와 사용 조건
GeoTIFF, GeoJSON/GPKG, 좌표 CSV, NetCDF와 메타데이터를 분석 전에 인계받을 때 사용합니다. CRS·datum·단위·범위 겹침·해상도·격자 정합·nodata 선언을 확인하고 일치·불일치·미확인 보고서와 필요한 연구자 결정을 작성합니다. 분석 정확도 인증이나 자동 재투영에는 쓰지 않습니다.

## 입력
- **격자 영상** (geotiff)
  crs: 원본 CRS·축 순서·datum·epoch와 인계 기준을 별도로 선언; 누락은 미확인; units: 좌표 단위와 변수 단위를 구분; 파일명으로 단위를 확정하지 않음; columns: ; missingValues: 파일별 sentinel·NaN·mask 및 유효범위; 0은 임의 결측값 아님; resolution: 원본 transform·pixel size·origin을 비교; degree≠metre
- **벡터 도형** (geopackage, geojson)
  crs: 원본 CRS·축 순서·datum·epoch와 인계 기준을 별도로 선언; 누락은 미확인; units: 좌표 단위와 변수 단위를 구분; 파일명으로 단위를 확정하지 않음; columns: ; missingValues: 파일별 sentinel·NaN·mask 및 유효범위; 0은 임의 결측값 아님; resolution: 원본 transform·pixel size·origin을 비교; degree≠metre
- **좌표 표** (csv)
  crs: 원본 CRS·축 순서·datum·epoch와 인계 기준을 별도로 선언; 누락은 미확인; units: 좌표 단위와 변수 단위를 구분; 파일명으로 단위를 확정하지 않음; columns: x, y; named coordinate columns must be explicitly supplied for CSV; missingValues: 파일별 sentinel·NaN·mask 및 유효범위; 0은 임의 결측값 아님; resolution: 원본 transform·pixel size·origin을 비교; degree≠metre
- **다차원 격자** (netcdf)
  crs: 원본 CRS·축 순서·datum·epoch와 인계 기준을 별도로 선언; 누락은 미확인; units: 좌표 단위와 변수 단위를 구분; 파일명으로 단위를 확정하지 않음; columns: ; missingValues: 파일별 sentinel·NaN·mask 및 유효범위; 0은 임의 결측값 아님; resolution: 원본 transform·pixel size·origin을 비교; degree≠metre
- **메타데이터·인계 조건** (json, markdown, pdf)
  crs: 원본 CRS·축 순서·datum·epoch와 인계 기준을 별도로 선언; 누락은 미확인; units: 좌표 단위와 변수 단위를 구분; 파일명으로 단위를 확정하지 않음; missingValues: 파일별 sentinel·NaN·mask 및 유효범위; 0은 임의 결측값 아님; resolution: 원본 transform·pixel size·origin을 비교; degree≠metre

## 방법과 판단
1. 원본·출처 고정: 파일 목록·hash·이용 조건과 인계 목적을 기록합니다. 자료는 읽기 전용입니다.
2. 선언과 실제 읽기: CRS·datum·축 순서·단위·nodata·transform을 파일과 metadata에서 독립적으로 읽습니다.
3. 겹침·격자 정합: 공통 좌표 표현의 bbox 겹침과 pixel size·origin 차이를 계산합니다. 명목 겹침은 실제 정확도 증거가 아닙니다.
4. 불일치 판단: 일치·불일치·미확인을 분리합니다. degree와 metre, 지도 단위와 변수 단위를 혼동하지 않습니다.
5. 정규화 여부 결정: 연구자가 target CRS·extent·resolution·보간·nodata 정책을 선택하기 전에는 정규화하지 않습니다. 이 CLI는 보고 전용입니다.
6. 인계 보고: 파일별 상태·근거·연구자 결정을 JSON/CSV/PNG로 보고합니다. 미확인은 통과가 아닙니다.

## 선택 기준
### CRS·단위·grid 선언이 충돌하거나 누락될 때
- 대안: 원본 유지 + 불일치·미확인 보고 / 출처 담당자에게 기준 확인 / 연구자 선택 후 별도 정규화 사본 작성
- 선택 근거: 인계 목적과 허용 위치 오차, 변수 의미를 확인합니다. 단순 label 재지정과 실제 재투영을 구분합니다.
- 확인: 원본 hash, 선언 출처, 좌표 연산·정확도, 겹침 면적 및 nodata 수를 독립 계산과 대조합니다.
- 예외: 근거가 없으면 미확인으로 중지합니다. 변환 후 범위·수량·값이 예상과 다르면 사본을 채택하지 않습니다.

## 연구자가 결정할 일
- 분석 목적에 맞는 기준 CRS·허용 오차·변수 단위·결측값·정규화 정책은 무엇입니까?

## 산출물
- 파일별 인계 점검 보고서와 비교 그림: 일치·불일치·미확인을 파일별로 읽습니다. 검사 코드가 통과해도 입력 자료가 호환된다는 뜻은 아닙니다.

## 제한
- 분야 전문가 검토 전입니다. 과학적 타당성·현장 정확도·지역 적용 가능성을 인증하지 않습니다.
- WGS84 ensemble과 GDA94의 명목 CRS 변환은 좌표 epoch와 변환 연산 없이는 실제 datum 차이를 검증하지 못합니다.
- 선언 누락은 미확인입니다. degree를 metre로 보거나 모든 nodata를 0으로 바꾸지 않습니다.
- 정규화는 연구자가 CRS·해상도·extent·보간·nodata 정책을 명시적으로 선택한 뒤 별도 사본에만 수행합니다.

## 근거와 출처
Staged GA WCS DescribeCoverage XML and MapServer JSON: compare declarations without downloading new data.
Geoscience Australia magnetic grid eCat 131505 DOI 10.26186/5e9cf3f2c0f1d; OZMIN eCat 144672.
Local rasterio/GDAL and pyproj/PROJ metadata readings are implementation evidence, not domain review.
RFC 7946 GeoJSON uses WGS84 longitude/latitude; legacy CRS must be declared and checked.

## 주의점과 완료 기준
[주의점](references/pitfalls.md) · [완료 기준](references/completion.md)


## 실행과 형식별 범위

[오프라인 CLI·입력 계약·형식별 한계](references/adapters.md)를 읽고 지원 범위를 먼저 확인합니다. `scripts/intake.py --input <자료 디렉터리> --handoff <JSON 선언> --output <새 보고 디렉터리>`로 보고서를 만듭니다. 입력은 수정하지 않습니다. 실행 종료 0은 보고서 작성 성공이며 자료 통과가 아닙니다. `scripts/selftest.py`는 구성 자료의 알려진 답을 검사합니다.

GeoPackage는 layer별 선언을 읽고, 다변수 NetCDF는 변수를 나열합니다. 실제 geometry나 CF 의미까지 검증했다고 설명하지 않습니다. CSV는 좌표 열 이름을 명시해야 합니다. 상세 검증이 필요한 형식은 적절한 reader로 확장하고 지원되지 않는 항목은 미확인으로 남깁니다.
