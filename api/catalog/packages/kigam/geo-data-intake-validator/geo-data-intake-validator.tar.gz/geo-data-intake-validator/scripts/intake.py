"""Offline, read-only geospatial handoff inspection. No normalization or network access."""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
import sqlite3
import xml.etree.ElementTree as ET

import numpy as np
import rasterio
from pyproj import CRS
from shapely.geometry import shape
from shapely.ops import unary_union

STATUS = {'agree': 1, 'unverified': 0, 'disagree': -1}
FIELDS = ['crs', 'units', 'extent', 'resolution', 'alignment', 'nodata']


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()


def local_path(root, relative):
    path = (Path(root) / relative).resolve()
    if not path.is_relative_to(Path(root).resolve()):
        raise ValueError(f'Path is outside input: {relative}')
    return path


def compare(actual, declared, tolerance=0):
    if actual is None or declared is None:
        return 'unverified'
    if isinstance(actual, (list, tuple)):
        if len(actual) != len(declared):
            return 'disagree'
        return worst_status([compare(a, b, tolerance) for a, b in zip(actual, declared)])
    if isinstance(actual, (float, int)) and isinstance(declared, (float, int)):
        if math.isnan(actual) and math.isnan(declared):
            return 'agree'
        return 'agree' if abs(actual - declared) <= tolerance else 'disagree'
    return 'agree' if actual == declared else 'disagree'


def worst_status(statuses):
    return 'disagree' if 'disagree' in statuses else 'unverified' if 'unverified' in statuses else 'agree'


def bbox_intersects(a, b):
    # Closed coordinate envelopes include points, lines and touching bounds.
    return min(a[2], b[2]) >= max(a[0], b[0]) and min(a[3], b[3]) >= max(a[1], b[1])


def bbox_area(a, b):
    """Coordinate rectangle intersection; NOT geodesic area or valid-data overlap."""
    return max(0., min(a[2], b[2]) - max(a[0], b[0])) * max(0., min(a[3], b[3]) - max(a[1], b[1]))


def grid_alignment(transform, reference, tolerance=1e-8):
    """North-up same-CRS affine grids only. Offset is measured in reference pixels."""
    a, b, c, d, e, f = transform[:6]
    ra, rb, rc, rd, re, rf = reference[:6]
    if any(abs(v) > 1e-14 for v in (b, d, rb, rd)) or not ra or not re:
        return {'status': 'unverified', 'reason': 'rotated or degenerate grid'}
    if not np.allclose([a, e], [ra, re], rtol=0, atol=1e-12):
        return {'status': 'disagree', 'reason': 'different pixel spacing'}
    offset = [(c - rc) / ra, (f - rf) / re]
    residual = [abs(v - round(v)) for v in offset]
    return {'status': 'agree' if max(residual) <= tolerance else 'disagree',
            'offset_pixels': offset, 'residual_pixels': residual,
            'reason': 'equal spacing and integer origin offset required'}


def read_wcs(path):
    """Read explicit EPSG and Lat/Long axis vectors; reject ambiguous axes."""
    doc = ET.parse(path)
    ns = {'g': 'http://www.opengis.net/gml/3.2', 's': 'http://www.opengis.net/swe/2.0'}
    env = doc.find('.//g:Envelope', ns)
    if env is None:
        return {}
    epsg = env.get('srsName', '').rsplit('/', 1)[-1]
    axes = env.get('axisLabels', '').lower().split()
    vectors = [[float(x) for x in node.text.split()] for node in doc.findall('.//g:offsetVector', ns)]
    spacing = None
    if len(vectors) == 2 and len(axes) == 2:
        try:
            xi = next(i for i, x in enumerate(axes) if x in ('long', 'lon', 'longitude', 'x'))
            yi = next(i for i, x in enumerate(axes) if x in ('lat', 'latitude', 'y'))
            if all(len(v) == 2 and sum(x != 0 for x in v) == 1 for v in vectors):
                spacing = [max(abs(v[xi]) for v in vectors), max(abs(v[yi]) for v in vectors)]
        except StopIteration:
            pass
    nil = doc.find('.//s:nilValue', ns)
    uom = doc.find('.//s:uom', ns)
    return {'crs': f'EPSG:{epsg}' if epsg.isdigit() else None, 'resolution': spacing,
            'nodata': float(nil.text) if nil is not None else None,
            'units': uom.get('code') if uom is not None else None,
            'axis_labels': axes, 'sha256': digest(path)}


def inspect_raster(path):
    with rasterio.open(path) as ds:
        if ds.subdatasets:
            # A multi-variable NetCDF is not a single grid. Inspect each variable separately.
            return {'kind': 'multidimensional', 'subdatasets': list(ds.subdatasets),
                    'note': 'Select a variable/time/level and rerun; CF conventions need separate review.'}
        bands = []
        for band in range(1, ds.count + 1):
            sentinel = ds.nodatavals[band - 1]
            counts = {'sentinel_count': None if sentinel is None else 0, 'mask_count': 0,
                      'nonfinite_count': 0}
            for _, window in ds.block_windows(band):
                a = ds.read(band, window=window)
                counts['mask_count'] += int(np.count_nonzero(ds.read_masks(band, window=window) == 0))
                counts['nonfinite_count'] += int(np.count_nonzero(~np.isfinite(a)))
                if sentinel is not None:
                    counts['sentinel_count'] += int(np.count_nonzero(np.isnan(a) if math.isnan(sentinel) else a == sentinel))
            bands.append({'band': band, 'nodata': 'NaN' if sentinel is not None and math.isnan(sentinel) else sentinel,
                          'units': ds.units[band - 1], **counts})
        return {'kind': 'raster', 'crs': ds.crs.to_string() if ds.crs else None,
                'bounds': list(ds.bounds), 'resolution': list(ds.res), 'transform': list(ds.transform)[:6],
                'shape': [ds.height, ds.width], 'bands': bands,
                'units': bands[0]['units'] if bands else None,
                'nodata': bands[0]['nodata'] if bands else None,
                'tags': ds.tags(), 'band_tags': ds.tags(1) if ds.count else {}}


def inspect_geojson(path):
    doc = json.loads(Path(path).read_text())
    features = doc.get('features', []) if doc.get('type') == 'FeatureCollection' else [doc]
    geometries = [shape(f['geometry']) for f in features if f.get('geometry')]
    explicit = doc.get('crs', {}).get('properties', {}).get('name')
    return {'kind': 'vector', 'crs': CRS.from_user_input(explicit).to_string() if explicit else None,
            'coordinate_assumption': None if explicit else 'RFC7946 WGS84 longitude/latitude; not an explicit EPSG declaration',
            'bounds': list(unary_union(geometries).bounds) if geometries else None,
            'feature_count': len(features), 'missing_geometry': len(features) - len(geometries)}


def inspect_gpkg(path):
    # Read declared extents without a vector I/O dependency. Do not call them measured geometry bounds.
    with sqlite3.connect(Path(path).as_uri() + '?mode=ro', uri=True) as db:
        rows = db.execute('SELECT table_name,min_x,min_y,max_x,max_y,srs_id FROM gpkg_contents WHERE data_type="features"').fetchall()
        layers = []
        for name, x0, y0, x1, y1, srs in rows:
            definition = db.execute('SELECT definition FROM gpkg_spatial_ref_sys WHERE srs_id=?', (srs,)).fetchone()
            try:
                crs = CRS.from_wkt(definition[0]).to_string() if definition else None
            except Exception:
                crs = None
            layers.append({'layer': name, 'bounds': [x0, y0, x1, y1], 'crs': crs})
        return {'kind': 'geopackage', 'layers': layers,
                'note': 'Header extent only; geometry validity, measured bounds and per-layer attributes remain unverified.'}


def inspect_csv(path, declaration):
    columns = declaration.get('coordinate_columns')
    with Path(path).open(newline='', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        headers = reader.fieldnames
        rows = list(reader)
    result = {'kind': 'coordinate-table', 'columns': headers, 'row_count': len(rows),
              'crs': None, 'bounds': None, 'note': 'CSV CRS/units are sidecar declarations, not embedded observations.'}
    if columns and len(columns) == 2 and all(c in (headers or []) for c in columns):
        xy, invalid = [], 0
        for row in rows:
            try:
                point = [float(row[c]) for c in columns]
                if not all(math.isfinite(x) for x in point):
                    raise ValueError()
                xy.append(point)
            except (ValueError, TypeError):
                invalid += 1
        result['invalid_coordinates'] = invalid
        if xy:
            a = np.asarray(xy)
            result['bounds'] = [*a.min(axis=0), *a.max(axis=0)]
    return result


def inspect_file(path, declaration):
    suffix = path.suffix.lower()
    if suffix in ('.tif', '.tiff', '.nc', '.netcdf'):
        return inspect_raster(path)
    if suffix in ('.geojson', '.json'):
        return inspect_geojson(path)
    if suffix == '.gpkg':
        return inspect_gpkg(path)
    if suffix == '.csv':
        return inspect_csv(path, declaration)
    return {'kind': 'unsupported', 'note': 'No supported offline reader; remains unverified.'}


def inspect_handoff(input_dir, handoff):
    root = Path(input_dir).resolve()
    files = []
    for entry in handoff['files']:
        path = local_path(root, entry['path'])
        record = {'path': entry['path'], 'declaration': entry.get('declared', {})}
        try:
            record['sha256'] = digest(path)
            record.update(inspect_file(path, entry))
        except (ValueError, OSError, sqlite3.Error, rasterio.errors.RasterioError) as exc:
            record.update(kind='unreadable', error=str(exc))
        if entry.get('capability'):
            record['capability'] = read_wcs(local_path(root, entry['capability']))
            record['capability_path'] = entry['capability']
        files.append(record)
    reference = next(r for r in files if r['path'] == handoff['reference'])
    for r in files:
        declared = r['declaration']
        cap = r.get('capability', {})
        comparisons = {}
        for field in ['crs', 'units', 'resolution', 'nodata']:
            expected = declared.get(field, cap.get(field))
            status = compare(r.get(field), expected, 1e-12 if field == 'resolution' else 0)
            band_observations = None
            if field in ('units', 'nodata') and r.get('bands'):
                band_observations = [b[field] for b in r['bands']]
                if isinstance(expected, list):
                    status = compare(band_observations, expected)
                else:
                    # A scalar handoff declaration applies to every band. A single WCS range
                    # declaration cannot independently substantiate other bands.
                    statuses = [compare(v, expected if field in declared or i == 0 else None)
                                for i, v in enumerate(band_observations)]
                    status = worst_status(statuses)
            comparisons[field] = {'status': status, 'band_observations': band_observations,
                                  'observed': r.get(field), 'expected': expected,
                                  'basis': 'handoff declaration' if field in declared else 'WCS declaration' if field in cap else 'no independent declaration',
                                  'decision': {'crs': 'Confirm datum, coordinate epoch and acceptable location error before conversion.',
                                               'units': 'Obtain authoritative VARIABLE unit; map-coordinate units are insufficient.',
                                               'resolution': 'Choose target grid spacing in its native unit; do not infer metres from filename.',
                                               'nodata': 'Confirm sentinel, mask and validity; absence is not zero missing values.'}[field]}
        bounds, ref_bounds = r.get('bounds'), reference.get('bounds')
        if bounds and ref_bounds:
            same_crs = bool(r.get('crs') and reference.get('crs') and CRS(r['crs']) == CRS(reference['crs']))
            # Nominal coordinate comparison is available only for same CRS or explicitly chosen geographic assumption.
            nominal = same_crs or (handoff.get('nominal_lonlat') and
                       ((r.get('crs') and CRS(r['crs']).is_geographic) or r.get('coordinate_assumption')) and
                       reference.get('crs') and CRS(reference['crs']).is_geographic)
            area = bbox_area(bounds, ref_bounds) if nominal else None
            comparisons['extent'] = {'status': ('agree' if bbox_intersects(bounds, ref_bounds) else 'disagree') if same_crs else 'unverified',
                                     'nonempty_coordinate_intersection': bbox_intersects(bounds, ref_bounds) if nominal else None,
                                     'intersection_coordinate_area': area,
                                     'basis': 'same-CRS bounding rectangles' if same_crs else 'conditional nominal lon/lat only; datum operation not accepted',
                                     'decision': 'Choose analysis AOI and required overlap fraction; bbox overlap is not valid-data overlap.'}
        else:
            comparisons['extent'] = {'status': 'unverified', 'decision': 'Obtain measured bounds and CRS for each selected layer.'}
        if r.get('transform') and reference.get('transform'):
            nominal_alignment = grid_alignment(r['transform'], reference['transform'])
            aligned_crs = r.get('crs') == reference.get('crs') and r.get('crs') is not None
            comparisons['alignment'] = {**nominal_alignment, 'status': nominal_alignment['status'] if aligned_crs else 'unverified',
                                        'nominal_grid_status': nominal_alignment['status'],
                                        'decision': 'Select datum operation and target lattice; numerical half-cell offsets alone do not resolve datum.'}
        else:
            comparisons['alignment'] = {'status': 'unverified', 'decision': 'Not a selected single raster grid; alignment is not established.'}
        # Keep declaration agreement separate from compatibility with the reference grid.
        r['declaration_comparisons'] = {k: dict(v) for k, v in comparisons.items() if k in ('crs','units','resolution','nodata')}
        r['reference_comparisons'] = {}
        for field in ('crs', 'resolution'):
            reference_status = compare(r.get(field), reference.get(field), 1e-12 if field == 'resolution' else 0)
            r['reference_comparisons'][field] = {'status': reference_status, 'expected': reference.get(field)}
            declaration_status = comparisons[field]['status']
            comparisons[field] = {'status': worst_status([reference_status, declaration_status]),
                                  'declaration_status': declaration_status, 'reference_status': reference_status,
                                  'observed': r.get(field), 'expected': reference.get(field),
                                  'basis': 'reference-file diagnostic; different is not scientifically invalid',
                                  'decision': comparisons[field]['decision']}
        r['comparisons'] = comparisons
        r['status'] = 'disagree' if any(c['status'] == 'disagree' for c in comparisons.values()) else 'unverified' if any(c['status'] == 'unverified' for c in comparisons.values()) else 'agree'
        if r.get('crs'):
            crs = CRS(r['crs'])
            r['crs_detail'] = {'datum': crs.datum.name if crs.datum else None,
                               'axes': [{'name': a.name, 'unit': a.unit_name, 'direction': a.direction} for a in crs.axis_info],
                               'coordinate_epoch': 'unverified: not read by this adapter'}
    return {'schema': 'geo-intake-report/v1', 'mode': 'report-only', 'reference': handoff['reference'],
            'normalization': 'not performed; explicit researcher choice and a separate tool are required',
            'scope': 'Declaration agreement is not scientific validity, positional accuracy or acceptance for analysis.', 'files': files}


def write_outputs(report, output):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    output = Path(output)
    output.mkdir(parents=True, exist_ok=False)
    (output / 'report.json').write_text(json.dumps(report, indent=2, ensure_ascii=False, allow_nan=False) + '\n')
    rows = []
    for i, r in enumerate(report['files'], 1):
        for j, field in enumerate(FIELDS, 1):
            rows.append({'file_index': i, 'file': r['path'], 'check_index': j, 'check': field,
                         'status': r['comparisons'][field]['status']})
    colors = {'agree': '#237858', 'disagree': '#c34b35', 'unverified': '#7a8490'}
    for when in ('before', 'after'):
        values = [{**r, 'status': 'unverified' if when == 'before' else r['status']} for r in rows]
        with (output / f'{when}.csv').open('w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=list(values[0])); writer.writeheader(); writer.writerows(values)
        fig, ax = plt.subplots(figsize=(10, 5), layout='constrained')
        for status, color in colors.items():
            data = [r for r in values if r['status'] == status]
            ax.scatter([r['file_index'] for r in data], [r['check_index'] for r in data], c=color, s=95, label=status)
        ax.set(xticks=range(1, len(report['files']) + 1), yticks=range(1, len(FIELDS) + 1),
               yticklabels=FIELDS, xlabel='File index (-)', ylabel='Check index (-)',
               title=f'{when.title()}: handoff knowledge, NOT normalized data')
        ax.set_xlim(.5, len(report['files']) + .5); ax.set_ylim(.5, len(FIELDS) + .5)
        ax.grid(alpha=.2); ax.legend(ncol=3, loc='upper center', bbox_to_anchor=(.5, 1.02))
        fig.savefig(output / f'{when}.png', dpi=125); plt.close(fig)
    points = []
    fig, ax = plt.subplots(figsize=(9, 6), layout='constrained')
    for r in report['files']:
        bounds = r.get('bounds')
        if not bounds:
            continue
        crs = r.get('crs')
        if not ((crs and CRS(crs).is_geographic) or r.get('coordinate_assumption')):
            continue
        x0, y0, x1, y1 = bounds
        xy = [(x0,y0),(x0,y1),(x1,y1),(x1,y0),(x0,y0)]
        for x, y in xy:
            points.append({'longitude': x, 'latitude': y, 'file': Path(r['path']).stem})
        ax.plot(*zip(*xy), label=Path(r['path']).stem, alpha=.8)
    ax.set(xlabel='Nominal longitude (degree)', ylabel='Nominal latitude (degree)',
           title='Input bounding boxes; mixed datums, not precise physical overlap')
    if points:
        ax.legend(fontsize=7)
    fig.savefig(output / 'input.png', dpi=125); plt.close(fig)
    with (output / 'input.csv').open('w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=['longitude','latitude','file']); writer.writeheader(); writer.writerows(points)
    with (output / 'decisions.csv').open('w', newline='') as f:
        writer = csv.writer(f); writer.writerow(['file','check','status','researcher_decision'])
        for r in report['files']:
            for field, c in r['comparisons'].items():
                writer.writerow([r['path'],field,c['status'],c.get('decision','')])


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input', required=True, type=Path)
    p.add_argument('--handoff', required=True, type=Path, help='JSON file manifest with reference path and independent declarations')
    p.add_argument('--output', required=True, type=Path, help='New directory outside input; never overwritten')
    args = p.parse_args()
    if args.output.resolve().is_relative_to(args.input.resolve()):
        p.error('Output must be outside input to preserve originals')
    report = inspect_handoff(args.input, json.loads(args.handoff.read_text()))
    write_outputs(report, args.output)
    print(json.dumps({'files': len(report['files']), 'output': str(args.output), 'normalization': 'not performed'}))

if __name__ == '__main__':
    main()
