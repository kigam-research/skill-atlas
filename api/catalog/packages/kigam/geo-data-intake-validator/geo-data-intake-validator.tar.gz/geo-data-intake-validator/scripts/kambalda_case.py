"""Execute PREDECLARED Kambalda checks; numeric success is not handoff acceptance."""
import argparse
import json
from pathlib import Path

from pyproj.transformer import TransformerGroup
from pyproj import Geod
from shapely.geometry import box

from intake import inspect_handoff, write_outputs, digest, bbox_area, local_path


def execute(input_dir, handoff, plan):
    report = inspect_handoff(input_dir, handoff)
    files = report['files']
    by_path = {r['path']: r for r in files}
    matched = [r for r in files if r.get('capability')]
    manifest = Path(input_dir) / 'MANIFEST.sha256'
    entries = [line.split(maxsplit=1) for line in manifest.read_text().splitlines() if line.strip()]
    valid = sum(digest(local_path(input_dir, name.lstrip('*'))) == sha for sha, name in entries)
    report['manifest'] = {'sha256': digest(manifest), 'entries': len(entries), 'verified': valid}
    ref = by_path[handoff['reference']]
    spacing_error = max(abs(a-b) for r in matched for a,b in zip(r['resolution'], r['capability']['resolution']))
    mask_error = max(abs(b['sentinel_count']-b['mask_count']) for r in files for b in r.get('bands',[]) if b['sentinel_count'] is not None)
    count_errors = [abs(by_path['rasters/'+name+'.tif']['bands'][0]['sentinel_count'] - 347)
                    for name in ['kambalda_k_pctk','kambalda_th_ppm','kambalda_u_ppm']]
    overlap_error = max(abs(bbox_area(r['bounds'], ref['bounds']) - box(*r['bounds']).intersection(box(*ref['bounds'])).area)
                        for r in files if r.get('bounds'))
    gravity = by_path['rasters/kambalda_grav_cscba.tif']
    residual = gravity['comparisons']['alignment']['residual_pixels']
    measured = {
        'manifest': (valid, 21, 0),
        'crs-declarations': (sum(r['declaration_comparisons']['crs']['status']=='agree' for r in matched),6,0),
        'pixel-spacing': (spacing_error,0,1e-12),
        'nodata-declarations': (sum(r['declaration_comparisons']['nodata']['status']=='agree' for r in matched),6,0),
        'mask-counts': (mask_error,0,0),
        'radiometry-counts': (max(count_errors),0,0),
        'bbox-intersection': (overlap_error,0,1e-10),
        'half-cell': (max(abs(v-.5) for v in residual),0,1e-8),
        'variable-units': (sum(r['comparisons']['units']['status']=='unverified' for r in files),9,0),
        'dem-nodata': (int(ref['comparisons']['nodata']['status']=='unverified' and ref['nodata'] is None),1,0),
        'datum-unverified': (sum(r['comparisons']['extent']['status']=='unverified' for r in files),8,0),
    }
    checks = []
    if set(measured) != {c['id'] for c in plan}:
        raise ValueError('Executed ids must equal the frozen check-plan ids')
    for c in plan:
        observed, expected, tolerance = measured[c['id']]
        checks.append({'id':c['id'], 'quantity':{'ko':c['quantity']}, 'observed':observed,
                       'expected':expected, 'tolerance':c['tolerance'],
                       'passed':bool(abs(observed-expected)<=tolerance and (c['id'] != 'manifest' or len(entries) == 21)), 'reference':c['reference']})
    # Inventory available operations without accepting one as scientific truth; no network grids downloaded.
    group = TransformerGroup('EPSG:4283','EPSG:4326',always_xy=True)
    geod = Geod(ellps='WGS84')
    inventory = []
    for transformer in group.transformers:
        x,y = transformer.transform(121.65,-31.25)
        inventory.append({'description':transformer.description,'accuracy_m':transformer.accuracy,
                          'sample_displacement_m':geod.inv(121.65,-31.25,x,y)[2], 'definition':transformer.definition})
    report['datum_operations'] = {'sample':[121.65,-31.25], 'available':inventory,
                                  'unavailable':[op.name for op in group.unavailable_operations],
                                  'accepted_operation':None, 'actual_offset_status':'unverified',
                                  'limit':'No staged independent published datum-offset reference. Computed operation displacement is not actual positional accuracy.'}
    report['checks'] = checks
    report['check_plan_sha256'] = digest(Path(__file__).resolve().parents[1]/'references/kambalda-check-plan.json')
    return report


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',required=True,type=Path)
    p.add_argument('--output',required=True,type=Path)
    args=p.parse_args()
    if args.output.resolve().is_relative_to(args.input.resolve()):
        p.error('Output must be outside input')
    refs=Path(__file__).resolve().parents[1]/'references'
    report=execute(args.input,json.loads((refs/'kambalda-handoff.json').read_text()),json.loads((refs/'kambalda-check-plan.json').read_text()))
    write_outputs(report,args.output)
    (args.output/'checks.json').write_text(json.dumps(report['checks'],indent=2)+'\n')
    print(json.dumps({'files':len(report['files']),'checks':len(report['checks']),'passed':sum(c['passed'] for c in report['checks']),'output':str(args.output)}))
    return 0 if all(c['passed'] for c in report['checks']) else 1

if __name__=='__main__':
    raise SystemExit(main())
