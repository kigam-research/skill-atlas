"""Known-answer fixtures. Offline; no real assets required; normally < 5 seconds."""
import json
from pathlib import Path
import sqlite3
import sys
import tempfile
import unittest

import numpy as np
import rasterio
from rasterio.transform import from_origin

sys.path.insert(0, str(Path(__file__).resolve().parent))
import intake


def raster(path, data, transform=None, nodata=-9999, crs='EPSG:4326'):
    a = np.asarray(data, dtype='float32')
    if a.ndim == 2:
        a = a[None]
    with rasterio.open(path, 'w', driver='GTiff', width=a.shape[2], height=a.shape[1], count=a.shape[0],
                       dtype='float32', crs=crs, transform=transform or from_origin(10, 20, 2, 2), nodata=nodata) as ds:
        ds.write(a)


class IntakeKnownAnswerTests(unittest.TestCase):
    def test_bbox_intersection(self):
        self.assertEqual(intake.bbox_area([0,0,3,2],[2,1,4,3]),1)
        self.assertEqual(intake.bbox_area([0,0,1,1],[1,1,2,2]),0)
        self.assertEqual(intake.bbox_area([0,0,1,1],[3,3,4,4]),0)

    def test_half_cell_resolution_and_rotation(self):
        ref=from_origin(0,10,2,2)
        self.assertEqual(intake.grid_alignment(from_origin(1,9,2,2),ref)['residual_pixels'],[.5,.5])
        self.assertEqual(intake.grid_alignment(from_origin(4,8,2,2),ref)['status'],'agree')
        self.assertEqual(intake.grid_alignment(from_origin(0,10,1,1),ref)['status'],'disagree')
        self.assertEqual(intake.grid_alignment(rasterio.Affine(2,.1,0,0,-2,10),ref)['status'],'unverified')

    def test_absence_is_not_agreement(self):
        self.assertEqual(intake.compare(None,None),'unverified')
        self.assertEqual(intake.compare([1,2],[1,2.01],.001),'disagree')
        self.assertEqual(intake.compare(float('nan'),float('nan')),'agree')
        self.assertEqual(intake.compare(['m',None],['m',None]),'unverified')
        self.assertEqual(intake.compare(['m',None],['m','K']),'unverified')
        self.assertEqual(intake.compare(['m','K'],['m','m']),'disagree')

    def test_raster_all_bands_nodata_and_bounds(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'r.tif'
            raster(p,[[[1,-9999,3],[4,5,6]],[[-9999,-9999,2],[1,2,3]]])
            r=intake.inspect_raster(p)
            self.assertEqual(r['bounds'],[10,16,16,20])
            self.assertEqual(r['shape'],[2,3])
            self.assertEqual([b['sentinel_count'] for b in r['bands']],[1,2])
            self.assertEqual([b['mask_count'] for b in r['bands']],[1,2])
            self.assertEqual(r['crs'],'EPSG:4326')

    def test_absent_nodata_and_nonfinite_are_separate(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'r.tif'; raster(p,[[0,np.nan],[1,2]],nodata=None)
            r=intake.inspect_raster(p)
            self.assertIsNone(r['bands'][0]['sentinel_count'])
            self.assertEqual(r['bands'][0]['nonfinite_count'],1)
            self.assertEqual(r['bands'][0]['mask_count'],0)

    def test_nan_nodata_counts(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'r.tif'; raster(p,[[0,np.nan]],nodata=np.nan)
            r=intake.inspect_raster(p)
            self.assertEqual(r['nodata'],'NaN')
            self.assertEqual(r['bands'][0]['sentinel_count'],1)
            self.assertEqual(r['bands'][0]['mask_count'],1)

    def test_wcs_axis_order_and_missing_unit(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'cap.xml'
            p.write_text('''<root xmlns:g="http://www.opengis.net/gml/3.2" xmlns:s="http://www.opengis.net/swe/2.0"><g:Envelope srsName="http://www.opengis.net/def/crs/EPSG/0/4283" axisLabels="Lat Long"/><g:offsetVector>0 0.2</g:offsetVector><g:offsetVector>-0.1 0</g:offsetVector><s:nilValue>-9</s:nilValue></root>''')
            cap=intake.read_wcs(p)
            self.assertEqual(cap['resolution'],[.2,.1])
            self.assertEqual(cap['crs'],'EPSG:4283')
            self.assertIsNone(cap['units'])
            p.write_text(p.read_text().replace('Lat Long','unknown unknown'))
            self.assertIsNone(intake.read_wcs(p)['resolution'])

    def test_csv_explicit_coordinates_and_unknown_crs(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'xy.csv';p.write_text('east,north\n1,2\n3,4\n,9\nNaN,5\n')
            r=intake.inspect_csv(p,{'coordinate_columns':['east','north']})
            self.assertEqual(r['bounds'],[1,2,3,4]);self.assertEqual(r['invalid_coordinates'],2)
            self.assertIsNone(r['crs'])
            self.assertIsNone(intake.inspect_csv(p,{})['bounds'])

    def test_geojson_measurement_is_not_explicit_crs(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'xy.geojson';p.write_text(json.dumps({'type':'FeatureCollection','features':[{'type':'Feature','geometry':{'type':'Point','coordinates':[2,3]},'properties':{}},{'type':'Feature','geometry':None,'properties':{}}]}))
            r=intake.inspect_geojson(p)
            self.assertEqual(r['bounds'],[2,3,2,3]);self.assertEqual(r['missing_geometry'],1)
            self.assertIsNone(r['crs']);self.assertIn('RFC7946',r['coordinate_assumption'])

    def test_gpkg_headers_remain_layer_declarations(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'x.gpkg'
            with sqlite3.connect(p) as db:
                db.execute('CREATE TABLE gpkg_contents(table_name,data_type,min_x,min_y,max_x,max_y,srs_id)')
                db.execute('CREATE TABLE gpkg_spatial_ref_sys(srs_id,definition)')
                db.execute("INSERT INTO gpkg_contents VALUES('samples','features',1,2,3,4,4326)")
                from pyproj import CRS
                db.execute('INSERT INTO gpkg_spatial_ref_sys VALUES(?,?)',(4326,CRS(4326).to_wkt()))
            r=intake.inspect_gpkg(p)
            self.assertEqual(r['layers'][0]['crs'],'EPSG:4326');self.assertNotIn('bounds',r)

    def test_netcdf_multi_variable_requires_selection(self):
        # Adapter's explicit unsupported branch: no claim to validate an arbitrary CF cube.
        from scipy.io import netcdf_file
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'cube.nc'
            with netcdf_file(p,'w') as nc:
                nc.createDimension('lat',2);nc.createDimension('lon',3)
                for name in ('a','b'):
                    v=nc.createVariable(name,'f',('lat','lon'));v[:]=np.arange(6).reshape(2,3)
            r=intake.inspect_raster(p)
            self.assertEqual(r['kind'],'multidimensional');self.assertEqual(len(r['subdatasets']),2)

    def test_report_preserves_original_and_distinguishes_reference(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);r=root/'ref.tif';g=root/'g.tif'
            raster(r,[[1,2],[3,4]],nodata=None)
            raster(g,[[1,-9999],[3,4]],crs='EPSG:4283')
            before=intake.digest(g)
            report=intake.inspect_handoff(root,{'reference':'ref.tif','nominal_lonlat':True,'files':[{'path':'ref.tif'},{'path':'g.tif','declared':{'crs':'EPSG:4283','nodata':-9999}}]})
            other=report['files'][1]
            self.assertEqual(other['declaration_comparisons']['crs']['status'],'agree')
            self.assertEqual(other['comparisons']['crs']['status'],'disagree')
            self.assertEqual(other['comparisons']['extent']['status'],'unverified')
            self.assertEqual(other['comparisons']['units']['status'],'unverified')
            self.assertEqual(intake.digest(g),before)
            intake.write_outputs(report,root/'out')
            self.assertTrue((root/'out/after.png').is_file())
            with self.assertRaises(FileExistsError):intake.write_outputs(report,root/'out')

    def test_declared_conflict_cannot_be_overwritten_by_self_reference(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); raster(root/'r.tif',[[1,2],[3,4]])
            with rasterio.open(root/'r.tif','r+') as ds: ds.set_band_unit(1,'m')
            report=intake.inspect_handoff(root,{'reference':'r.tif','files':[{'path':'r.tif','declared':{'crs':'EPSG:4283','resolution':[1,1],'units':'m','nodata':-9999}}]})
            r=report['files'][0]
            self.assertEqual(r['comparisons']['crs']['status'],'disagree')
            self.assertEqual(r['comparisons']['resolution']['status'],'disagree')
            self.assertEqual(r['status'],'disagree')

    def test_multiband_units_and_nodata_apply_to_every_band(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); raster(root/'r.tif',[[[1,2]],[[3,4]]])
            with rasterio.open(root/'r.tif','r+') as ds:
                ds.set_band_unit(1,'m'); ds.set_band_unit(2,'K')
            manifest={'reference':'r.tif','files':[{'path':'r.tif','declared':{'crs':'EPSG:4326','resolution':[2,2],'units':'m','nodata':-9999}}]}
            r=intake.inspect_handoff(root,manifest)['files'][0]
            self.assertEqual(r['comparisons']['units']['status'],'disagree')
            self.assertEqual(r['status'],'disagree')
            manifest['files'][0]['declared']['units']=['m','K']
            self.assertEqual(intake.inspect_handoff(root,manifest)['files'][0]['comparisons']['units']['status'],'agree')

    def test_point_extent_intersection_is_not_positive_area(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); raster(root/'ref.tif',[[1,2],[3,4]],transform=from_origin(0,2,1,1))
            (root/'p.geojson').write_text(json.dumps({'type':'FeatureCollection','crs':{'type':'name','properties':{'name':'EPSG:4326'}},'features':[{'type':'Feature','geometry':{'type':'Point','coordinates':[1,1]},'properties':{}}]}))
            report=intake.inspect_handoff(root,{'reference':'ref.tif','files':[{'path':'ref.tif'},{'path':'p.geojson'}]})
            extent=report['files'][1]['comparisons']['extent']
            self.assertEqual(extent['intersection_coordinate_area'],0)
            self.assertEqual(extent['status'],'agree')
            self.assertTrue(extent['nonempty_coordinate_intersection'])

    def test_input_path_confinement_and_unreadable_file(self):
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(ValueError):intake.local_path(d,'../other')
            r=intake.inspect_handoff(d,{'reference':'absent.tif','files':[{'path':'absent.tif'}]})
            self.assertEqual(r['files'][0]['kind'],'unreadable')
            self.assertEqual(r['files'][0]['status'],'unverified')

if __name__=='__main__':
    unittest.main()
