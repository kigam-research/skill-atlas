# Kola case provenance and accepted limits

Input: `kola_chorizon`, `~/assets/kola-chorizon/ce75a18b/`; manifest sha256 `3ed2191fe4c3960df8041ad1f9471739c15de5f0c80c21221a3707145f648cf6`.

- robCompositions 2.6.0, CRAN mirror commit `ce75a18b43558a0d44bac105b84bbce846ac6081`: https://github.com/cran/robCompositions/tree/ce75a18b43558a0d44bac105b84bbce846ac6081
- StatDA 1.7.11, CRAN mirror commit `828bc95cda80edd448192fea1239e5d5e61982fd`: https://github.com/cran/StatDA/tree/828bc95cda80edd448192fea1239e5d5e61982fd
- Reimann C. et al. (1998), *Environmental Geochemical Atlas of the Central Barents Region*, NGU-GTK-CKE Special Publication, Geological Survey of Norway, Trondheim. Survey 1993-1998, C-horizon soil, NW Russia/N Finland/N Norway. This task did not fetch or inspect the atlas body; no numerical atlas median is claimed.

Read local `robCompositions/man/chorizonDL.Rd`: individual variable units and zero/DL convention. `DATA-LICENSE.md` supplies analytical-method mapping: no suffix aqua-regia ICP; `_XRF` total XRF; `_INAA` INAA. Non-concentration variables are excluded. Raw R `DL` attribute has 54 entries including pH and LOI, not 54 eligible elemental components.

Preflight revealed actual StatDA binary has 605 rows although its Rd says 606. ID81 is absent for an undocumented reason. The 605 common unique IDs must be joined, not compared by row index. Ten XRF columns have robCompositions wt% vs StatDA apparent mg/kg (×10000 gives agreement). StatDA YCOO is rounded to 10000 m; XCOO matches exactly. Preserve the more precise chorizonDL coordinates; the second packaging is not independent spatial truth. Censored positive half-DL values in StatDA match rounded zeros in chorizonDL for these data; do not infer censoring from half-DL equality in other tables.

Selected subset: As,Cd,Co,Cu,Ni,Pb,Zn, all aqua-regia mg/kg. This choice avoids duplicate methods and exercises low-share As censoring; it is illustrative, not an optimized exploration suite. DL-fraction multiplicative replacement preserves observed selected subtotals, not true geological mass. Robust PCA: MCD covariance, seed17, ilr basis; arrows are directions only. Ni classes use original observed Ni, not rescaled replacement values. Background is all C-horizon samples, which may mix geology and anthropogenic influence; no expert has endorsed that population or threshold.

No staged documentation identifies a named CRS. Coordinates remain projected metres, CRS unverified. The Atlas regional anchor [30,68.5] is approximate and is NOT calculated by transforming XCOO/YCOO. It indicates the central Barents case region only; do not overlay external layers or compute spatial distances until CRS is confirmed.

## Rights notice

The following wording is copied from staged DATA-LICENSE.md:

> robCompositions (GPL (>= 2))
>
> StatDA (GPL (>= 3))

Derived Kola tables/figures: `GPL-2.0-or-later (robCompositions data)` / `GPL-3.0-or-later (StatDA data)` for cross-packaging audits. Cite Reimann et al. (1998), robCompositions and StatDA with every copy. MIT applies to new skill text/code only, not the data. Original package notices are retained in the staged immutable asset; no raw dataset is redistributed in this skill.
