# Generic CSV metadata contract

CSV: UTF-8, one row per unique sample, `.` decimal, ID and selected elemental concentration columns. Missing analyte cells stop the helper. Spatial x/y are optional, never transformed implicitly. JSON example:

```json
{
  "medium": "C-horizon soil",
  "id": "sample",
  "x": "easting",
  "y": "northing",
  "crs": "unknown projected metres",
  "anomaly_element": "Ni",
  "analytes": {
    "Ni": {"element": "Ni", "method": "aqua-regia ICP", "unit": "mg/kg", "dl": 0.5, "zero_is_censored": true},
    "Cu": {"element": "Cu", "method": "aqua-regia ICP", "unit": "mg/kg", "dl": 0.2},
    "Zn": {"element": "Zn", "method": "aqua-regia ICP", "unit": "mg/kg", "dl": 0.5}
  }
}
```

At least three distinct elements; mapping insertion order sets the Helmert basis and default first three ternary components. Optional `ternary_components` selects exactly three distinct selected columns (Kola uses Co,Cu,Ni). All selected units must be elemental `mg/kg` or `wt%`, `basis: element` (default). Metadata DL is in that column's native unit. `<number` supplies a per-cell limit; `<DL` uses the declared column limit. Negative flags require `negative_is_censored: true`; their magnitude is not silently taken as a DL. Positive substitutions require `censor_flag: <column>` with 0/1 or true/false; flags override their displayed value. Zeros require `zero_is_censored: true`; true structural zeros are unsupported by a log-ratio model.

Optional `closed_total_mgkg` and `closure_tolerance_mgkg` declare a complete analysis closure; otherwise the selected subtotal is only audited against the physical upper bound. Do not set full closure for a trace-element subset. Censored full totals need interval reasoning before this helper.

Default replacement fraction 0.5 is an explicit exploratory assumption. The runner writes fractions 0.25 and 0.75 sensitivity in clr units. The script rejects mixed duplicate methods by element, nonfinite values, missing ID, impossible mass, replacement exhaustion and rank/sample-size failures. It does not infer methods, missingness, CRS, or background strata. Set `coordinate_unit` for supplied x/y; it defaults to dimensionless/unspecified `-`. CRS and column names appear on the matplotlib map; no spatial transformation is performed.
