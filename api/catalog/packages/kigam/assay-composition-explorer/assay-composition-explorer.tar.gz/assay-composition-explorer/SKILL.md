---
name: assay-composition-explorer
description: Explore multi-element assays with explicit units, analytical methods and detection limits, censor audits, clr/ilr geometry, robust PCA, reference-normalized spiders and exploratory anomaly maps. Use for soil, sediment or rock assay exploration, not resource estimation or regulatory classification.
license: MIT
metadata:
  version: "0.1.0"
---

# Assay composition explorer

Use when an investigator has multi-element assays and needs a defensible exploratory view. The objective is judgment for the supplied medium and methods, not reproducing Kola. Read `references/metadata.md` for the input contract and `references/kola-provenance.md` for the worked case.

## 1. Establish what the numbers mean

Identify sample ID, medium/horizon, spatial support, laboratory, batch, digestion, units and DL per analyte. Separate missing values, true structural zeros, rounded below-DL zeros, negative flags, `<DL`/`<number`, and positive half-DL substitutions. A half-DL-sized positive number is not by itself proof of censoring. Keep the original table, flags and reporting-limit metadata. Count and report censored and missing values per element before transformation.

Convert elemental wt% to mg/kg by 10000. Do not confuse elemental concentrations with oxides; an oxide-to-element conversion needs its own stoichiometric specification. Do not sum mass and non-mass variables (pH, coordinates, LOI) as a composition. Check impossible mass totals above 1e6 mg/kg, the intended closure and denominator. A selected trace-element subcomposition is not a full 100% rock analysis; closing it changes scale, not the information lost by omitting elements.

Treat aqua-regia/partial digestion, XRF total and INAA as separate measurement methods. For duplicated elements, present recovery/method contrasts first and choose one column per element for PCA. Never average methods silently or include both as independent components. Batch and medium differences may dominate an apparent anomaly; stratify or restrict the background before interpreting.

## 2. Decide censor handling explicitly

- Preserve censored values as intervals when estimating concentrations is not needed. Report distributions with censoring-aware methods; do not pass zero to log.
- For a low-censoring exploratory subset, the helper implements DL-fraction multiplicative replacement. It inserts DL/2 by default and rescales uncensored parts proportionally to preserve each row's observed sub-sum. This preserves uncensored ratios; it does **not** estimate the true total or recover absolute concentrations.
- Compare fractions 0.25/0.5/0.75 and reconsider any interpretation that changes materially. For heavy or structured censoring, reduce the subset or use a justified multivariate censored model (e.g. lrEM with a documented implementation and diagnostics). The helper does **not** implement lrEM; do not label it as such.
- Entirely censored selected elements, all-censored rows, exhausted replacement mass, missing data, nonpositive unflagged values or unavailable DL stop the helper. Resolve them explicitly, not with an arbitrary epsilon. If all of an element is censored or MAD is zero, report that no useful estimate/threshold exists and choose a different analysis with the investigator.

## 3. Analyze ratios, not closure-induced correlations

Use clr = ln(x) - mean(ln(x)) and orthonormal Helmert ilr. Verify clr rows sum to zero and ilr distances equal clr distances. Never use plain Pearson correlation of closed concentrations as association evidence. clr covariance is singular; robust PCA here uses MinCovDet in the D-1 dimensional ilr space, then maps directions back to clr. It requires full rank and n >= 5(D-1); this pragmatic guard is not a statistical guarantee. Reduce dimensions or retain descriptive summaries if it fails. No marginal variance scaling is applied. Inspect robust support, loadings, omitted variance and high-leverage samples. The biplot arrows are clr directions multiplied by a display factor (2.5), not absolute concentration vectors or calibrated distances.

The helper reports observed and replaced medians and censor shares. Use sample-level clr tables for additional robust quantiles or log-ratio associations. Interpret biplot directions as ratios relative to the chosen subset; conclusions can change when the subset changes. Do not call high loadings mineralization without geological evidence.

## 4. Show patterns and exploratory anomaly classes

A spider needs an explicit reference for each element, medium, method and unit. The Kola example uses the all-sample replaced median for each element and displays class-wise median/reference profiles. This is survey-internal normalization, **not** upper crust, pristine background or a published reference composition. Save the numerical reference table. External reference compositions require their own exact citation and compatibility check.

Choose the target, background population and threshold rule before looking at the map. The helper uses ln(observed target mg/kg) > median + 2 **unscaled** MAD (strict >). This is a heuristic, not a 2-sigma limit, p-value or contamination standard. Censored target values are explicitly unclassified, not background. Tukey fences on an appropriate log population are an alternative; never switch rules to obtain a desired anomaly count. Raw ternary rows with zero selected three-part subtotal are undefined, counted in the analysis record and figure subtitle, and not plotted; never turn them into a fake composition. Map sample points by class; interpolation or regional validity does not follow. If CRS is unknown, retain source projected coordinates, label it unknown and use only an explicitly approximate regional Atlas anchor. Do not assign an EPSG from coordinate magnitude alone.

## 5. Run offline and verify

From a checkout with the declared numpy/pandas/scipy/matplotlib/scikit-learn/rdata environment:

```bash
uv run python skills/assay-composition-explorer/scripts/explore.py \
  --input /path/to/assays.csv --metadata /path/to/metadata.json --output /path/to/output
uv run python skills/assay-composition-explorer/scripts/selftest.py
```

The bundled adapter accepts the already-staged `kola_chorizon` input directory instead of CSV. In this repository, keep a recorded run with:

```bash
task job run --input assets:kola-chorizon/ce75a18b -- \
  uv run python skills/assay-composition-explorer/scripts/run_kola.py \
  --input /home/seongin3/assets/kola-chorizon/ce75a18b
```

`--output` defaults to `TASK_OUTPUT_DIR` in a recorded job. The script never downloads data. It writes CSVs, PNGs, an analysis/metadata record and sensitivity/check JSON. The Kola adapter reads raw R attributes before conversion because dataframe conversion drops the DL attribute. Preserve input hashes, code revision, parameters, all failed checks and data rights. Cross-packaging agreement tests software/data consistency, not field accuracy.

## 6. Handoff and researcher decisions

Report selected elements/methods and why; unit/closure and censor audits; replacement and sensitivity; robust PCA basis/support/eigenvalues; exact spider reference; threshold/background/counts; spatial uncertainty; and what remains untested. Ask the investigator to settle the element subset, replacement/model choice, duplicate-method choice and background population when not already specified. Geological explanation, representativeness, coordinates and any use for decision-making require a domain expert. The Kola case is n=1 and has **not** had domain-expert review. Do not claim economic, regulatory or regional predictive validity.
