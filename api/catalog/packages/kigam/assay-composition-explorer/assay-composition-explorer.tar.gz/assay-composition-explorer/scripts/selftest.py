"""Offline smoke test with analytical known answers; no assets/network."""
import numpy as np
from explore import replace_censored, logratios, anomaly
x = np.array([[0., 4., 6.]])
filled = replace_censored(x, np.ones_like(x)*2, x == 0)
np.testing.assert_allclose(filled, [[1., 3.6, 5.4]])
clr, ilr, basis = logratios([[1., 2., 4.], [2., 2., 2.]])
np.testing.assert_allclose(clr[0], [-np.log(2), 0., np.log(2)], atol=1e-12)
np.testing.assert_allclose(np.linalg.norm(clr[0]-clr[1]), np.linalg.norm(ilr[0]-ilr[1]), atol=1e-12)
assert anomaly(np.exp([-2., -1., 0., 1., 5.]))[0].tolist() == [False]*4+[True]
print('assay composition selftest: analytical fixtures passed')
