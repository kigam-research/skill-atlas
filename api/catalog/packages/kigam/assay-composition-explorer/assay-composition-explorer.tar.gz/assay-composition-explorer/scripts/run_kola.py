"""Recorded-run entry point: explore, sensitivity, independent checks."""
import argparse
import os
from pathlib import Path
import json
import numpy as np
from explore import analyze, load_kola, parse_assays, replace_censored, logratios
from verify_kola import verify

parser = argparse.ArgumentParser()
parser.add_argument('--input', type=Path, required=True)
parser.add_argument('--output', type=Path, default=os.environ.get('TASK_OUTPUT_DIR'), required=not bool(os.environ.get('TASK_OUTPUT_DIR')))
a = parser.parse_args()
frame, metadata, _ = load_kola(a.input)
report = analyze(frame, metadata, a.output)
x, dl, mask = parse_assays(frame, metadata)
base, _, _ = logratios(replace_censored(x, dl, mask, .5))
sensitivity = {}
for fraction in (.25, .75):
    clr, _, _ = logratios(replace_censored(x, dl, mask, fraction))
    sensitivity[str(fraction)] = {'max_clr_shift': float(abs(clr-base).max()), 'rms_clr_shift': float(np.sqrt(np.mean((clr-base)**2)))}
(a.output / 'sensitivity.json').write_text(json.dumps(sensitivity, indent=2)+'\n')
result = verify(a.input, a.output)
raise SystemExit(0 if result['passed'] else 1)
