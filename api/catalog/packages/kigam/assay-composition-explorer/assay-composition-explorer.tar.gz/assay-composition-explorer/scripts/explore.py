"""Offline compositional exploration. MIT code; input data retain their own rights."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.linalg import helmert
from scipy.spatial.distance import pdist
from sklearn.covariance import MinCovDet


def parse_assays(frame, metadata):
    """Normalize declared elemental mass units; retain censor mask and limits.

    No automatic negative or half-DL inference. <number is a per-cell upper bound.
    Missing values are rejected, not turned into zero. Metadata explicitly identifies
    positive half-DL substitutions using a flag column.
    """
    if not metadata.get('medium'):
        raise ValueError('medium must be declared')
    columns = metadata['analytes']
    if len(columns) < 3 or len(set(columns)) != len(columns):
        raise ValueError('select at least three unique analyte columns')
    x = np.zeros((len(frame), len(columns)))
    limits = np.zeros_like(x)
    mask = np.zeros_like(x, dtype=bool)
    methods = {}
    for j, (name, spec) in enumerate(columns.items()):
        if spec['unit'] not in ('mg/kg', 'wt%') or not spec.get('method') or not spec.get('element'):
            raise ValueError(f'{name}: explicit elemental unit, method and element required')
        if spec.get('basis', 'element') != 'element':
            raise ValueError('oxide conversion requires a separately justified stoichiometric preprocessing step')
        element = spec['element']
        if element in methods:
            raise ValueError(f'duplicate element {element}: choose one method, do not double-count')
        methods[element] = spec['method']
        factor = 10000.0 if spec['unit'] == 'wt%' else 1.0
        dl = float(spec.get('dl', 0))
        if not np.isfinite(dl) or dl < 0:
            raise ValueError('DL must be finite and non-negative')
        for i, raw in enumerate(frame[name]):
            text = str(raw).strip()
            censored = text.startswith('<')
            bound = dl
            if censored:
                suffix = text[1:].strip()
                bound = dl if suffix.upper() == 'DL' else float(suffix)
                value = 0.0
            else:
                value = float(raw)
                censored = (value == 0 and spec.get('zero_is_censored', False)) or (value < 0 and spec.get('negative_is_censored', False))
            if spec.get('censor_flag'):
                flag = frame[spec['censor_flag']].iloc[i]
                if str(flag).strip().lower() not in ('0', '1', 'false', 'true'):
                    raise ValueError('censor flags must be 0/1 or true/false')
                censored |= str(flag).strip().lower() in ('1', 'true')
            if not np.isfinite(value) or not np.isfinite(bound) or (censored and bound <= 0) or (not censored and value <= 0):
                raise ValueError(f'{name} row {i}: missing/nonpositive value or absent positive DL')
            x[i, j] = 0.0 if censored else value * factor
            limits[i, j] = bound * factor
            mask[i, j] = censored
    if np.any(mask.all(axis=0)):
        raise ValueError('entirely censored selected element; reconsider subset/model with investigator')
    if np.any(x.sum(axis=1) > 1e6):
        raise ValueError('selected elemental mass exceeds 1e6 mg/kg; check units/duplicate analytes')
    if metadata.get('closed_total_mgkg') is not None:
        if not np.allclose(x.sum(axis=1), metadata['closed_total_mgkg'], rtol=0, atol=metadata.get('closure_tolerance_mgkg', 1)):
            raise ValueError('declared full closure not met; censored totals need explicit interval treatment')
    return x, limits, mask


def replace_censored(x, limits, mask, fraction=0.5):
    """DL*fraction multiplicative replacement preserving each observed sub-sum.

    This is an exploratory replacement, NOT lrEM or recovered true concentrations.
    Ratios among uncensored parts are preserved. Limit fractions cannot exhaust mass.
    """
    x, limits, mask = np.asarray(x, float), np.asarray(limits, float), np.asarray(mask, bool)
    if x.shape != mask.shape or x.shape != limits.shape or x.ndim != 2:
        raise ValueError('matching 2D arrays required')
    if not 0 < fraction < 1 or not np.isfinite(x).all() or not np.isfinite(limits).all():
        raise ValueError('finite arrays and fraction in (0,1) required')
    if np.any(x[~mask] <= 0) or np.any(limits[mask] <= 0):
        raise ValueError('positive observed concentrations and censored limits required')
    observed = np.where(mask, 0.0, x)
    total = observed.sum(axis=1, keepdims=True)
    replacement = np.where(mask, fraction * limits, 0.0)
    mass = replacement.sum(axis=1, keepdims=True)
    if np.any(total <= mass):
        raise ValueError('replacement exhausts observed sub-sum; revise subset/model, never silently clip')
    return replacement + observed * (total - mass) / total


def logratios(x):
    x = np.asarray(x, float)
    if x.ndim != 2 or not np.isfinite(x).all() or np.any(x <= 0) or x.shape[1] < 3:
        raise ValueError('finite positive composition with >=3 parts required')
    logs = np.log(x)
    clr = logs - logs.mean(axis=1, keepdims=True)
    basis = helmert(x.shape[1], full=False).T
    return clr, clr @ basis, basis


def robust_pca(ilr, basis):
    """MCD covariance PCA in nonsingular ilr space, no marginal rescaling."""
    if len(ilr) < 5 * ilr.shape[1] or np.linalg.matrix_rank(ilr - ilr.mean(axis=0)) < ilr.shape[1]:
        raise ValueError('MCD needs full rank and n >= 5*(D-1); reduce subset or use descriptive view')
    fit = MinCovDet(random_state=17).fit(ilr)
    values, vectors = np.linalg.eigh(fit.covariance_)
    order = np.argsort(values)[::-1]
    values, vectors = values[order], vectors[:, order]
    # Stable display orientation: largest absolute clr loading points positive.
    for j in range(vectors.shape[1]):
        v = basis @ vectors[:, j]
        if v[np.argmax(abs(v))] < 0:
            vectors[:, j] *= -1
    return (ilr - fit.location_) @ vectors, basis @ vectors, values, fit.support_


def anomaly(values):
    logs = np.log(values)
    med = np.median(logs)
    mad = np.median(abs(logs - med))
    if mad <= 0:
        raise ValueError('zero MAD: choose an explicitly justified alternative; no silent epsilon')
    threshold = med + 2 * mad
    return logs > threshold, float(threshold), float(mad)


def analyze(frame, metadata, output, fraction=0.5):
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    names = list(metadata['analytes'])
    x, limits, mask = parse_assays(frame, metadata)
    filled = replace_censored(x, limits, mask, fraction)
    clr, ilr, basis = logratios(filled)
    scores, loadings, eigenvalues, support = robust_pca(ilr, basis)
    target = metadata['anomaly_element']
    j = names.index(target)
    # Anomaly classification uses observed absolute target concentration, not adjusted
    # mass. A censored target is explicitly unclassified (never called background).
    valid = ~mask[:, j]
    high, threshold, mad = anomaly(x[valid, j])
    classes = np.full(len(x), 'censored-target', dtype=object)
    classes[valid] = np.where(high, 'high-Ni' if target == 'Ni' else f'high-{target}', 'below-threshold')
    ids = frame[metadata['id']].astype(str)
    summary = pd.DataFrame({'element': names, 'censored': mask.sum(axis=0), 'censored_share': mask.mean(axis=0), 'median_observed_mgkg': [np.median(x[~mask[:, k], k]) if (~mask[:, k]).any() else np.nan for k in range(len(names))], 'median_replaced_mgkg': np.median(filled, axis=0)})
    summary.to_csv(output / 'summary.csv', index=False)
    raw = pd.DataFrame(x, columns=names).assign(sample=ids.to_numpy(), group=classes)
    raw.to_csv(output / 'raw.csv', index=False)
    pd.DataFrame(filled, columns=names).assign(sample=ids.to_numpy()).to_csv(output / 'replaced.csv', index=False)
    pd.DataFrame(clr, columns=names).assign(sample=ids.to_numpy()).to_csv(output / 'clr.csv', index=False)
    pd.DataFrame({'sample': ids, 'PC1': scores[:, 0], 'PC2': scores[:, 1], 'group': classes, 'mcd_support': support.astype(int)}).to_csv(output / 'scores.csv', index=False)
    pd.DataFrame(loadings[:, :2], index=names, columns=['PC1', 'PC2']).rename_axis('element').to_csv(output / 'loadings.csv')
    reference = np.median(filled, axis=0)
    pd.DataFrame({'element': names, 'reference_mgkg': reference}).to_csv(output / 'spider-reference.csv', index=False)
    # Full 606 lines obscure structure: show class-wise median profiles, declared explicitly.
    spider = pd.DataFrame([dict(zip(names, np.median(filled[classes == group], axis=0) / reference), group=group) for group in sorted(set(classes))])
    spider.to_csv(output / 'spider.csv', index=False)
    if metadata.get('x') and metadata.get('y'):
        locations = pd.DataFrame({'sample': ids, 'x': frame[metadata['x']], 'y': frame[metadata['y']], 'group': classes})
        locations.to_csv(output / 'points.csv', index=False)
    colors = {'below-threshold': '#287b9b', f'high-{target}': '#cc572d', 'censored-target': '#777777'}
    plt.rcParams.update({'font.size': 10, 'axes.spines.top': False, 'axes.spines.right': False})
    def save(fig, name):
        fig.tight_layout()
        fig.savefig(output / name, dpi=125)
        plt.close(fig)
    fig, ax = plt.subplots(figsize=(7, 5))
    for group in sorted(set(classes)):
        ix = classes == group
        ax.scatter(scores[ix, 0], scores[ix, 1], s=13, alpha=.65, label=f'{group} (n={ix.sum()})', color=colors[group])
    arrow_scale = 2.5
    for label_index, (name, loading) in enumerate(zip(names, loadings)):
        v = loading[:2] * arrow_scale
        ax.annotate('', xy=v, xytext=(0, 0), arrowprops={'arrowstyle': '->', 'color': '#363636'})
        ax.annotate(name, xy=v, xytext=(4, 4 + (label_index % 3) * 7), textcoords='offset points', fontsize=9)
    ax.set(xlabel='Robust PC1 (log-ratio)', ylabel='Robust PC2 (log-ratio)', title='MCD-PCA in ilr space | exploratory biplot')
    ax.legend(fontsize=8)
    fig.text(.02, .01, 'Arrows: clr directions ×2.5 (display only); scores: all samples', fontsize=8)
    save(fig, 'biplot.png')
    fig, ax = plt.subplots(figsize=(7, 5))
    ternary_names = metadata.get('ternary_components', names[:3])
    if len(ternary_names) != 3 or len(set(ternary_names)) != 3:
        raise ValueError('ternary_components requires three distinct selected columns')
    tri = x[:, [names.index(n) for n in ternary_names]]
    ternary_defined = tri.sum(axis=1) > 0
    ternary_undefined_n = int((~ternary_defined).sum())
    tri = np.divide(tri, tri.sum(axis=1, keepdims=True), out=np.full_like(tri, np.nan), where=ternary_defined[:, None])
    tx, ty = tri[:, 1] + .5 * tri[:, 2], np.sqrt(3) / 2 * tri[:, 2]
    ax.plot([0, 1, .5, 0], [0, 0, np.sqrt(3)/2, 0], color='#555555')
    for group in sorted(set(classes)):
        ix = classes == group
        ax.scatter(tx[ix], ty[ix], s=13, alpha=.65, label=group, color=colors[group])
    for xx, yy, label in [(0, -.04, ternary_names[0]), (1, -.04, ternary_names[1]), (.5, .89, ternary_names[2])]:
        ax.text(xx, yy, label, ha='center')
    ax.set(title='Before: raw three-part closure to 100%\nCensored parts plotted at recorded zero; not absence\n' + f'Undefined raw three-part subtotal: {ternary_undefined_n} samples (not plotted)', aspect='equal')
    ax.set_title(ax.get_title(), pad=28)
    ax.axis('off'); ax.legend(loc='upper right', fontsize=8)
    save(fig, 'raw-ternary.png')
    fig, ax = plt.subplots(figsize=(7, 4.5))
    for _, row in spider.iterrows():
        ax.plot(names, row[names].astype(float), marker='o', label=row['group'], color=colors[row['group']])
    ax.axhline(1, color='#666666', ls='--', lw=.8)
    ax.set(yscale='log', ylabel='Class median / all-sample replaced median (-)', title='Spider: survey-internal reference, not crustal background')
    ax.legend(fontsize=8); save(fig, 'spider.png')
    if metadata.get('x') and metadata.get('y'):
        fig, ax = plt.subplots(figsize=(7, 5))
        for group in sorted(set(classes)):
            ix = classes == group
            ax.scatter(locations.loc[ix, 'x'], locations.loc[ix, 'y'], s=16, alpha=.7, label=f'{group} (n={ix.sum()})', color=colors[group])
        unit = metadata.get('coordinate_unit', '-')
        ax.set(xlabel=f"{metadata['x']} ({unit})", ylabel=f"{metadata['y']} ({unit})", title='Sample classes | ' + metadata.get('crs', 'CRS unverified'), aspect='equal')
        ax.legend(fontsize=8); save(fig, 'map.png')
    fig, ax = plt.subplots(figsize=(7, 3))
    ax.axis('off')
    ax.table(cellText=frame[[metadata['id']] + names].head(6).round(4).values, colLabels=[metadata['id']] + names, loc='center')
    ax.set_title('Input preview: first six samples, native units\nMedium: ' + metadata['medium'])
    save(fig, 'input-preview.png')
    report = {'n': len(x), 'ternary_undefined_n': ternary_undefined_n, 'elements': names, 'medium': metadata['medium'], 'metadata': metadata,
              'replacement': {'method': 'DL-fraction multiplicative, preserves observed sub-sum', 'fraction': fraction, 'censored_counts': dict(zip(names, mask.sum(axis=0).tolist()))},
              'threshold': {'element': target, 'rule': 'ln(observed concentration)>median+2*unscaled MAD', 'log_value': threshold, 'mgkg': float(np.exp(threshold)), 'MAD_log': mad, 'counts': {g: int((classes == g).sum()) for g in sorted(set(classes))}},
              'pca': {'method': 'MinCovDet covariance in ilr, seed=17', 'support_n': int(support.sum()), 'eigenvalues': eigenvalues.tolist()},
              'checks': {'clr-zero': float(abs(clr.sum(axis=1)).max()), 'ilr-isometry': float(abs(pdist(clr) - pdist(ilr)).max()), 'closure': float(abs(filled.sum(axis=1) - x.sum(axis=1)).max())}}
    (output / 'analysis.json').write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n')
    return report


def load_kola(path):
    import rdata
    path = Path(path)
    parsed = rdata.parser.parse_file(path / 'robCompositions/data/chorizonDL.rda')
    # Conversion of the dataframe drops arbitrary R attributes. Read DL BEFORE conversion.
    attrs = rdata.conversion.convert(parsed.object.value[0].attributes)
    dl = attrs['DL']
    limits = dict(zip(dl.coords['dim_0'].values.tolist(), dl.values.tolist()))
    frame = rdata.conversion.convert(parsed)['chorizonDL']
    names = ['As', 'Cd', 'Co', 'Cu', 'Ni', 'Pb', 'Zn']
    metadata = {'medium': 'C-horizon soil; Kola Project 1993-1998', 'id': '*ID', 'x': 'XCOO', 'y': 'YCOO', 'crs': 'source projected metres; CRS unverified', 'coordinate_unit': 'm', 'anomaly_element': 'Ni', 'ternary_components': ['Co', 'Cu', 'Ni'], 'analytes': {n: {'element': n, 'unit': 'mg/kg', 'method': 'aqua-regia ICP', 'dl': limits[n], 'zero_is_censored': True} for n in names}}
    return frame, metadata, limits


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, required=True, help='named input directory (Kola) or CSV path')
    parser.add_argument('--metadata', type=Path, help='required for generic CSV; see references/metadata.md')
    parser.add_argument('--output', type=Path, default=os.environ.get('TASK_OUTPUT_DIR'), required=not bool(os.environ.get('TASK_OUTPUT_DIR')))
    parser.add_argument('--fraction', type=float, default=.5)
    args = parser.parse_args()
    if args.input.is_dir():
        frame, metadata, _ = load_kola(args.input)
    else:
        if args.metadata is None:
            parser.error('CSV input requires --metadata')
        frame = pd.read_csv(args.input)
        metadata = json.loads(args.metadata.read_text())
    if frame[metadata['id']].isna().any() or not frame[metadata['id']].is_unique:
        raise ValueError('sample IDs must be present and unique')
    report = analyze(frame, metadata, args.output, args.fraction)
    print(json.dumps({'n': report['n'], 'threshold': report['threshold'], 'checks': report['checks']}))


if __name__ == '__main__':
    main()
