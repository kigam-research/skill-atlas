"""Predeclared cross-packaging and analytical checks; no external service."""
import argparse
import json
from pathlib import Path

import numpy as np
import rdata
from explore import load_kola


def verify(source, output):
    frame, _, limits = load_kola(source)
    reference = rdata.conversion.convert(rdata.parser.parse_file(Path(source) / 'StatDA/data/chorizon.rda'))['chorizon']
    a, b = frame.set_index('*ID'), reference.set_index('ID')
    common = a.index.intersection(b.index)
    a, b = a.loc[common], b.loc[common]
    records = []
    def check(id, quantity, observed, expected, passed, tolerance, ref):
        records.append(dict(id=id, quantity=quantity, observed=observed, expected=expected, passed=bool(passed), tolerance=tolerance, reference=ref))
    observed = f'{len(frame)}/{len(reference)}/{len(common)}; DL-only IDs=' + ','.join(map(lambda v: str(int(v)), frame.set_index('*ID').index.difference(reference.ID)))
    check('sample-alignment', 'DL/StatDA/common sample counts and missing IDs', observed, '606/605/605; DL-only IDs=81', observed == '606/605/605; DL-only IDs=81' and frame['*ID'].is_unique and reference.ID.is_unique, 'exact', 'Two staged R binaries, aligned on unique ID, not row position')
    coordinate_error = max(float(abs(a.XCOO-b.XCOO).max()), float(abs(np.round(a.YCOO/10000)*10000-b.YCOO).max()))
    check('coordinate-packaging', 'X exact; StatDA Y rounded to 10000 m', coordinate_error, 0, coordinate_error == 0, '0 m', 'Observed packaging relationship; NOT a CRS validation')
    mismatches, maximum = 0, 0.0
    censor_rows = []
    for name, dl in limits.items():
        zero = a[name].to_numpy() == 0
        factor = 10000 if name.endswith('_XRF') else 1
        av, bv = a[name].to_numpy() * factor, b[name].to_numpy()
        half = bv == dl * factor / 2
        mismatches += int(np.count_nonzero(zero != half))
        if (~zero).any():
            maximum = max(maximum, float(abs(av[~zero] - bv[~zero]).max()))
        censor_rows.append({'element': name, 'DL_native': dl, 'unit': 'wt%' if factor == 10000 else 'mg/kg' if name not in ('pH', 'LOI') else '-' if name == 'pH' else 'wt%', 'DL606_zero_count': int((frame[name] == 0).sum()), 'DL605_zero_count': int(zero.sum()), 'StatDA605_halfDL_count': int(half.sum())})
    check('censor-agreement', 'Zero vs half-DL mask mismatches on 605 common IDs', mismatches, 0, mismatches == 0, 'exact', 'StatDA half-DL values independently compared with robCompositions raw DL attributes; includes 54 DL-bearing fields')
    check('observed-agreement', 'Maximum noncensored concentration difference after XRF conversion', maximum, 0, maximum <= 1e-9, 'absolute 1e-9 in harmonized units', 'StatDA chorizon; robCompositions _XRF wt% multiplied by 10000; all other fields unchanged')
    pd = __import__('pandas')
    pd.DataFrame(censor_rows).to_csv(Path(output) / 'censor-audit.csv', index=False)
    analysis = json.loads((Path(output) / 'analysis.json').read_text())
    for id, title in [('clr-zero', 'Maximum absolute clr row sum'), ('ilr-isometry', 'Maximum pairwise clr/ilr distance difference'), ('closure', 'Maximum observed sub-sum difference after replacement')]:
        value = analysis['checks'][id]
        check(id, title, value, 0, value <= 1e-9, 'absolute 1e-9', 'Analytical identity: centered log ratios; orthonormal Helmert basis; multiplicative mass conservation')
    fraction = float((frame.Ba_INAA >= frame.Ba).mean())
    check('ba-method', 'Fraction total INAA Ba >= aqua-regia Ba', fraction, '>=0.90', fraction >= .90, 'lower bound 0.90', 'Declared domain sanity expectation: partial digestion should generally recover less; not a certified recovery test')
    values = np.sort(np.log(frame.Ni.to_numpy(float)))
    def sorted_median(v):
        v = sorted(v)
        n = len(v)
        return (v[(n-1)//2] + v[n//2])/2
    center = sorted_median(values)
    threshold = center + 2*sorted_median([abs(v-center) for v in values])
    expected = int(sum(v > threshold for v in values))
    observed = analysis['threshold']['counts']['high-Ni']
    check('anomaly-reference', 'High-Ni count vs direct sorted-order median/MAD calculation', observed, expected, observed == expected, 'exact', 'Independent direct order-statistic implementation of fixed ln(Ni)>median+2 unscaled MAD')
    ratio = frame.Ba_INAA / frame.Ba
    result = {'checks': records, 'passed': all(r['passed'] for r in records), 'ba_ratio': {'min': float(ratio.min()), 'median': float(ratio.median()), 'max': float(ratio.max())}, 'coordinate_difference_DL_minus_StatDA_m': {'min': float((a.YCOO-b.YCOO).min()), 'max': float((a.YCOO-b.YCOO).max())}}
    (Path(output) / 'checks.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result))
    return result

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    result = verify(args.input, args.output)
    raise SystemExit(0 if result['passed'] else 1)
