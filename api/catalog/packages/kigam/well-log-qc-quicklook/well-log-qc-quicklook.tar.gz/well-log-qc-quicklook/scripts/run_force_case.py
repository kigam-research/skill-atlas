"""Execute the predeclared FORCE 25/9-1 example and independent export checks."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import zipfile
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from pyproj import Transformer
from well_log_qc import analyze, runs, break_depth_gaps, convert

CURVES=['GR','RHOB','NPHI','DTC','RDEP','CALI','BS']
TRACKS=[('GR','gAPI',(0,450)),('RHOB','g/cm3',(1.5,3.5)),('NPHI','m3/m3',(-.15,.9)),
        ('DTC','us/ft',(35,250)),('RDEP','ohm.m',(.01,10000)),('CALI','in',(5,25))]
WINDOW=(1800,2400)


def plot_tracks(raw, flags, report, output, marked):
    fig,axes=plt.subplots(1,len(TRACKS),figsize=(13,7),sharey=True)
    d=raw.DEPT.to_numpy();nominal=report['depth']['median_absolute_step']
    import matplotlib.patches as patches
    colors=['#2563eb','#b45309','#0f766e','#7c3aed','#b91c1c','#334155']
    for ax,(key,unit,extent),color in zip(axes,TRACKS,colors):
        if key=='RDEP':ax.set_xscale('log')
        ax.set_xlim(*extent)
        v=raw[key].to_numpy().copy()
        if key=='RDEP': v[v<=0]=np.nan # only log display; raw.csv retains values and flags
        dd,vv=break_depth_gaps(d,v,nominal);ax.plot(vv,dd,lw=.7,color=color,label=key)
        if key=='CALI':
            dd,vv=break_depth_gaps(d,raw.BS,nominal);ax.plot(vv,dd,lw=.8,color='#dc2626',ls='--',label='BS')
        if marked:
            for r in runs(flags[f'{key}__null'].to_numpy().astype(bool),d):
                ax.axhspan(r['first_depth']-nominal/2,r['last_depth']+nominal/2,color='#94a3b8',alpha=.3)
            for kind,c in [('range','#dc2626'),('spike','#d97706')]:
                m=flags[f'{key}__{kind}'].to_numpy().astype(bool)&np.isfinite(v)
                ax.scatter(v[m],d[m],s=8,color=c,zorder=3)
            if key=='CALI':
                for r in runs(flags.enlargement_candidate.to_numpy().astype(bool),d):
                    ax.axhspan(r['first_depth']-nominal/2,r['last_depth']+nominal/2,color='#f59e0b',alpha=.15)
        ax.set_xlabel(f'{key} [{unit}]');ax.grid(alpha=.2);ax.legend(loc='upper right',fontsize=8)
    axes[0].set_ylim(WINDOW[1],WINDOW[0]);axes[0].set_ylabel('LAS index / supplied MD [m]')
    fig.suptitle('FORCE 25/9-1 | '+('QC flags; values unchanged' if marked else 'Supplied export; no QC overlay'),fontsize=15)
    if marked:
        fig.legend(handles=[patches.Patch(color='#94a3b8',alpha=.3,label='Curve missing'),patches.Patch(color='#dc2626',label='Range candidate'),patches.Patch(color='#d97706',label='Spike candidate'),patches.Patch(color='#f59e0b',alpha=.3,label='CALI - BS > 1 in candidate')],loc='lower center',ncol=4,fontsize=9,bbox_to_anchor=(.5,.04))
    fig.text(.5,.012,'Bormann et al. (2020), FORCE / Zenodo 4351156 · CC BY 4.0; original data NOLD 2.0 · organiser-cleaned/despiked export',ha='center',fontsize=8)
    fig.tight_layout(rect=(0,.09,1,.95));fig.savefig(output,dpi=130);plt.close(fig)


def execute(asset, output):
    output.mkdir(parents=True,exist_ok=True)
    report,raw,flags,_=analyze(asset/'las/25_9-1.las',output,window=WINDOW)
    keep=raw.DEPT.between(*WINDOW)
    display=raw.loc[keep,['DEPT',*CURVES]].reset_index(drop=True)
    f=flags.loc[keep].reset_index(drop=True)
    display.to_csv(output/'raw.csv',index=False,na_rep='')
    shown=pd.concat([display,f[['RHOB__null','NPHI__null','DTC__null','CALI__null','range_candidate','spike_candidate','enlargement_candidate','depth_issue','depth_gap']]],axis=1)
    shown.to_csv(output/'flagged.csv',index=False,na_rep='')
    plot_tracks(display,f,report,output/'raw.png',False);plot_tracks(display,f,report,output/'flagged.png',True)
    # Independent CSV export. Match explicitly on LAS DEPTH_MD, NOT its resampled DEPT index.
    parts=[]
    with zipfile.ZipFile(asset/'train.zip') as z:
        with z.open('train.csv') as stream:
            for chunk in pd.read_csv(stream,sep=';',chunksize=100000):
                parts.append(chunk.loc[chunk.WELL=='25/9-1'])
    csv=pd.concat(parts,ignore_index=True)
    reference_depth=csv.DEPTH_MD.to_numpy()
    valid=raw.DEPTH_MD.notna();las_indices=np.flatnonzero(valid)
    order=np.argsort(raw.DEPTH_MD[valid].to_numpy());las_indices=las_indices[order]
    ld=raw.DEPTH_MD.to_numpy()[las_indices]
    pos=np.searchsorted(ld,reference_depth);left=np.clip(pos-1,0,len(ld)-1);right=np.clip(pos,0,len(ld)-1)
    nearest=np.where(abs(ld[left]-reference_depth)<=abs(ld[right]-reference_depth),left,right)
    dist=abs(ld[nearest]-reference_depth); matched=dist<=.001
    one_to_one=len(np.unique(nearest[matched]))==int(matched.sum())
    a=raw.iloc[las_indices[nearest[matched]]][CURVES].reset_index(drop=True)
    b=csv.loc[matched,CURVES].reset_index(drop=True)
    errors=[];per_curve=[]
    for c in CURVES:
        shared=a[c].notna()&b[c].notna()
        error=float(abs(a.loc[shared,c]-b.loc[shared,c]).max()) if shared.any() else None
        if error is not None: errors.append(error)
        per_curve.append(dict(curve=c,shared_finite=int(shared.sum()),max_abs_difference=error,
            las_null_fraction=float(a[c].isna().mean()),csv_null_fraction=float(b[c].isna().mean()),
            null_mask_disagreement=int((a[c].isna()!=b[c].isna()).sum())))
    max_error=max(errors) if errors else float('inf')
    null_difference=max(abs(v['las_null_fraction']-v['csv_null_fraction']) for v in per_curve)
    def check(id,quantity,observed,expected,tol,passed,unit,reference):
        return dict(id=id,quantity=quantity,observed=observed,expected=expected,tolerance=tol,passed=bool(passed),unit=unit,reference=reference)
    hdr=report['depth'];res=max(abs(hdr['start_residual']),abs(hdr['stop_residual']))
    sonic=np.array([35.,100.,250.]);rt=float(np.max(abs(convert(sonic/.3048,'DT','us/m')-sonic)))
    checks=[check('csv-values','LAS vs CSV curve values: maximum absolute difference',max_error,0,'<= 1e-4',max_error<=1e-4,'native curve units','FORCE train.csv independently exported from supplied LAS; seven curves on shared rows'),
        check('csv-null-fraction','Maximum per-curve missing-fraction difference',null_difference,0,'<= 1e-12',null_difference<=1e-12,'fraction','Identical matched rows in train.csv; null masks also retained in reference.json'),
        check('csv-match','Uniquely matched CSV row fraction',float(matched.mean()),1,'depth <= 0.001 m; one-to-one',matched.all() and one_to_one,'fraction','LAS DEPTH_MD vs CSV DEPTH_MD, no interpolation'),
        check('header-start-stop','Maximum first/last vs STRT/STOP residual',res,0,'<= 1e-6',res<=1e-6,'m','LAS header versus parsed first-column measurements'),
        check('median-step','Median signed increment vs STEP residual',abs(hdr['step_residual']),0,'<= 1e-6',abs(hdr['step_residual'])<=1e-6,'m','LAS STEP header versus independently recomputed increments'),
        check('sonic-roundtrip','Sonic conversion round-trip error',rt,0,'<= 1e-12',rt<=1e-12,'us/ft','International foot 0.3048 m exactly; constructed 35/100/250 us/ft')]
    # Mean XY is only an approximate map location (trajectory may be deviated).
    xy=csv[['X_LOC','Y_LOC']].dropna().median();lon,lat=Transformer.from_crs(23031,4326,always_xy=True).transform(*xy)
    finite=raw.DEPTH_MD.notna()
    ref=dict(checks=checks,per_curve=per_curve,csv_rows=len(csv),matched_rows=int(matched.sum()),one_to_one=one_to_one,
             max_match_distance_m=float(dist[matched].max()),las_rows=len(raw),
             depth_index_vs_depth_md_max_difference_m=float(abs(raw.loc[finite,'DEPT']-raw.loc[finite,'DEPTH_MD']).max()),
             location=dict(point=[lon,lat],approximate=True,assumption='Median XY from CSV; ED50 / UTM 31N (EPSG:23031) assumed, no surveyed CRS verification'),
             input_sha256={n:hashlib.sha256((asset/n).read_bytes()).hexdigest() for n in ['las/25_9-1.las','train.zip']},
             result='passed' if all(c['passed'] for c in checks) else 'failed')
    (output/'reference.json').write_text(json.dumps(ref,indent=2,allow_nan=False)+'\n')
    shutil.copyfile(asset/'DATA-LICENSE.md',output/'DATA-LICENSE.md')
    print(json.dumps(ref,indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--input',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    args=p.parse_args();execute(args.input,args.output)
