"""Portable offline known-answer smoke test (<60 s), no repository/asset dependency."""
import numpy as np
from well_log_qc import convert, depth_qc, inspect_arrays

def main():
    report,mask,_=depth_qc([3,2,1],3,1,-1)
    assert not mask.any() and report['direction']=='decreasing'
    np.testing.assert_allclose(convert([20],'NPHI','%'),[.2])
    assert convert([20],'NPHI','_') is None
    x=np.ones(31)*50;x[15]=1000;original=x.copy()
    r,f,_=inspect_arrays(np.arange(31),{'GR':x},{'GR':'gAPI'})
    assert f.loc[15,'GR__spike'] and f.loc[15,'GR__range']
    np.testing.assert_array_equal(x,original)
    print('well-log QC known-answer selftest passed')

if __name__=='__main__':main()
