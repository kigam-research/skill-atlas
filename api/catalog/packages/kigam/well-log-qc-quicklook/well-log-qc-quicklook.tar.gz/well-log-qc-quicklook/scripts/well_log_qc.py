"""Offline, non-destructive LAS 2.0 QC. No petrophysical interpretation."""
from __future__ import annotations
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import warnings

import lasio
import numpy as np
import pandas as pd

# Screening defaults, NOT tool specifications or universal physical limits.
FAMILIES = {
    'GR': ('GR', 'SGR'), 'RHOB': ('RHOB', 'RHOZ', 'DEN'),
    'NPHI': ('NPHI', 'TNPH', 'CNL'), 'DT': ('DT', 'DTC', 'AC', 'DTS'),
    'RES': ('RDEP', 'RMED', 'RSHA', 'RT', 'ILD', 'ILM', 'LLD', 'LLS', 'RXO', 'RMIC'),
    'CALI': ('CALI', 'CAL', 'HCAL'), 'BS': ('BS', 'BIT'),
}
RANGES = {'GR': (0, 300), 'RHOB': (1.5, 3.5), 'NPHI': (-0.15, 0.65),
          'DT': (35, 250), 'RES': (0.01, 10000), 'CALI': (2, 40), 'BS': (2, 40)}
CANONICAL = {'GR': 'gAPI', 'RHOB': 'g/cm3', 'NPHI': 'v/v', 'DT': 'us/ft',
             'RES': 'ohm.m', 'CALI': 'in', 'BS': 'in'}
# Each multiplier maps a documented unit into the canonical screening unit.
FACTORS = {
    'GR': {'gapi': 1, 'api': 1},
    'RHOB': {'g/cm3': 1, 'g/cc': 1, 'kg/m3': .001},
    'NPHI': {'v/v': 1, 'm3/m3': 1, 'fraction': 1, '%': .01, 'pu': .01},
    'DT': {'us/ft': 1, 'us/m': .3048},
    'RES': {'ohm.m': 1, 'ohmm': 1, 'ohm-m': 1},
    'CALI': {'in': 1, 'inch': 1, 'inches': 1, 'mm': 1/25.4, 'cm': 1/2.54},
    'BS': {'in': 1, 'inch': 1, 'inches': 1, 'mm': 1/25.4, 'cm': 1/2.54},
}


def unit_key(unit):
    return str(unit).lower().strip().replace(' ', '').replace('µ', 'u').replace('μ', 'u').replace('³', '3')


def family(mnemonic):
    return next((f for f, names in FAMILIES.items() if mnemonic.upper() in names), None)


def convert(values, group, unit):
    """New canonical array; unknown units are not inferred from numeric values."""
    factor = FACTORS.get(group, {}).get(unit_key(unit))
    return None if factor is None else np.asarray(values, dtype=float).copy() * factor


def depth_qc(depth, start=None, stop=None, step=None, tolerance=1e-3):
    d = np.asarray(depth, dtype=float)
    delta = np.diff(d)
    finite = np.isfinite(d)
    valid_delta = delta[np.isfinite(delta) & (delta != 0)]
    signed = float(np.median(valid_delta)) if len(valid_delta) else None
    nominal = abs(signed) if signed is not None else None
    direction = 'increasing' if signed is not None and signed > 0 else 'decreasing' if signed is not None else 'indeterminate'
    reverse = np.zeros(len(d), dtype=bool)
    duplicate = np.zeros(len(d), dtype=bool)
    changes = np.zeros(len(d), dtype=bool)
    gap = np.zeros(len(d), dtype=bool)
    if nominal is not None:
        reverse[1:] = np.isfinite(delta) & (delta * signed < 0)
        duplicate[1:] = np.isfinite(delta) & (delta == 0)
        changes[1:] = np.isfinite(delta) & (np.abs(np.abs(delta) - nominal) > tolerance)
        gap[1:] = np.isfinite(delta) & (np.abs(delta) > nominal * 1.5 + tolerance)
    else:
        duplicate[1:] = np.isfinite(delta) & (delta == 0)
    issue = ~finite | reverse | duplicate | changes
    def residual(a, b):
        return float(a-b) if a is not None and b is not None and np.isfinite(a) and np.isfinite(b) else None
    report = dict(direction=direction, median_signed_step=signed, median_absolute_step=nominal,
                  first=float(d[0]) if finite[0] else None, last=float(d[-1]) if finite[-1] else None,
                  nonfinite=int((~finite).sum()), duplicate=int(duplicate.sum()), reversals=int(reverse.sum()),
                  step_changes=int(changes.sum()), gaps=int(gap.sum()), tolerance=tolerance,
                  start_residual=residual(d[0], start), stop_residual=residual(d[-1], stop),
                  step_residual=residual(signed, step), header=dict(STRT=start, STOP=stop, STEP=step))
    return report, issue, gap


def spike_candidates(values, depth, nominal_step, floor, threshold=8, window=11):
    """Hampel-like candidate rule; never bridge null/depth breaks, never replace."""
    x = np.asarray(values, float)
    d = np.asarray(depth, float)
    result = np.zeros(len(x), bool)
    breaks = ~np.isfinite(x) | ~np.isfinite(d)
    jump = np.r_[False, np.abs(np.diff(d)) > (nominal_step or 0)*1.5 + 1e-3]
    reversal = np.r_[False, np.diff(d) * (np.nanmedian(np.diff(d)) if len(d)>1 else 0) <= 0]
    segments = np.cumsum(breaks | np.r_[False, breaks[:-1]] | jump | reversal)
    for seg in np.unique(segments):
        idx = np.flatnonzero((segments == seg) & ~breaks)
        if len(idx) < window:
            continue
        s = pd.Series(x[idx]); median = s.rolling(window, center=True, min_periods=window).median()
        # Local MAD is calculated about each window's own median.
        mad = s.rolling(window, center=True, min_periods=window).apply(lambda a: np.median(np.abs(a-np.median(a))), raw=True)
        result[idx] = (np.abs(s-median) > threshold*np.maximum(1.4826*mad, floor)).fillna(False).to_numpy()
    return result


def runs(mask, depth):
    """Inclusive sample endpoints and counts; no invented thickness at edges."""
    m = np.asarray(mask, bool); d = np.asarray(depth, float)
    boundaries = np.flatnonzero(np.diff(np.r_[False, m, False]))
    return [dict(first_row=int(a), last_row=int(b-1), first_depth=float(d[a]) if np.isfinite(d[a]) else None,
                 last_depth=float(d[b-1]) if np.isfinite(d[b-1]) else None, samples=int(b-a))
            for a,b in zip(boundaries[::2], boundaries[1::2])]


def inspect_arrays(depth, curves, units, originals=None, headers=None, unit_overrides=None, washout_threshold=1.0):
    """Testable QC core. Curves include raw depth and other columns, never mutated."""
    originals = originals or {k: k for k in curves}
    overrides = unit_overrides or {}
    unknown = set(overrides)-set(curves)
    if unknown:
        raise ValueError(f'Unknown unit override columns: {sorted(unknown)}')
    headers = headers or {}
    dr, di, gaps = depth_qc(depth, headers.get('STRT'), headers.get('STOP'), headers.get('STEP'))
    duplicated = [m for m, count in Counter(v.upper() for v in originals.values()).items() if count>1]
    inventory, intervals, canonical = [], [], {}
    flags = pd.DataFrame({'depth_issue': di.astype(int), 'depth_gap': gaps.astype(int)})
    floors = {'GR': 1, 'RHOB': .01, 'NPHI': .01, 'DT': 1, 'RES': .05, 'CALI': .05, 'BS': .05}
    for key, values in curves.items():
        x = np.asarray(values, float)
        original = originals[key]
        group = family(original)
        effective = overrides.get(key, units.get(key, ''))
        normalized = convert(x, group, effective)
        ambiguous = original.upper() in duplicated
        if ambiguous:
            normalized = None
        null = ~np.isfinite(x)
        out = np.zeros(len(x), bool); spike = out.copy()
        if normalized is not None:
            canonical[key] = normalized
            low, high = RANGES[group]
            out = np.isfinite(normalized) & ((normalized<low) | (normalized>high))
            if group == 'RES':
                out |= np.isfinite(normalized) & (normalized<=0)
                sx = np.full(len(x), np.nan); positive=normalized>0
                sx[positive] = np.log10(normalized[positive])
            else:
                sx = normalized
            spike = spike_candidates(sx, depth, dr['median_absolute_step'], floors[group])
        for typ, mask in [('null',null), ('range',out), ('spike',spike)]:
            flags[f'{key}__{typ}'] = mask.astype(int)
            intervals += [dict(curve=key, kind=typ, **r) for r in runs(mask, depth)]
        inventory.append(dict(mnemonic=key, original_mnemonic=original, unit=units.get(key,''),
            effective_unit=effective, unit_override=key in overrides, family=group, duplicate=ambiguous,
            samples=len(x), finite=int((~null).sum()), null_fraction=float(null.mean()),
            first_valid_depth=next((float(depth[i]) for i in np.flatnonzero(~null) if np.isfinite(depth[i])), None),
            last_valid_depth=next((float(depth[i]) for i in np.flatnonzero(~null)[::-1] if np.isfinite(depth[i])), None),
            screening_unit=CANONICAL.get(group) if normalized is not None else None,
            range_screen='assessed' if normalized is not None else 'unassessed', range_flags=int(out.sum()), spike_candidates=int(spike.sum())))
    cal = [k for k in canonical if family(originals[k])=='CALI']
    bit = [k for k in canonical if family(originals[k])=='BS']
    washout = dict(status='unassessed', reason='Need exactly one unambiguous CALI and BS with resolved units')
    flags['enlargement_candidate'] = 0
    if len(cal)==len(bit)==1:
        c,b=canonical[cal[0]],canonical[bit[0]]; valid=np.isfinite(c)&np.isfinite(b)
        mask=valid & ((c-b)>washout_threshold)
        flags['enlargement_candidate']=mask.astype(int)
        washout=dict(status='assessed' if valid.any() else 'unassessed', caliper=cal[0], bit=bit[0],
                     co_valid=int(valid.sum()), threshold_in=washout_threshold, candidates=int(mask.sum()),
                     reason='Candidate enlarged borehole only; casing/tool/environment unknown')
        intervals += [dict(curve=cal[0]+'-'+bit[0],kind='enlargement',**r) for r in runs(mask,depth)]
    selected = [k for k in curves if family(originals[k]) in ('GR','RHOB','NPHI','DT','RES','CALI','BS')]
    flags['any_null'] = flags[[f'{k}__null' for k in selected]].max(axis=1) if selected else 0
    flags['range_candidate'] = flags[[f'{k}__range' for k in selected]].max(axis=1) if selected else 0
    flags['spike_candidate'] = flags[[f'{k}__spike' for k in selected]].max(axis=1) if selected else 0
    return dict(depth=dr, duplicates=duplicated, inventory=inventory, intervals=intervals,
                washout=washout, missing_families=[g for g in FAMILIES if not any(family(v)==g for v in originals.values())],
                rules=dict(range_bounds=RANGES, spike='11-sample full window, abs(x-median)>8*max(1.4826*MAD,family_floor); resistivity in log10',
                           spike_floor=floors, conditioning='none; raw values and ordering preserved')), flags, canonical


def load_las(path):
    text = Path(path).read_text(errors='replace')
    match = re.search(r'^\s*VERS\s*\.\s*([0-9.]+)', text, re.M|re.I)
    if not match or float(match.group(1)) != 2.0:
        raise ValueError('Helper supports LAS 2.0 only. LAS 3.0 may contain multiple measurement tables: inventory sections and obtain a verified LAS 2.0 export; never silently read only the first table.')
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter('always')
        las = lasio.read(path, null_policy='strict', ignore_header_errors=False)
    if las.data.ndim!=2 or not len(las.data) or not len(las.curves):
        raise ValueError('Empty LAS measurement table')
    if any(not c.original_mnemonic.strip() for c in las.curves):
        raise ValueError('Missing curve mnemonic; identify the column from source before QC')
    curves = {c.mnemonic: las.data[:,i].copy() for i,c in enumerate(las.curves)}
    units = {c.mnemonic: c.unit for c in las.curves}
    originals = {c.mnemonic: c.original_mnemonic for c in las.curves}
    headers={}
    for k in ('STRT','STOP','STEP','NULL'):
        try:
            v=float(las.well[k].value); headers[k]=v if np.isfinite(v) else None
        except (KeyError,ValueError,TypeError):
            headers[k]=None
    return las, curves, units, originals, headers, [str(w.message) for w in caught]


def analyze(path, output, unit_overrides=None, window=None):
    output=Path(output); output.mkdir(parents=True,exist_ok=True)
    las,curves,units,originals,headers,parser_warnings=load_las(path)
    depth=las.data[:,0].copy()
    if unit_overrides and las.curves[0].mnemonic in unit_overrides:
        raise ValueError('Depth-unit overrides are not supported: reconcile depth/header units in a separately verified export')
    report,flags,canonical=inspect_arrays(depth,curves,units,originals,headers,unit_overrides)
    report.update(input_sha256=hashlib.sha256(Path(path).read_bytes()).hexdigest(),
                  input_file=Path(path).name, version='2.0', depth_column=las.curves[0].mnemonic,
                  depth_unit=las.curves[0].unit, parser_warnings=parser_warnings, NULL=headers['NULL'],
                  depth_convention='LAS first-column index; MD/TVD and datum require source confirmation')
    raw=pd.DataFrame(curves); marked=pd.concat([raw,flags],axis=1)
    # No interpolation or subsampling. The CSVs keep every row in the chosen window.
    keep=np.ones(len(depth),bool) if window is None else (depth>=window[0])&(depth<=window[1])
    if not keep.any():
        raise ValueError('No samples in requested display interval')
    raw.loc[keep].to_csv(output/'raw.csv',index=False,na_rep='')
    marked.loc[keep].to_csv(output/'flagged.csv',index=False,na_rep='')
    pd.DataFrame(report['inventory']).to_csv(output/'inventory.csv',index=False)
    (output/'qc.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    return report, raw, flags, canonical


def break_depth_gaps(depth, values, nominal):
    """Display-only NaN separators across missing depth samples and reversed passes."""
    d=np.asarray(depth,float); v=np.asarray(values,float)
    out_d=[]; out_v=[]
    direction=np.nanmedian(np.diff(d)) if len(d)>1 else 1
    for i in range(len(d)):
        if i and (not np.isfinite(d[i-1:i+1]).all() or abs(d[i]-d[i-1])>(nominal or 0)*1.5+1e-3 or (d[i]-d[i-1])*direction<=0):
            out_d.append(np.nan); out_v.append(np.nan)
        out_d.append(d[i]); out_v.append(v[i])
    return np.array(out_d),np.array(out_v)


def quicklook(raw, flags, report, output, curve_names=None, window=None):
    """One raw-unit track per chosen curve; unresolved units visible, no shared-scale overlay."""
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    inventory={c['mnemonic']: c for c in report['inventory']}
    chosen=curve_names if curve_names is not None else [k for k,c in inventory.items() if c['family']]
    if not chosen or any(k not in raw or k==report['depth_column'] for k in chosen):
        raise ValueError('Quicklook needs existing non-depth curve names; use --curves for unrecognised mnemonics')
    d=raw[report['depth_column']].to_numpy()
    keep=np.isfinite(d) if window is None else np.isfinite(d)&(d>=window[0])&(d<=window[1])
    fig,axes=plt.subplots(1,len(chosen),figsize=(max(4,len(chosen)*2),7),sharey=True,squeeze=False)
    for ax,k in zip(axes[0],chosen):
        c=inventory[k]; v=raw[k].to_numpy().copy()
        if c['family']=='RES' and c['screening_unit']:
            ax.set_xscale('log'); v[v<=0]=np.nan
        dd,vv=break_depth_gaps(d,v,report['depth']['median_absolute_step'])
        # Keep separators when windowing so distinct segments cannot become connected.
        shown=(~np.isfinite(dd))|((dd>=window[0])&(dd<=window[1])) if window else np.ones(len(dd),bool)
        ax.plot(vv[shown],dd[shown],lw=.7,color='#2563eb',label=k)
        for r in runs(flags[f'{k}__null'].to_numpy().astype(bool),d):
            if r['first_depth'] is not None and r['last_depth'] is not None:
                ax.axhspan(r['first_depth'],r['last_depth'],color='#94a3b8',alpha=.3)
        for kind,color in [('range','#dc2626'),('spike','#d97706')]:
            m=keep & flags[f'{k}__{kind}'].to_numpy().astype(bool)
            ax.scatter(v[m],d[m],s=8,color=color,label=kind+' candidate')
        unit=c['effective_unit'] if unit_key(c['effective_unit']) not in ('','_') else 'unresolved'
        if c['unit_override']:
            unit+=f"; override (source: {c['unit'] or 'blank'})"
        ax.set_xlabel(f"{k} [{unit}]");ax.grid(alpha=.2);ax.legend(fontsize=7)
    finite=d[keep]
    axes[0,0].set_ylim((window[1],window[0]) if window else (max(finite),min(finite)))
    axes[0,0].set_ylabel(f"{report['depth_column']} [{report['depth_unit'] or 'unresolved'}] | MD/TVD unverified")
    fig.suptitle('QC candidates only | raw values unchanged | grey: curve missing')
    fig.tight_layout();fig.savefig(output,dpi=120);plt.close(fig)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--las',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--curves',nargs='+',help='Exact column names for separate raw-unit tracks; default all recognised curve families')
    p.add_argument('--depth-window',type=float,nargs=2);p.add_argument('--unit-overrides',type=Path,help='JSON mapping of exact LAS column to confirmed unit; does not alter source')
    a=p.parse_args()
    try:
        report,raw,flags,_=analyze(a.las,a.output,json.loads(a.unit_overrides.read_text()) if a.unit_overrides else None,a.depth_window)
        quicklook(raw,flags,report,a.output/'quicklook.png',a.curves,a.depth_window)
    except ValueError as e:
        p.exit(2,str(e)+'\n')
    print(json.dumps(dict(rows=report['inventory'][0]['samples'],depth=report['depth'],duplicates=report['duplicates'])))

if __name__=='__main__': main()
