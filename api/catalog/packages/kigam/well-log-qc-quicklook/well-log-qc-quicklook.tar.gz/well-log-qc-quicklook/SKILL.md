---
name: well-log-qc-quicklook
description: Inventory petroleum LAS well-log curves, check depth/header/unit consistency, flag candidate anomalies and produce non-destructive multi-track quicklooks. Use for LAS intake/QC, not LiDAR LAS or lithology/fluid interpretation. LAS 2.0 has an offline helper; LAS 3.0 needs verified section-aware export.
license: MIT
metadata:
  version: "0.1.0"
---

# Well-log QC and quicklook

Deliver a curve inventory, explicit issues/unassessed checks, a same-scope raw/flagged view, and decisions for the researcher. The supplied file is immutable. Never equate a QC flag with invalid geology or silently replace, interpolate, despike, sort or merge samples.

## Intake and format boundary

Establish well ID, logging run/tool, purpose, depth convention (MD/TVD), reference datum, depth unit, NULL sentinel and provenance. Ask for deviation survey, tops, bit-size/casing intervals only when the intended comparison needs them. A curve name or negative Z is not proof of TVD. Tops and trajectories with different datums cannot be overlaid without reconciliation.

For LAS 2.0, use the offline helper below. It reads the declared NULL sentinel; finite zero is retained. Review parser warnings and inventory original versus parser-renamed mnemonics. Missing mnemonics are a blocking ambiguity, not permission to guess column meanings. Duplicate mnemonics stay distinct and unit-dependent screening is unassessed until a researcher identifies them.

LAS 3.0 may carry multiple measurement datasets, independent depth/time indices, units and relationships. Inventory all section/table names and associations before using a section-aware parser or asking for a verified LAS 2.0 export of the selected log table. Check exported row count, depth range, curves, units and NULLs against that table. **The bundled helper explicitly rejects LAS 3.0; it does not validate or partially parse it.** Never call conversion success proof of full LAS 3.0 preservation. DLIS and image-only logs need a separate reader.

## Depth and curve decisions

1. Compare first/last sample with STRT/STOP, signed median increment with STEP, and flag nonfinite depths, duplicates, reversals, step changes and missing depth intervals. A descending run with negative STEP is valid. Preserve order: sorting a multi-pass log can conflate runs. Float/export precision needs a stated tolerance, not exact equality. Inspect a second depth column independently; do not silently substitute it for the first LAS index.
2. Inventory mnemonic, original mnemonic, unit text, finite coverage and sample-bounded null intervals. Separate no curve, all-null curve, unresolved unit, and unassessed screening. NULL runs are different from missing depth samples. No observations means unknown, not zero.
3. Reconcile units from source/tool documentation or an explicit researcher-confirmed mapping, not magnitude alone. Consult `references/qc-decisions.md` for family-specific choices. The helper converts **derived screening arrays only**; raw output keeps original units and values. `%` neutron porosity differs from v/v by 100; sonic us/m differs from us/ft by 1/0.3048. Unknown units suppress numeric family range/spike checks rather than receiving assumed units.
4. Read range, spike and caliper flags as review cues. Default limits are broad author-chosen screening envelopes, not physical impossibility or tool accuracy limits. Formation boundaries and bed-scale variation can trigger spikes. The helper uses an 11-sample local median/MAD rule; its physical window changes with sampling step. Adapt the method when tool response, sampling or scientific purpose demands it and record the reason.
5. Resistivity must be positive for a log axis. Keep nonpositive raw values and flag them; do not replace with epsilon. Choose deep/medium/shallow curves by tool investigation depth, available coverage and target question, not the most attractive curve. CALI minus BS is evaluated only on co-valid reconciled units: excess is a candidate enlarged borehole, not confirmed washout. Casing, mudcake, tool geometry and absent BS can make the comparison unassessed or misleading.
6. Show raw and flagged curves over identical well/run/depth extents and identical axes; nulls and missing depth samples remain breaks. Never join curves through gaps or a reversed pass. Display downhole depth increasing downward with units. Do not overlay density and neutron on a shared numeric scale without explicitly different calibrated axes.

## Offline helper

Runtime: Python with numpy, pandas, lasio; matplotlib/pyproj for the FORCE example. From a compatible project environment:

```bash
uv run python skills/well-log-qc-quicklook/scripts/well_log_qc.py \
  --las /path/to/well.las --output /path/to/output --depth-window 1800 2400
uv run python skills/well-log-qc-quicklook/scripts/selftest.py
```

The CLI writes `inventory.csv`, `qc.json`, `raw.csv`, `flagged.csv`, and `quicklook.png`. The PNG shows each recognised curve in a separate raw-unit track; use `--curves GR RHOB NPHI DTC RDEP CALI BS` (exact column names) for a focused view or to include unrecognised vendor mnemonics. Flags cover all parsed curves; curve values, row order and original units remain unchanged. `--unit-overrides /path/to/confirmed-units.json` accepts an exact-column-to-unit mapping (e.g. `{"NPHI":"%"}`) and records original/effective units separately. Plot labels use the effective unit and visibly show the original unit when overridden. Depth-column overrides are rejected because depth/header consistency must first be reconciled in a verified export. This is an explicit interpretation supplied by the caller, not inferred calibration. The helper's depth tolerance is 0.001 in the LAS depth unit; assess whether that is suitable for other units/resolutions.

For the staged FORCE case, `scripts/run_force_case.py --input <asset-directory> --output <output-directory>` writes the six-track raw/flagged PNG pair, small CSV display tables and independent reference-check JSON. It is a case adapter, not a requirement to use this dataset. The generic helper supports arbitrary LAS 2.0 curve tables; adapt plots and screening for other families without inventing unit equivalence.

## Handoff and decisions

Report confirmed structural defects separately from candidate scientific anomalies and checks not performed. Include source hash, header/data residuals, unit assumptions/overrides, curve inventory, flagged row/depth intervals, rule parameters, unchanged raw data, and open choices: curve selection, MD versus TVD, threshold appropriateness, whether to accept any proposed conditioning. Conditioning requires a separately named derived dataset and a before/after impact record after the researcher chooses it; this skill's example performs none.

The FORCE example is one organiser-cleaned/partially despiked well export (Bormann et al. 2020, Zenodo 4351156, CC BY 4.0; original Norwegian data NOLD 2.0). It demonstrates export concordance and a real STOP mismatch, not universal quality, lithology, fluids, reservoir properties or geographic validity. Domain-expert review has not been performed. Keep data attribution with derived tables and figures; see `examples/force-25-9-1/DATA-LICENSE.md`.
