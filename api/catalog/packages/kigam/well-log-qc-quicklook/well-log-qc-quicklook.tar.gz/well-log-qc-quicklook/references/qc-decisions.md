# Curve-family decision cues

These author-selected screening defaults are in canonical units; they are **not** instrument specifications, certified physical limits or an expert-reviewed petrophysical method. Resolve the source mnemonic/unit before applying them. Read this reference when interpreting units/flags or adapting the helper.

| Family | Canonical unit; screening envelope | Choice cue / alternative | Verify / exception |
|---|---|---|---|
| GR/SGR | gAPI; 0–300 | Confirm API calibration; total versus spectral/corrected GR may not be interchangeable | High radioactive beds can exceed envelope; negative environmental corrections are not proof of an export error |
| RHOB/RHOZ/DEN | g/cm3; 1.5–3.5 | g/cm3 or g/cc versus kg/m3 (×0.001) | Check tool corrections and CALI/DRHO; gas, coal and bad borehole response can have overlapping signatures |
| NPHI/TNPH/CNL | v/v; −0.15–0.65 | Percent/porosity units (×0.01) versus fraction | Matrix calibration (limestone/sandstone/dolomite), lithology and environment matter; negative values can be genuine tool response |
| DT/DTC/AC/DTS | us/ft; 35–250 | us/m ×0.3048; compressional versus shear must remain distinct | Cycle skipping and formation changes both look anomalous; the same broad range is only an intake cue, especially unsuitable for inferring shear quality |
| Resistivity | ohm.m; 0.01–10000, additionally nonpositive flagged | Multiple depths of investigation: retain original curves, choose one explicitly | Positive values only on log axis; extremes do not imply fluid type; no log(0), epsilon replacement or silent clipping |
| CALI and BS | in; 2–40; CALI−BS >1 in candidate | mm /25.4, cm /2.54; require co-valid bit size | No BS means unassessed. Casing/run/tool changes can invalidate open-hole enlargement reasoning |

The helper uses exact alias matching and deliberately does not guess vendor mnemonics. Unlisted families remain inventoried but unassessed. Add a documented mapping for another tool family; do not recycle thresholds solely because the unit is the same. Resistivity spike candidates use log10 values; other families use canonical values. The full-window local median/MAD test has factor 8, window 11, and family floors (GR 1 gAPI, RHOB 0.01 g/cm3, NPHI 0.01 v/v, DT 1 us/ft, RES 0.05 log10 units, CALI/BS 0.05 in). It does not bridge nulls or depth discontinuities. Edge windows are unassessed, not passed.

## Common failure modes and alternatives

- **Header/data mismatch:** report both numbers. A different header STOP can be export metadata, rounding, or truncated data. Do not pad/trim until the run and source are checked.
- **Missing depth rows:** preserve the actual gaps; display NaN separators or separate line segments, not interpolation that appears measured.
- **Multiple passes / duplicate depths:** split by source run identifiers when available; otherwise report ambiguity. Averaging or deduplication can erase measurements.
- **Blank or `_` unit:** preserve the text and mark unresolved. Obtain tool/export metadata or a confirmed override; similar magnitudes cannot distinguish neutron percent from fraction safely.
- **MD versus TVD:** use deviation and survey/reference datums for transformation. Do not relabel the axis using well suffix, Z_LOC or assumptions about verticality.
- **Expert review absent:** keep all scientific flags candidate-only. Export concordance validates implementation against another export of the same provider data, not independent measurement truth.
