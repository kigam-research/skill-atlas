---
name: pumping-test-diagnostics
description: Diagnose pumping-test time–drawdown series, identify candidate flow regimes, and compare confined/leaky analytical fits with explicit windows and uncertainty. Use for constant or variable pumping and recovery; not for slug tests or a general groundwater numerical model.
license: MIT
metadata:
  version: "0.1.0"
---

# Pumping-test diagnostics

Deliver diagnostic plots, competing conceptual models and defensible parameter **ranges**, not just an optimizer's best fit. Read [references/interpretation.md](references/interpretation.md) for regime cues, assumptions and the field-example provenance.

## Establish the data contract

- Obtain the pumping **history**, including every rate change and shutoff, common time origin, initial head/trend, measurement units, observation distances, pumping/casing radius, aquifer thickness and screen/penetration. Distinguish measured geometry from a schematic/default. Unknown construction data remains unknown; explain its effect on early-time trust.
- Convert to consistent m, days, m³/day, T in m²/day, dimensionless S, leakage factor B in m. Specific storage Ss is **not** S: S=Ss*b only for the stated aquifer thickness. Hydraulic conductivity K=T/b requires independently justified b.
- Positive drawdown means extraction-induced head reduction. Negative head changes need a documented sign conversion, not abs(). Preserve recovery residual drawdown and injection signs.
- Check strictly increasing positive times, duplicate times, gaps, tide/barometric corrections, baseline drift, discharge changes and transducer precision. Do not silently sort, deduplicate, smooth or delete a row. If time zero/rate/units are unresolved, stop parameter interpretation and report the missing information.

## Diagnose before selecting a model

Show raw linear time–drawdown, log-log drawdown and **ds/dln(t)**, plus semi-log drawdown and signed residuals. Bourdet differentiation uses a weighted three-point slope on irregular log time. State separation (helper: 0.15 log10 cycles), compare a wider separation (0.30), leave endpoints missing and count nonpositive derivatives. Never plot abs(derivative), convert missing values to zero or connect a derivative stencil across a rate change. A downward/noisy derivative is not automatically leakage.

Interpret the cues in the reference as candidate regimes. Mark an IARF window only when a stable derivative plateau is supported over a useful log-time span and is consistent across observation wells. Early well storage/skin/partial penetration and late boundaries can bias S or T. A single piezometer cannot uniquely distinguish all mechanisms.

## Fit candidate models on declared windows

- **Theis:** infinite homogeneous isotropic confined, fully penetrating line source, linear response, no well storage/skin. W(u)=E1(u), u=r²S/(4Tt).
- **Cooper–Jacob:** the small-u semi-log asymptote. The helper requires a single constant positive rate and verifies fitted max u<=0.01 in the chosen window. Fit Theis on the **same window** before comparing T. Do not validate CJ by a straight-looking graph alone.
- **Hantush–Jacob:** leakage with fixed source head, negligible aquitard storage; B=sqrt(T*c), c=b'/K'. Compare with Theis, not just a more flexible best fit. Delayed yield and aquitard storage require different models; the helper does not implement them.
- **Variable rate / recovery:** use linear superposition of **rate increments**, not absolute rates. The input schedule stores absolute rates; `(tp,0)` removes the preceding extraction. Exact Theis recovery is s(t,Q)-s(t-tp,Q), t measured from pumping start. Do not reset the model clock at shutoff or infer ordinary constant-rate regimes from unnormalised post-change derivatives. Late recovery approximations may poorly identify S.

Use physically positive parameters, explicit bounds and measurement-appropriate residual weighting. The helper uses unweighted head residuals; uneven sampling and well counts influence its joint fit. Inspect residual structure, bound hits and conditioning; a normal return does not demonstrate a valid conceptual model. Compare physically admissible models and alternative defensible windows/observation wells. Report T/S/B/c envelopes as **sensitivity ranges**, not confidence intervals. For research uncertainty, justify a measurement-error model and profile/ensemble analysis; do not call a local least-squares covariance a guaranteed interval.

## Offline helper

Dependencies: numpy, pandas, scipy, matplotlib. No ttim/lmfit, network or new data acquisition.

```bash
uv run python <skill>/scripts/diagnose.py \
  --input-dir <resolved-named-input-root> \
  --config <metadata.json> --output-dir <output-directory>
uv run python <skill>/scripts/selftest.py
```

Use [references/oude-korendijk.json](references/oude-korendijk.json) or [references/dalem.json](references/dalem.json) as **metadata format examples**, not universal presets. `observations` declares file, skiprows, delimiter (optional), zero-based time/head columns (default 0/1), time_to_day, drawdown_sign, distance_m, optional fit_start_day/fit_end_day and CJ start. `schedule` contains `[start_day, absolute_rate_m3_day]`. Choose models (`theis`, `cooper-jacob`, `hantush-jacob`); remove example reference checks for a new site and declare site-appropriate ones before execution. Fit/CJ window endpoints use the same clock as schedule starts and source times after conversion to days. CSV `time_day` and diagnostic derivatives use elapsed time since the first pumping step; `schedule_time_day` preserves the original clock. File paths resolve relative to the input root. The helper is for explicit numeric time/head tables, not automatic interpretation of arbitrary files.

Outputs: per-well diagnostic CSV (signed derivative and residuals), raw/diagnostic/semi-log PNGs, model-comparison CSV and results JSON with units, input hashes, selected windows, parameter sensitivity, bound/conditioning diagnostics and executed checks. Config/metadata errors fail without repairing observations. Numeric reference failures write results then exit nonzero; retain them instead of changing a tolerance to make them pass.

## Handoff to the researcher

State the selected candidate and alternatives, which observations/time window were used, residual RMSE/structure, excluded mechanisms, sensitivity ranges and what is not identifiable. Present the decisions still needed: model choice, fitting window and whether early time is trustworthy. Offer a recommendation with its evidence; do not add an approval interruption if the researcher already specified those choices. Clearly separate constructed analytical checks, stored field-example equivalence and **domain expert review (not performed)**. Two Dutch examples do not establish regional validity or calibrated probability coverage.
