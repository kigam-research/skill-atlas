# Interpretation cues and reference scope

## Candidate cues (constant-rate periods only)

| Observed log-log cue | Candidates and discrimination | Verification / failure mode |
|---|---|---|
| Stable ds/dln(t) plateau; semi-log straight segment | Infinite-acting radial flow (IARF); T≈Q/(4π*plateau) | Confirm rate stability, several useful log-time samples and consistency across wells. CJ additionally needs fitted u<=0.01. A short noisy plateau is weak evidence. |
| Drawdown and derivative parallel, unit slope early | Wellbore storage; early well response may not be aquifer response | Check casing radius, pumping-well vs observation-well location, pump ramp and transducer response. Do not estimate aquifer S from storage-dominated early data. Helper does not fit storage/skin. |
| Derivative turns downward; drawdown flattens | Leakage, constant-head/recharge boundary, rate reduction or correction artefact | Compare observed rate history and other wells. Hantush-Jacob assumes fixed head and no aquitard storage. These cues alone do not identify leakance. |
| Derivative rises toward twice a preceding plateau | Ideal single no-flow boundary (image-well response); heterogeneity or additional wells also possible | Check geometry and spatial consistency. Helper does not fit image boundaries; a second plateau is not a unique boundary location. |
| Derivative trough followed by rebound | Delayed yield/unconfined response, double porosity, partial penetration or layered flow | Use water-table/screen information, aquifer thickness, multiple depths/distances; compare a suitable unconfined/storage model externally. Do not label a trough “leakage” automatically. |
| Derivative oscillates or changes sign | Measurement precision, corrections, discharge change, recovery, heterogeneity | Retain signed derivative, compare smoothing separation and raw observations. Log plots omit nonpositive points but CSV retains them. |

The helper diagnoses and compares simple candidates; it does not automatically assign a flow regime from a derivative slope. Researcher judgment is needed when geometry and derivative cues conflict.

## Equations and numerical implementation

Theis: `s=Q/(4πT)*E1(u)` and `ds/dln(t)=Q/(4πT)*exp(-u)`.
Cooper–Jacob uses `-gamma-ln(u)`, equivalent to `ln(4 exp(-gamma) Tt/(r²S))`; this avoids rounding 2.2458 to 2.25 in the computational check.
Hantush–Jacob: `W(u,r/B)=integral_u^infinity exp[-y-(r/B)²/(4y)]/y dy`. The helper integrates in log(y) with scipy.quad; the upper tail after y>=50 is negligible for the provided checks. For extreme u/r/B with tiny drawdowns, absolute quadrature tolerance may dominate; assess precision before treating a near-zero fit as informative. The derivative for a constant step is `Q/(4πT)*exp[-u-t/(c*S)]`; steady limit is `2*K0(r/B)`. Superposition requires linear time-invariant aquifer response and known stress history.

Bourdet: with `a=ln(t_i/t_left)` and `b=ln(t_right/t_i)`, derivative is `[(s_i-s_left)/a*b + (s_right-s_i)/b*a]/(a+b)`. Neighbours are the nearest available points at least the chosen log separation away, or the available edge point; endpoints are missing. It is not log(s) differentiation. Wider separation is a sensitivity check, not an improvement guaranteed to preserve regimes.

## Staged examples and independence

Source: TTim repository, commit `e75759040362f010fc0b1a4e74cb20f9b32ee0c1`, `docs/03pumpingtests/`, [upstream source](https://github.com/mbakker7/ttim/tree/e75759040362f010fc0b1a4e74cb20f9b32ee0c1/docs/03pumpingtests). No TTim computation/code is used by this skill. Stored notebook outputs are an independent numerical comparator, **not an independently rerun or independently verified geological truth**. Original field tests are attributed there to Kruseman & de Ridder, *Analysis and Evaluation of Pumping Test Data*, ILRI publication 47. Notebook years differ (1970/1990); keep this discrepancy visible rather than resolving it without a source.

- **Oude Korendijk:** south of Rotterdam, confined aquifer 18–25 m, b=7 m, Q=788 m³/d, radius 0.2 m in notebook model, piezometers at 30/90 m. `piezometer_h*.txt` have header, minutes and negative head change; negate and divide time by 1440. Positive `.dat` variants have no header. Zero-based notebook cells 34–35 give joint no-storage K/Ss and RMSE; converted T=462.6250347025864 m²/d, S=0.00017786101350513936, RMSE=0.050059911747508554 m. Cells 21/30 report individual fits; they do not identify one universally correct site pair. The fixed CJ windows are >=15 min at 30 m and >=120 min at 90 m; they are computational examples subject to early-time/late-boundary expert review. P90 decreases slightly at the end. Notebook's K&dR comparison uses a steady Thiem approximation despite no steady state; do not require transient Theis to match it.
- **Dalem:** b=37 m (8–45 m), Q=761 m³/d, piezometers 30/60/90/120 m; series already tide-corrected, header, time in days and negative head change. Notebook narrative says 8 hours, code shuts off at 0.34 d; last observation is 0.333 d, **no measured recovery**. No measured radius/construction log is supplied; full penetration is a schematic assumption. Cells 31/45 give the no-aquitard-storage joint comparator: T=1677.2876980326907, S=0.0017620324728680494, c=331.18639103690293 d, B=745.3152751970414 m; cell 32 RMSE=0.005916842158003594 m. Cell 30 constructs `m_1` but 31 calibrates prior `ml` with equivalent configuration; this is a stateful-notebook caveat. Excluding P30 drives c to an upper bound near 100000 d; other exclusions span about 181–349 d. Parameter sensitivity is not proof of spatial variation. Different starting values/storage assumptions also change solutions. A decreasing derivative is plausible, but this short record does not show a fully developed zero-derivative regime.

Package `DATA-LICENSE.md` and `TTim-LICENSE` accompany display derivatives. Site points are approximate locality markers, not measured well coordinates. Field checks test notebook-equivalence within predeclared tolerances; constructed tests cover recovery and limiting equations. Domain expert review has not occurred.
