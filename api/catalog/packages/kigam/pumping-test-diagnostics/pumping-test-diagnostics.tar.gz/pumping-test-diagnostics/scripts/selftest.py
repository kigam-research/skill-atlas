"""Small offline analytical smoke check, not evidence of field validity."""
import numpy as np
from pumping import bourdet, theis, superposition, hantush_w
from scipy.special import k0

t = np.geomspace(.01, 1e4, 200)
np.testing.assert_allclose(bourdet(t, 3*np.log(t))[1:-1], 3., atol=1e-12)
np.testing.assert_allclose(theis([1.], 2., 4*np.pi, 1., 1.), [.2193839343955203], rtol=1e-6)
np.testing.assert_allclose(hantush_w(1e-10, .5), 2*k0(.5), rtol=1e-8)
np.testing.assert_allclose(superposition(t, 30, [[0,788],[1,0]], 500,.001),
                           theis(t,30,788,500,.001)-theis(t-1,30,788,500,.001))
print('pumping-test-diagnostics selftest passed')
