"""Read explicit metadata and time/head files; write auditable offline diagnostics."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.special import k0
from pumping import bourdet, fit_model, superposition, cooper_jacob, theis, hantush_w, validate_schedule


def analytical_checks():
    u = np.array([.001,.01,.1,1.,10.])
    ref=np.array([6.331539364136149,4.037929576538114,1.822923958419391,.2193839343955203,4.156968929685325e-6])
    err=float(np.max(np.abs(theis(1/u,2.,4*np.pi,1.,1.)/ref-1)))
    t=np.geomspace(.001,1e4,300)
    d=bourdet(t,theis(t,30,788,500,.001))
    derr=float(np.max(np.abs(d[-20:-1]/(788/(4*np.pi*500))-1)))
    herr=float(abs(hantush_w(1e-10,.5)/(2*k0(.5))-1))
    rerr=float(np.max(np.abs(superposition(t,30,[[0,788],[1,0]],500,.001)-(theis(t,30,788,500,.001)-theis(t-1,30,788,500,.001)))))
    return [dict(id=i,quantity=q,observed=v,expected=0,tolerance=tol,unit='-' if i!='recovery-identity' else 'm',passed=bool(v<=limit),reference=source) for i,q,v,limit,tol,source in [
        ('theis-tabulation','Maximum relative E1 error',err,1e-6,'<=1e-6','E1 decimal tabulation at u=0.001,0.01,0.1,1,10'),
        ('derivative-plateau','Synthetic late Theis derivative relative error',derr,.001,'<=0.001','ds/dln(t)=Q/(4*pi*T)*exp(-u)'),
        ('hantush-steady','Hantush steady-limit relative error',herr,1e-8,'<=1e-8','W(0,r/B)=2*K0(r/B)'),
        ('recovery-identity','Recovery vs two-step identity maximum absolute error',rerr,1e-12,'<=1e-12 m','Theis(t,Q)-Theis(t-tp,Q)')]]


def segmented_derivative(t,s,schedule,spacing):
    # No stencil crosses a rate event. Diagnostic clock is elapsed since first pumping.
    result=np.full_like(s,np.nan)
    starts=np.asarray(schedule)[:,0]
    group=np.searchsorted(starts,t,side='right')
    for g in np.unique(group):
        ix=np.where(group==g)[0]
        if len(ix)>=3: result[ix]=bourdet(t[ix]-schedule[0][0],s[ix],spacing)
    return result


def run(config_path, input_dir, output_dir):
    config=json.loads(config_path.read_text())
    schedule=validate_schedule(config['schedule']).tolist()
    output_dir.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(config_path,output_dir/'config.json')
    records=[]; inputs=[]
    ids=[item['id'] for item in config['observations']]
    if len(set(ids)) != len(ids): raise ValueError('observation ids must be unique')
    for item in config['observations']:
        ident=item['id']
        if not ident or any(c not in 'abcdefghijklmnopqrstuvwxyz0123456789-_' for c in ident):
            raise ValueError('observation id must be a simple filename-safe identifier')
        path=input_dir/item['file']
        a=np.loadtxt(path,skiprows=item.get('skiprows',0),delimiter=item.get('delimiter'))
        if a.ndim!=2 or a.shape[1]<2: raise ValueError('input needs >=2 numeric columns')
        t=a[:,item.get('time_column',0)]*item['time_to_day']
        s=a[:,item.get('head_column',1)]*item['drawdown_sign']
        if item['drawdown_sign'] not in (-1,1): raise ValueError('drawdown_sign must be +1 or -1')
        if item['time_to_day']<=0: raise ValueError('time conversion must be positive')
        if not np.all(np.isfinite(t)) or not np.all(np.isfinite(s)) or np.any(np.diff(t)<=0):
            raise ValueError('original observations must be finite with strictly increasing times; correct or document preprocessing explicitly')
        keep=(t>=item.get('fit_start_day',0)) & (t<=item.get('fit_end_day',np.inf))
        t,s=t[keep],s[keep]
        # Validate before deriving or fitting; no implicit sort/drop/dedup.
        bourdet(t-schedule[0][0],s)
        records.append((item,t,s))
        inputs.append(dict(file=item['file'],sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                           original_rows=len(a),selected_rows=len(t),distance_m=item['distance_m'],
                           time_to_day=item['time_to_day'],drawdown_sign=item['drawdown_sign']))
    observations=[(t,s,i['distance_m']) for i,t,s in records]
    models={}; sensitivity={}; windows={}
    for model in config['models']:
        obs=observations
        if model=='cooper-jacob':
            obs=[(t[t>=i['cj_start_day']],s[t>=i['cj_start_day']],i['distance_m']) for i,t,s in records]
            windows[model]=[dict(id=i['id'],start_day=i['cj_start_day']) for i,_,_ in records]
        fit=fit_model(obs,schedule,model)
        models[model]=fit
        if model=='cooper-jacob':
            models['theis-cj-window']=fit_model(obs,schedule,'theis')
        else:
            # Predefined sensitivity: retain the final 75% of each log-time span.
            trimmed=[(t[t>=schedule[0][0]+np.exp(np.log(t[0]-schedule[0][0])+.25*np.log((t[-1]-schedule[0][0])/(t[0]-schedule[0][0])))],
                      s[t>=schedule[0][0]+np.exp(np.log(t[0]-schedule[0][0])+.25*np.log((t[-1]-schedule[0][0])/(t[0]-schedule[0][0])))],r) for t,s,r in obs]
            alt=fit_model(trimmed,schedule,model)
            sensitivity[model]=dict(rule='trim first 25% of log-time span, per well; not a confidence interval',
                                    alternate=alt,ranges={k:[min(fit[k],alt[k]),max(fit[k],alt[k])] for k in ('T_m2_day','S','B_m','c_day') if k in fit})
    checks=analytical_checks()
    for c in config.get('reference_checks',[]):
        observed=models[c['model']][c['key']]
        if 'maximum' in c:
            expected=f"<= {c['maximum']}"; tol='upper bound'; passed=observed<=c['maximum']
        else:
            expected=c['expected']; threshold=c.get('absolute_tolerance',c.get('relative_tolerance',0)*abs(expected))
            tol=f"absolute +/- {threshold:.12g}"; passed=abs(observed-expected)<=threshold
        checks.append(dict(id=c['id'],quantity=c['quantity'],observed=observed,expected=expected,tolerance=tol,
                           unit=c['unit'],passed=bool(passed),reference=config['reference']))
    if 'cooper-jacob' in models:
        cj=models['cooper-jacob']; other=models['theis-cj-window']
        err=abs(cj['T_m2_day']/other['T_m2_day']-1)
        checks.extend([
            dict(id='cj-theis-t',quantity='CJ vs Theis T on same IARF windows relative difference',observed=err,expected=0,tolerance='<=0.05',unit='-',passed=bool(err<=.05),reference='same predeclared late windows; asymptotic method comparison'),
            dict(id='cj-validity',quantity='Maximum fitted Cooper-Jacob u',observed=cj['max_u'],expected='<=0.01',tolerance='upper bound',unit='-',passed=bool(cj['max_u']<=.01),reference='u=r^2*S/(4*T*t)')])
    plot_stats=[]
    colors={'theis':'#277c8e','cooper-jacob':'#d58b24','hantush-jacob':'#8046a0'}
    for item,t,s in records:
        ident=item['id']; r=item['distance_m']
        elapsed=t-schedule[0][0]
        df=pd.DataFrame(dict(time_day=elapsed,schedule_time_day=t,observed_m=s))
        df['derivative_m']=segmented_derivative(t,s,schedule,.15)
        df['derivative_wide_m']=segmented_derivative(t,s,schedule,.30)
        for model in config['models']:
            fit=models[model]
            if model=='cooper-jacob':
                values=cooper_jacob(elapsed,r,schedule[0][1],fit['T_m2_day'],fit['S'])
                values=np.where(t>=item['cj_start_day'],values,np.nan)
            else: values=superposition(t,r,schedule,fit['T_m2_day'],fit['S'],fit.get('B_m'))
            df[model.replace('-','_')+'_m']=values
            df[model.replace('-','_')+'_residual_m']=values-s
        df.to_csv(output_dir/f'{ident}-diagnostic.csv',index=False,float_format='%.12g',na_rep='')
        fig,ax=plt.subplots(figsize=(7.2,4.4),layout='constrained')
        ax.plot(elapsed,s,'o',ms=4,color='#273d50',label='Observed drawdown')
        ax.set(xlabel='Time since pumping start [d]',ylabel='Drawdown [m]',title=f"{config['title']} / {ident} ({r:g} m)")
        ax.grid(alpha=.25); ax.legend(); fig.savefig(output_dir/f'{ident}-raw.png',dpi=145); plt.close(fig)
        fig,ax=plt.subplots(figsize=(7.2,4.4),layout='constrained')
        ax.loglog(elapsed,np.where(s>0,s,np.nan),'o',ms=4,color='#273d50',label='Observed drawdown')
        d=df['derivative_m'].to_numpy(); dw=df['derivative_wide_m'].to_numpy()
        ax.loglog(elapsed,np.where(d>0,d,np.nan),'x',ms=5,color='#c75728',label='Bourdet derivative (0.15 cycles)')
        ax.loglog(elapsed,np.where(dw>0,dw,np.nan),'.',ms=3,alpha=.55,color='#c75728',label='Derivative (0.30 cycles)')
        for model in config['models']:
            ax.loglog(elapsed,df[model.replace('-','_')+'_m'],color=colors[model],label=model)
        ax.set(xlabel='Time since pumping start [d]',ylabel='Drawdown, ds/d ln(t) [m]',title=f"{config['title']} / {ident}")
        ax.grid(which='both',alpha=.18); ax.legend(fontsize=8)
        fig.savefig(output_dir/f'{ident}-diagnostic.png',dpi=145); plt.close(fig)
        fig,axs=plt.subplots(2,1,figsize=(7.2,5.5),sharex=True,layout='constrained')
        axs[0].semilogx(elapsed,s,'o',ms=4,label='Observed')
        for model in config['models']:
            axs[0].semilogx(elapsed,df[model.replace('-','_')+'_m'],label=model,color=colors[model])
            axs[1].semilogx(elapsed,df[model.replace('-','_')+'_residual_m'],'.-',ms=3,label=model,color=colors[model])
        axs[0].set(ylabel='Drawdown [m]',title=f"{config['title']} / {ident}")
        axs[1].set(xlabel='Time since pumping start [d]',ylabel='Model - observed [m]'); axs[1].axhline(0,color='gray',lw=1)
        for ax in axs: ax.grid(alpha=.2); ax.legend(fontsize=8)
        fig.savefig(output_dir/f'{ident}-semilog-residual.png',dpi=145); plt.close(fig)
        plot_stats.append(dict(id=ident,nonpositive_drawdown=int(np.sum(s<=0)),nonpositive_derivative=int(np.sum(d<=0)),missing_derivative=int(np.sum(~np.isfinite(d)))))
    if (input_dir/'DATA-LICENSE.md').exists(): shutil.copyfile(input_dir/'DATA-LICENSE.md',output_dir/'DATA-LICENSE.md')
    if (input_dir/'LICENSE').exists(): shutil.copyfile(input_dir/'LICENSE',output_dir/'TTim-LICENSE')
    result=dict(config=config,time_origin_day=schedule[0][0],inputs=inputs,models=models,window_sensitivity=sensitivity,windows=windows,
                checks=checks,plot_stats=plot_stats,units=dict(time='d',length='m',rate='m3/d',T='m2/d',S='dimensionless',B='m'),
                limits=['Window envelopes are NOT confidence intervals.','Derivative cues are nonunique; no expert review.','Line-source models omit well storage, skin, partial penetration, aquitard storage and delayed yield.'],
                runtime=dict(python=sys.version.split()[0],numpy=np.__version__))
    (output_dir/'results.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    pd.DataFrame([dict(v, fit_id=k) for k,v in models.items()]).to_csv(output_dir/'model-comparison.csv',index=False)
    print(json.dumps(dict(output=str(output_dir),models=models,checks=checks),indent=2))
    return all(c['passed'] for c in checks)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input-dir',type=Path,required=True,help='named input root resolved by caller')
    parser.add_argument('--config',type=Path,required=True,help='JSON with unit/sign/geometry/rate metadata and windows')
    parser.add_argument('--output-dir',type=Path,default=Path(os.environ['TASK_OUTPUT_DIR']) if 'TASK_OUTPUT_DIR' in os.environ else None)
    args=parser.parse_args()
    if args.output_dir is None: parser.error('--output-dir or TASK_OUTPUT_DIR is required')
    if not run(args.config,args.input_dir,args.output_dir): sys.exit(1)

if __name__=='__main__': main()
