"""Offline line-source pumping-test models. Units: m, d, m3/d, m2/d."""
from __future__ import annotations

import numpy as np
from scipy.integrate import quad
from scipy.optimize import least_squares
from scipy.special import exp1


def _positive(**values):
    for key, value in values.items():
        if np.any(~np.isfinite(value)) or np.any(np.asarray(value) <= 0):
            raise ValueError(f"{key} must be finite and positive")


def theis(t, r, Q, T, S):
    """Positive drawdown for extraction; response is zero at/before the step."""
    _positive(r=r, T=T, S=S)
    t = np.asarray(t, float)
    if not np.all(np.isfinite(t)) or not np.isfinite(Q):
        raise ValueError("non-finite time or rate")
    safe = np.where(t > 0, t, 1.0)
    return np.where(t > 0, Q / (4 * np.pi * T) * exp1(r * r * S / (4 * T * safe)), 0.0)


def hantush_w(u, rho):
    """Integral_u^inf exp(-y-rho^2/(4y))/y dy, log-y quadrature."""
    _positive(u=u)
    if not np.isfinite(rho) or rho < 0:
        raise ValueError("r/B must be finite and nonnegative")
    if rho == 0:
        return exp1(u)
    def one(v):
        if v > 700:
            return 0.0
        return quad(lambda z: np.exp(-np.exp(z) - rho * rho / (4 * np.exp(z))),
                    np.log(v), np.log(max(50., v * 2)), epsabs=1e-10, epsrel=1e-9)[0]
    values = np.asarray(u, float)
    return np.array([one(v) for v in values.ravel()]).reshape(values.shape)


def hantush(t, r, Q, T, S, B):
    """Hantush-Jacob: fixed source head, no aquitard storage, B=sqrt(T*c)."""
    _positive(r=r, T=T, S=S, B=B)
    t = np.asarray(t, float)
    if not np.all(np.isfinite(t)) or not np.isfinite(Q):
        raise ValueError("non-finite time or rate")
    safe = np.where(t > 0, t, 1.)
    w = hantush_w(r * r * S / (4 * T * safe), r / B)
    return np.where(t > 0, Q / (4 * np.pi * T) * w, 0.)


def cooper_jacob(t, r, Q, T, S):
    """Small-u asymptote with exact exp(-Euler gamma) constant; t>0 required."""
    _positive(t=t, r=r, T=T, S=S)
    return Q / (4 * np.pi * T) * (np.log(4 * T * np.asarray(t) / (r * r * S)) - np.euler_gamma)


def validate_schedule(schedule):
    a = np.asarray(schedule, float)
    if a.ndim != 2 or a.shape[1] != 2 or len(a) == 0 or not np.all(np.isfinite(a)):
        raise ValueError("schedule must contain finite [start_day, absolute_rate_m3_day] pairs")
    if a[0, 0] < 0 or np.any(np.diff(a[:, 0]) <= 0):
        raise ValueError("schedule times must increase strictly and be nonnegative")
    return a


def superposition(t, r, schedule, T, S, B=None):
    """Sum rate increments. Shutoff is an absolute rate of zero, NOT a second +Q."""
    a = validate_schedule(schedule)
    result = np.zeros_like(np.asarray(t, float))
    for (start, _), delta in zip(a, np.diff(np.r_[0., a[:, 1]])):
        if B is None:
            result += theis(np.asarray(t) - start, r, delta, T, S)
        else:
            result += hantush(np.asarray(t) - start, r, delta, T, S, B)
    return result


def bourdet(t, s, spacing=0.15):
    """Weighted d(s)/d(ln t), using points at least spacing log10 cycles away.

    Endpoints are missing. No interpolation or log(s) is used; signed derivatives
    remain signed. Small spacing increases noise; never span a rate change.
    """
    t, s = np.asarray(t, float), np.asarray(s, float)
    _positive(t=t, spacing=spacing)
    if t.ndim != 1 or s.shape != t.shape or len(t) < 3 or np.any(np.diff(t) <= 0) or not np.all(np.isfinite(s)):
        raise ValueError("need >=3 finite samples at strictly increasing positive times")
    x = np.log(t)
    width = spacing * np.log(10)
    out = np.full_like(s, np.nan)
    for i in range(1, len(t)-1):
        left = max(0, min(i-1, np.searchsorted(x, x[i]-width, side='right')-1))
        right = min(len(t)-1, max(i+1, np.searchsorted(x, x[i]+width)))
        a, b = x[i]-x[left], x[right]-x[i]
        out[i] = ((s[i]-s[left])/a*b + (s[right]-s[i])/b*a)/(a+b)
    return out


def fit_model(observations, schedule, model='theis', initial=(500., 1e-3, 500.), u_limit=0.01):
    """Joint unweighted head residuals across explicit per-well windows.

    observations: list of (time_day, drawdown_m, distance_m). Bounds are broad
    engineering limits, not priors or scientific validity. Check hit_bounds.
    """
    schedule = validate_schedule(schedule)
    if model not in ('theis', 'cooper-jacob', 'hantush-jacob'):
        raise ValueError("unsupported model")
    if model == 'cooper-jacob' and (len(schedule) != 1 or schedule[0, 1] <= 0):
        raise ValueError("Cooper-Jacob fitting needs a single positive constant-rate step")
    prepared = []
    for t, s, r in observations:
        t, s = np.asarray(t, float), np.asarray(s, float)
        _positive(t=t, r=r)
        if t.ndim != 1 or s.shape != t.shape or np.any(np.diff(t) <= 0) or not np.all(np.isfinite(s)):
            raise ValueError("observations need finite, strictly increasing samples")
        if np.any(t <= schedule[0, 0]):
            raise ValueError("fit samples must follow pumping start")
        prepared.append((t, s, r))
    npar = 3 if model == 'hantush-jacob' else 2
    if sum(len(t) for t, _, _ in prepared) <= npar:
        raise ValueError("insufficient observations for fit")
    def predict(p, t, r):
        if model == 'cooper-jacob':
            return cooper_jacob(t-schedule[0, 0], r, schedule[0, 1], *p)
        return superposition(t, r, schedule, *p)
    def residual(logp):
        p = np.exp(logp)
        return np.concatenate([predict(p, t, r)-s for t, s, r in prepared])
    lower = np.array([1e-3, 1e-10, 1.])[:npar]
    upper = np.array([1e7, 1., 1e7])[:npar]
    result = least_squares(residual, np.log(initial[:npar]), bounds=(np.log(lower), np.log(upper)),
                           xtol=1e-10, ftol=1e-10, gtol=1e-10)
    if not result.success:
        raise RuntimeError(result.message)
    p = np.exp(result.x)
    max_u = max(float(np.max(r*r*p[1]/(4*p[0]*(t-schedule[0, 0])))) for t, _, r in prepared)
    if model == 'cooper-jacob' and max_u > u_limit:
        raise ValueError(f"Cooper-Jacob window invalid: max u={max_u:.6g} > {u_limit}")
    res = residual(result.x)
    answer = dict(zip(('T_m2_day', 'S', 'B_m')[:npar], map(float, p)))
    answer.update(model=model, rmse_m=float(np.sqrt(np.mean(res**2))), n=len(res),
                  max_u=max_u, hit_bounds=bool(np.any(result.active_mask)),
                  jacobian_condition=float(np.linalg.cond(result.jac)))
    if npar == 3:
        answer['c_day'] = float(p[2]**2/p[0])
    return answer
