"""Optional bagging-PU index skeleton; caller owns estimator and scientific choices.

Pass ONLY the current training partition's observed labels: 1=P, 0=U.
Indices are local to that vector, NOT global row IDs. Each member uses every P
and a fresh subset of U, sampled without replacement within the member.
U is a temporary training class, not confirmed absence. This is neither Spy-EM
nor the outer spatial bootstrap used to assess model stability.

Example inside an already isolated train partition::

    members = bagging_indices(y_train, n_members=T,
                              unlabeled_per_member=n_u, seed=seed)
    # Preprocessing must also be train-local; keep model/row-ID provenance.
    for k, idx in enumerate(members):
        model = make_estimator(seed + k)  # caller selects estimator/parameters
        model.fit(X_train[idx], y_train[idx])
        predictions.append(model.predict_proba(X_test)[:, 1])
    score = np.mean(predictions, axis=0)  # keep fitted members, not just score

The P-preserving/U-resampling structure is adapted from bagging PU (Mordelet & Vert,
https://arxiv.org/abs/1010.0772). This helper uses WITHOUT-replacement U subsets, unlike their bootstrap scheme.
Their bagging-SVM uses SVM (the paper also experiments with logistic regression); another learner is
an adaptation, not exact reproduction. The aggregate is a ranking score, not
a calibrated geological probability. Tune T/n_u only within training folds.
For transductive U ranking, caller may average only members that did not train
on each U cell, saving the contributing-member count. That OOB policy differs
from full-fit all-member scoring and is not spatially held-out evaluation.
"""
import operator
import warnings

import numpy as np


def _positive_integer(value, name):
    try:
        if isinstance(value, (bool, np.bool_)):
            raise TypeError
        result = operator.index(value)
    except TypeError as exc:
        raise ValueError(f"{name} must be a positive integer") from exc
    if result < 1:
        raise ValueError(f"{name} must be a positive integer")
    return result


def bagging_indices(observed_labels, *, n_members, unlabeled_per_member, seed, replace=False):
    """Return a list of local train-index arrays; no fit or label mutation.

    Explicit support counts avoid silently changing the agent's sampling plan.
    Reusing the seed gives the same member prefix when T changes. Identical
    predictions can still occur for valid learners: subset diversity is not
    proof of model diversity, and numerical differences are not proof of PU.
    """
    y = np.asarray(observed_labels)
    if y.ndim != 1 or not len(y) or not np.isin(y, [0, 1]).all():
        raise ValueError("One-dimensional observed labels 1=P, 0=U required")
    positive = np.flatnonzero(y == 1)
    unlabeled = np.flatnonzero(y == 0)
    if not len(positive) or not len(unlabeled):
        raise ValueError("Both P and U are required in this training partition")
    count = _positive_integer(n_members, "n_members")
    size = _positive_integer(unlabeled_per_member, "unlabeled_per_member")
    if size > len(unlabeled) and not replace:
        raise ValueError("Requested U subset exceeds available train U; revise the plan explicitly")
    if size == len(unlabeled) and count > 1:
        warnings.warn("Every member uses all U: no PU subset diversity; repetition adds no resampling information", RuntimeWarning, stacklevel=2)
    try:
        if isinstance(seed, (bool, np.bool_)):
            raise TypeError
        seed = operator.index(seed)
    except TypeError as exc:
        raise ValueError("Explicit nonnegative integer seed required") from exc
    if seed < 0:
        raise ValueError("Explicit nonnegative integer seed required")
    children = np.random.SeedSequence(seed).spawn(count)
    return [np.concatenate([positive, np.random.default_rng(child).choice(unlabeled, size=size, replace=replace)])
            for child in children]


class BaggingPU:
    """Bagging PU ensemble: each member fits every P and a fresh U subset treated as the other class.

    `make_learner(seed)` returns an unfitted classifier with fit/predict_proba. `unlabeled_fraction` of
    the training U per member (replace=True draws a bootstrap U sample). The mean member probability is
    a ranking score, not a calibrated probability of occurrence.
    """
    def __init__(self, make_learner, *, n_members, unlabeled_fraction, seed, replace=False):
        self.make_learner, self.n_members, self.unlabeled_fraction = make_learner, n_members, unlabeled_fraction
        self.seed, self.replace = seed, replace

    def fit(self, X, y):
        y = np.asarray(y).astype(int)
        size = max(1, int(round(self.unlabeled_fraction * int((y == 0).sum()))))
        with warnings.catch_warnings():
            warnings.simplefilter('ignore', RuntimeWarning)  # all-U members are allowed when the fraction is 1
            members = bagging_indices(y, n_members=self.n_members, unlabeled_per_member=size, seed=self.seed,
                                      replace=self.replace)
        self.members_ = [self.make_learner(self.seed + k).fit(X[i], y[i]) for k, i in enumerate(members)]
        return self

    def member_predictions(self, X):
        return np.array([m.predict_proba(X)[:, 1] for m in self.members_])

    def predict_proba(self, X):
        p = self.member_predictions(X).mean(axis=0)
        return np.column_stack([1 - p, p])

