"""Stage evidence from saved tables: the default way to draw M0–M6 evidence figures.

    uv run python <skill>/assets/stage_evidence.py template INPUT.csv [--metadata META.json] > SPEC.json
    uv run python <skill>/assets/stage_evidence.py render SPEC.json
    uv run python <skill>/assets/stage_evidence.py check FIGURE_DIR [MORE_DIRS...] [--report REPORT.md]

`template` writes a first spec from the input table (guessed columns, CRS from metadata when found).
Check every guess, then render M0–M2 at once; add later stages to the same spec as their tables are
saved and render again.

`render` reads the tables the analysis already saved and draws each stage's evidence with
checked helpers: cell-support maps that name the CRS, P/U distributions, correlations,
distance dependence with pair counts, held-out assignment with support, held-out
evaluation, stability, score roles, zones, candidate and far-target zooms. Nothing is fitted and no
method is chosen here. Every figure is saved through figure_style.save_figure, which
rejects missing glyphs, maps without a CRS and dependence plots without pair counts, and
adds an entry (stage, question, source tables with sha256, checks) to figure-records.json.

`check` lists every PNG under the folders, says which ones have no record (drawn outside
the checked path) and repeats recorded layout warnings. Open every PNG afterwards: passing
checks is not an inspection.

SPEC.json (relative paths resolve against the current directory; omit stages you do not
have — the summary lists them as not drawn):

{
  "out": "figures",
  "cells": {"table": "data/cells.csv", "id": "cell_id", "x": "x", "y": "y", "unit": "m",
            "crs": "EPSG:<code>", "spacing": [5000, 5000], "label": "label",
            "positive": 1, "unlabeled": 0, "class_names": ["Recorded positive", "Unlabeled"]},
  "predictors": [{"column": "tmi", "title": "TMI", "unit": "nT", "map": true,
                  "display": "symlog", "linthresh": 50, "cmap": "RdBu_r"}],
  "dependence": {"edges": [0, 5000, 10000]} | {"table": "...", "distance": "lag_m",
                 "value": "gamma", "pairs": "n_pairs", "variable": "label"},
  "assignment": {"table": "...", "id": "cell_id", "group": "fold", "block": "block"},
                 (block_design.py writes split/split_manifest.csv with "outer_fold" and "block")
  "heldout": {"table": "...", "id": "cell_id", "group": "fold", "scores": {"RF": "rf_oof"}}
             | {"table": "...", "id": "cell_id", "group": "fold", "model": "model", "score": "score"},
  "scores": {"table": "...", "id": "cell_id",
             "columns": [{"column": "rf_oof", "role": "held-out"},
                         {"column": "rf_full", "role": "full-fit"}]},
  "stability": {"table": "...", "id": "cell_id", "column": "seed_sd",
                "what": "SD over 20 RF seeds, same data (not data or spatial uncertainty)",
                "score": "rf_full"},
  "zones": {"table": "...", "id": "cell_id", "column": "zone", "order": ["High", "Medium", "Low"], "colors": [...],
            "score_role": "full-fit", "rule": "top 10% / next 20% of full-fit score"},
  "zone_rules": {"score": "rf_oof", "score_role": "held-out", "fractions": [0.05, 0.1, 0.2], "chosen": 0.1},
                 (an optional top-fraction comparison; fractions from the purpose or budget)
  "candidates": {"table": "...", "id": "cell_id", "column": "candidate", "score": "rf_oof",
                 "score_role": "held-out", "max": 3},
  "far_targets": {...same keys as candidates..., "notes": {"F01": "outside screen"}}
                 (optional: best-ranked cells away from recorded positives; pu_workflow fills it; "notes"
                 are shown under each zoom title, here and in "candidates")
}

A predictor with "type": "categorical" (rock unit, land cover, ...) is mapped by class, compared by class
composition of P and U (m1_categories.png) and kept out of correlations and percentiles; its "expect"
lists the favourable classes.
Predictors may carry "role" (e.g. "geology", "geophysics", "geochemistry", "availability") for the
candidate profile (m7_candidate_profiles.png, m7_candidate_evidence.csv), and "expect": "high" | "low"
with "basis" (the reason from the domain model, e.g. a deposit or hazard model) where it predicts a direction. M1 then compares it with
the P/U difference (m1_expectation_check.csv) and M7 marks which side of the median each candidate is.
When a few extreme cells take most of a predictor's range, its M0 map colour is clipped at the
2nd-98th percentile (stated on the colour bar and in the notes; values unchanged). Give
"limits": [low, high] or "limits": "full" to choose otherwise.

Any stage table may add "where" to keep matching rows of a long table (one row per cell and
model or split), e.g. "assignment": {..., "where": {"model": "rf"}}.
A score column ("scores".columns[], "stability".column/score, "candidates"/"far_targets".score) is a name in the
stage's own table or the scores table, or {"table", "id", "column", "where": {"model": "rf"}} for
any saved table; a scores entry may also give "name" for display.
A unit of "degree" draws geographic maps; distance-based stages then need projected
coordinates and are skipped with a note. A Mercator CRS (e.g. EPSG:3857) keeps map units: its
distances are ground distances / cos(latitude), so the summary notes it and areas are left out. Copy and adapt when the data need another view.
"""
from pathlib import Path
import argparse
import importlib.util
import json
import re
import sys
import textwrap

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent


def _load(name):
    spec = importlib.util.spec_from_file_location(name, HERE / f'{name}.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


figure_style, grid_map, eda_view, variogram, evaluation_view = (
    _load(n) for n in ('figure_style', 'grid_map', 'eda_view', 'variogram', 'evaluation_view'))
P_MARK = dict(marker='*', s=46, c='black', edgecolors='white', linewidths=.5, zorder=5)
GROUP_COLORS = ['#4C72B0', '#DD8452', '#55A868', '#8172B3', '#937860', '#DA8BC3', '#8C8C8C', '#CCB974',
                '#64B5CD', '#C44E52']
ZONE_COLORS = ['#b2182b', '#ef8a62', '#fddbc7', '#d1e5f0', '#67a9cf', '#2166ac']


class Cells:
    """The input cell table with its geometry, labels and display conversion."""

    def __init__(self, spec):
        c = spec['cells']
        self.source = Path(c['table'])
        frame = pd.read_csv(self.source)
        self.id, self.xcol, self.ycol, self.label = c['id'], c['x'], c['y'], c['label']
        if frame[self.id].duplicated().any():
            raise ValueError(f'{self.source}: duplicate {self.id}')
        if not np.isfinite(frame[[self.xcol, self.ycol]].to_numpy(float)).all():
            raise ValueError(f'{self.source}: non-finite coordinates')
        self.positive, self.unlabeled = c.get('positive', 1), c.get('unlabeled', 0)
        if not frame[self.label].isin([self.positive, self.unlabeled]).all():
            raise ValueError(f'{self.label}: values other than {self.positive}/{self.unlabeled}')
        self.class_names = c.get('class_names', ['Recorded positive', 'Unlabeled (not a confirmed negative)'])
        self.short = c.get('class_short', ['P', 'U'])  # e.g. ['P', 'N'] for positive/negative labels
        self.unit, self.crs = c['unit'], c['crs']
        if not str(self.crs).strip() or str(self.crs).strip().lower() in ('unknown', 'none', 'epsg:????'):
            raise ValueError('cells.crs: name the CRS of the coordinates (e.g. an EPSG code or a projection name); do not draw maps without it')
        nodata = c.get('nodata', [])  # sentinel values, for all columns or {column: [values]}
        self.nodata_counts = {}
        for column in frame.columns:
            values = nodata.get(column, []) if isinstance(nodata, dict) else nodata
            if values and column not in (self.id, self.xcol, self.ycol, self.label):
                hit = frame[column].isin(values)
                if hit.any():
                    self.nodata_counts[column] = int(hit.sum())
                    frame.loc[hit, column] = np.nan
        self.frame = frame.set_index(self.id, drop=False)
        self.frame.index = self.frame.index.astype(str)
        self.is_p = (self.frame[self.label] == self.positive).to_numpy()
        scale = 1000.0 if self.unit == 'm' else 1.0
        self.display_unit = 'km' if self.unit == 'm' else self.unit
        self.x = self.frame[self.xcol].to_numpy(float) / scale
        self.y = self.frame[self.ycol].to_numpy(float) / scale
        self.spacing = (c['spacing'][0] / scale, c['spacing'][1] / scale)
        self.projected = self.unit in ('m', 'km')
        self.latitude = float(np.mean(self.y)) if not self.projected else None
        # Mercator map distance = ground distance / cos(latitude): distances and areas are map units only.
        self.mercator = self.projected and bool(re.search(r'mercator|\b(3857|3395|900913)\b', str(self.crs), re.I))
        self.placement = None
        try:  # maps assume an axis-aligned regular grid of cells
            grid_map.cell_grid(self.x, self.y, np.zeros(len(self.x)), spacing=self.spacing)
            self.grid_problem = None
        except ValueError as e:
            try:  # e.g. aggregated edge blocks whose mean coordinates sit off the block centre
                *_, cx, cy, record = grid_map.grid_indices(self.x, self.y, spacing=self.spacing)
                share = record['max_shift'] / min(self.spacing)
                self.placement = {**record, 'max_shift_cells': share, 'unit': self.display_unit,
                                  'max_shift_text': f"largest move {record['max_shift']:.4g} {self.display_unit} "
                                                    f"= {share:.0%} of a cell spacing"}
                self.x, self.y = cx, cy
                self.grid_problem = None
            except ValueError as e2:
                self.grid_problem = f'cell maps need an axis-aligned regular grid: {e}; {e2}'

    def join(self, table, id_col, columns, stage, where=None):
        """Values of `columns` aligned to every input cell (NaN where the table has no row).

        `where` keeps rows whose columns equal the given values, e.g. {"model": "rf"} in a long table."""
        frame = pd.read_csv(table)
        for key, value in (where or {}).items():
            frame = frame[frame[key].astype(str) == str(value)]
        frame[id_col] = frame[id_col].astype(str)
        if frame[id_col].duplicated().any():
            raise ValueError(f'{stage}: duplicate {id_col} in {table}')
        unknown = set(frame[id_col]) - set(self.frame.index)
        if unknown:
            raise ValueError(f'{stage}: {len(unknown)} ids in {table} are not input cells (e.g. {sorted(unknown)[:3]})')
        missing = [c for c in columns if c not in frame.columns]
        if missing:
            raise ValueError(f'{stage}: columns {missing} not in {table}')
        return frame.set_index(id_col).reindex(self.frame.index)[columns]

    def map_panel(self, ax, values, *, title, unit='', categories=None, markers=True, **kw):
        info = grid_map.raster_map(ax, self.x, self.y, np.asarray(values, float), spacing=self.spacing, name=title,
                                   value_unit=unit, categories=categories, **kw)
        figure_style.map_axes(ax, projected=self.projected, unit=self.display_unit, crs=self.crs,
                              latitude=self.latitude)
        if markers:
            ax.scatter(self.x[self.is_p], self.y[self.is_p], label=f'{self.class_names[0]} ({self.short[0]}) cell', **P_MARK)
        return info

    def group_edges(self, ax, groups, *, label=None, color='white'):
        """Draw cell edges where neighbouring cells belong to different groups (e.g. held-out folds)."""
        from matplotlib.collections import LineCollection
        codes = pd.Series(groups).astype('category').cat.codes.to_numpy(float)
        codes[pd.isna(groups)] = np.nan
        xe, ye, z = grid_map.cell_grid(self.x, self.y, codes, spacing=self.spacing)
        z = np.ma.filled(z.astype(float), np.nan)
        segments = []
        for i in range(z.shape[0]):
            for j in range(z.shape[1] - 1):
                a, b = z[i, j], z[i, j + 1]
                if np.isfinite(a) and np.isfinite(b) and a != b:
                    segments.append([(xe[j + 1], ye[i]), (xe[j + 1], ye[i + 1])])
        for i in range(z.shape[0] - 1):
            for j in range(z.shape[1]):
                a, b = z[i, j], z[i + 1, j]
                if np.isfinite(a) and np.isfinite(b) and a != b:
                    segments.append([(xe[j], ye[i + 1]), (xe[j + 1], ye[i + 1])])
        ax.add_collection(LineCollection(segments, colors=color, linewidths=1.4, label=label, zorder=4))

    def figsize(self, ncols, nrows, panel_width=5.2):
        w, h = grid_map.map_figsize(self.x, self.y, spacing=self.spacing, ncols=ncols, nrows=nrows,
                                    panel_width=panel_width)
        return w, min(h, 3 * panel_width * nrows + 1.6 * nrows)  # cap very tall, thin areas


def category_colorbar(ax, info, categories, *, location='bottom'):
    """A colorbar-shaped key for a categorical raster, so it lines up with value panels."""
    from matplotlib.cm import ScalarMappable
    from matplotlib.colors import BoundaryNorm, ListedColormap
    names = ['\n'.join(textwrap.wrap(v[0], 22)) for v in categories.values()]  # long class names wrap, not collide
    colors = [v[1] for v in categories.values()]
    if info['absent_cells']:
        names.append('No input cell')
        colors.append('#FFFFFF')
    mappable = ScalarMappable(norm=BoundaryNorm(np.arange(len(names) + 1) - .5, len(names)), cmap=ListedColormap(colors))
    fig = ax.figure
    constrained = type(fig.get_layout_engine()).__name__ == 'ConstrainedLayoutEngine'
    cb = fig.colorbar(mappable, ax=ax, location=location, pad=.02 if constrained else .12, fraction=.04,
                      ticks=np.arange(len(names)))
    cb.ax.set_xticklabels(names) if location in ('bottom', 'top') else cb.ax.set_yticklabels(names)
    cb.outline.set_edgecolor('#888888')
    grid_map.fit_colorbar_to_map(ax, cb, location)
    return cb


CATEGORY_COLORS = ['#1b9e77', '#d95f02', '#7570b3', '#e7298a', '#66a61e', '#e6ab02', '#a6761d', '#666666']


def is_categorical(p):
    return p.get('type') == 'categorical'


def category_codes(series, max_categories=8):
    """Codes of the most frequent categories (the rest pooled as 'other'); missing stays missing."""
    if pd.api.types.is_numeric_dtype(series):
        series = series.map(lambda v: f'{v:g}' if pd.notna(v) else None)
    raw = series.astype('string')
    counts = raw.value_counts(dropna=True)
    pooled = len(counts) > max_categories
    keep = list(counts.index[:max_categories - 1] if pooled else counts.index)
    code = raw.map({v: i for i, v in enumerate(keep)}).astype('Float64')
    if pooled:
        code[raw.notna() & code.isna()] = len(keep)
    return code.to_numpy(dtype=float, na_value=np.nan), keep + (['other'] if pooled else [])


class Renderer:
    def __init__(self, spec):
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        self.plt = plt
        self.spec = spec
        self.out = Path(spec.get('out', 'figures'))
        self.out.mkdir(parents=True, exist_ok=True)
        figure_style.apply_style()
        self.cells = Cells(spec)
        self.summary = {'figures': [], 'tables': [], 'not_drawn': [], 'notes': []}
        if self.cells.placement:
            self.summary['notes'].append({'stage': 'cells', 'kind': 'grid placement', **self.cells.placement,
                                          'note': 'cells whose coordinates are off the grid (e.g. averaged centres of '
                                                  'partial edge blocks) are drawn and measured at the centre of the grid '
                                                  'cell that holds them'})
        if self.cells.mercator:
            note = {'stage': 'cells', 'kind': 'map-unit distances', 'crs': self.cells.crs,
                    'interpret': 'Mercator coordinates: a map distance is the ground distance / cos(latitude) (about '
                    '1.15 at 30 degrees, 1.41 at 45). Lags, ranges, block sizes and candidate distances here are map '
                    'units, and zone-rule areas are left out. Reproject to a local projected CRS (e.g. UTM) for '
                    'distances and an equal-area CRS for areas, or report the factor'}
            if re.search(r'\b(3857|900913)\b', str(self.cells.crs)):  # spherical, no false northing
                lat = np.degrees(2 * np.arctan(np.exp(np.array([self.cells.y.min(), self.cells.y.max()])
                                                      * (1000.0 if self.cells.display_unit == 'km' else 1.0) / 6378137.0)) - np.pi / 2)
                note['latitude_range'] = [round(float(v), 2) for v in sorted(lat)]
                note['map_to_ground_factor'] = [round(float(1 / np.cos(np.radians(v))), 3) for v in sorted(np.abs(lat))]
            self.summary['notes'].append(note)

    def save(self, fig, name, *, stage, question, sources, maps=(), dependence=False, **extra):
        record = {'stage': stage, 'question': question, 'sources': [str(s) for s in sources], **extra}
        png = figure_style.save_figure(fig, self.out / name, maps=maps, crs=self.cells.crs if maps else None,
                                       dependence=dependence, record=record)
        self.plt.close(fig)
        self.summary['figures'].append({'file': str(png), 'stage': stage, 'question': question})
        return png

    def table(self, frame, name):
        path = self.out / name
        frame.to_csv(path, index=False)
        self.summary['tables'].append(str(path))
        return path

    # M0/M1 -----------------------------------------------------------------
    def domain(self):
        c = self.cells
        panels = [p for p in self.spec.get('predictors', []) if p.get('map', True)][:8]
        n = 1 + len(panels)
        ncols = 2 if n in (2, 4) else min(3, n)
        nrows = int(np.ceil(n / ncols))
        fig, axes = self.plt.subplots(nrows, ncols, figsize=c.figsize(ncols, nrows), layout='constrained', squeeze=False)
        cats = {0: (f'{c.class_names[1]} ({c.short[1]})', '#cfcfcf'), 1: (f'{c.class_names[0]} ({c.short[0]})', '#d62728')}
        first = c.map_panel(axes.flat[0], c.is_p.astype(int), title=f'Recorded label: {int(c.is_p.sum())} of {len(c.x)} cells',
                            categories=cats, markers=False)
        category_colorbar(axes.flat[0], first, cats, location='bottom')
        maps, stretched = [axes.flat[0]], []
        for ax, p in zip(axes.flat[1:], panels):
            if is_categorical(p):
                codes, names = category_codes(c.frame[p['column']])
                pcats = {i: (n, CATEGORY_COLORS[i % len(CATEGORY_COLORS)]) for i, n in enumerate(names)}
                info = c.map_panel(ax, codes, title=p.get('title', p['column']), categories=pcats)
                category_colorbar(ax, info, pcats, location='bottom')
                maps.append(ax)
                continue
            values = pd.to_numeric(c.frame[p['column']], errors='coerce').to_numpy(float)
            kw = {'cmap': p.get('cmap', 'viridis'), 'colorbar_location': 'bottom'}
            unit = p.get('unit') or 'unit not given'
            if p.get('limits') == 'full':
                pass
            elif p.get('limits'):
                kw['limits'] = tuple(p['limits'])
            else:
                # A few extreme cells otherwise take the whole colour range. Colour only; values are kept.
                v = values[np.isfinite(values)]
                lo, hi = np.percentile(v, [2, 98]) if len(v) else (np.nan, np.nan)
                if len(v) and lo < hi and hi - lo < .5 * (v.max() - v.min()):
                    kw['limits'] = (float(lo), float(hi))
                    kw['colorbar_label'] = f"{p.get('title', p['column'])} ({unit}); colour 2-98th pct"
            info = c.map_panel(ax, values, title=p.get('title', p['column']), unit=unit, **kw)
            if 'colorbar_label' in kw:
                stretched.append({'column': p['column'], 'colour_limits': list(kw['limits']),
                                  'cells_below': info['clipped_low'], 'cells_above': info['clipped_high']})
            maps.append(ax)
        if stretched:
            self.summary['notes'].append({'stage': 'M0', 'kind': 'colour stretch', 'columns': stretched,
                                          'interpret': 'map colours are clipped at the 2nd-98th percentile (arrows on the '
                                          'colour bar); values are not changed. Set "limits" per predictor, or "full"'})
        for ax in list(axes.flat)[n:]:
            ax.set_visible(False)
        fig.suptitle(f'Stars: {c.class_names[0]} ({c.short[0]}) cells', fontsize=10)
        return self.save(fig, 'm0_domain', stage='M0/M1', maps=maps, sources=[c.source],
                         question='What is analysed where: every input cell, its recorded label and the main predictors')

    def expectation_checks(self):
        """Compare the P/U difference with the direction the domain model (e.g. a deposit model) leads one to expect ("expect": high|low).

        P are recorded positives and U unlabeled cells (not negatives), so a P/U difference is weaker than a
        positive/background difference would be. A P/U difference against the expectation is a question for the
        interpretation (label mix, proxy, support, scale), not proof that the model is wrong."""
        from scipy.stats import mannwhitneyu
        c = self.cells
        declared = [p for p in self.spec.get('predictors', []) if p.get('expect')]
        if not declared:
            self.summary['notes'].append({'stage': 'M1', 'kind': 'no expectations',
                                          'note': 'no predictor declares "expect" (high/low) and "basis" from the domain '
                                                  'model; the report has to link predictors to the model some other way'})
            return None
        rows = []
        for p in declared:
            if is_categorical(p):
                if not isinstance(p['expect'], list):
                    raise ValueError(f"{p['column']}: a categorical expect lists the favourable categories")
                raw = c.frame[p['column']]
                raw = raw.map(lambda v: f'{v:g}' if isinstance(v, (int, float)) and pd.notna(v) else v).astype('string')
                ok = raw.notna().to_numpy()
                fav = raw.isin([str(v) for v in p['expect']]).to_numpy() & ok
                sp = float(fav[c.is_p & ok].mean()) if (c.is_p & ok).any() else np.nan
                su = float(fav[~c.is_p & ok].mean()) if (~c.is_p & ok).any() else np.nan
                rows.append({'column': p['column'], 'expect': 'in ' + ', '.join(map(str, p['expect'])), 'basis': p.get('basis', ''),
                             f'{c.short[0]}_valid': int((c.is_p & ok).sum()), f'{c.short[1]}_valid': int((~c.is_p & ok).sum()),
                             f'prob_{c.short[0]}_above_{c.short[1]}': np.nan, f'{c.short[0]}_median_percentile': np.nan,
                             f'{c.short[0]}_share_in_expected': sp, f'{c.short[1]}_share_in_expected': su,
                             'observed': 'not evaluated' if not np.isfinite([sp, su]).all() else
                             f'{c.short[0]} more often in them' if sp > su else f'{c.short[0]} not more often in them'})
                continue
            if p['expect'] not in ('high', 'low'):
                raise ValueError(f"{p['column']}: expect must be 'high' or 'low'")
            v = pd.to_numeric(c.frame[p['column']], errors='coerce').to_numpy(float)
            ok = np.isfinite(v)
            vp, vu = v[ok & c.is_p], v[ok & ~c.is_p]
            prob = float(mannwhitneyu(vp, vu).statistic / (len(vp) * len(vu))) if len(vp) and len(vu) else np.nan
            rows.append({'column': p['column'], 'expect': p['expect'], 'basis': p.get('basis', ''),
                         f'{c.short[0]}_valid': int(len(vp)), f'{c.short[1]}_valid': int(len(vu)),
                         f'prob_{c.short[0]}_above_{c.short[1]}': prob,
                         f'{c.short[0]}_median_percentile': float(np.mean(v[ok] <= np.median(vp)) * 100) if len(vp) else np.nan,
                         'observed': 'not evaluated' if not np.isfinite(prob) else 'no clear difference' if abs(prob - .5) < .05
                         else f'{c.short[0]} higher' if prob > .5 else f'{c.short[0]} lower'})
        table = pd.DataFrame(rows)
        expected = table['expect'].map({'high': f'{c.short[0]} higher', 'low': f'{c.short[0]} lower'})
        expected = expected.where(~table['expect'].astype(str).str.startswith('in '), f'{c.short[0]} more often in them')
        table['agrees'] = table['observed'] == expected
        self.table(table, 'm1_expectation_check.csv')
        off = table[~table['agrees']]
        if len(off):
            self.summary['notes'].append({'stage': 'M1', 'kind': 'expectation check',
                                          'interpret': 'say for each why recorded positives do not show the expected '
                                          'direction (label mix, proxy, support, scale, or the hypothesis) and what you did '
                                          'with the predictor',
                                          'columns': off[['column', 'expect', 'observed', f'prob_{c.short[0]}_above_{c.short[1]}']].to_dict('records')})
        missing_basis = [p['column'] for p in declared if not str(p.get('basis', '')).strip()]
        if missing_basis:
            self.summary['notes'].append({'stage': 'M1', 'kind': 'expectation without basis', 'columns_without_basis': missing_basis,
                                          'note': 'give the domain-model reason ("basis") for each expectation'})
        return table

    def value_checks(self):
        """Missing, negative and extreme values per predictor, for the analyst to interpret (valid value or marker?)."""
        c, rows = self.cells, []
        for p in self.spec.get('predictors', []):
            if is_categorical(p):
                continue
            raw = c.frame[p['column']]
            v = pd.to_numeric(raw, errors='coerce')
            ok = v.dropna()
            rows.append({'column': p['column'], 'unit': p.get('unit', ''), 'n': int(len(v)),
                         'missing': int(v.isna().sum()), 'non_numeric': int((v.isna() & raw.notna()).sum()),
                         'negative': int((ok < 0).sum()), 'zero': int((ok == 0).sum()),
                         'min': float(ok.min()) if len(ok) else None, 'p01': float(ok.quantile(.01)) if len(ok) else None,
                         'median': float(ok.median()) if len(ok) else None, 'p99': float(ok.quantile(.99)) if len(ok) else None,
                         'max': float(ok.max()) if len(ok) else None,
                         'most_common_value_share': float(ok.value_counts(normalize=True).iloc[0]) if len(ok) else None})
        table = pd.DataFrame(rows)
        spread = (table['p99'] - table['median']).abs()
        body = (table['median'] - table['p01']).abs().replace(0, np.nan)
        table['long_upper_tail'] = (spread / body > 5) | (table['max'] > table['p99'] + 3 * spread)
        table['dominant_value'] = table['most_common_value_share'] > .5
        self.table(table, 'm1_value_checks.csv')
        shape = table[table['long_upper_tail'] | table['dominant_value']]
        if len(shape):
            self.summary['notes'].append({'stage': 'M1', 'kind': 'distribution shape', 'interpret': 'say for each how the long tail or dominant value '
                                          '(e.g. many zeros) was handled (kept, transformed, binned, why) and what the P/U '
                                          'comparison changed in your choices',
                                          'columns': shape[['column', 'median', 'p99', 'max', 'most_common_value_share']].to_dict('records')})
        flagged = table[(table['negative'] > 0) | (table['non_numeric'] > 0) | (table['min'] <= -999)]
        if len(flagged):
            self.summary['notes'].append({'stage': 'M1', 'kind': 'negative or non-numeric values',
                                          'interpret': 'say for each whether these are valid values or '
                                          'missing markers, and what you did with them',
                                          'columns': flagged[['column', 'negative', 'non_numeric', 'min']].to_dict('records')})

    def distributions(self):
        c = self.cells
        preds = [p for p in self.spec.get('predictors', []) if not is_categorical(p)]
        self.value_checks()
        self.expectation_checks()
        files = [self.categories()] if any(is_categorical(p) for p in self.spec.get('predictors', [])) else []
        per = int(np.ceil(len(preds) / max(1, int(np.ceil(len(preds) / 16)))))  # balanced figures of up to 16 panels
        for k in range(0, len(preds), per):
            chunk = preds[k:k + per]
            titles = {p['column']: p.get('title', p['column']) for p in chunk}
            frame = c.frame[list(titles)].apply(pd.to_numeric, errors='coerce').rename(columns=titles)
            scales = {titles[p['column']]: {'kind': p['display'], **({'linthresh': p['linthresh']} if 'linthresh' in p else {})}
                      for p in chunk if p.get('display', 'linear') != 'linear'}
            fig = eda_view.plot_distributions(frame, c.frame[c.label].to_numpy(), positive=c.positive,
                                              unlabeled=c.unlabeled, units={titles[p['column']]: p.get('unit') or 'unit not given' for p in chunk},
                                              max_columns=4, display_scales=scales, class_names=tuple(c.short[:2]))
            fig.suptitle(f'Distributions by recorded label. {c.short[0]} = {c.class_names[0]}; '
                         f'{c.short[1]} = {c.class_names[1]}', fontsize=10)
            name = 'm1_distributions' if len(preds) <= per else f'm1_distributions_{k // per + 1}'
            files.append(self.save(fig, name, stage='M1', sources=[c.source],
                                   question='Do recorded positives differ from unlabeled cells, and where are tails or gaps'))
        return files

    def categories(self):
        """Share of recorded positives and of the other cells in each category of each categorical predictor."""
        c = self.cells
        preds = [p for p in self.spec.get('predictors', []) if is_categorical(p)][:8]
        ncols = min(2, len(preds))
        nrows = int(np.ceil(len(preds) / ncols))
        fig, axes = self.plt.subplots(nrows, ncols, figsize=(6.5 * ncols, 3.4 * nrows), layout='constrained', squeeze=False)
        rows = []
        for ax, p in zip(axes.flat, preds):
            codes, names = category_codes(c.frame[p['column']])
            share = lambda mask: [float(np.mean(codes[mask] == i)) if mask.any() else np.nan for i in range(len(names))]
            sp, su = share(c.is_p), share(~c.is_p)
            ypos = np.arange(len(names))
            ax.barh(ypos - .2, sp, .4, color='#d62728', label=f'{c.short[0]} (n={int(c.is_p.sum())})')
            ax.barh(ypos + .2, su, .4, color='#7f7f7f', label=f'{c.short[1]} (n={int((~c.is_p).sum())})')
            ax.set_yticks(ypos, ['\n'.join(textwrap.wrap(n, 20)) for n in names], fontsize=8)
            ax.invert_yaxis()
            ax.set(xlabel='Share of cells in the class (missing counted in neither)', title=p.get('title', p['column']))
            ax.legend(fontsize=8, loc='lower right')
            rows += [{'column': p['column'], 'category': n, f'share_{c.short[0]}': a, f'share_{c.short[1]}': b}
                     for n, a, b in zip(names, sp, su)]
        for ax in list(axes.flat)[len(preds):]:
            ax.set_visible(False)
        self.table(pd.DataFrame(rows), 'm1_category_composition.csv')
        return self.save(fig, 'm1_categories', stage='M1', sources=[c.source],
                         question='Which categories hold the recorded positives, compared with the other cells')

    def correlation(self):
        c = self.cells
        cols = [p['column'] for p in self.spec.get('predictors', []) if not is_categorical(p)]
        if len(cols) < 2:
            self.summary['not_drawn'].append({'stage': 'M1 correlation', 'reason': 'fewer than two predictors'})
            return None
        fig, corr, counts = eda_view.plot_correlations(c.frame[cols].apply(pd.to_numeric, errors='coerce'))
        self.table(corr.reset_index(names='predictor'), 'm1_spearman.csv')
        self.table(counts.reset_index(names='predictor'), 'm1_spearman_pair_counts.csv')
        pairs = [(a, b, float(corr.loc[a, b])) for i, a in enumerate(cols) for b in cols[i + 1:]
                 if np.isfinite(corr.loc[a, b]) and abs(corr.loc[a, b]) >= .8]
        if pairs:
            self.summary['notes'].append({'stage': 'M1', 'strong_pairs_abs_rho_ge_0.8': pairs})
        return self.save(fig, 'm1_correlation', stage='M1', sources=[c.source],
                         question='Which predictors carry overlapping information')

    # M2 --------------------------------------------------------------------
    def dependence(self):
        c, d = self.cells, self.spec['dependence']
        plt = self.plt
        if 'fit' in d:
            raise ValueError('dependence: draw fitted curves yourself with variogram.plot(empirical, [fit]) so the curve '
                             'uses the fitted object; render draws the empirical diagnosis and pair counts only')
        if 'table' in d:
            t = pd.read_csv(d['table'])
            for key, value in (d.get('where') or {}).items():
                t = t[t[key].astype(str) == str(value)]
            scale = 1000.0 if d.get('distance_unit', c.unit) == 'm' else 1.0
            h = t[d['distance']].to_numpy(float) / scale
            upper = t[d['distance_upper']].to_numpy(float) / scale if 'distance_upper' in d else None
            if upper is not None:  # lower and upper lag edges saved: plot at bin centres
                h, widths = (h + upper) / 2, (upper - h) * .9
            fig, (top, bottom) = plt.subplots(2, 1, figsize=(8, 6.5), sharex=True, layout='constrained',
                                              gridspec_kw={'height_ratios': [3, 1]})
            top.scatter(h, t[d['value']], color='black', s=22, label='Empirical (as saved)')
            top.set(ylabel=d.get('value_label', 'Semivariance'),
                    title=f"{d.get('variable', 'Variable')}: dependence by distance")
            top.legend(fontsize=8)
            if upper is None:
                widths = np.median(np.diff(np.sort(h))) * .8 if len(h) > 1 else 1
            bottom.bar(h, t[d['pairs']], width=widths, color='#537a96')
            unit = 'km' if scale == 1000 else d.get('distance_unit', c.unit)
            bottom.set(xlabel=f"Distance ({unit}{'; Mercator map units' if c.mercator else ''})", ylabel='Pairs')
            sources = [c.source, Path(d['table'])]
        else:
            if not c.projected:
                self.summary['not_drawn'].append({'stage': 'M2', 'reason': 'distance edges need projected coordinates'})
                return None
            scale = 1000.0 if c.unit == 'm' else 1.0
            edges = np.asarray(d['edges'], float) / scale
            z = c.is_p.astype(float)
            if c.grid_problem:  # a uniform pair sample: at regional extent few sampled pairs fall in short lags
                xy = c.frame[[c.xcol, c.ycol]].to_numpy(float) / scale
                e = variogram.empirical(xy, z, edges)
            else:  # every pair within the last edge, exactly
                _, _, grid = grid_map.cell_grid(c.x, c.y, z, spacing=c.spacing)
                e = variogram.grid_empirical(grid.filled(np.nan), dx=c.spacing[0], dy=c.spacing[1], edges=edges)
            note = {'stage': 'M2', 'pairs_retained': int(e['retained_pairs']), 'sampling': e['sampling'],
                    **{k: e[k] for k in ('pair_budget', 'seed') if k in e}}
            g = e['semivariance'][np.isfinite(e['semivariance'])]
            if len(g) >= 4 and (np.diff(g[-4:]) > 0).all():
                note['still_rising'] = (f'semivariance still rises over the last lags (to {edges[-1]:g} {c.display_unit}): '
                                        'extend the edges; if it keeps rising, read it as a regional trend in recorded P, '
                                        'not a range, before choosing a block size')
            self.summary['notes'].append(note)
            axes = variogram.plot(e, [], unit=('km' if scale == 1000 else c.unit) + ('; Mercator map units' if c.mercator else ''),
                                  title='Recorded label: semivariance by distance (pattern of recorded P, not of all occurrences)')
            fig = axes[0].figure
            axes[0].axhline(e['value_variance'], color='#888888', linestyle='--', label=f"Label variance {e['value_variance']:.4f}")
            axes[0].legend(fontsize=8)
            out = pd.DataFrame({'lag_lower': edges[:-1], 'lag_upper': edges[1:], 'mean_distance': e['mean_distance'],
                                'semivariance': e['semivariance'], 'pairs': e['pair_count']})
            self.table(out, 'm2_label_semivariance.csv')
            sources = [c.source]
        return self.save(fig, 'm2_dependence', stage='M2', sources=sources, dependence=True,
                         question='Up to what distance are values dependent, and how many pairs support each lag')

    # M3 --------------------------------------------------------------------
    def assignment(self):
        c, a = self.cells, self.spec['assignment']
        groups = c.join(a['table'], a['id'], [a['group']], 'assignment', a.get('where'))[a['group']]
        assigned = groups.notna().to_numpy()
        rows = []
        tree = None
        if c.projected:
            from scipy.spatial import cKDTree
        for g in sorted(groups.dropna().unique(), key=str):
            inside = (groups == g).to_numpy()
            row = {'group': g, 'cells': int(inside.sum()), 'P': int((inside & c.is_p).sum()),
                   'U': int((inside & ~c.is_p).sum())}  # P/U columns keep their names; class_short labels the figure
            if c.projected and (~inside & assigned).any():
                tree = cKDTree(np.c_[c.x[~inside & assigned], c.y[~inside & assigned]])
                dist, _ = tree.query(np.c_[c.x[inside], c.y[inside]])
                # centre distance to any cell of another group (buffer cells included): a geometry check,
                # not the train-test distance of a particular split
                row[f'nearest_other_group_{c.display_unit}'] = float(dist.min())
            rows.append(row)
        support = pd.DataFrame(rows)
        self.table(support, 'm3_assignment_support.csv')
        codes = {g: i for i, g in enumerate(support['group'])}
        values = groups.map(codes).to_numpy(float)
        cats = {}
        for r in rows:
            near = r.get(f'nearest_other_group_{c.display_unit}')
            text = f"{a['group']} {r['group']}: {r['cells']} cells, {c.short[0]}={r['P']}, {c.short[1]}={r['U']}"
            if near is not None:
                text += f', nearest other-group cell {near:.3g} {c.display_unit}'
            cats[codes[r['group']]] = (text, GROUP_COLORS[codes[r['group']] % len(GROUP_COLORS)])
        fig, ax = self.plt.subplots(figsize=c.figsize(1, 1, 7.5), layout='constrained')
        info = c.map_panel(ax, values, title='Which cells are held out together', categories=cats)
        if a.get('block'):  # e.g. "block" from block_design's split_manifest.csv
            c.group_edges(ax, c.join(a['table'], a['id'], [a['block']], 'assignment', a.get('where'))[a['block']].to_numpy())
        figure_style.map_legend(ax, info, fontsize=8, **({'title': 'White lines: block edges', 'title_fontsize': 8}
                                                         if a.get('block') else {}))
        if (~assigned).any():
            self.summary['notes'].append({'stage': 'M3', 'cells_without_assignment': int((~assigned).sum())})
        return self.save(fig, 'm3_assignment', stage='M3', maps=[ax], sources=[c.source, Path(a['table'])],
                         question='Which cells are evaluated together, with how many P/U, and how close to the rest')

    # M4 --------------------------------------------------------------------
    def heldout(self):
        from sklearn.metrics import precision_recall_curve
        c, h = self.cells, self.spec['heldout']
        where = dict(h.get('where') or {})
        if 'model' in h:  # long table: one row per cell and model, each model with its own groups
            frame = pd.read_csv(h['table'])
            for key, value in where.items():
                frame = frame[frame[key].astype(str) == str(value)]
            names = h.get('scores') or {str(m): str(m) for m in pd.unique(frame[h['model']])}
            per_model = {name: c.join(h['table'], h['id'], [h['group'], h['score']], 'heldout', {**where, h['model']: m})
                         .dropna(subset=[h['group']]) for name, m in names.items()}
        else:
            base = c.join(h['table'], h['id'], [h['group']] + list(h['scores'].values()), 'heldout', where or None)
            base = base.dropna(subset=[h['group']])
            per_model = {name: base[[h['group'], col]].rename(columns={col: 'score'}) for name, col in h['scores'].items()}
            h = dict(h, score='score')
        if len(per_model) == 1:
            self.summary['notes'].append({'stage': 'M4', 'note': 'one model only: compare it with a simple baseline on '
                                          'the same held-out groups, or say in the report why not'})
        first = next(iter(per_model.values()))
        same = all(t.index.equals(first.index) and (t[h['group']].astype(str) == first[h['group']].astype(str)).all()
                   for t in per_model.values())
        if not same:
            self.summary['notes'].append({'stage': 'M4', 'note': 'models were evaluated on different groups or rows; '
                                          'per-group points use each model\'s own groups'})
        fig, axes = self.plt.subplots(1, 3, figsize=(15, 4.8), layout='constrained')
        rows = []
        order = sorted({g for t in per_model.values() for g in pd.unique(t[h['group']])}, key=str)
        for k, (name, t) in enumerate(per_model.items()):
            y = c.is_p[c.frame.index.get_indexer(t.index)].astype(int)
            groups = t[h['group']].to_numpy()
            s = t[h['score']].to_numpy(float)
            if not np.isfinite(s).all():
                raise ValueError(f'heldout: {name} has missing scores on evaluated rows')
            pooled = evaluation_view.pu_metrics(y, s)
            rows.append({'model': name, 'group': 'pooled', **pooled})
            color = GROUP_COLORS[k % len(GROUP_COLORS)]
            p, r, _ = precision_recall_curve(y, s)
            axes[0].step(r, p, where='post', color=color, label=f"{name}: AP={pooled['average_precision']:.3f}")
            for i, g in enumerate(order):
                m = groups == g
                if not m.any():
                    continue
                row = evaluation_view.pu_metrics(y[m], s[m])
                rows.append({'model': name, 'group': g, **row})
                if row['average_precision'] is not None:
                    axes[1].scatter(i + (k - (len(per_model) - 1) / 2) * .12, row['average_precision'], color=color,
                                    label=name if i == 0 else None)
                if k == 0:
                    axes[1].scatter(i, row['observed_prevalence'], marker='_', s=300, color='#888888',
                                    label='Recorded P fraction (AP of a random score)' if i == 0 else None)
            curve = evaluation_view.capture_curve(y, s)
            axes[2].step(curve['fraction'], curve['capture'], where='post', color=color, label=name)
        y = c.is_p[c.frame.index.get_indexer(first.index)].astype(int)
        groups = first[h['group']].to_numpy()
        prevalence = y.mean()
        axes[0].axhline(prevalence, color='#888888', linestyle='--', label=f'Recorded P fraction {prevalence:.3f}')
        axes[0].set(xlabel=f'Recall of {c.short[0]}', ylabel=f'Precision ({c.short[0]} vs {c.short[1]})', title='Held-out discrimination',
                    xlim=(0, 1), ylim=(0, 1.02))
        axes[0].legend(fontsize=8, loc='upper right')
        ticks = [f"{g}\n{c.short[0]}={int(y[groups == g].sum())}, {c.short[1]}={int((groups == g).sum() - y[groups == g].sum())}"
                 for g in order]
        axes[1].set_xticks(range(len(order)), ticks, fontsize=8)
        axes[1].set(xlabel=f"Held-out {h['group']} (support below{'' if same else ', first model'})", ylabel='Average precision',
                    title='Variation between held-out groups', ylim=(0, 1.02))
        axes[1].legend(fontsize=8)
        axes[2].plot([0, 1], [0, 1], '--', color='#888888', label='Random equal-cell selection')
        axes[2].set(xlabel='Fraction of evaluated cells selected (highest first)', ylabel='Fraction of recorded P',
                    title='Held-out capture', xlim=(0, 1), ylim=(0, 1.02))
        axes[2].legend(fontsize=8, loc='lower right')
        for ax in axes:
            ax.grid(alpha=.2)
        self.table(pd.DataFrame(rows), 'm4_heldout_metrics.csv')
        return self.save(fig, 'm4_heldout', stage='M4', sources=[c.source, Path(h['table'])], score_role='held-out',
                         question='What do the models separate on cells they did not see, and how much does it vary')

    def _groups(self, ref=None):
        """Held-out groups for a score: from the score's own long table when it carries the group column
        (so each model's own split is drawn), else from the assignment stage."""
        a = self.spec.get('assignment')
        if not a:
            return None
        if isinstance(ref, dict) and a['group'] in pd.read_csv(ref['table'], nrows=0).columns:
            return self.cells.join(ref['table'], ref['id'], [a['group']], 'assignment', ref.get('where'))[a['group']].to_numpy(object)
        return self.cells.join(a['table'], a['id'], [a['group']], 'assignment', a.get('where'))[a['group']].to_numpy(object)

    # M5/M6 -----------------------------------------------------------------
    def _series(self, stage, conf, ref):
        """A score-like column: a name in the stage table or the scores table, or
        {"table", "id", "column", "where"} for any saved table (long tables via "where")."""
        if isinstance(ref, dict):
            return c_join(self.cells, ref['table'], ref['id'], ref['column'], stage, ref.get('where')), Path(ref['table'])
        for source in (conf, self.spec.get('scores') or {}):
            if 'table' in source and ref in pd.read_csv(source['table'], nrows=0).columns:
                return c_join(self.cells, source['table'], source['id'], ref, stage, source.get('where')), Path(source['table'])
        raise ValueError(f'{stage}: column {ref!r} not found in its table or the scores table')

    def stability(self):
        c, st = self.cells, self.spec['stability']
        if not st.get('what'):
            raise ValueError('stability: say what varies ("what"), e.g. "SD over 20 seeds, same data"')
        panels = []
        if st.get('score'):
            panels.append((st['score'], 'Score (not a probability)', 'viridis'))
        panels.append((st['column'], st['what'], 'magma'))
        fig, axes = self.plt.subplots(1, len(panels), figsize=c.figsize(len(panels), 1), layout='constrained', squeeze=False)
        sources = [c.source]
        for ax, (col, title, cmap) in zip(axes.flat, panels):
            values, src = self._series('stability', st, col)
            sources.append(src)
            label = col['column'] if isinstance(col, dict) else col
            c.map_panel(ax, values, title='\n'.join(textwrap.wrap(title, 52)), unit='', cmap=cmap,
                        colorbar_location='bottom', colorbar_label=label)
        return self.save(fig, 'm5_stability', stage='M5', maps=list(axes.flat), sources=sorted(set(sources), key=str),
                         question=f"How stable is the score: {st['what']}")

    def score_roles(self):
        c, s = self.cells, self.spec['scores']
        cols = [dict(x, name=x.get('name', x['column'])) for x in s['columns']]
        table, sources, edges_of = pd.DataFrame(index=c.frame.index), {c.source}, {}
        for x in cols:
            ref = {k: x[k] for k in ('table', 'id', 'column', 'where') if k in x} if 'table' in x else x['column']
            table[x['name']], src = self._series('scores', s, ref)
            sources.add(src)
            edges_of[x['name']] = self._groups(ref)
        values = table.to_numpy(float)
        lo, hi = np.nanmin(values), np.nanmax(values)
        limits = (0.0, 1.0) if lo >= 0 and hi <= 1 else (float(lo), float(hi))
        n = len(cols)
        fig = self.plt.figure(figsize=(c.figsize(n, 1)[0] + 5, c.figsize(n, 1)[1]), layout='constrained')
        axes = fig.subplots(1, n + 1, gridspec_kw={'width_ratios': [1] * n + [.9]})
        for ax, x in zip(axes[:n], cols):
            groups = edges_of[x['name']]
            edges = groups is not None and x['role'] == 'held-out'
            c.map_panel(ax, table[x['name']], title=f"{x['name']} ({x['role']})" + ('\nwhite lines: held-out group edges' if edges else ''),
                        unit='', limits=limits, colorbar_location='bottom', colorbar_label='Score (not a probability)')
            if edges:  # a held-out map is stitched from several models; show where they meet
                c.group_edges(ax, groups)
        fig.suptitle(f'Stars: {c.class_names[0]} ({c.short[0]}) cells. Roles are as declared in the spec, not verified here',
                     fontsize=10)
        cap = axes[n]
        rows = []
        ok = np.isfinite(table.to_numpy(float)).all(axis=1)  # one population for every curve
        if (~ok).any():
            self.summary['notes'].append({'stage': 'M6', 'cells_without_every_score': int((~ok).sum())})
        for k, x in enumerate(cols):
            v = table[x['name']].to_numpy(float)
            curve = evaluation_view.capture_curve(c.is_p[ok].astype(int), v[ok])
            heldout = x['role'] == 'held-out'
            trained = x['role'] in ('full-fit', 'in-sample', 'training')
            note = '' if heldout else (': trained on these cells, not selection performance' if trained
                                       else ': check which cells trained it before reading as performance')
            name = f"{x['name']} ({x['role']}){note}"
            cap.step(curve['fraction'], curve['capture'], where='post', color=GROUP_COLORS[k % len(GROUP_COLORS)],
                     linestyle='-' if heldout else ':', label=name)
            for f in (.05, .1, .2):
                at = evaluation_view.capture_at(curve, f)
                rows.append({'column': x['name'], 'role': x['role'], 'budget_fraction': f,
                             'selected_fraction': at['fraction'], 'capture': at['capture'], 'P_total': curve['positive_total']})
        cap.plot([0, 1], [0, 1], '--', color='#aaaaaa', label='Random equal-cell selection')
        cap.set(xlabel=f'Fraction of cells selected (highest first; n={int(ok.sum())}, {c.short[0]}={int(c.is_p[ok].sum())})',
                ylabel=f'Fraction of {c.short[0]}',
                title='Capture depends on the score role', xlim=(0, 1), ylim=(0, 1.02))
        cap.legend(fontsize=7, loc='upper center', bbox_to_anchor=(.5, -.14), borderaxespad=0)  # below: curves stay visible
        self.table(pd.DataFrame(rows), 'm6_capture_by_role.csv')
        return self.save(fig, 'm6_score_roles', stage='M6', maps=list(axes[:n]), sources=sorted(sources, key=str),
                         score_role=[x['role'] for x in cols],
                         question='Which score is shown, what did its model see, and what would each capture')

    def zones(self):
        c, z = self.cells, self.spec['zones']
        zone = c_join(self.cells, z['table'], z['id'], z['column'], 'zones', z.get('where'))
        order = z.get('order') or sorted(zone.dropna().unique(), key=str)
        extra = set(zone.dropna().unique()) - set(order)
        if extra:
            raise ValueError(f'zones: values {sorted(extra, key=str)[:3]} not in "order"')
        role = z.get('score_role', 'unstated')
        codes = {v: i for i, v in enumerate(order)}
        colors = z.get('colors') or [ZONE_COLORS[i % len(ZONE_COLORS)] for i in range(len(order))]
        if len(colors) != len(order):
            raise ValueError('zones: "colors" needs one colour per zone in "order"')
        cats, rows = {}, []
        for v in order:
            m = (zone == v).to_numpy()
            rows.append({'zone': v, 'cells': int(m.sum()), 'fraction': float(m.mean()), 'P': int((m & c.is_p).sum())})
            cats[codes[v]] = (f"{v}: {int(m.sum())} cells ({m.mean():.1%}), {c.short[0]}={int((m & c.is_p).sum())}",
                              colors[codes[v]])
        self.table(pd.DataFrame(rows).assign(score_role=role), 'm6_zone_counts.csv')
        fig, ax = self.plt.subplots(figsize=c.figsize(1, 1, 7.5), layout='constrained')
        info = c.map_panel(ax, zone.map(codes).to_numpy(float), title=f"Zones from the {role} score", categories=cats)
        title = f"Rule: {z.get('rule', 'not stated')}"
        if role != 'held-out':
            title += f'\n{c.short[0]} counts use {role} scores: not selection performance unless held-out'
        figure_style.map_legend(ax, info, fontsize=8, title=title, title_fontsize=8)
        return self.save(fig, 'm6_zones', stage='M6', maps=[ax], sources=[c.source, Path(z['table'])], score_role=role,
                         question='Where are the zones, by which rule, and how large is each')

    def zone_rules(self):
        """Budget, capture and area for alternative top-fraction rules on one score (an optional example of a rule
        comparison, not the required zoning method).

        Applied to a held-out ranking, a rule's capture is what it would have found on cells its models did not
        see. With any other role (or none stated) the numbers are a description of that score, not selection
        performance. Fractions come from the purpose or budget; a rule picked by looking at these held-out
        results turns them into development evidence."""
        c, zr = self.cells, self.spec['zone_rules']
        if not zr.get('fractions') and not zr.get('chosen'):  # no silent budget: the fractions are a decision
            self.summary['not_drawn'].append({'stage': 'zone_rules', 'reason': 'give "fractions" (upper fractions of the '
                                              'ranking to compare, from the purpose or budget)'})
            return None
        score, src = self._series('zone_rules', zr, zr['score'])
        role = zr.get('score_role', 'unstated')
        heldout = role == 'held-out'
        chosen = zr.get('chosen')
        fractions = sorted({float(f) for f in zr.get('fractions') or []} | ({float(chosen)} if chosen else set()))
        v = score.to_numpy(float)
        ok = np.isfinite(v)
        p_unscored = int((c.is_p & ~ok).sum())
        curve = evaluation_view.capture_curve(c.is_p[ok].astype(int), v[ok])
        area_unit = f'{c.display_unit}2' if c.projected and not c.grid_problem and not c.mercator else None
        cell_area = c.spacing[0] * c.spacing[1] if area_unit else None
        label = lambda f: f'top {f * 100:g}%'
        rows = []
        for f in fractions:
            at = evaluation_view.capture_at(curve, f)
            captured = int(round(at['capture'] * curve['positive_total']))
            rows.append({'rule': label(f), 'budget_fraction': f, 'selected_fraction': at['fraction'],
                         'selected_cells': int(at['selected_n']), 'score_threshold': at['threshold'],
                         'P_captured': captured, 'P_scored': curve['positive_total'], 'P_without_score': p_unscored,
                         'cells_scored': int(ok.sum()), 'cells_total': int(len(v)),
                         'capture': at['capture'], 'lift': at['capture'] / at['fraction'] if at['fraction'] else None,
                         f'selected_area_{area_unit}' if area_unit else 'selected_area': at['selected_n'] * cell_area if cell_area else None,
                         'score_role': role, 'chosen': chosen is not None and np.isclose(f, float(chosen))})
        table = pd.DataFrame(rows)
        added = table['selected_cells'].diff().fillna(table['selected_cells'])
        table['P_gained_per_100_cells'] = table['P_captured'].diff().fillna(table['P_captured']) / added.replace(0, np.nan) * 100
        self.table(table, 'm6_zone_rules.csv')
        if not heldout:
            self.summary['notes'].append({'stage': 'M6 zone rules', 'note': f'score role {role}: capture here describes '
                                          'this score and is not selection performance'})
        fig, (a, b) = self.plt.subplots(1, 2, figsize=(13, 5), layout='constrained')
        a.step(curve['fraction'], curve['capture'], where='post', color='#176B87', label=f"{zr.get('score_name', 'score')} ({role})")
        a.plot([0, 1], [0, 1], '--', color='#aaaaaa', label='Random equal-cell selection')
        for r in rows:
            a.scatter(r['selected_fraction'], r['capture'], s=70 if r['chosen'] else 30, zorder=3,
                      color='#d62728' if r['chosen'] else '#333333')
            a.annotate(f"{r['rule']}: {r['P_captured']}/{r['P_scored']} ({r['selected_cells']} cells)",
                       (r['selected_fraction'], r['capture']), textcoords='offset points', xytext=(6, -10), fontsize=8)
        note = f', {p_unscored} {c.short[0]} without score' if p_unscored else ''
        a.set(xlabel=f'Fraction of scored cells selected ({int(ok.sum())} of {len(v)}{note}; ties kept together)',
              ylabel=f'Fraction of scored {c.short[0]} captured',
              title='Budget and capture of each rule' + ('' if heldout else f'\n(score role {role}: not selection performance)'),
              xlim=(0, max(.5, max(fractions) * 1.3)), ylim=(0, 1.02))
        a.legend(fontsize=8, loc='lower right')
        gained = table['P_gained_per_100_cells']
        b.bar(table['rule'], gained.fillna(0), color=['#d62728' if r['chosen'] else '#537a96' for r in rows])
        for i, g in enumerate(gained):
            if not np.isfinite(g):
                b.annotate('no cells added (ties)', (i, 0), textcoords='offset points', xytext=(0, 4), ha='center', fontsize=8)
        b.set(xlabel='Rule (each bar: cells added since the previous rule)', ylabel=f'{c.short[0]} gained per 100 cells',
              title='What each widening of the rule adds')
        return self.save(fig, 'm6_zone_rules', stage='M6', sources=[c.source, src], score_role=role,
                         question='How much would each zone rule find, at what area, and what does widening it add')

    def candidate_evidence(self, cand, ids, key='candidates'):
        """Per-candidate table and profile: where each candidate's predictor medians sit among all cells.

        Context for interpretation, not importance or independent validation: the percentile is the ECDF of all
        valid cells at the candidate median; roles are as declared in the spec; containing or lying next to a
        recorded positive says the candidate re-finds known ground."""
        c, k, kind = self.cells, self.spec[key], CANDIDATE_KINDS[key]
        preds = self.spec.get('predictors', [])
        if not preds:
            self.summary['not_drawn'].append({'stage': f"M7 {kind['stage']} evidence", 'reason': 'no predictors in spec'})
            return None
        from scipy.spatial import cKDTree
        tree = cKDTree(np.c_[c.x[c.is_p], c.y[c.is_p]]) if c.projected and c.is_p.any() else None
        # neighbour = one of the 8 surrounding cells, as pu_workflow.candidate_patches classifies re-checks
        cells_tree = cKDTree(np.c_[c.x[c.is_p] / c.spacing[0], c.y[c.is_p] / c.spacing[1]]) if tree is not None else None
        rule = 'a recorded positive in the candidate or in one of the 8 cells around a candidate cell'
        usable, skipped = [], []
        for p in preds:
            v = pd.to_numeric(c.frame[p['column']], errors='coerce')
            (usable if v.nunique() > 2 and not is_categorical(p) else skipped).append(p)
        if skipped:
            self.summary['notes'].append({'stage': f"M7 {kind['stage']} evidence", 'not_profiled': [p['column'] for p in skipped],
                                          'reason': 'categorical, or two or fewer distinct values: describe categories by composition instead'})
        rows, prof = [], []
        for cid in ids:
            m = (cand == cid).to_numpy()
            row = {'candidate': cid, 'cells': int(m.sum()), f'{c.short[0]}_inside': int((m & c.is_p).sum())}
            if tree is not None:
                d = float(tree.query(np.c_[c.x[m], c.y[m]])[0].min())
                row[f'nearest_{c.short[0]}_centre_distance_{c.display_unit}'] = d
                steps = float(cells_tree.query(np.c_[c.x[m] / c.spacing[0], c.y[m] / c.spacing[1]], p=np.inf)[0].min())
                row['relation_to_recorded'] = ('contains recorded positive' if row[f'{c.short[0]}_inside'] else
                                               'next to recorded positive' if steps <= 1.5 else 'no recorded positive nearby')
                row['adjacency_rule'] = rule
            else:
                row['relation_to_recorded'] = 'not evaluated (no projected coordinates)'
            others = c.is_p & ~m  # recorded positives outside this candidate
            agreeing = []
            for p in usable:
                col = p['column']
                v = pd.to_numeric(c.frame[col], errors='coerce').to_numpy(float)
                valid = v[np.isfinite(v)]
                med = float(np.nanmedian(v[m])) if np.isfinite(v[m]).any() else np.nan
                row[col] = med
                pct = float(np.mean(valid <= med) * 100) if np.isfinite(med) else np.nan
                side = (None if not p.get('expect') or not np.isfinite(pct) else
                        bool(pct > 50) if p['expect'] == 'high' else bool(pct < 50))
                if side is not None:
                    agreeing.append(f"{col} {p['expect']}: {'yes' if side else 'no'}")
                prof.append({'candidate': str(cid), 'column': col, 'role': p.get('role', 'unspecified'), 'value': med,
                             'percentile': pct, 'expect': p.get('expect'), 'on_expected_side_of_median': side,
                             'valid_cells': int(len(valid)),
                             'P_outside_median_percentile': float(np.mean(valid <= np.nanmedian(v[others])) * 100)
                             if np.isfinite(v[others]).any() else np.nan})
            row['expected_side_of_median'] = '; '.join(agreeing) if agreeing else 'no expectation declared'
            rows.append(row)
        self.table(pd.DataFrame(rows), f"{kind['m7']}_evidence.csv")
        prof = pd.DataFrame(prof)
        self.table(prof, f"{kind['m7']}_profiles.csv")
        if prof.empty:
            return None
        order = [p['column'] for p in sorted(usable, key=lambda p: (p.get('role', 'unspecified'), usable.index(p)))]
        fig, ax = self.plt.subplots(figsize=(8.5, .38 * len(order) + 2.4), layout='constrained')
        ypos = {col: i for i, col in enumerate(order)}
        for j, cid in enumerate(map(str, ids)):
            q = prof[prof['candidate'] == cid]
            relation = next((r.get('relation_to_recorded') for r in rows if str(r['candidate']) == cid), None)
            offset = (j - (len(ids) - 1) / 2) * .12
            # a thin tick under the candidate dot, so a median at the same place does not hide the candidate
            ax.scatter(q['P_outside_median_percentile'], q['column'].map(ypos) + offset, marker='|', s=110, linewidths=1.4,
                       color='#333333', zorder=2, label=f'{c.short[0]} median outside the candidate (tick)' if j == 0 else None)
            ax.scatter(q['percentile'], q['column'].map(ypos) + offset, s=30, color=GROUP_COLORS[j % len(GROUP_COLORS)],
                       edgecolors='white', linewidths=.6, zorder=4, label=f"{kind['Word']} {cid}" + (f' ({relation})' if relation else ''))
        roles = {p['column']: p.get('role', 'unspecified') + (f"; expect {p['expect']}" if p.get('expect') else '')
                 for p in usable}
        ax.set_yticks(range(len(order)), [f"{o} [{roles[o]}]" for o in order], fontsize=8)
        shaded = False
        for p in usable:
            if p.get('expect'):
                lo, hi = (50, 100) if p['expect'] == 'high' else (0, 50)
                y = ypos[p['column']]
                ax.fill_betweenx([y - .4, y + .4], lo, hi, color='#e6efdc', zorder=0,
                                 label=None if shaded else 'Expected side of the median (declared)')
                shaded = True
        ax.axvline(50, color='#bbbbbb', linewidth=.8)
        ax.set(xlim=(0, 100), xlabel='Percentile among all valid cells (ECDF at the candidate median; not importance)',
               title=f"Where each {kind['word']} sits on each predictor ([declared role; expected side])")
        figure_style.outside_legend(ax, fontsize=8)
        return self.save(fig, f"{kind['m7']}_profiles", stage='M7', sources=[c.source, Path(k['table'])],
                         question=f"Which predictor values make each {kind['word']} stand out, compared with recorded positives")

    def candidates(self, key='candidates'):
        """Overview with candidate windows on top; same-size, same-scale cell-level zooms below."""
        from matplotlib.patches import Rectangle
        c, k, kind = self.cells, self.spec[key], CANDIDATE_KINDS[key]
        cand = c_join(self.cells, k['table'], k['id'], k['column'], key, k.get('where'))
        score, src = self._series(key, k, k['score'])
        span_x, span_y = np.ptp(c.x) + c.spacing[0], np.ptp(c.y) + c.spacing[1]
        local, wide = [], []
        natural = lambda v: [int(s) if s.isdigit() else s for s in re.split(r'(\d+)', str(v))]
        for v in sorted(cand.dropna().unique(), key=natural):  # ids in their own order (N1, N2, ..., N10)
            m = (cand == v).to_numpy()
            if np.ptp(c.x[m]) + c.spacing[0] > span_x / 3 or np.ptp(c.y[m]) + c.spacing[1] > span_y / 3:
                wide.append(str(v))
            else:
                local.append(v)
        if wide:
            self.summary['notes'].append({'stage': f"M6 {kind['stage']}", 'not_zoomed': wide,
                                          'reason': 'spans more than a third of the area; a zoom needs a local candidate '
                                                    '(e.g. one connected patch). Zones belong in the zone map'})
        ids = local[:k.get('max', 3)]
        if not ids:
            self.summary['not_drawn'].append({'stage': f"M6 {kind['stage']}", 'reason': f"no {kind['word']} cells"})
            return None
        v = score.to_numpy(float)
        limits = (0.0, 1.0) if np.nanmin(v) >= 0 and np.nanmax(v) <= 1 else (float(np.nanmin(v)), float(np.nanmax(v)))
        role = k.get('score_role', 'unstated')
        name = k.get('score_name') or (k['score']['column'] if isinstance(k['score'], dict) else k['score'])
        dx, dy = c.spacing
        # one square window size for every zoom, so cells look the same size in each
        half = max(max(np.ptp(c.x[(cand == i).to_numpy()]) + dx, np.ptp(c.y[(cand == i).to_numpy()]) + dy)
                   for i in ids) / 2 + 2 * max(dx, dy)
        nz = len(ids)
        width = max(4.3 * nz, 9.5)
        heights = [c.figsize(1, 1, 7.5)[1] + .6, width / nz + .4]
        fig = self.plt.figure(figsize=(width, sum(heights)), layout='constrained')
        top, bottom = fig.subfigures(2, 1, height_ratios=heights)
        overview = top.subplots()
        c.map_panel(overview, v, title=f"{name} ({role}) with {kind['word']} windows", limits=limits,
                    colorbar_location='bottom', colorbar_label='Score (not a probability)')
        zooms = list(bottom.subplots(1, nz, squeeze=False).flat)
        for ax, cid in zip(zooms, ids):
            m = (cand == cid).to_numpy()
            cx, cy = (c.x[m].min() + c.x[m].max()) / 2, (c.y[m].min() + c.y[m].max()) / 2
            # snap the window to cell edges so no cell is cut in half
            ex, ey = c.x.min() - dx / 2, c.y.min() - dy / 2
            ex1, ey1 = c.x.max() + dx / 2, c.y.max() + dy / 2
            wx, wy = np.ceil(2 * half / dx) * dx, np.ceil(2 * half / dy) * dy
            x0 = ex + np.floor((cx - half - ex) / dx) * dx
            y0 = ey + np.floor((cy - half - ey) / dy) * dy
            # keep the window on the mapped area where it fits, so neither the zoom nor the outline runs off the map
            x0 = min(max(x0, ex), max(ex, ex1 - wx))
            y0 = min(max(y0, ey), max(ey, ey1 - wy))
            x1, y1 = x0 + wx, y0 + wy
            overview.add_patch(Rectangle((x0, y0), x1 - x0, y1 - y0, fill=False, edgecolor='black', linewidth=1.2))
            overview.annotate(str(cid), (x0, min(y1, ey1)), textcoords='offset points', xytext=(3, -3), fontsize=8,
                              ha='left', va='top', bbox=dict(boxstyle='round,pad=.15', fc='white', ec='none', alpha=.85))
            window = (c.x >= x0) & (c.x <= x1) & (c.y >= y0) & (c.y <= y1)
            info = grid_map.raster_map(ax, c.x[window], c.y[window], v[window], spacing=c.spacing,
                                       name=f"{cid}: {int(m.sum())} cell{'s' if m.sum() != 1 else ''}, {c.short[0]}={int((m & c.is_p).sum())}"
                                            + (f"\n{k['notes'][str(cid)]}" if str(cid) in k.get('notes', {}) else ''),
                                       value_unit='', limits=limits)
            info['colorbar'].remove()  # same limits as the overview colorbar
            figure_style.map_axes(ax, projected=c.projected, unit=c.display_unit, crs=c.crs, latitude=c.latitude)
            ax.scatter(c.x[window & c.is_p], c.y[window & c.is_p], **P_MARK)
            for xi, yi in zip(c.x[m], c.y[m]):
                ax.add_patch(Rectangle((xi - dx / 2, yi - dy / 2), dx, dy, fill=False, edgecolor='white', linewidth=.9))
            ax.set_xlim(x0, x1)
            ax.set_ylim(y0, y1)
        bottom.suptitle(f"{kind['Word']} cells outlined in white; stars are recorded positive cells; same colour scale as above",
                        fontsize=9)
        png = self.save(fig, kind['m6'], stage='M6', maps=[overview, *zooms], sources=[c.source, Path(k['table']), src],
                        score_role=role, question=kind['question'])
        self.candidate_evidence(cand, local[:k.get('evidence_max', 8)], key)
        return png

    def far_targets(self):
        """The same overview, zooms and evidence for the far targets: best-ranked cells away from recorded positives."""
        return self.candidates('far_targets')

    def clear_previous(self):
        """Remove the figures and tables a previous render wrote to this folder, so a stage that is not drawn now
        leaves nothing stale behind (other files in the folder are kept)."""
        previous = self.out / 'stage-evidence-summary.json'
        if not previous.exists():
            return
        old = json.loads(previous.read_text())
        gone = set()
        for f in old.get('figures', []):
            png = Path(f['file'])
            for path in (png, png.with_suffix('.svg')):
                path.unlink(missing_ok=True)
            gone.add(png.name)
        for table in old.get('tables', []):
            Path(table).unlink(missing_ok=True)
        records = self.out / 'figure-records.json'
        if records.exists() and gone:
            kept = [r for r in json.loads(records.read_text()) if r.get('file') not in gone]
            records.write_text(json.dumps(kept, indent=2, ensure_ascii=False) + '\n')
        previous.unlink()

    def run(self):
        self.clear_previous()
        stages = [('domain', 'cells', self.domain), ('distributions', 'predictors', self.distributions),
                  ('correlation', 'predictors', self.correlation), ('dependence', 'dependence', self.dependence),
                  ('assignment', 'assignment', self.assignment), ('heldout', 'heldout', self.heldout),
                  ('stability', 'stability', self.stability), ('score_roles', 'scores', self.score_roles),
                  ('zones', 'zones', self.zones), ('zone_rules', 'zone_rules', self.zone_rules),
                  ('candidates', 'candidates', self.candidates), ('far_targets', 'far_targets', self.far_targets)]
        maps = {'domain', 'assignment', 'stability', 'score_roles', 'zones', 'candidates', 'far_targets'}
        optional = {'far_targets'}  # filled by pu_workflow; a spec without it has nothing missing
        for name, key, draw in stages:
            if key not in self.spec or not self.spec[key]:
                if key not in optional:
                    self.summary['not_drawn'].append({'stage': name, 'reason': f'"{key}" not in spec'})
                continue
            if name in maps and self.cells.grid_problem:
                self.summary['not_drawn'].append({'stage': name, 'reason': self.cells.grid_problem + '; draw these maps '
                                                  'with a point or polygon view and save them with figure_style.save_figure'})
                continue
            draw()
        if self.cells.nodata_counts:
            self.summary['notes'].append({'stage': 'M0', 'sentinel_values_set_to_missing': self.cells.nodata_counts})
        self.summary['input_table'] = str(Path(self.spec['cells']['table']).resolve())  # figures beside it are inputs
        # records of the design and decision commands whose tables this render drew (check --report lists their values)
        self.summary['decision_records'] = [str((Path(self.spec[key]['table']).parent / name).resolve())
                                            for key, name in (('assignment', 'block_design.json'), ('zones', 'pu_workflow.json'))
                                            if isinstance(self.spec.get(key), dict) and self.spec[key].get('table')
                                            and (Path(self.spec[key]['table']).parent / name).exists()]
        self.summary['reminder'] = 'Open every PNG and look at it; checks do not replace inspection.'
        (self.out / 'stage-evidence-summary.json').write_text(json.dumps(self.summary, indent=2, ensure_ascii=False, default=str) + '\n')
        return self.summary


def c_join(cells, table, id_col, columns, stage, where=None):
    single = isinstance(columns, str)
    out = cells.join(table, id_col, [columns] if single else list(columns), stage, where)
    return out[columns] if single else out


SHEET_DIR = '_contact_sheets'
# the local candidates of the tiers (N new, R re-check) and the far targets (F, ranked among cells away from positives)
CANDIDATE_KINDS = {
    'candidates': {'m6': 'm6_candidates', 'm7': 'm7_candidate', 'stage': 'candidates', 'word': 'candidate',
                   'Word': 'Candidate', 'question': 'Where each candidate lies and what its cells look like up close'},
    'far_targets': {'m6': 'm6_far_targets', 'm7': 'm7_far_target', 'stage': 'far targets', 'word': 'far target',
                    'Word': 'Far target', 'question': 'Where the best-ranked cells away from recorded positives lie and '
                                                      'what they look like up close'}}


def contact_sheets(pngs, folder, per_sheet=9):
    """Thumbnails of the checked figures, nine to a sheet with their paths, in <folder>/_contact_sheets/: a quick way
    to look at every figure. A thumbnail shows gross defects only; open the full PNG where one looks wrong and for the
    figures a conclusion rests on."""
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.image as mpimg
    import matplotlib.pyplot as plt
    out = Path(folder) / SHEET_DIR
    out.mkdir(parents=True, exist_ok=True)
    for old in out.glob('sheet_*.png'):
        old.unlink()
    written = []
    for s in range(0, len(pngs), per_sheet):
        batch = pngs[s:s + per_sheet]
        fig, axes = plt.subplots(3, 3, figsize=(15, 15))
        for ax, png in zip(axes.flat, batch):
            try:
                ax.imshow(mpimg.imread(png))
            except Exception as e:  # an unreadable file is itself worth seeing
                ax.text(.5, .5, f'unreadable: {e}', ha='center', va='center', wrap=True)
            ax.set_title(str(png)[-70:], fontsize=8)
        for ax in axes.flat:
            ax.axis('off')
        path = out / f'sheet_{s // per_sheet + 1:02d}.png'
        fig.savefig(path, dpi=100, bbox_inches='tight')
        plt.close(fig)
        written.append(str(path))
    return written


def check(folders, report_path=None, sheets=True):
    """PNG files without a matching figure record, records whose PNG changed, recorded layout warnings, and,
    with a report, whether the report takes up what the render notes asked for."""
    report = {'recorded': [], 'not_recorded': [], 'changed_after_record': [], 'layout_warnings': [],
              'checks_not_declared': [], 'missing_folders': [], 'report_missing': [], 'report_reminders': []}
    summaries, inspected = [], set()

    def inspect(png):
        if png.resolve() in inspected:  # overlapping folders (or a report link) name the same figure once
            return
        inspected.add(png.resolve())
        records_path = png.parent / 'figure-records.json'
        records = json.loads(records_path.read_text()) if records_path.exists() else []
        entry = next((r for r in records if r.get('file') == png.name), None)
        if entry is None:
            report['not_recorded'].append(str(png))
            return
        if entry.get('png_sha256') and entry['png_sha256'] != figure_style._sha256(png):
            report['changed_after_record'].append(str(png))
            return
        report['recorded'].append(str(png))
        checks = entry.get('checks', {})
        if checks.get('map_crs') == 'not declared' and checks.get('pair_counts') == 'not declared':
            report['checks_not_declared'].append(str(png))
        for w in checks.get('layout_warnings', []):
            report['layout_warnings'].append(f'{png}: {w}')

    for folder in folders:
        folder = Path(folder)
        if not folder.is_dir():
            report['missing_folders'].append(str(folder))
            continue
        summaries += [json.loads(p.read_text()) for p in folder.rglob('stage-evidence-summary.json')
                      if p.resolve() not in inspected and not inspected.add(p.resolve())]
        for png in sorted(folder.rglob('*.png')):
            if SHEET_DIR not in png.parts:  # the contact sheets check writes are not figures of the analysis
                inspect(png)
    if report_path is not None:
        import re
        text = Path(report_path).read_text(errors='replace') if Path(report_path).exists() else ''
        if not text:
            report['report_missing'].append(f'report not found or empty: {report_path}')
        # Figures the report shows or names are checked too, wherever they were saved; figures beside the input table are inputs.
        from urllib.parse import unquote
        seen = {Path(p).resolve() for k in ('recorded', 'not_recorded', 'changed_after_record') for p in report[k]}
        tables = [Path(s['input_table']) for s in summaries if s.get('input_table') and Path(s['input_table']).exists()]
        base = Path(report_path).resolve().parent

        def delivered_with_input(path):  # beside the input table and not newer than it: an input figure
            return any(path.parent == tb.parent and path.stat().st_mtime <= tb.stat().st_mtime + 60 for tb in tables)
        link = re.compile(r'\]\(\s*<?([^)<>]+?\.png)>?(?:\s+"[^"]*")?\s*\)|<img[^>]+src="([^"]+?\.png)"', re.I)
        linked = [unquote(md or html) for md, html in link.findall(text)]  # Markdown or HTML links, spaces and %20 allowed
        named = re.findall(r'[\w./-]*\w\.png\b', link.sub(' ', text), re.I)  # file names in the text outside links
        for ref, explicit in [(r, True) for r in dict.fromkeys(linked)] + [(r, False) for r in dict.fromkeys(named)]:
            found = next((c.resolve() for c in (base / ref, Path.cwd() / ref) if c.is_file()), None)
            if found is None:
                if explicit:
                    report['report_missing'].append(f'the report links a figure that does not exist: {ref}')
                elif not any(p.name.lower() == Path(ref).name.lower() for p in seen | inspected):
                    report['report_reminders'].append(f'the report names a figure that was not found: {ref}')
                continue
            if found in seen or found in inspected or delivered_with_input(found) or SHEET_DIR in found.parts:
                continue
            seen.add(found)
            inspect(found)
        for summary in summaries:
            for note in summary.get('notes', []):
                for col in note.get('columns', []) if note.get('interpret') else []:
                    if not re.search(rf'(?<![A-Za-z0-9_]){re.escape(col["column"])}(?![A-Za-z0-9_])', text):
                        report['report_reminders'].append(f"not named in the report: {col['column']} ({note.get('kind', 'value check')})")
                if note.get('kind') == 'map-unit distances' and not re.search(
                        r'mercator|메르카토르|map[- ]units?|지도 단위|reproject|재투영', text, re.I):
                    report['report_reminders'].append('Mercator coordinates: distances and areas in map units (reprojected, or the factor stated)')
                if note.get('kind') == 'no expectations':
                    report['report_reminders'].append('no expected directions declared: still link the predictors whose '
                                                      'identity is known (from the name or data description, even without '
                                                      'units) and the candidates to the domain model (e.g. the deposit model '
                                                      'of the commodity the request or data description names), as labelled '
                                                      'hypotheses where the data cannot confirm them; for a predictor whose '
                                                      'identity cannot be established, withhold its interpretation and say '
                                                      'what definition would allow it')
                if note.get('stage') == 'M2' and note.get('still_rising'):
                    report['report_reminders'].append('M2 semivariance still rising at the last lag: how the block size was '
                                                      'chosen without a range (longer lags, trend, or another basis)')
                if note.get('stage') == 'M4' and note.get('note', '').startswith('one model only'):
                    report['report_reminders'].append('one model only: baseline comparison or the reason for none')
            for n in summary.get('not_drawn', []):
                report['report_reminders'].append(f"not drawn: {n['stage']} ({n['reason'][:80]}) - drawn elsewhere, or stated in the report")
        values = []
        for path in dict.fromkeys(r for s in summaries for r in s.get('decision_records', [])):
            try:
                rec = json.loads(Path(path).read_text())
            except (OSError, ValueError):
                continue
            if 'block' in rec and 'assignment' in rec:
                b, a = rec['block'], rec['assignment']
                inner = sorted({len(x.get('folds', [])) for x in a.get('inner', [])})
                values.append(f"{len(a['outer']['folds'])} outer / {'-'.join(map(str, inner))} inner folds, block "
                              f"{b['size'][0]:g} {b.get('unit', '')} ({b['basis']})")
            elif 'config' in rec and 'tiers' in rec['config']:
                g = rec['config']
                text_ = (f"tiers {g['tiers']} ({g['zone_mode']}), alpha {g['alpha']} (screen {g.get('screen_rule', 'pool')}), "
                         f"rel IQR cut {g['rel_iqr_cut']}" + (f", far-target gap {g['new_gap']} grid steps" if 'new_gap' in g else ''))
                d = rec.get('deployment', {}).get(g.get('primary'), {})
                if d.get('cells_ranked_in_tiers') and d.get('tier_cells_moved_by_uncertainty') == 0:
                    text_ += (f" (the rel IQR cut moves none of the {d['cells_ranked_in_tiers']} tier cells of the map; "
                              f"tier rel IQR p10/p50/p90 {[round(v, 3) for v in d.get('tier_rel_iqr_p10_p50_p90') or []]})")
                if g.get('rezoned_from'):
                    text_ += (f"; revised from {g['previous_decision_values']} because: {g['rezone_reason']} (if the "
                              'revision followed held-out capture or coverage, those held-out results are development '
                              'evidence: say so)')
                values.append(text_)
        if values:
            report['report_reminders'].append('decision values: give the reason for each from the purpose, budget or data '
                                              '(not a default or another study; a definition of the value is not a reason: '
                                              'say what it was weighed against, e.g. the budget, the cost of missing a '
                                              'positive, the rel IQR spread): ' + ' | '.join(values))
        evidence = False
        for folder in folders:
            for kind in CANDIDATE_KINDS.values():
                for path in Path(folder).rglob(f"{kind['m7']}_evidence.csv"):
                    ids = pd.read_csv(path, dtype=str)['candidate']
                    evidence = evidence or len(ids) > 0
                    # Hangul particles may follow an id ("후보 A는"); short or numeric ids need a candidate word before them
                    named = lambda i: re.search(rf'(?<![A-Za-z0-9_]){re.escape(i)}(?![A-Za-z0-9_])' if len(i) >= 3 and not i.isdigit()
                                                else rf'(?:candidate|후보|target|patch)\s*[#:]?\s*{re.escape(i)}(?![A-Za-z0-9_])', text, re.I)
                    if not any(named(i) for i in ids):
                        report['report_reminders'].append(f"{kind['stage']} evidence: no {kind['word']} from {path.name} is named")
        if evidence and not re.search(r'가설|hypothe[st]', text, re.I):  # a word match, not a check of the interpretation
            report['report_reminders'].append('candidate interpretation: for the leading candidates give the observed '
                                              'values and status, and link them to the domain model through the '
                                              'predictors whose identity is known (what it expects, what the candidate '
                                              'shows, what data would test it), marked as hypotheses where the data cannot '
                                              'confirm them')
    report['report_reminders'] = list(dict.fromkeys(report['report_reminders']))
    checked = sorted({p for k in ('recorded', 'not_recorded', 'changed_after_record') for p in report[k]})
    report['contact_sheets'] = contact_sheets(checked, folders[0]) if sheets and checked and Path(folders[0]).is_dir() else []
    return report


def template(table, metadata=None):
    """A first spec from the input table: cells and predictors guessed, CRS from metadata if found.

    Every guess must be checked: the id/x/y/label columns, the unit and spacing, the CRS, and which
    columns are predictors (label-derived counts, identifiers and survey proxies are listed apart)."""
    import re
    frame = pd.read_csv(table, nrows=200_000)
    cols = list(frame.columns)
    pick = lambda pattern: next((c for c in cols if re.fullmatch(pattern, c, re.I)), None)
    idc = pick(r'cell_?id|id|cell') or cols[0]
    x = pick(r'x|easting|east|x_m|lon|longitude')
    y = pick(r'y|northing|north|y_m|lat|latitude')
    binary = lambda c: pd.api.types.is_numeric_dtype(frame[c]) and set(frame[c].dropna().unique()) <= {0, 1}
    # a 0/1 column named like a label; counts such as n_positive are not labels
    label = next((c for c in cols if re.search(r'label|target|positive|class|^lab', c, re.I) and binary(c)), None)
    if label is None:  # fall back to the first 0/1 column that is not an id or coordinate
        label = next((c for c in cols if c not in (idc, x, y) and binary(c)), None)
    xs = np.unique(frame[x].to_numpy(float)) if x else np.array([])
    ys = np.unique(frame[y].to_numpy(float)) if y else np.array([])
    def step(u):  # the most common gap: off-grid edge cells (e.g. partial blocks) add smaller ones
        if len(u) < 2:
            return None
        gaps, counts = np.unique(np.round(np.diff(u), 6), return_counts=True)
        return float(gaps[np.argmax(counts)])
    unit = 'degree' if x and np.nanmax(np.abs(xs)) <= 360 else 'm'
    crs, crs_note = 'EPSG:????', 'not found in the metadata: name it from the data description'
    if metadata:
        text = Path(metadata).read_text(errors='replace').replace('\\"', '"')  # WKT inside a JSON string
        found = re.search(r'EPSG\s*:?\s*(\d{4,6})', text, re.I)
        wkt = re.search(r'(PROJCS|PROJCRS|GEOGCS|GEOGCRS)\s*\[\s*"([^"]+)"', text)
        if found:
            crs, crs_note = f'EPSG:{found.group(1)}', 'EPSG code from the metadata'
        elif wkt:  # a WKT definition without an EPSG code: its name, marked as such
            crs = f'{wkt.group(2)} (metadata WKT, no EPSG code)'
            crs_note = 'named from a WKT definition in the metadata; say in the report that no EPSG code was given'
    skip = {idc, x, y, label} | {c for c in cols if re.fullmatch(r'row|col|column|in_aoi', c, re.I)}
    suspect = [c for c in cols if c not in skip and re.search(r'deposit|occurrence|event|inventory|presence|count|^n_|names?$|label|mine', c, re.I)]
    numeric = [c for c in cols if c not in skip and c not in suspect and pd.api.types.is_numeric_dtype(frame[c])]
    coded = [c for c in numeric if 2 < frame[c].nunique() <= 12 and np.allclose(frame[c].dropna() % 1, 0)]
    text = [c for c in cols if c not in skip and c not in suspect and not pd.api.types.is_numeric_dtype(frame[c])
            and 1 < frame[c].nunique() <= 30]
    spec = {
        'out': 'figures',
        'cells': {'table': str(table), 'id': idc, 'x': x, 'y': y, 'unit': unit, 'crs': crs,
                  'spacing': [step(xs), step(ys)], 'label': label, 'positive': 1, 'unlabeled': 0,
                  'class_names': ['Recorded positive', 'Unlabeled (not a confirmed negative)'], 'class_short': ['P', 'U']},
        'predictors': [{'column': c, 'title': c, 'unit': '', 'map': i < 3} for i, c in enumerate(numeric)]
                      + [{'column': c, 'title': c, 'type': 'categorical', 'map': False} for c in text],
        'dependence': {'edges': variogram.lag_edges(step(xs), min(np.ptp(xs), np.ptp(ys)))} if unit != 'degree' and step(xs) and len(ys) > 1 else None,
        '_check_before_render': [f'cells: id, x, y, label, unit, spacing and CRS (CRS {crs_note})'
                                 + ('' if x and y else '; coordinate columns not recognised: set cells.x, cells.y and the '
                                    'spacing, and move them out of the predictors'), 'predictors: units, titles, display '
                                 'scales, which to map; remove any that are not predictors; role, and expect (high/low) '
                                 'with basis where the domain model (e.g. deposit model) predicts a direction',
                                 f'columns kept out as possible label-derived or proxy columns: {suspect}',
                                 f'numeric columns with few whole-number values, possibly category codes (set "type": '
                                 f'"categorical" if so): {coded}',
                                 'add assignment, heldout, scores, stability, zones, candidates as their tables are saved'],
    }
    if spec['dependence'] is None:
        spec.pop('dependence')
    return spec


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__.split('\n\n')[0])
    sub = parser.add_subparsers(dest='command', required=True)
    r = sub.add_parser('render')
    r.add_argument('spec')
    k = sub.add_parser('check')
    k.add_argument('folders', nargs='+')
    k.add_argument('--report', help='the report; checks that it takes up the render notes')
    k.add_argument('--no-sheets', action='store_true', help='do not write contact sheets of the checked figures')
    t = sub.add_parser('template')
    t.add_argument('table')
    t.add_argument('--metadata')
    a = parser.parse_args(argv)
    if a.command == 'template':
        print(json.dumps(template(a.table, a.metadata), indent=2, ensure_ascii=False))
        return 0
    if a.command == 'render':
        summary = Renderer(json.loads(Path(a.spec).read_text())).run()
        for f in summary['figures']:
            print('figure', f['file'], '-', f['question'])
        for n in summary['not_drawn']:
            print('not drawn', n['stage'], '-', n['reason'])
        for n in summary['notes']:
            print('note', json.dumps(n, ensure_ascii=False, default=str))
        print(summary['reminder'])
        return 0
    report = check(a.folders, a.report, sheets=not a.no_sheets)
    for p in report['missing_folders']:
        print('folder not found:', p)
    for p in report['not_recorded']:
        print('no record (drawn outside the checked path; re-save with figure_style.save_figure or report what you checked by eye):', p)
    for p in report['changed_after_record']:
        print('changed after its record (re-save through save_figure):', p)
    for w in report['layout_warnings']:
        print('layout warning:', w)
    for m in report['report_missing']:
        print('report problem:', m)
    for m in report['report_reminders']:
        print('report reminder:', m)
    if report['report_reminders']:
        print('(reminders are word matches: take up what applies; naming a column is not an interpretation)')
    if report['checks_not_declared']:
        print(f"{len(report['checks_not_declared'])} recorded figures declared no map or dependence check (fine for non-map plots)")
    for sheet in report['contact_sheets']:
        print('contact sheet:', sheet)
    print(f"{len(report['recorded'])} recorded, {len(report['not_recorded'])} without record. Look at every figure (the "
          "contact sheets show them all; open the full PNG where one looks wrong and for those a conclusion rests on), "
          "and write in the report only the checks you made.")
    bad = (report['missing_folders'] or report['not_recorded'] or report['changed_after_record'] or report['layout_warnings']
           or report['report_missing'])
    return 1 if bad else 0


if __name__ == '__main__':
    sys.exit(main())
