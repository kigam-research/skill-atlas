"""Optional semivariogram primitives; no CRS/block selection or dataset loader.

All fitted models use r95: 95% of the STRUCTURED partial sill. Draw from the
same `curve` used for fitting. Pair counts are not independent sample sizes.
"""
import numpy as np
from scipy.optimize import least_squares, brentq

_LOG20 = float(np.log(20))
_SPH95 = brentq(lambda t: 1.5*t - .5*t**3 - .95, 0, 1)


def curve(h, *, model, r95, partial_sill, nugget):
    if model not in ('gaussian', 'exponential', 'spherical'):
        raise ValueError('Unknown variogram model')
    if not np.isfinite([r95, partial_sill, nugget]).all() or r95 <= 0 or min(partial_sill, nugget) < 0:
        raise ValueError('Positive r95 and nonnegative sill/nugget required')
    h = np.asarray(h, dtype=float)
    if not np.isfinite(h).all() or (h < 0).any():
        raise ValueError('Finite nonnegative distances required')
    u = h / r95
    if model == 'gaussian':
        v = -np.expm1(-_LOG20*u*u)
    elif model == 'exponential':
        v = -np.expm1(-_LOG20*u)
    else:
        t = np.minimum(u * _SPH95, 1)
        v = 1.5*t - .5*t**3
    return nugget + partial_sill*v


def empirical(xy, values, edges, *, max_pairs=1_000_000, seed=42,
              direction_degrees=None, tolerance_degrees=22.5):
    """Uniform label-independent unordered pair sample (deduplicated).

    Exact all-pairs for small n. Larger cases draw at most max_pairs candidate
    pairs before lag/direction filtering; low lag support is NOT auto-hidden.
    Coordinates and distances must use a defensible common metric unit.
    Direction uses +x counter-clockwise modulo 180 degrees, NOT north azimuth.
    """
    xy = np.asarray(xy, float); z = np.asarray(values, float)
    edges = np.asarray(edges, float)
    if xy.ndim != 2 or xy.shape[1] != 2 or z.shape != (len(xy),) or len(z) < 2:
        raise ValueError('Need aligned n by 2 coordinates and n values')
    if not np.isfinite(xy).all() or not np.isfinite(z).all():
        raise ValueError('Explicitly filter missing values and record retained IDs')
    if edges.ndim != 1 or len(edges) < 3 or edges[0] != 0 or not np.isfinite(edges).all() or (np.diff(edges) <= 0).any():
        raise ValueError('Increasing finite distance edges starting at zero required')
    if isinstance(max_pairs, bool) or int(max_pairs) != max_pairs or max_pairs < 1:
        raise ValueError('Positive integer pair budget required')
    n = len(z); possible = n*(n-1)//2
    if possible <= max_pairs:
        i,j = np.triu_indices(n, 1); design = 'exact_all_unordered_pairs'
    else:
        rng = np.random.default_rng(seed)
        i = rng.integers(0, n, int(max_pairs)); j = rng.integers(0, n-1, int(max_pairs))
        j += (j >= i)
        pairs = np.unique(np.column_stack([np.minimum(i,j), np.maximum(i,j)]), axis=0)
        i,j = pairs.T; design = 'uniform_unordered_pair_sample_without_duplicate_pairs'
    sampled = len(i)
    dxy = xy[j]-xy[i]
    h = np.hypot(dxy[:,0], dxy[:,1])
    keep = (h > 0) & (h <= edges[-1])
    if direction_degrees is not None:
        if not np.isfinite(direction_degrees) or not 0 < tolerance_degrees <= 90:
            raise ValueError('Finite direction and tolerance in (0,90] required')
        angle = np.degrees(np.arctan2(dxy[:,1],dxy[:,0])) % 180
        difference = np.abs((angle-direction_degrees+90)%180-90)
        keep &= difference <= tolerance_degrees
    zero_distance_pairs=int(np.sum(h==0))
    h = h[keep]; delta = .5*(z[j[keep]]-z[i[keep]])**2
    bins = np.searchsorted(edges,h,side='right')-1
    bins = np.minimum(bins,len(edges)-2) # inclusive final edge
    count = np.bincount(bins,minlength=len(edges)-1)
    gamma = np.divide(np.bincount(bins,weights=delta,minlength=len(count)), count,
                      out=np.full(len(count),np.nan),where=count>0)
    mean_h = np.divide(np.bincount(bins,weights=h,minlength=len(count)),count,
                      out=np.full(len(count),np.nan),where=count>0)
    return {'edges':edges,'mean_distance':mean_h,'semivariance':gamma,'pair_count':count,
            'disagreement_pair_count':np.bincount(bins,weights=(delta>0),minlength=len(count)).astype(int) if len(np.unique(z))<=2 else None,
            'zero_distance_pairs_excluded':zero_distance_pairs,
            'direction_convention':'+x counter-clockwise modulo 180 degrees',
            'n_observations':n,'sampling':design,'seed':seed,'pair_budget':int(max_pairs),
            'sampled_unique_pairs':sampled,'retained_pairs':int(count.sum()),
            'direction_degrees':direction_degrees,'tolerance_degrees':tolerance_degrees,
            'value_mean':float(z.mean()),'value_variance':float(z.var()),
            'distance_unit':'caller-supplied coordinate unit'}


def fit(empirical_result, *, model, min_pairs=30):
    """Descriptive unweighted lag-bin fit; never an automatic block-size rule."""
    e=empirical_result
    use=(e['pair_count']>=min_pairs)&np.isfinite(e['semivariance'])&np.isfinite(e['mean_distance'])
    h=np.asarray(e['mean_distance'])[use]; y=np.asarray(e['semivariance'])[use]
    base={'model':model,'range_definition':'r95: 95% structured partial sill',
          'weighting':'equal populated lag bins','min_pairs':min_pairs,'bins_used':int(use.sum()),'used_bin_mask':use.tolist()}
    if len(h)<4 or max(y, default=0)<=0:
        return {**base,'status':'insufficient_support_or_zero_variation'}
    scale=max(float(y.max()),np.finfo(float).tiny); hscale=float(h.max())
    def residual(p):
        return (curve(h/hscale,model=model,r95=p[0],partial_sill=p[1],nugget=p[2])-y/scale)
    attempts=[least_squares(residual,[r0,.8,.1],bounds=([1e-4,0,0],[5,10,10])) for r0 in [.05,.5,2.]]
    result=min(attempts,key=lambda x:float(np.sum(x.fun*x.fun)))
    r,s,n=result.x
    fitted=curve(h,model=model,r95=r*hscale,partial_sill=s*scale,nugget=n*scale)
    warnings=[]
    if r*hscale < h.min(): warnings.append('range_below_first_supported_lag')
    if r>=1: warnings.append('r95_not_reached_in_observed_lags')
    if r>=4.99 or s>=9.99 or n>=9.99: warnings.append('fit_near_parameter_bound')
    if s <= 1e-5: warnings.append('negligible_structured_sill_range_unidentified')
    nugget_fraction=float(n/(n+s)) if n+s>0 else None
    if nugget_fraction is not None and nugget_fraction>.75:
        warnings.append('high_nugget_fraction_review_short_lag_resolution')
    variance=e.get('value_variance',0)
    # Descriptive heuristic, not a stationarity test: long-lag rise above variance.
    tail=y[-3:]
    if variance>0 and np.all(tail>variance*1.05) and np.all(np.diff(tail)>0):
        warnings.append('possible_drift_or_nonstationarity_review_lag_sensitivity')
    if not result.success: warnings.append('optimizer_not_converged')
    return {**base,'status':'diagnostic_fit','r95':float(r*hscale),
            'partial_sill':float(s*scale),'nugget':float(n*scale),
            'rmse':float(np.sqrt(np.mean((fitted-y)**2))), 'warnings':warnings,
            'total_sill_to_value_variance':float((s+n)*scale/e['value_variance']) if e.get('value_variance',0)>0 else None,
            'multistart_count':len(attempts),'nugget_fraction':nugget_fraction,
            'diagnostic_heuristics':{'high_nugget_fraction':.75,'tail_bins':3,'tail_above_variance_factor':1.05},
            'interpretation':'Requires sampling/lag/direction/geological assessment; not independence proof'}


def lag_edges(step, extent, *, fraction=.5, fine=8, coarse=12):
    """Lag edges: one-cell bins near zero, then about `coarse` wider bins to `fraction` of the extent.

    Bins hold [lower, upper); half-step edges put the nearest neighbours (1 and 1.4 cells) in the first
    bin. `extent` is the smaller side of the area, in the same unit as `step`."""
    near = [0] + [(i + .5) * step for i in range(1, fine + 1)]
    reach = fraction * extent
    if reach <= near[-1] + coarse * step:  # small area: one-cell bins up to the reach, no further
        n = max(2, int(np.ceil(reach / step - .5)))
        return [round(e, 6) for e in [0] + [(i + .5) * step for i in range(1, n + 1)]]
    width = step * max(1, round((reach - near[-1]) / coarse / step))
    return [round(e, 6) for e in near + [near[-1] + width * k for k in range(1, coarse + 1)]]


_UNUSABLE_FIT = {'r95_not_reached_in_observed_lags', 'fit_near_parameter_bound', 'range_below_first_supported_lag',
                 'negligible_structured_sill_range_unidentified', 'optimizer_not_converged',
                 'possible_drift_or_nonstationarity_review_lag_sensitivity'}


def label_range(empirical_result, *, models=('gaussian', 'exponential', 'spherical'), min_pairs=30):
    """Range of a label semivariogram for sizing spatial blocks, by a stated rule.

    1. 'variance reached': the empirical variance-reached distance - the first lag at which the empirical
       semivariance reaches the label variance (interpolated between bin mean distances, bins with at
       least `min_pairs` pairs). Only under stationarity does this mark zero correlation; with a trend
       it is a practical design distance, not proof of independence;
    2. 'fitted r95': otherwise the lowest-RMSE fit whose r95 lies inside the lag window and carries none
       of the warnings that make it unusable (unreached, at a bound, no structured sill, drift);
    3. 'not identified': otherwise; the caller states another basis or asks.
    Fitted ranges are always reported: with sparse, clustered labels they move with the lag window and
    take up regional trends (a curve still rising past the variance), so they come second. Descriptive,
    not a decorrelation proof.
    """
    e = empirical_result
    window = float(np.asarray(e['edges'])[-1])
    variance = float(e['value_variance'])
    fits = [fit(e, model=m, min_pairs=min_pairs) for m in models]
    summary = [{k: f.get(k) for k in ('model', 'status', 'r95', 'rmse', 'nugget_fraction')} | {'warnings': f.get('warnings', [])}
               for f in fits]
    base = {'window': window, 'label_variance': variance, 'min_pairs': min_pairs, 'fits': summary}
    if not np.isfinite(variance) or variance <= 0:
        return {**base, 'rule': 'not identified', 'range': None, 'reason': 'constant_label',
                'note': 'the label does not vary; no spatial dependence range can be defined'}
    g, h, n = (np.asarray(e[k], float) for k in ('semivariance', 'mean_distance', 'pair_count'))
    ok = np.flatnonzero((n >= min_pairs) & np.isfinite(g) & np.isfinite(h))
    reached = [i for i in ok if g[i] >= variance]
    if reached:
        i = reached[0]
        before = [j for j in ok if j < i]
        x = h[i] if not before else h[before[-1]] + (variance - g[before[-1]]) / (g[i] - g[before[-1]]) * (h[i] - h[before[-1]])
        result = {**base, 'rule': 'variance reached', 'range': float(x), 'bin': int(i)}
        tail = g[ok][-3:]
        if len(tail) == 3 and (tail > 1.05 * variance).all() and (np.diff(tail) > 0).all():
            result['trend'] = ('semivariance still rises above the label variance at the longest lags '
                               '(possibly a regional trend or nonstationarity)')
        return result
    usable = [f for f in fits if f.get('status') == 'diagnostic_fit' and f['r95'] <= window
              and not _UNUSABLE_FIT & set(f['warnings'])]
    if usable:
        best = min(usable, key=lambda f: f['rmse'])
        return {**base, 'rule': 'fitted r95', 'range': best['r95'], 'model': best['model']}
    return {**base, 'rule': 'not identified', 'range': None,
            'note': 'semivariance stays below the label variance and no usable fit within the window; '
                    'extend the lags or state another basis'}


def plot(empirical_result, fits, *, unit, title, axes=None):
    import matplotlib.pyplot as plt
    if axes is None:
        _,axes=plt.subplots(2,1,figsize=(7,6),sharex=True,gridspec_kw={'height_ratios':[3,1]},layout='constrained')
    top,bottom=axes; e=empirical_result; h=e['mean_distance']
    used=np.zeros(len(h),dtype=bool)
    fitted=[f for f in fits if f.get('status')=='diagnostic_fit']
    for f in fitted: used |= np.asarray(f['used_bin_mask'],bool)
    if not fitted:  # no fit attempted or none succeeded: every bin is plain empirical evidence
        reason='no model fitted' if not fits else 'fit not identified: '+', '.join(sorted({f.get('status','') for f in fits}))
        top.scatter(h,e['semivariance'],color='black',s=22,label=f'Empirical ({reason})')
    else:
        top.scatter(np.asarray(h)[used],np.asarray(e['semivariance'])[used],color='black',s=22,label='Empirical (used by fit)')
        if (~used).any(): top.scatter(np.asarray(h)[~used],np.asarray(e['semivariance'])[~used],facecolors='none',edgecolors='gray',s=22,label='Not used by fit (few pairs)')
    grid=np.linspace(0,e['edges'][-1],300)
    for f in fits:
        if f.get('status')=='diagnostic_fit':
            top.plot(grid,curve(grid,**{k:f[k] for k in ('model','r95','partial_sill','nugget')}),
                     label=f"{f['model']}: r95={f['r95']:.3g} {unit}")
    top.set(title=title,ylabel='Semivariance');top.legend(fontsize=8)
    bottom.bar((e['edges'][:-1]+e['edges'][1:])/2,e['pair_count'],width=np.diff(e['edges'])*.9,color='#537a96')
    bottom.set(xlabel=f'Lag distance ({unit})',ylabel='Pairs')
    from matplotlib.ticker import FuncFormatter
    bottom.yaxis.set_major_formatter(FuncFormatter(lambda v,_: f'{v:,.0f}'))  # full counts, no '1e6' multiplier
    return axes


def grid_empirical(grid, *, dx, dy, edges, direction_degrees=None, tolerance_degrees=22.5):
    """Exact lag sums on a regular planar grid using FFT correlations.

    Missing cells are excluded, never filled. dx/dy are cell-centre spacings.
    Rows must increase in y; caller verifies regular geometry before pivoting.
    Direction uses +x counter-clockwise modulo 180 degrees (not north azimuth).
    Exact all-pair statistics (up to floating arithmetic), not an FFT fit/model.
    For 0/1 input, binary_pair_moments describes the actual retained lag pairs.
    Its product-marginal independence benchmark is descriptive, not a spatial
    null test under heterogeneous prevalence or a declaration of independence.
    """
    from scipy.signal import fftconvolve
    z=np.asarray(grid,float);edges=np.asarray(edges,float)
    if z.ndim!=2 or min(z.shape)<1 or np.isinf(z).any() or np.isfinite(z).sum()<2:
        raise ValueError('2D regular grid with >=2 finite cells; missing encoded NaN')
    if not np.isfinite([dx,dy]).all() or min(dx,dy)<=0:
        raise ValueError('Finite positive regular cell-centre spacings required')
    if edges.ndim!=1 or len(edges)<3 or edges[0]!=0 or not np.isfinite(edges).all() or (np.diff(edges)<=0).any():
        raise ValueError('Increasing finite edges starting at zero required')
    mask=np.isfinite(z).astype(float)
    # Centering prevents catastrophic cancellation for large constant offsets.
    center=float(np.nanmean(z));a=np.where(np.isfinite(z),z-center,0.)
    def corr(left,right):return fftconvolve(left,right[::-1,::-1],mode='full')
    pairs=np.maximum(np.rint(corr(mask,mask)),0).astype(np.int64)
    ss=corr(a*a,mask)
    squared=np.maximum(ss+ss[::-1,::-1]-2*corr(a,a),0)
    nr,nc=z.shape
    xx,yy=np.meshgrid(np.arange(-(nc-1),nc)*dx,np.arange(-(nr-1),nr)*dy)
    h=np.hypot(xx,yy)
    keep=((yy>0)|((yy==0)&(xx>0)))&(h<=edges[-1])&(pairs>0)
    if direction_degrees is not None:
        if not np.isfinite(direction_degrees) or not 0<tolerance_degrees<=90:
            raise ValueError('Finite direction and tolerance in (0,90] required')
        angle=np.degrees(np.arctan2(yy,xx))%180
        keep &= np.abs((angle-direction_degrees+90)%180-90)<=tolerance_degrees
    distance=h[keep];weights=pairs[keep]
    bins=np.minimum(np.searchsorted(edges,distance,side='right')-1,len(edges)-2)
    counts=np.rint(np.bincount(bins,weights=weights,minlength=len(edges)-1)).astype(np.int64)
    semisum=np.bincount(bins,weights=.5*squared[keep],minlength=len(counts))
    gamma=np.divide(semisum,counts,out=np.full(len(counts),np.nan),where=counts>0)
    mean_h=np.divide(np.bincount(bins,weights=distance*weights,minlength=len(counts)),counts,
                     out=np.full(len(counts),np.nan),where=counts>0)
    unique=np.unique(z[np.isfinite(z)])
    disagree=np.rint(2*semisum/(unique[-1]-unique[0])**2).astype(np.int64) if len(unique)==2 else (np.zeros(len(counts),dtype=np.int64) if len(unique)==1 else None)
    binary = None
    if np.isin(unique, [0., 1.]).all():
        raw = np.where(np.isfinite(z), z, 0.)
        endpoint = corr(raw, mask)
        def pair_mean(sums):
            total = np.bincount(bins, weights=np.rint(sums[keep]), minlength=len(counts))
            return np.divide(total, counts, out=np.full(len(counts), np.nan), where=counts>0)
        ph, pt, p11 = pair_mean(endpoint), pair_mean(endpoint[::-1,::-1]), pair_mean(corr(raw, raw))
        binary = {'p_head': ph, 'p_tail': pt, 'p_both': p11,
                  'independent_marginal_gamma': .5*(ph+pt)-ph*pt,
                  'pair_covariance': p11-ph*pt,
                  'null_assumption': 'Independent Bernoulli endpoints with these lag-aggregated marginals; not a heterogeneity-adjusted spatial null',
                  'endpoint_convention': 'head minus tail has +y, or +x when dy=0'}
    return {'edges':edges,'mean_distance':mean_h,'semivariance':gamma,'pair_count':counts,
            'binary_pair_moments':binary,
            'disagreement_pair_count':disagree,'zero_distance_pairs_excluded':0,
            'direction_convention':'+x counter-clockwise modulo 180 degrees',
            'n_observations':int(mask.sum()),'sampling':'exact_regular_grid_all_pairs_fft',
            'retained_pairs':int(counts.sum()),'direction_degrees':direction_degrees,
            'tolerance_degrees':tolerance_degrees,'value_mean':center,'value_variance':float(np.nanvar(z)),
            'distance_unit':'caller-supplied coordinate unit','shape':list(z.shape),'dx':dx,'dy':dy}
