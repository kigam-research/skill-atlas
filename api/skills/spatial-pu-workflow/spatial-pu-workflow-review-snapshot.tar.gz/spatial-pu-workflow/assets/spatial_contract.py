"""Spatial block splits for sparse labels, and independent assignment checkers.

balanced_block_folds / nested_block_folds: optimized random block assignment that
spreads sparse positives evenly over folds (and over the inner folds of each outer
training set), using per-block label counts only, never model scores.
group_folds: a label-blind alternative. block_size_for_range: blocks from a range.
Copy/adapt; the CRS, the range basis and the fold counts stay the caller's choices.
"""
import numpy as np
import pandas as pd
from sklearn.model_selection import GroupKFold


def grid_groups(x, y, *, block_size, origin):
    """Scalar or (x, y) block dimensions, in projected coordinate units."""
    xy = np.column_stack([x, y]).astype(float)
    size = np.asarray(block_size, dtype=float)
    if size.shape not in [(), (2,)] or not np.isfinite(xy).all() or not np.isfinite(size).all() or (size <= 0).any():
        raise ValueError('Finite projected coordinates and positive block size required')
    if len(origin) != 2 or not np.isfinite(origin).all():
        raise ValueError('Explicit finite fixed origin required')
    cells = np.floor((xy - np.asarray(origin)) / size).astype(np.int64)
    return np.array([f'{a}:{b}' for a, b in cells])


def block_size_for_range(distance, spacing, *, factor=1.0):
    """Smallest whole number of cells per block side whose length is at least factor x distance.

    `distance` and `spacing` share one unit. At least one cell per side."""
    if distance is None or not np.isfinite(distance) or distance < 0 or not factor > 0:
        raise ValueError('A finite nonnegative range and a positive factor are required')
    dx, dy = map(float, spacing)
    kx, ky = (max(1, int(np.ceil(factor * distance / d - 1e-9))) for d in (dx, dy))
    return {'cells': [kx, ky], 'size': [kx * dx, ky * dy], 'range': float(distance), 'factor': float(factor)}


def group_folds(groups, *, n_folds):
    """Pass row-level groups; unique groups alone change row-count balancing."""
    groups = np.asarray(groups)
    if not 2 <= n_folds <= len(np.unique(groups)):
        raise ValueError('Need at least one spatial group per fold and >=2 folds')
    fold = np.full(len(groups), -1, dtype=int)
    for i, (_, test) in enumerate(GroupKFold(n_splits=n_folds).split(groups, groups=groups)):
        fold[test] = i
    return fold


def check_assignments(row_ids, groups, folds, labels, *, positive, unlabeled):
    """Per-fold support; `unlabeled` is the non-positive class code (negatives for P/N data)."""
    table = pd.DataFrame({'row_id': row_ids, 'group': groups, 'fold': folds, 'label': labels})
    if table.empty or table.isna().any().any() or not table.row_id.is_unique:
        raise ValueError('Empty/missing assignment or nonunique row identity')
    if table.groupby('group').fold.nunique().max() != 1:
        raise ValueError('Spatial group crosses test folds')
    if not table.label.isin([positive, unlabeled]).all():
        raise ValueError('Labels outside supplied P/U contract')
    if not np.all(table.fold == table.fold.astype(int)) or (table.fold < 0).any() or table.fold.nunique() < 2:
        raise ValueError('Invalid fold IDs')
    result = []
    for fold, test in table.groupby('fold'):
        train = table[table.fold != fold]
        p_test = int((test.label == positive).sum())
        p_train = int((train.label == positive).sum())
        result.append({'fold': int(fold), 'test_rows': len(test), 'test_positive': p_test,
                       'test_unlabeled': int((test.label == unlabeled).sum()),
                       'train_rows': len(train), 'train_positive': p_train,
                       'two_classes_train_and_test': 0 < p_test < len(test) and 0 < p_train < len(train)})
    return result


def nearest_split_distances(x, y, folds):
    """Residual point adjacency in coordinate units; not proof of independence."""
    from scipy.spatial import cKDTree
    xy = np.column_stack([x, y]).astype(float)
    folds = np.asarray(folds)
    if len(xy) != len(folds) or not len(xy) or not np.isfinite(xy).all() or len(np.unique(folds)) < 2:
        raise ValueError('Finite coordinates and >=2 assigned folds required')
    report = []
    for fold in np.unique(folds):
        test = folds == fold
        distances, _ = cKDTree(xy[~test]).query(xy[test], k=1)
        report.append({'fold': int(fold), 'min_distance': float(distances.min()),
                       'p10_distance': float(np.quantile(distances, .1)),
                       'median_distance': float(np.median(distances))})
    return report


def buffered_split(x, y, folds, *, test_fold, buffer):
    """Exclude train centres <= buffer from any test centre (coordinate units).

    Return positional indices for the original row order and one nearest-kept-
    train distance per test row. Persist stable row IDs using these indices.
    Point-centre distances are not polygon-edge distances or independence proof.
    """
    from scipy.spatial import cKDTree
    xy = np.column_stack([x, y]).astype(float)
    folds = np.asarray(folds)
    if folds.ndim != 1 or len(xy) != len(folds) or pd.isna(folds).any() or not np.isfinite(xy).all() or np.ndim(buffer) != 0 or not np.isfinite(buffer) or buffer < 0:
        raise ValueError('Finite projected coordinates, aligned folds and nonnegative buffer required')
    test = np.flatnonzero(folds == test_fold)
    train = np.flatnonzero(folds != test_fold)
    if not len(test) or not len(train):
        raise ValueError('Nonempty train and test required')
    distance, _ = cKDTree(xy[test]).query(xy[train], k=1)
    kept, excluded = train[distance > buffer], train[distance <= buffer]
    if not len(kept):
        raise ValueError('No training rows remain after buffer')
    nearest, _ = cKDTree(xy[kept]).query(xy[test], k=1)
    return {'test_indices': test, 'train_indices': kept, 'excluded_indices': excluded,
            'test_to_train_distances': nearest}


def _objective(fp, fr):
    """Compared in order: positive spread, positive squared deviation, row spread, row squared deviation."""
    return (int(fp.max() - fp.min()), float(((fp - fp.mean()) ** 2).sum()),
            int(fr.max() - fr.min()), float(((fr - fr.mean()) ** 2).sum()))


def positive_spread_bound(groups, labels, *, positive, n_folds):
    """A lower bound on max - min positives over folds that keep blocks whole: the fold holding the block with the
    most positives has at least that many, and the other folds share the rest. Returns the bound and that block."""
    g, y = np.asarray(groups), np.asarray(labels) == positive
    per = {b: int(y[g == b].sum()) for b in np.unique(g)}
    top = max(per, key=per.get)
    total, k = int(y.sum()), per[top]
    even = int(total % n_folds != 0)
    bound = max(even, k - (total - k) // (n_folds - 1)) if n_folds > 1 else 0
    return {'lower_bound': int(bound), 'largest_block': str(top), 'largest_block_positive': k, 'positives': total}


def max_balanced_folds(groups, labels, *, positive, min_positive=1):
    """Upper bound on the fold count for which every fold can hold at least `min_positive` positives:
    no more folds than blocks with a positive, nor than total positives // min_positive. A necessary
    condition only; whether an assignment exists is settled by the search in balanced_block_folds."""
    groups, y = np.asarray(groups), np.asarray(labels) == positive
    _, inv = np.unique(groups, return_inverse=True)
    pos = np.bincount(inv, weights=y).astype(int)
    return int(min((pos > 0).sum(), pos.sum() // max(1, min_positive)))


def balanced_block_folds(groups, labels, *, n_folds, positive, seed, min_positive=1, candidates=32, moves=None):
    """Optimized random assignment of spatial blocks to folds that spreads sparse positives evenly.

    Uses only per-block counts of positives and rows, never model scores. The objective, compared in
    order: (1) spread of positive counts over folds (max - min, then squared deviation), (2) spread of
    row counts. Each candidate places blocks in a random order - blocks with positives first, larger
    counts first, ties random - on the fold with the fewest positives (then rows), then improves it by
    random block moves and swaps. The best of `candidates` seeded candidates is kept, so blocks of one
    fold are scattered over the area. Every fold must end with at least `min_positive` positives.
    Returns (row-level fold array, record).
    """
    groups, labels = np.asarray(groups), np.asarray(labels)
    if groups.shape != labels.shape or groups.ndim != 1 or not len(groups) or pd.isna(groups).any():
        raise ValueError('Aligned nonmissing row-level groups and labels required')
    y = labels == positive
    blocks, inv = np.unique(groups, return_inverse=True)
    rows, pos = np.bincount(inv), np.bincount(inv, weights=y).astype(int)
    bound = max_balanced_folds(groups, labels, positive=positive, min_positive=min_positive)
    if not 2 <= n_folds <= len(blocks) or n_folds > bound:
        raise ValueError(f'{n_folds} folds cannot each hold >= {min_positive} positive(s): {int((pos > 0).sum())} '
                         f'blocks hold {int(pos.sum())} positives; at most {bound} folds')
    moves = moves if moves is not None else min(20 * len(blocks), 20000)
    best = None
    for c in range(candidates):
        rng = np.random.default_rng([seed, c])
        tie = rng.random(len(blocks))
        order = np.lexsort((tie, -rows, -pos))  # positives first, then larger blocks; random within ties
        fold = np.empty(len(blocks), int)
        fp, fr = np.zeros(n_folds, int), np.zeros(n_folds, int)
        for b in order:
            key = np.lexsort((rng.random(n_folds), fr, fp)) if pos[b] else np.lexsort((rng.random(n_folds), fr))
            f = key[0]
            fold[b], fp[f], fr[f] = f, fp[f] + pos[b], fr[f] + rows[b]
        score = _objective(fp, fr)
        stale, patience = 0, max(200, 3 * len(blocks))
        for _ in range(moves):
            stale += 1
            if stale > patience:  # no improvement for a while
                break
            b = rng.integers(len(blocks))
            a, t = fold[b], rng.integers(n_folds)
            if a == t:
                continue
            if rng.random() < .5:  # move b from a to t
                fp[a] -= pos[b]; fp[t] += pos[b]; fr[a] -= rows[b]; fr[t] += rows[b]
                new = _objective(fp, fr)
                if new < score and fp[a] >= min_positive:
                    fold[b], score, stale = t, new, 0
                else:
                    fp[a] += pos[b]; fp[t] -= pos[b]; fr[a] += rows[b]; fr[t] -= rows[b]
            else:  # swap b with a random block of fold t
                members = np.flatnonzero(fold == t)
                if not len(members):
                    continue
                o = members[rng.integers(len(members))]
                dp, dr = pos[b] - pos[o], rows[b] - rows[o]
                fp[a] -= dp; fp[t] += dp; fr[a] -= dr; fr[t] += dr
                new = _objective(fp, fr)
                if new < score and fp.min() >= min_positive:
                    fold[b], fold[o], score, stale = t, a, new, 0
                else:
                    fp[a] += dp; fp[t] -= dp; fr[a] += dr; fr[t] -= dr
        if fp.min() >= min_positive and (best is None or score < best[0]):
            best = (score, fold.copy(), c)
    if best is None:
        raise ValueError(f'the search found no assignment giving every fold >= {min_positive} positive(s) '
                         '(not a proof that none exists); use fewer folds, more candidates or smaller blocks')
    score, fold, chosen = best
    fp = np.bincount(fold, weights=pos, minlength=n_folds).astype(int)
    fr = np.bincount(fold, weights=rows, minlength=n_folds).astype(int)
    record = {'algorithm': 'optimized random block assignment: greedy placement (positives first, random ties) '
                           'then random moves/swaps; best of seeded candidates',
              'uses': 'per-block counts of positives and rows only; no model scores',
              'seed': int(seed), 'candidates': int(candidates), 'moves_per_candidate': int(moves),
              'chosen_candidate': int(chosen), 'min_positive': int(min_positive), 'blocks': int(len(blocks)),
              'objective': {'positive_spread': score[0], 'positive_sq_dev': score[1],
                            'row_spread': score[2], 'row_sq_dev': score[3]},
              'folds': [{'fold': int(f), 'blocks': int((fold == f).sum()), 'rows': int(fr[f]),
                         'positive': int(fp[f]), 'other': int(fr[f] - fp[f])} for f in range(n_folds)]}
    return fold[inv], record


def nested_block_folds(groups, labels, *, outer_folds, inner_folds, positive, seed, min_positive=1, candidates=32):
    """Outer folds, and inner folds built the same way inside each outer training set.

    Returns (outer fold per row, {outer fold: inner fold per row, -1 on that outer test}, record).
    Inner folds are reduced, with the reason recorded, when a training set cannot give every
    inner fold `min_positive` positives.
    """
    groups, labels = np.asarray(groups), np.asarray(labels)
    outer, record = balanced_block_folds(groups, labels, n_folds=outer_folds, positive=positive, seed=seed,
                                         min_positive=min_positive, candidates=candidates)
    inner, inner_records = {}, []
    for k in range(outer_folds):
        train = outer != k
        bound = max_balanced_folds(groups[train], labels[train], positive=positive, min_positive=min_positive)
        fold = None
        for used in range(min(inner_folds, bound), 1, -1):  # fewer inner folds only when the search fails
            try:
                fold, rec = balanced_block_folds(groups[train], labels[train], n_folds=used, positive=positive,
                                                 seed=seed + 1000 * (k + 1), min_positive=min_positive,
                                                 candidates=candidates)
                break
            except ValueError:
                continue
        if fold is None:
            raise ValueError(f'outer fold {k}: no split of its training set gives two inner folds '
                             f'>= {min_positive} positive(s) each')
        column = np.full(len(groups), -1)
        column[train] = fold
        inner[k] = column
        inner_records.append({'outer_fold': k, 'inner_folds': used,
                              **({'reduced_from': inner_folds, 'reason': f'{inner_folds} inner folds with >= '
                                  f'{min_positive} positive(s) each were not possible or not found'}
                                 if used < inner_folds else {}), **rec})
    return outer, inner, {'outer': record, 'inner': inner_records}


def check_nested(groups, labels, outer, inner, *, positive, min_positive=1):
    """Independent check of a nested block split; returns per-fold support, raises on a violation."""
    groups, labels, outer = np.asarray(groups), np.asarray(labels), np.asarray(outer)
    frame = pd.DataFrame({'group': groups, 'outer': outer, 'p': labels == positive})
    if pd.isna(groups).any() or pd.isna(outer).any() or not np.all(np.mod(outer.astype(float), 1) == 0):
        raise ValueError('Every row needs a block and an integer outer fold')
    if frame.groupby('group').outer.nunique().max() != 1:
        raise ValueError('A block crosses outer folds')
    if set(inner) != set(np.unique(outer).astype(int).tolist()):
        raise ValueError('Inner assignments are needed for every outer fold and no other')
    rows = []
    for k, column in inner.items():
        column = np.asarray(column)
        test = outer == k
        if (column[test] != -1).any() or (column[~test] < 0).any():
            raise ValueError(f'outer fold {k}: outer test rows in inner folds, or training rows without one')
        sub = frame[~test].assign(inner=column[~test])
        if sub.groupby('group').inner.nunique().max() != 1:
            raise ValueError(f'outer fold {k}: a block crosses inner folds')
        counts = sub.groupby('inner').p.agg(['size', 'sum'])
        if len(counts) < 2:
            raise ValueError(f'outer fold {k}: fewer than two inner folds')
        if not 0 < frame.p[~test].sum() < (~test).sum():
            raise ValueError(f'outer fold {k}: its training set needs both label classes')
        if counts['sum'].min() < min_positive:
            raise ValueError(f'outer fold {k}: an inner fold holds fewer than {min_positive} positive(s)')
        rows.append({'outer_fold': int(k), 'outer_test_rows': int(test.sum()), 'outer_test_positive': int(frame.p[test].sum()),
                     'inner': [{'fold': int(f), 'rows': int(r['size']), 'positive': int(r['sum'])} for f, r in counts.iterrows()]})
    return rows


def check_split_manifest(manifest, ids, labels, *, positive, id_column, min_positive=1):
    """Validate a saved nested split (block_design's split_manifest.csv) before anything is fitted on it:
    one row per id, integer outer folds (at least two), whole blocks per outer and inner fold, an
    inner_fold_<k> column for every outer fold with -1 exactly on that outer test, and positives in
    every inner fold. Returns (outer, inner, blocks) aligned to `ids`; raises on a violation."""
    m = manifest.copy()
    m[id_column] = m[id_column].astype(str)
    if m[id_column].duplicated().any():
        raise ValueError('split manifest repeats an id')
    m = m.set_index(id_column).reindex([str(i) for i in ids])
    if m['outer_fold'].isna().any() or 'block' not in m or m['block'].isna().any():
        raise ValueError('split manifest does not give every cell a block and an outer fold')
    raw = m['outer_fold'].to_numpy(float)
    if not np.all(np.mod(raw, 1) == 0):
        raise ValueError('outer folds must be integers')
    outer = raw.astype(int)
    if (outer < 0).any():
        raise ValueError('outer folds must be non-negative integers (-1 marks the outer test only in inner_fold_<k>)')
    if len(np.unique(outer)) < 2:
        raise ValueError('at least two outer folds are needed')
    inner = {}
    for k in np.unique(outer):
        col = f'inner_fold_{k}'
        if col not in m or m[col].isna().any() or not np.all(np.mod(m[col].to_numpy(float), 1) == 0):
            raise ValueError(f'missing or non-integer {col}')
        inner[int(k)] = m[col].to_numpy(float).astype(int)
    blocks = m['block'].astype(str).to_numpy()
    check_nested(blocks, np.asarray(labels), outer, inner, positive=positive, min_positive=min_positive)
    return outer, inner, blocks
