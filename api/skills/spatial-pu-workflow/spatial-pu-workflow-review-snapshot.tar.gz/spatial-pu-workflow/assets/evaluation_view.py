"""Optional P/U evaluation-view skeleton, independent of models and file schemas.

Metric/curve functions use held-out scores only. Candidate selection is a separate
budget policy, not evaluation; caller declares OOF/full-fit provenance. Caller
resolves duplicate sites and support. No fitted model or probability claim.
Coding is 1 = recorded positive, 0 = the other class: unlabeled for P/U data,
verified negatives for P/N data. Keys keep P/U names (n_u); name the class in reports.
Fold-comparison/capture views only; no fixed methods, zone counts or target lines.
"""
import numpy as np
from sklearn.metrics import average_precision_score, precision_recall_curve, roc_auc_score, roc_curve


def checked_vectors(labels, scores):
    y, s = np.asarray(labels), np.asarray(scores, dtype=float)
    if y.ndim != 1 or not len(y) or s.shape != y.shape:
        raise ValueError('Nonempty aligned label/score vectors required')
    if not np.isin(y, [0, 1]).all() or not np.isfinite(s).all():
        raise ValueError('Use explicit P=1/U=0 coding and finite scores')
    return y.astype(int), s


def pu_metrics(labels, scores):
    """AP (not trapezoidal PR area); undefined class comparisons remain None."""
    y, s = checked_vectors(labels, scores)
    n_p = int(y.sum())
    both = 0 < n_p < len(y)
    return {'n': len(y), 'n_p': n_p, 'n_u': len(y) - n_p,
            'observed_prevalence': n_p / len(y),
            'average_precision': float(average_precision_score(y, s)) if both else None,
            'roc_auc': float(roc_auc_score(y, s)) if both else None}


def partial_roc_auc(labels, scores, *, max_fpr):
    """Tie-grouped ROC integration to an explicitly chosen FPR cutoff.

    Returns raw integral and McClish-standardized area, never conflated. For P/U
    labels FPR uses U as the reference class, not verified geological absences.
    ROC segments interpolate thresholds, not individual row-order tie breaks.
    No support-area weighting: this metric compares labelled observation units.
    """
    y, s = checked_vectors(labels, scores)
    if np.ndim(max_fpr) != 0 or not np.isfinite(max_fpr) or not 0 < max_fpr <= 1:
        raise ValueError('Explicit max_fpr in (0, 1] required')
    result = {'max_fpr': float(max_fpr), 'raw_area': None, 'standardized_area': None}
    if y.sum() in (0, len(y)):
        return result
    fpr, tpr, _ = roc_curve(y, s, drop_intermediate=False)
    stop = int(np.searchsorted(fpr, max_fpr, side='right'))
    fx, ty = fpr[:stop], tpr[:stop]
    if fx[-1] < max_fpr:
        endpoint = np.interp(max_fpr, fpr[stop-1:stop+1], tpr[stop-1:stop+1])
        fx, ty = np.r_[fx, max_fpr], np.r_[ty, endpoint]
    raw = float(np.trapezoid(ty, fx))
    null_area = .5 * max_fpr**2
    result.update(raw_area=raw,
                  standardized_area=float(.5*(1+(raw-null_area)/(max_fpr-null_area))))
    return result


def capture_curve(labels, scores, *, support=None):
    """Threshold-endpoint capture, invariant to ordering within score ties.

    support=None means observation count, NOT area. Supply positive finite support
    weights only with documented cell-area/cost semantics. Capture denominator is
    recorded P units, not all true deposits. No interpolation through tied groups.
    """
    y, s = checked_vectors(labels, scores)
    w = np.ones(len(y)) if support is None else np.asarray(support, dtype=float)
    if w.shape != y.shape or not np.isfinite(w).all() or (w <= 0).any():
        raise ValueError('Support weights must be aligned, finite, and positive')
    if y.sum() == 0:
        raise ValueError('Capture is undefined without recorded positives')
    order = np.argsort(-s, kind='stable')
    yy, ss, ww = y[order], s[order], w[order]
    ends = np.r_[np.flatnonzero(ss[:-1] != ss[1:]), len(ss) - 1]
    return {'fraction': np.r_[0., np.cumsum(ww)[ends] / ww.sum()],
            'capture': np.r_[0., np.cumsum(yy)[ends] / yy.sum()],
            'threshold': np.r_[np.inf, ss[ends]],
            'selected_n': np.r_[0, ends + 1],
            'support_total': float(ww.sum()), 'positive_total': int(yy.sum())}


def capture_at(curve, fraction):
    """Last attainable threshold within a budget; never split a tied group."""
    if not np.isfinite(fraction) or not 0 <= fraction <= 1:
        raise ValueError('Budget fraction must lie in [0, 1]')
    idx = int(np.searchsorted(curve['fraction'], fraction, side='right') - 1)
    return {key: np.asarray(curve[key])[idx].item()
            for key in ('fraction', 'capture', 'threshold', 'selected_n')}


def select_candidates(scores, eligible, fraction, *, support=None):
    """Highest-score eligible threshold groups within a whole-support budget.

    Ineligible units remain in the denominator (e.g. P excluded from candidates,
    but budget is a fraction of ALL valid-cell area). Never split score ties or
    skip a higher group to pack lower groups. None support means unit COUNT, not
    area. This selects a policy budget, not a predictive performance threshold.
    Budget boundaries allow relative 1e-12 rounding tolerance (zero stays exact).
    """
    s, e = np.asarray(scores, dtype=float), np.asarray(eligible)
    if s.ndim != 1 or not len(s) or e.shape != s.shape or e.dtype != np.dtype(bool) or not np.isfinite(s).all():
        raise ValueError('Finite scores and aligned explicit boolean eligibility required')
    w = np.ones(len(s)) if support is None else np.asarray(support, dtype=float)
    if w.shape != s.shape or not np.isfinite(w).all() or (w <= 0).any():
        raise ValueError('Positive finite aligned support required')
    if np.ndim(fraction) != 0 or not np.isfinite(fraction) or not 0 <= fraction <= 1:
        raise ValueError('Budget fraction must lie in [0, 1]')
    total = float(w.sum())
    idx = np.flatnonzero(e)
    order = idx[np.argsort(-s[idx], kind='stable')]
    chosen = order[:0]
    if len(order):
        ends = np.r_[np.flatnonzero(s[order][:-1] != s[order][1:]), len(order) - 1]
        cumulative = np.cumsum(w[order])[ends]
        budget = fraction * total
        within = ends[(cumulative <= budget) | np.isclose(cumulative, budget, rtol=1e-12, atol=0)]
        if fraction == 1:
            chosen = order
        elif len(within):
            chosen = order[:within[-1] + 1]
    selected = float(w[chosen].sum())
    return {'indices': chosen, 'selected_n': len(chosen), 'eligible_n': len(idx),
            'selected_support': selected, 'support_total': total, 'budget_support': fraction * total,
            'fraction': selected / total,
            'threshold': float(s[chosen[-1]]) if len(chosen) else None}


def evaluation_figure(labels, scores, folds, *, support=None,
                      support_label='Evaluated observation fraction', other_class='U'):
    """Three linked views: pooled PR, fold AP with support, threshold capture.

    If sites/cells were deduplicated, change support_label accordingly. For weights,
    require an explicit label such as 'Evaluated valid-cell area fraction'. Returns
    figure + computed tables so caller can save, inspect, and independently verify.
    """
    import matplotlib.pyplot as plt
    y, s = checked_vectors(labels, scores)
    f = np.asarray(folds)
    if f.shape != y.shape or any(v is None or v != v for v in f):
        raise ValueError('Aligned nonmissing fold IDs required')
    if support is not None and support_label == 'Evaluated observation fraction':
        raise ValueError('Weighted support needs an explicit denominator label')
    pooled = pu_metrics(y, s)
    table = [dict(fold=str(k), **pu_metrics(y[f == k], s[f == k])) for k in np.unique(f)]
    curve = capture_curve(y, s, support=support)
    fig, axes = plt.subplots(1, 3, figsize=(14, 4.5), layout='constrained')
    ax = axes[0]
    if pooled['average_precision'] is not None:
        precision, recall, _ = precision_recall_curve(y, s)
        ax.step(recall, precision, where='post', color='#176B87',
                label=f"Pooled fold-model AP={pooled['average_precision']:.3f}")
    ax.axhline(pooled['observed_prevalence'], color='#888888', linestyle='--',
               label=f"Recorded P fraction={pooled['observed_prevalence']:.3f}")
    ax.set(xlabel='Recall of recorded P', ylabel='Precision for P vs U',
           title='Held-out discrimination', xlim=(0, 1), ylim=(0, 1.02))
    ax.legend(loc='upper right', fontsize=8)
    ax = axes[1]
    for i, row in enumerate(table):
        if row['average_precision'] is not None:
            ax.scatter(i, row['average_precision'], color='#176B87')
        else:
            ax.annotate('n/a', (i, .5), ha='center', fontsize=9)
        ax.scatter(i, row['observed_prevalence'], marker='_', color='#888888')
    ax.set_xticks(range(len(table)), [f"{r['fold']}\nP={r['n_p']}, {other_class}={r['n_u']}" for r in table])
    ax.set(xlabel='Held-out fold (gray: P fraction)', ylabel='Average precision',
           title='Fold support and variation', ylim=(0, 1.02))
    ax = axes[2]
    ax.step(curve['fraction'], curve['capture'], where='post', color='#176B87')
    ax.scatter(curve['fraction'], curve['capture'], s=5, color='#176B87')
    # For equal-size evaluated units, random selection has expected capture q.
    # Do not silently extend this claim to unequal-area/budget-constrained sampling.
    if support is None or np.all(np.asarray(support) == np.asarray(support)[0]):
        ax.plot([0, 1], [0, 1], '--', color='#888888', label='Random equal-unit selection')
        ax.legend(loc='lower right', fontsize=8)
    ax.set(xlabel=support_label, ylabel='Fraction of recorded P captured',
           title='Pooled fold-model capture', xlim=(0, 1), ylim=(0, 1.02))
    for ax in axes:
        ax.grid(alpha=.2)
    return fig, {'pooled': pooled, 'folds': table, 'capture': curve}
