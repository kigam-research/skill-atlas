"""Optional EDA computations/figures. No imputation, feature deletion or fitting.

P/U comparisons are descriptive observed-label statistics, not causality.
Caller must map metadata-defined sentinels to NaN before these summaries.
"""
import numpy as np
import pandas as pd


def summarize_numeric(frame, labels, *, positive, unlabeled, tail_fraction=.01):
    """Per-feature counts, quantiles and tail P rates for description only.

    tail_fraction is a diagnostic display choice, not a winsorization rule.
    `unlabeled` is the non-positive class code (verified negatives for P/N data).
    """
    labels=np.asarray(labels)
    if len(frame)!=len(labels) or not 0 < tail_fraction < .5 or positive==unlabeled:
        raise ValueError('Aligned labels and tail fraction in (0,.5) required')
    if not np.isin(labels,[positive,unlabeled]).all(): raise ValueError('Unknown label')
    rows=[]
    for name in frame.columns:
        x=pd.to_numeric(frame[name],errors='raise').to_numpy(dtype=float,na_value=np.nan)
        valid=np.isfinite(x); v=x[valid]; p=labels==positive
        row={'feature':name,'n':len(x),'valid':int(valid.sum()),'missing_or_nonfinite':int((~valid).sum()),
             'positive_valid':int((valid&p).sum()),'positive_missing':int((~valid&p).sum()),
             'availability_role':'diagnostic, not geological cause'}
        if len(v):
            lo,q25,med,q75,hi=np.quantile(v,[tail_fraction,.25,.5,.75,1-tail_fraction])
            tail=valid&((x<lo)|(x>hi))
            for direction,part in [('lower',valid&(x<lo)),('upper',valid&(x>hi))]:
                row[f'{direction}_tail_n']=int(part.sum())
                row[f'{direction}_tail_p']=int((part&p).sum())
                row[f'{direction}_tail_p_rate']=float(p[part].mean()) if part.any() else None
            row.update(min=float(v.min()),max=float(v.max()),median=float(med),iqr=float(q75-q25),
                       lower_tail_cut=float(lo),upper_tail_cut=float(hi),tail_n=int(tail.sum()),
                       tail_p=int((tail&p).sum()),tail_p_rate=float(p[tail].mean()) if tail.any() else None,
                       valid_p_rate=float(p[valid].mean()),positive_median=float(np.median(x[valid&p])) if (valid&p).any() else None,
                       unlabeled_median=float(np.median(x[valid&~p])) if (valid&~p).any() else None)
        rows.append(row)
    return pd.DataFrame(rows)


def plot_distributions(frame, labels, *, positive, unlabeled, units=None, max_columns=3,
                       display_scales=None, class_names=('Known positive', 'Unlabeled')):
    """Full-support ECDFs; optional display scales never transform stored values.

    For signed heavy tails, e.g. display_scales={'TMI': {'kind': 'symlog',
    'linthresh': 50}}. The caller chooses the linear-region width in native
    units. 'log' is only valid when every observed value is strictly positive;
    zeros/negatives are not silently removed. These are display choices, not
    model preprocessing or a reason to delete tails. For P/N data pass
    class_names=('Positive', 'Negative'); U is not a confirmed negative.
    """
    import matplotlib.pyplot as plt
    if (len(frame)!=len(labels) or not len(frame.columns) or positive==unlabeled
            or not np.isin(labels,[positive,unlabeled]).all() or max_columns<1):
        raise ValueError('Nonempty aligned P/U data required')
    units=units or {};labels=np.asarray(labels);n=len(frame.columns);display_scales=display_scales or {}
    if set(display_scales)-set(frame.columns):raise ValueError('Display scale names must match columns')
    values={name:pd.to_numeric(frame[name],errors='raise').to_numpy(dtype=float,na_value=np.nan)
            for name in frame.columns}
    for name,x in values.items():
        choice=display_scales.get(name,{})
        if not isinstance(choice,dict):raise ValueError('Each display scale must be a mapping with kind')
        kind=choice.get('kind','linear')
        if kind not in ('linear','log','symlog'):raise ValueError('Choose linear, log or symlog display')
        if kind=='log' and (x[np.isfinite(x)]<=0).any():
            raise ValueError(f'{name}: log display would hide nonpositive values; use linear or symlog')
        if kind=='symlog':
            width=choice.get('linthresh',np.nan)
            if not np.isfinite(width) or width<=0:raise ValueError('Supply positive finite linthresh in native units')
    fig,axes=plt.subplots(int(np.ceil(n/max_columns)),min(n,max_columns),figsize=(4*min(n,max_columns),3*int(np.ceil(n/max_columns))),squeeze=False,layout='constrained')
    for ax,name in zip(axes.flat,frame.columns):
        x=values[name];choice=display_scales.get(name,{});kind=choice.get('kind','linear')
        for value,color,text in [(unlabeled,'#7f7f7f',class_names[1]),(positive,'#d62728',class_names[0])]:
            v=np.sort(x[(labels==value)&np.isfinite(x)])
            if len(v): ax.step(v,np.arange(1,len(v)+1)/len(v),where='post',color=color,label=f'{text} (n={len(v)})')
        ax.set_xscale(kind,**({'linthresh':choice['linthresh']} if kind=='symlog' else {}))
        if kind=='linear':
            # Large native values (e.g. distances in m) crowd the default ticks in small panels.
            from matplotlib.ticker import MaxNLocator
            ax.xaxis.set_major_locator(MaxNLocator(nbins=4))
        if kind=='symlog':
            # On one-sided data the default locator can place tiny log ticks
            # beside zero inside the linear region. Keep zero and the tails.
            from matplotlib.ticker import FixedLocator
            ticks=[t for t in ax.get_xticks() if t==0 or abs(t)>=choice['linthresh']]
            if len(ticks)>=2:ax.xaxis.set_major_locator(FixedLocator(ticks))
        display_note=(f"; symlog (linear ±{choice['linthresh']:g})" if kind=='symlog'
                      else f'; {kind} display' if kind!='linear' else '')
        ax.set(title=name,xlabel=units.get(name,'native value')+display_note,ylabel='Empirical CDF');ax.legend(fontsize=7)
    for ax in list(axes.flat)[n:]: ax.set_visible(False)
    from matplotlib.ticker import FuncFormatter
    for ax in axes.flat:  # mathtext log ticks draw U+2212, missing from many CJK fonts
        if ax.get_xscale() in ('log','symlog'): ax.xaxis.set_major_formatter(FuncFormatter(lambda v,_: f'{v:g}'))
    return fig


def plot_correlations(frame, *, min_periods=30):
    import matplotlib.pyplot as plt
    clean=frame.replace([np.inf,-np.inf],np.nan)
    corr=clean.corr(method='spearman',min_periods=min_periods)
    fig,ax=plt.subplots(figsize=(max(6,.42*len(corr)),max(5,.4*len(corr))),layout='constrained')
    im=ax.imshow(np.ma.masked_invalid(corr.to_numpy()),vmin=-1,vmax=1,cmap='RdBu_r')
    ax.set_xticks(range(len(corr)),corr.columns,rotation=90,fontsize=8)
    ax.set_yticks(range(len(corr)),corr.columns,fontsize=8)
    ax.set_title('Spearman correlation between predictors')
    fig.colorbar(im,ax=ax,label='Spearman rho (pairwise observed values)')
    counts=clean.notna().astype(int).T.dot(clean.notna().astype(int))
    return fig,corr,counts
