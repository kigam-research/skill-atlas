"""Optional plotting/layout skeleton: copy/adapt in user workspace.

Geometry/units are caller decisions. Lint does not establish scientific truth or
catch every overlap. Use actual rendered inspection where available.
"""
from pathlib import Path
import hashlib
import json
import logging
import math
import re
import warnings
import numpy as np
import matplotlib as mpl
from matplotlib import font_manager

COLORS = {'positive': '#d62728', 'unlabeled': '#7f7f7f', 'accent': '#176B87'}  # references/visual-defaults.md
FONT_DIR = Path(__file__).resolve().parent / 'fonts'  # bundled NanumGothic, SIL OFL 1.1


def register_bundled_fonts(font_dir=FONT_DIR):
    """Register bundled TTF files with matplotlib (process only, no system install).

Returns the registered family names; empty when the folder was not copied along.
"""
    font_dir = Path(font_dir)
    known = {Path(f.fname).resolve() for f in font_manager.fontManager.ttflist}
    names = []
    for path in sorted(font_dir.glob('*.ttf')) if font_dir.is_dir() else []:
        if path.resolve() not in known:
            font_manager.fontManager.addfont(str(path))
        names.append(font_manager.FontProperties(fname=str(path)).get_name())
    return sorted(set(names))


def apply_style(font_family=None):
    register_bundled_fonts()
    available = {f.name for f in font_manager.fontManager.ttflist}
    if font_family is None:
        font_family = next((f for f in ('Noto Sans CJK KR', 'NanumGothic', 'Noto Sans CJK JP')
                            if f in available), 'DejaVu Sans')
    mpl.rcParams.update({
        'font.family': font_family, 'font.size': 10, 'axes.unicode_minus': False,
        'axes.titlesize': 12, 'axes.labelsize': 10,
        'axes.spines.top': False, 'axes.spines.right': False,
        'figure.facecolor': 'white', 'axes.facecolor': '#FAFBFC',
        'savefig.facecolor': 'white', 'svg.fonttype': 'none',
    })
    return font_family  # if no Hangul font available, choose English plot labels


def short_crs(crs):
    """The CRS as an axis label can carry it: an EPSG code or a name up to its first qualifier, at most 24 characters."""
    text = str(crs).strip()
    if len(text) <= 24:
        return text
    head = re.split(r' \(|,|;', text)[0].strip()
    return head if len(head) <= 24 else head[:23] + '…'


def map_axes(ax, *, projected, unit, crs, latitude=None):
    """Small-area map aspect only; not a projection engine or CRS inference. A long CRS name is shortened in the
    axis labels (short_crs; the full name stays on the axis for check_map_crs) so side-by-side maps do not collide."""
    if projected:
        if unit not in ('m', 'km'):
            raise ValueError('Supply projected coordinates in m or km')
        ax.set_aspect('equal', adjustable='box')
        names = ('Easting', 'Northing')
    else:
        if unit != 'degree' or latitude is None or not -85 < latitude < 85:
            raise ValueError('Small-area geographic view needs degree units and nonpolar latitude')
        ax.set_aspect(1 / math.cos(math.radians(latitude)), adjustable='box')
        names = ('Longitude', 'Latitude')
    from matplotlib.ticker import MaxNLocator, ScalarFormatter
    for axis in (ax.xaxis, ax.yaxis):
        axis.set_major_locator(MaxNLocator(nbins=4))
        # Plain text ticks: mathtext draws '-' as U+2212, which many CJK fonts lack.
        # Full coordinate values: no offset and no '1e4' multiplier at the axis end.
        formatter=ScalarFormatter(useOffset=False, useMathText=False)
        formatter.set_scientific(False)
        axis.set_major_formatter(formatter)
    ax._map_crs = str(crs)
    ax.set_xlabel(f'{names[0]} ({unit}; {short_crs(crs)})')
    ax.set_ylabel(f'{names[1]} ({unit}; {short_crs(crs)})')


def outside_legend(ax, **kwargs):
    """Keep observations unobscured; reserve right-hand space in figure layout."""
    return ax.legend(loc='upper left', bbox_to_anchor=(1.02, 1), borderaxespad=0, **kwargs)


def map_legend(ax, *raster_layers, extra_handles=(), **kwargs):
    """Retain raster category/nodata meanings when adding overlay legends.

    Pass raster_map return dictionaries AFTER adding labelled overlays.
    Caller controls placement and must inspect actual PNG contrast/layout.
    Labels are semantic keys: distinct meanings need distinct legend labels.
    """
    handles = [h for layer in raster_layers for h in layer['legend_handles']]
    handles += list(extra_handles) + list(ax.get_legend_handles_labels()[0])
    unique = {}
    for handle in handles:
        label = handle.get_label()
        if label and not label.startswith('_'):
            unique.setdefault(label, handle)
    options = {'loc': 'upper left', 'bbox_to_anchor': (1.02, 1), 'borderaxespad': 0}
    options.update(kwargs)
    return ax.legend(handles=list(unique.values()), **options)


def lint_axes(ax, *, unit=None, require_legend=False):
    """Return concrete issues for one DATA axes (not a colorbar axes)."""
    problems = []
    if not ax.has_data():
        problems.append('empty data axes')
    for which, label in [('x', ax.get_xlabel()), ('y', ax.get_ylabel())]:
        if not label:
            problems.append(f'{which} label missing')
        if unit and unit not in label:
            problems.append(f'{which} expected unit missing: {unit}')
    if require_legend and ax.get_legend() is None:
        problems.append('legend missing for declared multiple series')
    return problems


def plain_scale_ticks(fig):
    """Log/symlog tick labels in plain text (e.g. -100, 1e+04).

Matplotlib draws them with mathtext, whose minus sign (U+2212) is missing from
the bundled Hangul font and renders as a dummy symbol.
"""
    from matplotlib.ticker import FuncFormatter
    fmt = FuncFormatter(lambda v, _: f'{v:g}')
    for ax in fig.axes:
        for axis, scale in ((ax.xaxis, ax.get_xscale()), (ax.yaxis, ax.get_yscale())):
            if scale in ('log', 'symlog'):
                axis.set_major_formatter(fmt)


def _tick_boxes(ax, axis, renderer):
    lo, hi = sorted(axis.get_view_interval())
    return [(label.get_text(), label.get_window_extent(renderer))
            for tick in axis.get_major_ticks() if lo <= tick.get_loc() <= hi
            for label in (tick.label1, tick.label2) if label.get_visible() and label.get_text()]


def _text_boxes(ax, renderer):
    """Window boxes of an axes' own title, axis labels and visible tick labels."""
    boxes = [(t.get_text(), t.get_window_extent(renderer)) for t in (ax.title, ax.xaxis.label, ax.yaxis.label)
             if t.get_visible() and t.get_text()]
    return boxes + _tick_boxes(ax, ax.xaxis, renderer) + _tick_boxes(ax, ax.yaxis, renderer)


def lint_layout(fig):
    """Report tick-label, legend and colorbar collisions after actual layout.

Flags: tick labels overlapping each other; a legend (axes or figure level) over
the title, axis labels or tick labels of any axes, its own included; a legend
over another axes' data area; a colorbar over another axes' text. Advisory, not
a proof of readability: inspect the exported image too.
"""
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    axes = [(i, ax) for i, ax in enumerate(fig.axes) if ax.get_visible()]
    texts = {i: _text_boxes(ax, renderer) for i, ax in axes}
    issues = []
    for i, ax in axes:
        for name, axis in (('x', ax.xaxis), ('y', ax.yaxis)):
            boxes = [b for _, b in _tick_boxes(ax, axis, renderer)]
            if any(a.overlaps(b) for j, a in enumerate(boxes) for b in boxes[j+1:]):
                issues.append(f'axes {i} {name} tick labels overlap; reduce tick density, format units or enlarge panel')
    legends = [(f'legend on axes {i}', ax, ax.get_legend()) for i, ax in axes]
    legends += [(f'figure legend {k}', None, lg) for k, lg in enumerate(fig.legends)]
    for name, owner, legend in legends:
        if legend is None or not legend.get_visible():
            continue
        box = legend.get_window_extent(renderer)
        for j, other in axes:
            hit = [t for t, b in texts[j] if box.overlaps(b)]
            if hit:
                issues.append(f'{name} covers text of axes {j}: {hit[0]!r}')
            elif other is not owner and box.overlaps(other.get_window_extent(renderer)):
                issues.append(f'{name} overlaps axes {j}')
    for i, ax in axes:  # a title or axis label running into another axes' text
        own = [(t.get_text(), t.get_window_extent(renderer)) for t in (ax.title, ax.xaxis.label, ax.yaxis.label)
               if t.get_visible() and t.get_text()]
        for j, other in axes:
            if j == i:
                continue
            hit = [(t, u) for t, b in own for u, c in texts[j] if b.overlaps(c)]
            if hit:
                issues.append(f'text of axes {i} {hit[0][0]!r} overlaps text of axes {j} {hit[0][1]!r}')
    for i, cax in axes:
        if not hasattr(cax, '_colorbar'):
            continue
        box = cax.get_window_extent(renderer)
        for j, other in axes:
            hit = [t for t, b in texts[j] if other is not cax and box.overlaps(b)]
            if hit:
                issues.append(f'colorbar axes {i} covers text of axes {j}: {hit[0]!r}')
    return issues


# A map must name its CRS: an EPSG code, or a named system with its zone/datum. A projection name
# alone (e.g. 'Mercator') or a bare unit is not enough.
CRS_PATTERN = re.compile(r'EPSG\s*:?\s*\d{4,6}|\bUTM\b\D{0,12}\d{1,2}|\bMGA\s*(?:94|2020)?\b\D{0,12}\d{1,2}|'
                         r'\bGDA\s*(?:94|2020)\b|\bWGS\s*84\b|\bNAD\s*(?:27|83)\b|'
                         r'\bCRS\s*[:=]\s*(?!unknown|none|\?)\S', re.I)
PAIR_PATTERN = re.compile(r'(?<!no )\bpairs?\b|쌍|N\(h\)', re.I)


def check_map_crs(ax, crs=None):
    """A map must name its CRS (EPSG code, or projection and zone) as well as the unit."""
    fig = ax.figure
    suptitle = fig.get_suptitle() if hasattr(fig, 'get_suptitle') else ''
    text = ' '.join([ax.get_xlabel(), ax.get_ylabel(), ax.get_title(), suptitle])
    if crs is not None:
        if not str(crs).strip() or str(crs).strip().lower() in ('unknown', 'none'):
            return ['CRS unknown: find it in the metadata or ask; do not draw a map without it']
        shown = crs in text or (getattr(ax, '_map_crs', None) == str(crs) and short_crs(crs) in text)
        return [] if shown else [f'map axes does not show the CRS {crs!r} in labels or title']
    return [] if CRS_PATTERN.search(text) else ['map axes names no CRS (e.g. an EPSG code or a UTM zone); a unit alone is not a CRS']


def check_pair_support(fig):
    """A distance-dependence figure must show how many pairs support each lag."""
    for ax in fig.axes:
        words = [ax.get_xlabel(), ax.get_ylabel(), ax.get_title()] + [t.get_text() for t in ax.texts]
        legend = ax.get_legend()
        if legend is not None:
            words += [t.get_text() for t in legend.get_texts()]
        if any(PAIR_PATTERN.search(w) for w in words if w):
            return []
    return ['dependence figure shows no pair counts per lag (add a pairs panel, axis or labels)']


def map_legend_issues(fig, maps):
    """A legend drawn over a map hides cells; keep map legends outside the map box."""
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    issues = []
    legends = [(ax, ax.get_legend()) for ax in maps] + [(None, lg) for lg in fig.legends]
    for owner, legend in legends:
        if legend is None or not legend.get_visible():
            continue
        box = legend.get_window_extent(renderer)
        for i, ax in enumerate(maps):
            area = ax.get_window_extent(renderer)
            if box.overlaps(area) and min(box.x1, area.x1) - max(box.x0, area.x0) > 2 and min(box.y1, area.y1) - max(box.y0, area.y0) > 2:
                issues.append(f'legend covers cells of map {i}; place it outside the map (e.g. figure_style.map_legend)')
    return issues


def map_shape_issues(fig, maps):
    """A 2D map should show the analysis grid as an axis-aligned rectangle of square cells.

Flags map axes with no cell raster (points or polygons only), cells that are not
axis-aligned (a grid reprojected or rotated for display), a frame much larger than
the grid, and a free aspect ratio. Draw in the grid's own CRS (grid_map.raster_map).
"""
    from matplotlib.collections import QuadMesh
    from matplotlib.image import AxesImage
    issues = []
    for i, ax in enumerate(maps):
        meshes = [m for m in ax.collections if isinstance(m, QuadMesh)]
        images = [m for m in ax.get_images() if isinstance(m, AxesImage)]
        if not meshes and not images:
            issues.append(f'map {i} has no cell raster; draw the grid as an axis-aligned raster (grid_map.raster_map), '
                          'not points or reprojected polygons')
            continue
        coords = [np.asarray(m.get_coordinates()) for m in meshes]
        if any(not (np.allclose(c[..., 0], c[:1, :, 0]) and np.allclose(c[..., 1], c[:, :1, 1])) for c in coords):
            issues.append(f'map {i} cells are not axis-aligned (grid reprojected or rotated for display); '
                          "draw it in the grid's own CRS so the map stays rectangular")
            continue
        boxes = [(c[..., 0].min(), c[..., 0].max(), c[..., 1].min(), c[..., 1].max()) for c in coords]
        boxes += [tuple(sorted(im.get_extent()[:2])) + tuple(sorted(im.get_extent()[2:])) for im in images]
        x0, x1 = min(b[0] for b in boxes), max(b[1] for b in boxes)
        y0, y1 = min(b[2] for b in boxes), max(b[3] for b in boxes)
        if coords:
            cell = max(np.median(np.abs(np.diff(coords[0][0, :, 0]))) if coords[0].shape[1] > 1 else 0,
                       np.median(np.abs(np.diff(coords[0][:, 0, 1]))) if coords[0].shape[0] > 1 else 0)
        else:
            rows, cols = images[0].get_array().shape[:2]
            cell = max((x1 - x0) / max(cols, 1), (y1 - y0) / max(rows, 1))
        (fx0, fx1), (fy0, fy1) = sorted(ax.get_xlim()), sorted(ax.get_ylim())
        slack = max(1.5 * cell, .05 * max(fx1 - fx0, fy1 - fy0))
        if fx0 < x0 - slack or fx1 > x1 + slack or fy0 < y0 - slack or fy1 > y1 + slack:
            issues.append(f'map {i} frame is larger than the grid; set the limits to the grid extent')
        geographic = re.search(r'longitude|latitude|degree', ax.get_xlabel() + ax.get_ylabel(), re.I)
        if ax.get_aspect() == 'auto':
            issues.append(f'map {i} aspect is free, so cells are not square; use map_axes or set_aspect')
        elif not geographic and not np.isclose(float(ax.get_aspect()), 1.0):
            issues.append(f'map {i} aspect is {float(ax.get_aspect()):g}, so projected cells are stretched; use equal aspect')
    return issues


def _drawn_grid(artist):
    """(x edges, y edges, 2D values) as drawn by a QuadMesh or an AxesImage; row i spans y_edges[i]..y_edges[i+1]."""
    from matplotlib.image import AxesImage
    values = np.ma.filled(np.ma.asarray(artist.get_array(), dtype=float), np.nan)
    if isinstance(artist, AxesImage):
        if values.ndim != 2:
            return None  # an RGB(A) picture: no cell values to compare
        left, right, bottom, top = artist.get_extent()
        rows, cols = values.shape
        # matplotlib puts row 0 at the `top` extent value with origin='upper' and at `bottom` with origin='lower'
        first, last = (top, bottom) if artist.origin == 'upper' else (bottom, top)
        return np.linspace(left, right, cols + 1), np.linspace(first, last, rows + 1), values
    coords = np.asarray(artist.get_coordinates())
    if values.size != (coords.shape[0] - 1) * (coords.shape[1] - 1):
        return None  # values on the corners (e.g. shading='gouraud'): no cell values to compare
    return coords[0, :, 0], coords[:, 0, 1], values.reshape(coords.shape[0] - 1, coords.shape[1] - 1)


def map_placement_issues(maps, cells=None):
    """Every cell raster on a map axis must show each table cell at its own coordinates.

Rasters drawn by grid_map.raster_map are placed from the coordinates and pass. Any other raster
(imshow, a hand-built pcolormesh) is compared with `cells` = (x, y, values) of the table it shows,
values as drawn (e.g. zone codes): one tuple for every map or a list with one per map. Without
`cells` its placement is unverified and flagged: a flipped or shifted image looks like a map.
"""
    from matplotlib.collections import QuadMesh
    from matplotlib.image import AxesImage
    import importlib.util
    spec = importlib.util.spec_from_file_location('grid_map', Path(__file__).resolve().parent / 'grid_map.py')
    grid_map = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(grid_map)
    tables = list(cells) if isinstance(cells, list) else [cells] * len(maps)
    issues = []
    for i, ax in enumerate(maps):
        table = tables[i] if i < len(tables) else None
        rasters = [m for m in ax.collections if isinstance(m, QuadMesh)] + [m for m in ax.get_images() if isinstance(m, AxesImage)]
        for artist in rasters:
            if artist.get_transform() is not ax.transData:
                issues.append(f'map {i}: a raster drawn with a transform other than the axis data coordinates; its cell '
                              'placement is unverified (draw it in data coordinates)')
                continue
            if getattr(artist, '_cell_placement', None) == 'raster_map':
                continue
            if table is None:
                issues.append(f'map {i}: a raster not drawn by grid_map.raster_map has unverified cell placement; '
                              'draw it with raster_map, or pass cells=(x, y, values as drawn) to save_figure')
                continue
            drawn = _drawn_grid(artist)
            if drawn is None:
                issues.append(f'map {i}: a raster without one value per cell (an RGB image or corner shading) cannot be '
                              'checked against the table; draw cell values instead')
                continue
            x, y = np.asarray(table[0], float), np.asarray(table[1], float)
            v = np.ma.filled(np.ma.asarray(table[2], dtype=float), np.nan)  # masked table values compare as missing
            bad = grid_map.check_cell_placement(*drawn, x, y, v)
            if len(bad):
                issues.append(f'map {i}: {len(bad)} of {len(x)} table cells are drawn elsewhere or with another value '
                              '(e.g. rows flipped north-south, or a grid stretched over a wrong extent)')
    return issues


class _GlyphLog(logging.Handler):
    """Collects matplotlib's missing-glyph messages; mathtext reports them through logging, not warnings."""
    def __init__(self):
        super().__init__(logging.WARNING)
        self.messages = []

    def emit(self, record):
        message = record.getMessage()
        if 'glyph' in message.lower():
            self.messages.append(message)


def _sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for block in iter(lambda: f.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()


def save_figure(fig, stem, *, maps=(), crs=None, dependence=False, record=None, cells=None):
    """Save PNG and SVG after checks; optionally add an entry to <folder>/figure-records.json.

Rejects: an empty figure; missing glyphs (text warnings and the mathtext log
messages); map axes listed in `maps` that name no CRS (or not `crs`); a figure
declared `dependence=True` that shows no pair counts. Layout collisions, maps
that are not an axis-aligned rectangular raster, and map rasters whose cells do not
sit at the table's coordinates are warned, not fixed. Rasters drawn by
grid_map.raster_map pass the placement check; for any other raster pass `cells`
(see map_placement_issues). `record` (stage, question, sources, score_role, ...) is kept
with the checks so a reader can see what each figure answers and from which tables.
Passing checks is not an inspection: open the PNG as well.
"""
    stem = Path(stem)
    maps = [] if maps is None else list(np.ravel(np.asarray(maps, dtype=object)))  # a list, an array of axes or one axis
    if not fig.axes or not any(a.has_data() for a in fig.axes):
        raise ValueError('Empty figure')
    problems = [p for ax in maps for p in check_map_crs(ax, crs)]
    if dependence:
        problems += check_pair_support(fig)
    if problems:
        raise ValueError(f'{stem.name}: ' + '; '.join(sorted(set(problems))))
    stem.parent.mkdir(parents=True, exist_ok=True)
    glyphs = _GlyphLog()
    logger = logging.getLogger('matplotlib')
    logger.addHandler(glyphs)
    try:
        with warnings.catch_warnings():
            warnings.filterwarnings('error', message=r'Glyph .* missing from font')
            fig.canvas.draw()
            if glyphs.messages:
                raise ValueError(f'{stem.name}: missing glyphs {sorted(set(glyphs.messages))[:2]}; for log/symlog '
                                 'axes call plain_scale_ticks(fig), otherwise replace the character')
            layout = (lint_layout(fig) + map_legend_issues(fig, maps) + map_shape_issues(fig, maps)
                      + map_placement_issues(maps, cells))
            for issue in layout:
                warnings.warn(issue, UserWarning, stacklevel=2)
            for extension in ('png', 'svg'):
                fig.savefig(stem.with_suffix('.' + extension), dpi=180, bbox_inches='tight')
    finally:
        logger.removeHandler(glyphs)
    png = stem.with_suffix('.png')
    if glyphs.messages:
        for extension in ('png', 'svg'):
            stem.with_suffix('.' + extension).unlink(missing_ok=True)  # do not leave a defective file behind
        raise ValueError(f'{stem.name}: missing glyphs during export {sorted(set(glyphs.messages))[:2]}')
    if record is not None:
        entry = dict(record)
        entry['sources'] = [{'path': str(src), 'sha256': _sha256(src)} for src in record.get('sources', [])]
        entry.update({'file': png.name, 'png_sha256': _sha256(png), 'checks': {
            'glyphs': 'ok', 'layout_warnings': layout,
            'map_crs': 'ok' if maps else 'not declared', 'pair_counts': 'ok' if dependence else 'not declared'}})
        path = stem.parent / 'figure-records.json'
        records = json.loads(path.read_text()) if path.exists() else []
        records = [r for r in records if r.get('file') != png.name] + [entry]
        path.write_text(json.dumps(records, indent=2, ensure_ascii=False) + '\n')
    return png


def value_map(ax, x, y, values, *, name, unit, positive_mask=None, cmap='viridis'):
    """Point-value diagnostic example; values must already have sentinel→NaN.

No raster interpolation, no CRS inference, no implied equal-area support.
Call map_axes, outside_legend and set shared limits as appropriate afterwards.
"""
    x, y, v = np.asarray(x, float), np.asarray(y, float), np.asarray(values, float)
    if x.ndim != 1 or y.shape != x.shape or v.shape != x.shape or not len(x):
        raise ValueError('Nonempty equal-length point arrays required')
    if not np.isfinite(x).all() or not np.isfinite(y).all():
        raise ValueError('Resolve invalid coordinates before plotting')
    valid = np.isfinite(v)
    result = {'valid_n': int(valid.sum()), 'missing_n': int((~valid).sum())}
    if valid.any():
        dots = ax.scatter(x[valid], y[valid], c=v[valid], cmap=cmap, s=22, zorder=2)
        result['colorbar'] = ax.figure.colorbar(dots, ax=ax, label=f'{name} ({unit})' if unit else name, shrink=.85)
    if (~valid).any():
        ax.scatter(x[~valid], y[~valid], marker='x', c='#606060', s=25,
                   label=f'Missing ({result["missing_n"]} rows)', zorder=3)
    if positive_mask is not None:
        p = np.asarray(positive_mask, bool)
        if p.shape != x.shape:
            raise ValueError('Positive mask shape differs from coordinates')
        ax.scatter(x[p], y[p], facecolors='none', edgecolors='black', s=65,
                   linewidths=.8, label='Known positive observations', zorder=4)
    ax.set_title(name)
    return result
