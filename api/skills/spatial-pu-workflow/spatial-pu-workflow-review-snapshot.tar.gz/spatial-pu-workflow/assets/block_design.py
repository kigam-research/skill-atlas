"""Spatial block design for sparse labels: label range -> block size -> nested balanced folds.

    uv run python block_design.py <spec.json> [--outer 5] [--inner 4] [--seed 42] [--min-positive 1]
                                  [--block-size <m or km, as the cells unit>] [--range-factor 1.0] [--out DIR]

<spec.json> is the stage-evidence spec; only its "cells" part is read (table, id, x, y, unit, crs,
spacing, label, positive, unlabeled). The cells must form a regular grid (partial edge blocks with
averaged centres are placed in the grid cell that holds them).

1. Label semivariogram over every pair of cells on the grid, lags to half the smaller extent.
2. Label range by variogram.label_range: the empirical variance-reached distance (the lag where the
   semivariance first reaches the label variance), else a usable fitted r95, else not identified - then the command
   stops and asks for --block-size with its basis.
3. Block side: the smallest whole number of cells >= range x --range-factor, blocks tiled from the
   grid's lower-left edge.
4. Outer folds, and inner folds inside each outer training set, by
   spatial_contract.nested_block_folds: optimized random assignment that spreads the positives evenly
   (then rows), from per-block label counts only - never model scores.
5. Checks (no block crosses a fold, outer test rows never in inner folds, every fold holds a positive)
   and outputs in DIR (default <spec out>/split): block_design.json, label_semivariance.csv,
   split_manifest.csv (id, block, outer_fold, inner_fold_<k> with -1 on that outer test),
   fold_summary.csv, block_range.png, block_folds.png, inner_folds.png (checked by save_figure).

Feature semivariograms are not computed (cost); compute them when the user asks. The block size is a
design choice supported by the label pattern, not a proof that folds are independent.
"""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import sys

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent


def _load(name):
    spec = importlib.util.spec_from_file_location(name, HERE / f'{name}.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


stage_evidence = _load('stage_evidence')
figure_style, grid_map, variogram = stage_evidence.figure_style, stage_evidence.grid_map, stage_evidence.variogram
spatial_contract = _load('spatial_contract')
COLORS, P_MARK = stage_evidence.GROUP_COLORS, stage_evidence.P_MARK


def design(spec, *, outer=5, inner=4, seed=42, min_positive=1, block_size=None, range_factor=1.0, out=None,
           candidates=32):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    figure_style.apply_style()
    c = stage_evidence.Cells(spec)
    if c.grid_problem:
        raise ValueError(f'block design needs the analysis grid: {c.grid_problem}')
    if not c.projected:
        raise ValueError('block distances need projected coordinates (unit m or km)')
    out = Path(out or Path(spec.get('out', 'figures')) / 'split')
    out.mkdir(parents=True, exist_ok=True)
    unit, (dx, dy) = c.display_unit, c.spacing
    scale = 1000.0 if c.unit == 'm' else 1.0
    col, row, *_ = grid_map.grid_indices(c.x, c.y, spacing=c.spacing)
    grid = np.full((row.max() + 1, col.max() + 1), np.nan)
    grid[row, col] = c.is_p.astype(float)
    edges = variogram.lag_edges(min(dx, dy), min(col.max() * dx, row.max() * dy))
    e = variogram.grid_empirical(grid, dx=dx, dy=dy, edges=edges)
    found = variogram.label_range(e)
    pd.DataFrame({'lag_lower': edges[:-1], 'lag_upper': edges[1:], 'mean_distance': e['mean_distance'],
                  'semivariance': e['semivariance'], 'pairs': e['pair_count']}).to_csv(out / 'label_semivariance.csv', index=False)
    if block_size is not None:
        block = spatial_contract.block_size_for_range(block_size / scale, (dx, dy))
        block['basis'] = 'given by the caller (--block-size)'
    elif found['range'] is None:
        raise ValueError(f"label range not identified within {edges[-1]:g} {unit}: {found.get('note')}. "
                         'Give --block-size and state its basis')
    else:
        block = spatial_contract.block_size_for_range(found['range'], (dx, dy), factor=range_factor)
        block['basis'] = f"label range ({found['rule']}) x {range_factor:g}"
    kx, ky = block['cells']
    groups = np.array([f'b{a:03d}_{b:03d}' for a, b in zip(col // kx, row // ky)])
    labels = c.frame[c.label].to_numpy()
    outer_f, inner_f, assignment = spatial_contract.nested_block_folds(
        groups, labels, outer_folds=outer, inner_folds=inner, positive=c.positive, seed=seed,
        min_positive=min_positive, candidates=candidates)
    checks = spatial_contract.check_nested(groups, labels, outer_f, inner_f, positive=c.positive, min_positive=min_positive)
    distances = spatial_contract.nearest_split_distances(c.x, c.y, outer_f)

    ids = c.frame[c.id].to_numpy()
    manifest = pd.DataFrame({c.id: ids, 'block': groups, 'outer_fold': outer_f,
                             **{f'inner_fold_{k}': v for k, v in inner_f.items()}})
    manifest.to_csv(out / 'split_manifest.csv', index=False)
    summary = []
    for f in assignment['outer']['folds']:
        d = next(x for x in distances if x['fold'] == f['fold'])
        summary.append({'level': 'outer', 'outer_fold': f['fold'], 'fold': f['fold'], 'blocks': f['blocks'],
                        'rows': f['rows'], 'positive': f['positive'], 'other': f['other'],
                        f'test_to_train_min_{unit}': d['min_distance'], f'test_to_train_median_{unit}': d['median_distance']})
    for r in assignment['inner']:
        for f in r['folds']:
            summary.append({'level': 'inner', 'outer_fold': r['outer_fold'], 'fold': f['fold'], 'blocks': f['blocks'],
                            'rows': f['rows'], 'positive': f['positive'], 'other': f['other']})
    pd.DataFrame(summary).to_csv(out / 'fold_summary.csv', index=False)

    spread = spatial_contract.positive_spread_bound(groups, labels, positive=c.positive, n_folds=outer)
    counts = [f['positive'] for f in assignment['outer']['folds']]
    spread['achieved'] = int(max(counts) - min(counts))
    assignment['outer']['positive_spread'] = spread
    notes = ['folds use per-block counts of positives and rows only; no model scores',
             'feature semivariograms not computed; compute them when the user asks',
             'block edges are a design grid, not geological boundaries; blocks reduce but do not remove spatial leakage']
    if spread['achieved']:
        k, total = spread['largest_block_positive'], spread['positives']
        why = (f"block {spread['largest_block']} holds {k} of {total} positives" if k > -(-total // outer) else
               f"{total} positives do not divide evenly into {outer} folds")
        if spread['achieved'] == spread['lower_bound']:
            notes.append(f"outer folds differ by {spread['achieved']} positives, the least possible with whole blocks "
                         f"({why})")
        else:
            notes.append(f"outer folds differ by {spread['achieved']} positives; a bound from the largest block gives "
                         f"{spread['lower_bound']}, and whole blocks of these sizes may not allow less (not proven)")
    if found.get('trend'):
        notes.append(found['trend'] + '; the range is an empirical design distance, not a sill of that trend '
                     'and not proof of independent folds')
    if c.mercator:
        notes.append(f'{c.crs} is Mercator: distances and block sides are map units (ground = map x cos(latitude))')
    if c.placement:
        notes.append(f"{c.placement['moved']} cells off the grid were placed in the grid cell that holds them")
    record = {'input': {'table': str(c.source), 'sha256': hashlib.sha256(Path(c.source).read_bytes()).hexdigest(),
                        'rows': int(len(ids)), 'positives': int(c.is_p.sum())},
              'grid': {'crs': c.crs, 'unit': unit, 'spacing': [dx, dy], 'shape': list(grid.shape)},
              'label_range': {**found, 'edges': edges, 'unit': unit},
              'block': {**block, 'unit': unit, 'blocks': int(len(np.unique(groups))),
                        'origin': 'lower-left edge of the grid'},
              'assignment': assignment, 'checks': checks, 'outer_test_to_train': distances, 'notes': notes}
    (out / 'block_design.json').write_text(json.dumps(record, indent=2, ensure_ascii=False, default=float) + '\n')

    files = [_range_figure(plt, c, e, found, block, out), _fold_figure(plt, c, groups, outer_f, assignment, block, out),
             _inner_figure(plt, c, groups, outer_f, inner_f, out)]
    return {'out': str(out), 'record': record, 'figures': [str(f) for f in files]}


def _range_figure(plt, c, e, found, block, out):
    unit = c.display_unit + ('; Mercator map units' if c.mercator else '')
    axes = variogram.plot(e, [], unit=unit, title='Recorded label: semivariance by distance and the block side')
    top = axes[0]
    top.axhline(e['value_variance'], color='#888888', linestyle='--', label=f"Label variance {e['value_variance']:.4g}")
    if found['range'] is not None:
        top.axvline(found['range'], color='#b2182b', label=f"Label range ({found['rule']}): {found['range']:.3g} {c.display_unit}")
    top.axvline(block['size'][0], color='#2166ac', linestyle=':', linewidth=1.6,
                label=f"Block side {block['size'][0]:.3g} {c.display_unit} ({block['cells'][0]} cells)")
    top.legend(fontsize=8, loc='lower right')
    fig = top.figure
    fig.set_size_inches(8, 6.5)
    return figure_style.save_figure(fig, out / 'block_range', dependence=True, record={
        'stage': 'M2-M3', 'question': 'Up to what distance are labels alike, and what block side follows',
        'sources': [c.source]})


def _categories(values, names):
    return {k: (names[k], COLORS[k % len(COLORS)]) for k in sorted(set(values)) if k >= 0}


def _fold_figure(plt, c, groups, outer_f, assignment, block, out):
    fig, ax = plt.subplots(figsize=c.figsize(1, 1, 7.5), layout='constrained')
    names = {f['fold']: f"fold {f['fold']}: {f['blocks']} blocks, {c.short[0]}={f['positive']}, {c.short[1]}={f['other']}"
             for f in assignment['outer']['folds']}
    info = c.map_panel(ax, outer_f.astype(float), categories=_categories(outer_f, names),
                       title=f"Outer folds: blocks of {block['cells'][0]} x {block['cells'][1]} cells "
                             f"({block['size'][0]:.3g} {c.display_unit}), positives spread evenly")
    c.group_edges(ax, groups)
    figure_style.map_legend(ax, info, fontsize=8, title='White lines: block edges', title_fontsize=8)
    return figure_style.save_figure(fig, out / 'block_folds', maps=[ax], crs=c.crs, record={
        'stage': 'M3', 'question': 'Which blocks form each outer fold, and how many positives each holds',
        'sources': [c.source]})


def _inner_figure(plt, c, groups, outer_f, inner_f, out):
    n = len(inner_f)
    ncols = min(3, n + 1)  # one slot is kept for the legend
    nrows = int(np.ceil((n + 1) / ncols))
    fig, axes = plt.subplots(nrows, ncols, figsize=c.figsize(ncols, nrows, 4.2), layout='constrained', squeeze=False)
    maps, handles = [], {}
    for ax, (k, column) in zip(axes.flat, inner_f.items()):
        values = np.where(outer_f == k, -1, column).astype(float)
        counts = [int((c.is_p & (column == f)).sum()) for f in sorted(set(column[column >= 0]))]
        cats = {-1: ('outer test of that panel', '#d9d9d9'),
                **{f: (f'inner fold {f}', COLORS[f % len(COLORS)]) for f in sorted(set(column[column >= 0]))}}
        info = c.map_panel(ax, values, categories=cats,
                           title=f"Outer fold {k}: inner {c.short[0]} = {'/'.join(map(str, counts))}")
        c.group_edges(ax, groups)
        maps.append(ax)
        for h in info['legend_handles'] + ax.get_legend_handles_labels()[0]:
            handles.setdefault(h.get_label(), h)
    spare = list(axes.flat)[n:]
    for ax in spare:
        ax.set_axis_off()
    spare[0].legend(handles=list(handles.values()), loc='center left', fontsize=8,
                    title='White lines: block edges', title_fontsize=8)
    fig.suptitle('Inner folds inside each outer training set (same balancing)', fontsize=10)
    return figure_style.save_figure(fig, out / 'inner_folds', maps=maps, crs=c.crs, record={
        'stage': 'M3', 'question': 'How each outer training set is split for tuning, and with how many positives',
        'sources': [c.source]})


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('spec')
    parser.add_argument('--outer', type=int, default=5)
    parser.add_argument('--inner', type=int, default=4)
    parser.add_argument('--seed', type=int, default=42)
    parser.add_argument('--min-positive', type=int, default=1)
    parser.add_argument('--block-size', type=float, help='block side in the cells unit, when the label range is not used')
    parser.add_argument('--range-factor', type=float, default=1.0)
    parser.add_argument('--candidates', type=int, default=32)
    parser.add_argument('--out')
    args = parser.parse_args(argv)
    spec = json.loads(Path(args.spec).read_text())
    result = design(spec, outer=args.outer, inner=args.inner, seed=args.seed, min_positive=args.min_positive,
                    block_size=args.block_size, range_factor=args.range_factor, out=args.out, candidates=args.candidates)
    r = result['record']
    lr, b = r['label_range'], r['block']
    print(f"label range: {lr['rule']}" + (f" {lr['range']:.4g} {lr['unit']}" if lr['range'] is not None else ''))
    print(f"block side: {b['size'][0]:.4g} x {b['size'][1]:.4g} {b['unit']} ({b['cells'][0]} x {b['cells'][1]} cells), "
          f"{b['blocks']} blocks; basis: {b['basis']}")
    for f in r['assignment']['outer']['folds']:
        print(f"outer fold {f['fold']}: {f['blocks']} blocks, {f['rows']} rows, {f['positive']} positive")
    s = r['assignment']['outer'].get('positive_spread', {})
    if s:
        print(f"outer positive spread {s['achieved']} (lower bound {s['lower_bound']}: block {s['largest_block']} holds "
              f"{s['largest_block_positive']} of {s['positives']})")
    for x in r['assignment']['inner']:
        print(f"inner folds of outer {x['outer_fold']}: positives {[f['positive'] for f in x['folds']]}"
              + (f" (reduced: {x['reason']})" if 'reason' in x else ''))
    for note in r['notes']:
        print('note:', note)
    for f in result['figures']:
        print('figure', f)
    print('Open every PNG; the block size is a design choice, not proof of independent folds.')
    return 0


if __name__ == '__main__':
    sys.exit(main())
