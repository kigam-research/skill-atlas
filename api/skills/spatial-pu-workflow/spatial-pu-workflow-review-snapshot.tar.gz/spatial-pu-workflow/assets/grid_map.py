"""Optional cell-grid geometry skeleton; not for irregular point observations.

Caller must establish cell semantics, projected CRS, spacing and duplicate policy.
Coordinates are sorted by keys, not assumed to follow CSV order. No interpolation.
"""
import numpy as np


def transformed_cell_areas(x, y, *, spacing, transform):
    """Per-input-cell polygon area in target coordinate units squared.

    x/y are unique rectangular cell centres in the SOURCE CRS; spacing is in
    that CRS. transform accepts array x/y (e.g. pyproj always_xy Transformer).
    Caller must choose an appropriate equal-area projected target and establish
    its units before reporting physical area. Four transformed corners joined
    by straight edges approximate curved footprints, NOT exact geodesic area.
    No absent grid cells are fabricated; output order matches input order.
    Caller establishes non-overlapping support before summing (cell_grid can
    check regular-grid alignment); this helper does not infer an AOI.
    """
    x, y = np.asarray(x, float), np.asarray(y, float)
    dx, dy = map(float, spacing)
    if x.ndim != 1 or y.shape != x.shape or not len(x):
        raise ValueError('Nonempty equal-length 1D centre arrays required')
    if not np.isfinite(x).all() or not np.isfinite(y).all() or not np.isfinite([dx, dy]).all() or min(dx, dy) <= 0:
        raise ValueError('Finite centres and positive explicit spacing required')
    if len(set(zip(x, y))) != len(x):
        raise ValueError('Duplicate cell centres would double-count area')
    sx = x[:, None] + np.array([-.5, .5, .5, -.5])*dx
    sy = y[:, None] + np.array([-.5, -.5, .5, .5])*dy
    tx, ty = (np.asarray(a, float) for a in transform(sx, sy))
    if tx.shape != sx.shape or ty.shape != sy.shape or not np.isfinite(tx).all() or not np.isfinite(ty).all():
        raise ValueError('Transform must return finite arrays of the same shape')
    # Shift to a local origin to avoid cancellation for large projected coords.
    tx, ty = tx-tx[:, :1], ty-ty[:, :1]
    area = .5*np.abs(np.sum(tx*np.roll(ty, -1, axis=1)-ty*np.roll(tx, -1, axis=1), axis=1))
    if np.any(area <= 0):
        raise ValueError('Degenerate transformed cell polygon')
    return area


def grid_indices(x, y, *, spacing, origin=None, min_aligned=.5):
    """Column/row of the grid cell holding each point, and that cell's centre.

A regular grid whose edge cells carry averaged coordinates (for example blocks
aggregated from a finer grid, where a partial edge block's mean lies off the
block centre) still maps to one rectangle. `origin` is one cell centre (x, y);
by default the centre alignment shared by most points, which must hold for at
least `min_aligned` of them on each axis (irregular samples are not a grid).
Rows increase with y.
Returns (col, row, centre_x, centre_y, record); the record counts points moved
to their cell centre and the largest shift. Two points in one cell raise.
"""
    x, y = np.asarray(x, float), np.asarray(y, float)
    dx, dy = map(float, spacing)
    if x.ndim != 1 or y.shape != x.shape or not len(x):
        raise ValueError('Nonempty equal-length 1D arrays required')
    if not np.isfinite(x).all() or not np.isfinite(y).all() or not np.isfinite([dx, dy]).all() or min(dx, dy) <= 0:
        raise ValueError('Finite coordinates and positive explicit spacing required')

    def axis(v, d, o):
        if o is None:  # the within-cell offset most points share
            frac = np.round(np.mod(v - v.min(), d) / d, 6) % 1
            values, counts = np.unique(frac, return_counts=True)
            if counts.max() < min_aligned * len(v):
                raise ValueError(f'only {counts.max()} of {len(v)} coordinates share a grid alignment; '
                                 'not a regular grid (supply origin if it is one)')
            o = v.min() + values[np.argmax(counts)] * d
        raw = np.floor((v - (o - d / 2)) / d + 1e-9).astype(np.int64)
        return raw - raw.min(), o + raw * d

    col, cx = axis(x, dx, None if origin is None else float(origin[0]))
    row, cy = axis(y, dy, None if origin is None else float(origin[1]))
    if len(set(zip(col, row))) != len(x):
        raise ValueError('Two points fall in one grid cell; aggregate them first or check the spacing')
    shift = np.hypot(x - cx, y - cy)
    moved = shift > 1e-6 * min(dx, dy)
    return col, row, cx, cy, {'moved': int(moved.sum()), 'max_shift': float(shift.max()),
                              'origin': [float(cx[0] - col[0] * dx), float(cy[0] - row[0] * dy)]}


def cell_grid(x, y, values, *, spacing, return_presence=False):
    x, y, values = np.asarray(x, float), np.asarray(y, float), np.asarray(values, float)
    dx, dy = map(float, spacing)
    if x.ndim != 1 or y.shape != x.shape or values.shape != x.shape or not len(x):
        raise ValueError('Nonempty equal-length 1D arrays required')
    if not np.isfinite(x).all() or not np.isfinite(y).all() or not np.isfinite([dx, dy]).all() or min(dx, dy) <= 0:
        raise ValueError('Finite coordinates and positive explicit spacing required')
    ux, uy = np.unique(x), np.unique(y)
    ix_float, iy_float = (x-ux[0])/dx, (y-uy[0])/dy
    ix, iy = np.rint(ix_float).astype(int), np.rint(iy_float).astype(int)
    if not np.allclose(ix_float, ix, atol=1e-6, rtol=0) or not np.allclose(iy_float, iy, atol=1e-6, rtol=0):
        raise ValueError('Coordinates do not align to supplied cell grid')
    if len(set(zip(ix, iy))) != len(x):
        raise ValueError('Duplicate cell coordinates require an explicit aggregation policy')
    nx, ny = int(ix.max()+1), int(iy.max()+1)
    if nx*ny > 10_000_000:
        raise ValueError('Grid too large for this small skeleton; use a tiled geospatial writer')
    z = np.full((ny, nx), np.nan)
    z[iy, ix] = values
    x_edges = ux[0] + (np.arange(nx+1)-.5)*dx
    y_edges = uy[0] + (np.arange(ny+1)-.5)*dy
    result = (x_edges, y_edges, np.ma.masked_invalid(z))
    if return_presence:
        present = np.zeros(z.shape, dtype=bool)
        present[iy, ix] = True
        return (*result, present)
    return result


def _edges(edges):
    edges = np.asarray(edges, float)
    if edges.ndim != 1 or len(edges) < 2 or not np.isfinite(edges).all():
        raise ValueError('Edges must be a finite 1D array with at least two values')
    step = np.diff(edges)
    if not (np.all(step > 0) or np.all(step < 0)):
        raise ValueError('Edges must be strictly monotonic')
    return edges


def _edge_index(edges, v):
    n = len(edges)-1
    ascending = edges[1] > edges[0]
    asc = edges if ascending else edges[::-1]
    k = np.searchsorted(asc, v, side='right')-1
    inside = np.isfinite(v) & (k >= 0) & (k < n) & (v < asc[-1])
    return (k if ascending else n-1-k), inside


def check_cell_placement(x_edges, y_edges, grid, x, y, values, *, atol=1e-9):
    """Return table indices whose cell is drawn elsewhere or with another value.

    Pass the edges and 2D array that were actually drawn, whatever the drawing
    call: grid[i, j] spans y_edges[i]..y_edges[i+1] and x_edges[j]..x_edges[j+1].
    Edges may decrease (e.g. an image whose first row is drawn at the top, so
    y_edges run from the top edge downwards); a coordinate belongs to the cell
    whose interval [lower, upper) holds it. x/y/values come from the saved
    table. NaN or masked values match NaN or masked values on either side; a
    non-finite or outside coordinate is reported. An empty result means the
    table agrees with the edges and array passed in. It does not prove that
    they are what the figure shows (check the render), nor anything about the
    CRS, axis labels or meaning of the values. Equal values can hide a swap,
    so check a variable that differs between cells (e.g. the score).
    """
    xe, ye = _edges(x_edges), _edges(y_edges)
    x, y = np.asarray(x, float), np.asarray(y, float)
    values = np.ma.filled(np.ma.asarray(values, dtype=float), np.nan)
    z = np.ma.filled(np.ma.asarray(grid, dtype=float), np.nan)
    if z.shape != (len(ye)-1, len(xe)-1):
        raise ValueError('Grid shape must be (len(y_edges)-1, len(x_edges)-1)')
    if x.ndim != 1 or x.shape != y.shape or values.shape != x.shape:
        raise ValueError('Equal-length 1D table arrays required')
    j, okx = _edge_index(xe, x)
    i, oky = _edge_index(ye, y)
    inside = okx & oky
    drawn = np.full(x.shape, np.nan)
    drawn[inside] = z[i[inside], j[inside]]
    same = np.isclose(drawn, values, atol=atol, rtol=0) | (np.isnan(drawn) & np.isnan(values))
    return np.flatnonzero(~inside | ~same)


def fit_colorbar_to_map(ax, colorbar, location):
    """Match the colorbar's long side to the drawn map box and keep it next to the map.

An equal-aspect map usually fills less than its layout slot, so a
plain colorbar ends up wider than the map with a gap between them. The map is
anchored against the colorbar and, at draw time, the colorbar is rescaled to
the map's actual extent (extend triangles keep their share).
"""
    from matplotlib.transforms import Bbox
    cax = colorbar.ax
    ax.set_anchor({'bottom': 'S', 'top': 'N', 'right': 'E', 'left': 'W'}[location])
    base = cax.get_axes_locator()
    horizontal = location in ('bottom', 'top')

    def locate(a, renderer):
        pos = base(a, renderer) if base is not None else a.get_position(original=True)
        a.set_box_aspect(None)  # the base locator re-imposes the colorbar aspect ratio
        slot = a.get_position(original=True)
        ax.apply_aspect()
        box = ax.get_position(original=False)
        if horizontal:
            k = box.width / slot.width
            return Bbox.from_extents(box.x0 + (pos.x0 - slot.x0) * k, pos.y0, box.x0 + (pos.x1 - slot.x0) * k, pos.y1)
        k = box.height / slot.height
        return Bbox.from_extents(pos.x0, box.y0 + (pos.y0 - slot.y0) * k, pos.x1, box.y0 + (pos.y1 - slot.y0) * k)
    cax.set_axes_locator(locate)
    return colorbar


def map_figsize(x, y, *, spacing, ncols=1, nrows=1, panel_width=5.5, extra_height=1.6):
    """Figure size whose panels follow the data's east-west/north-south ratio (no wide blank margins)."""
    x, y = np.asarray(x, float), np.asarray(y, float)
    width = np.ptp(x) + spacing[0]
    height = np.ptp(y) + spacing[1]
    panel_height = panel_width * height / width
    return (panel_width * ncols + 1.2, (panel_height + extra_height) * nrows)


def raster_map(ax, x, y, values, *, spacing, name, value_unit,
               cmap='viridis', limits=None, categories=None, nodata_color='#d9d9d9',
               colorbar_label=None, colorbar_location='bottom', absent_color='#FFFFFF'):
    """Fill actual cell footprints, without point gaps or invented interpolation.

Coordinates/spacing share one projected unit. Supply a value per unique cell.
`categories` is {numeric_value: (label, color)} for discrete maps (fold/zone).
Caller handles CRS transforms, scientific labels, duplicate resolution and overlay.
Bottom colorbar keeps the right side free for outside_legend; use a short colorbar_label.
The colorbar follows the drawn map width (fit_colorbar_to_map); size figures with map_figsize.
Use constrained layout and inspect the rendered combination, including custom legends.
"""
    from matplotlib import colormaps
    from matplotlib.colors import ListedColormap, BoundaryNorm, Normalize
    from matplotlib.patches import Patch
    xe, ye, z, present = cell_grid(x, y, values, spacing=spacing, return_presence=True)
    missing = present & np.ma.getmaskarray(z)
    clipped_low = clipped_high = 0
    extend = 'neither'
    legend_handles = []
    if categories is None:
        cm = colormaps[cmap].copy()
        vmin, vmax = limits if limits is not None else (None, None)
        if limits is not None:
            if not np.isfinite([vmin, vmax]).all() or vmin >= vmax:
                raise ValueError('Finite increasing color limits required')
            clipped_low = int((z.compressed() < vmin).sum())
            clipped_high = int((z.compressed() > vmax).sum())
            extend = 'both' if clipped_low and clipped_high else 'min' if clipped_low else 'max' if clipped_high else 'neither'
        norm = Normalize(vmin=vmin, vmax=vmax)
        data = z
    else:
        keys = list(categories)
        if not keys:
            raise ValueError('Nonempty category mapping required')
        existing = np.unique(z.compressed())
        if not set(existing).issubset(keys):
            raise ValueError('Raster has values outside declared categories')
        data = np.ma.masked_all(z.shape, dtype=float)
        for i, key in enumerate(keys):
            data[(~np.ma.getmaskarray(z)) & (z.data == key)] = i
            label, color = categories[key]
            legend_handles.append(Patch(facecolor=color, label=label))
        cm = ListedColormap([categories[k][1] for k in keys])
        norm = BoundaryNorm(np.arange(len(keys)+1)-.5, len(keys))
    cm = cm.with_extremes(bad=nodata_color)
    mesh = ax.pcolormesh(xe, ye, data, cmap=cm, norm=norm, shading='flat',
                         edgecolors='none', linewidth=0, antialiased=False, rasterized=True)
    mesh._cell_placement = 'raster_map'  # placed from the coordinates; figure_style.save_figure trusts it
    absent_mesh = None
    if (~present).any():
        absent_mesh = ax.pcolormesh(
            xe, ye, np.ma.masked_where(present, np.zeros(z.shape)),
            cmap=ListedColormap([absent_color]), shading='flat', edgecolors='none',
            linewidth=0, antialiased=False, rasterized=True)
        absent_mesh._cell_placement = 'raster_map'
        legend_handles.append(Patch(facecolor=absent_color, edgecolor='#888888',
                                    label='No input cell (support unknown)'))
    ax.set_xlim(xe[0], xe[-1])
    ax.set_ylim(ye[0], ye[-1])
    ax.set_aspect('equal', adjustable='box')
    ax.set_title(name)
    colorbar = None
    if categories is None and z.count():
        constrained = type(ax.figure.get_layout_engine()).__name__ == 'ConstrainedLayoutEngine'
        pad = .02 if constrained else (.12 if colorbar_location in ('bottom', 'top') else .05)
        colorbar = ax.figure.colorbar(
            mesh, ax=ax, label=colorbar_label or (f'{name} ({value_unit})' if value_unit else name),
            location=colorbar_location, pad=pad, fraction=.04, extend=extend)
        fit_colorbar_to_map(ax, colorbar, colorbar_location)
    if missing.any():
        legend_handles.append(Patch(facecolor=nodata_color, label='No valid data'))
    return {'mesh': mesh, 'colorbar': colorbar, 'legend_handles': legend_handles,
            'x_edges': xe, 'y_edges': ye, 'grid': z, 'valid_cells': int(z.count()),
            'nodata_cells': int(missing.sum()), 'absent_cells': int((~present).sum()),
            'present_mask': present, 'absent_mesh': absent_mesh,
            'clipped_low': clipped_low, 'clipped_high': clipped_high}
