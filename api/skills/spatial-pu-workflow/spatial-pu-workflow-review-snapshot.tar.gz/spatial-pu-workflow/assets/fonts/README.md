# 동봉 한글 글꼴

`figure_style.apply_style()`이 시스템 한글 글꼴이 없는 환경에서도 한국어 축·범례를 그리도록 동봉한 원본 글꼴이다. `register_bundled_fonts()`가 이 폴더의 `*.ttf`를 matplotlib에 등록하며 시스템 설치는 하지 않는다.

| 파일 | 크기(byte) | sha256 |
| --- | --- | --- |
| `NanumGothic.ttf` | 4,691,820 | `48a28e97b34fc8e5b157657633670cd1b7de126cfc414da65ce9c3d5bc8be733` |
| `NanumGothicBold.ttf` | 4,642,244 | `454eb3f503f377782a99eb84fc4bb7dde22a0f075d41b47427737f2985053bc9` |

- 출처: NAVER 나눔글꼴(https://hangeul.naver.com/2017/nanum). 파일은 Ubuntu noble `fonts-nanum` 20200506-1 패키지의 `/usr/share/fonts/truetype/nanum/`에서 수정 없이 복사했다(2026-09-23).
- 라이선스: SIL Open Font License 1.1, 전문은 [`OFL.txt`](OFL.txt). 글꼴을 다른 소프트웨어와 함께 재배포할 수 있으나 글꼴 자체만 판매할 수 없다. 이 글꼴로 만든 그림에는 라이선스가 적용되지 않는다.
- 예약 글꼴 이름(Nanum, NanumGothic 등) 때문에 부분 추출·변환한 수정본을 같은 이름으로 배포하지 않는다. 용량을 줄이려면 원본 대신 시스템 글꼴을 쓰고 이 폴더를 빼면 된다(`apply_style()`은 시스템 글꼴로 되돌아간다).
- `figure_style.py`를 workspace로 복사해 쓸 때는 이 `fonts/` 폴더도 함께 복사하거나 `register_bundled_fonts(<스킬 경로>/assets/fonts)`를 직접 호출한다.
