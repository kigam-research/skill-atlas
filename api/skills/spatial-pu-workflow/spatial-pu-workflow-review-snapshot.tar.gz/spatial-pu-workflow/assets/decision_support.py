"""Optional stability/screening/ranking primitives, NOT a conformal guarantee.

No estimator or threshold is silently selected. Missing outputs remain invalid.
"""
import numpy as np


def bootstrap_summary(predictions, *, min_mean):
    """Replicate mean, quartiles and relative IQR (Q75-Q25)/mean, returned as `rho`.

    One dispersion summary among several (SD, rank stability, selection frequency).
    Cut-offs on it are policy choices made by the caller, not defaults.
    """
    p=np.asarray(predictions,float)
    if p.ndim!=2 or p.shape[0]<2 or not p.shape[1] or not np.isfinite(p).all() or ((p<0)|(p>1)).any():
        raise ValueError('Finite B>=2 by N probability matrix in [0,1] required')
    if not np.isfinite(min_mean) or min_mean<=0: raise ValueError('Positive denominator floor required')
    mean=p.mean(axis=0);q25,q75=np.quantile(p,[.25,.75],axis=0)
    rho=np.divide(q75-q25,mean,out=np.full(len(mean),np.nan),where=mean>=min_mean)
    return {'mean':mean,'q25':q25,'q75':q75,'rho':rho,'rho_valid':np.isfinite(rho),'replicates':p.shape[0],
            'interpretation':'Quantile precision requires replicate sensitivity; caller sets decision-relevant rho mask'}


def positive_screen_threshold(calibrated_scores, labels, *, positive, alpha, correction):
    """Largest observed threshold obeying empirical positive FNR + correction.

    Caller supplies correction and assumptions. None means unsupported, never
    auto-fallback to a reported valid guarantee. Threshold uses >= membership.
    """
    s=np.asarray(calibrated_scores,float);y=np.asarray(labels)
    if s.ndim!=1 or y.shape!=s.shape or not len(s) or not np.isfinite(s).all() or ((s<0)|(s>1)).any():
        raise ValueError('Aligned finite calibrated probabilities required')
    if not 0<alpha<1 or not np.isfinite(correction) or correction<0:
        raise ValueError('Valid alpha and explicit nonnegative correction required')
    p=s[y==positive];n=len(p)
    base={'n_positive':n,'alpha':alpha,'correction':correction,'guarantee':'none asserted by helper'}
    if not n or correction>alpha:
        return {**base,'status':'unsupported','threshold':None,'reason':'no_positive_or_correction_exceeds_alpha'}
    ordered=np.sort(p)
    candidates=np.unique(s)
    fnr=np.searchsorted(ordered,candidates,side='left')/n
    allowed=fnr+correction<=alpha+1e-12
    t=float(candidates[allowed][-1]);actual=float(np.mean(p<t))
    return {**base,'status':'empirical_screen','threshold':t,'calibration_fnr':actual,
            'calibration_retained_fraction':float(np.mean(s>=t))}


def upper_fraction(scores, *, weights=None):
    """Conservative rank: fraction at or ABOVE score; ties kept together.

    Caller invokes on the declared ranking population (not a hidden subset).
    Supply area weights only if geometrically validated; default is cell count.
    """
    s=np.asarray(scores,float);w=np.ones(len(s)) if weights is None else np.asarray(weights,float)
    if s.ndim!=1 or w.shape!=s.shape or not len(s) or not np.isfinite(s).all() or not np.isfinite(w).all() or (w<=0).any():
        raise ValueError('Finite scores and positive support weights required')
    order=np.argsort(-s,kind='stable');ss=s[order];cumulative=np.cumsum(w[order])/w.sum()
    end=np.r_[np.flatnonzero(ss[:-1]!=ss[1:]),len(ss)-1]
    start=np.r_[0,end[:-1]+1];result=np.empty(len(s))
    for a,b in zip(start,end): result[order[a:b+1]]=cumulative[b]
    return result


def _aligned_scores(scores, sample_ids, population):
    s = np.asarray(scores, float)
    ids = np.asarray(sample_ids)
    if (s.ndim != 2 or s.shape[0] < 2 or not s.shape[1]
            or not np.isfinite(s).all() or ids.ndim != 1
            or len(ids) != s.shape[1] or len(set(ids.tolist())) != len(ids)
            or not isinstance(population, str) or not population.strip()):
        raise ValueError('Finite aligned M>=2 by N scores, unique IDs and explicit population required')
    if any(x is None or (isinstance(x, (float, np.floating)) and not np.isfinite(x)) for x in ids):
        raise ValueError('Stable IDs must not be missing')
    return s, ids


def rank_stability(scores, *, sample_ids, population, weights=None):
    """Rank-only dispersion for aligned model/replicate by item scores.

    Higher scores rank first. Caller joins every row to the SAME ordered IDs
    and declares the comparison population/fit roles; never pool unmatched
    folds or silently drop missing support. Weights describe that population,
    not an implicit survey budget. No calibration or confidence is inferred.
    """
    s, ids = _aligned_scores(scores, sample_ids, population)
    ranks = np.stack([upper_fraction(row, weights=weights) for row in s])
    q25, q75 = np.quantile(ranks, [.25, .75], axis=0)
    return {'sample_ids': ids.copy(), 'population': population,
            'upper_fraction': ranks, 'mean': ranks.mean(axis=0),
            'sd': ranks.std(axis=0, ddof=1), 'q25': q25, 'q75': q75,
            'replicates': s.shape[0],
            'interpretation': 'Conditional rank dispersion, not probability or total uncertainty'}


def rank_agreement(scores, *, sample_ids, population, k_values, groups=None):
    """Cached rank comparisons, not an exploration-budget policy.

    Higher scores rank first. Each explicit k is a count diagnostic, NOT area.
    Include the entire exact-score tie at kth place; realized counts may exceed k.
    Spearman uses average tied ranks; constant-score correlations are undefined.
    Sorted scores, ranks, correlations and each k's masks are computed once.
    Optional groups identify configuration/member strata; mixed summaries must
    not be attributed solely to member resampling. Caller verifies fit roles.
    """
    s, _ = _aligned_scores(scores, sample_ids, population)
    ks = list(k_values)
    if not ks or any(isinstance(k, (bool, np.bool_)) or not isinstance(k, (int, np.integer))
                     or not 1 <= k <= s.shape[1] for k in ks):
        raise ValueError('Explicit nonempty integer k values within population required')
    labels = ['unspecified'] * len(s) if groups is None else list(groups)
    if len(labels) != len(s) or any(not isinstance(g, str) or not g.strip() for g in labels):
        raise ValueError('One nonempty group label per ranker required')
    ordered = np.sort(s, axis=1)
    ranks = np.stack([(np.searchsorted(o, row, 'left') + np.searchsorted(o, row, 'right') + 1) / 2
                      for o, row in zip(ordered, s)])
    with np.errstate(divide='ignore', invalid='ignore'):
        corr = np.corrcoef(ranks) if s.shape[1] > 1 else np.full((len(s), len(s)), np.nan)
    pairs = [(i, j) for i in range(len(s)) for j in range(i + 1, len(s))]
    rhos = np.array([corr[i, j] for i, j in pairs])

    def stats(values, prefix):
        finite = np.asarray(values)[np.isfinite(values)]
        return {prefix + '_' + name: float(fn(finite)) if len(finite) else None
                for name, fn in [('min', np.min), ('median', np.median), ('max', np.max)]}

    strata = {}
    for n, (i, j) in enumerate(pairs):
        key = tuple(sorted((labels[i], labels[j])))
        strata.setdefault(key, []).append(n)
    pair_records = [{'i': i, 'j': j, 'groups': [labels[i], labels[j]],
                     'spearman': float(rhos[n]) if np.isfinite(rhos[n]) else None}
                    for n, (i, j) in enumerate(pairs)]
    top = []
    for k in dict.fromkeys(ks):
        masks = s >= ordered[:, -k, None]
        sizes = masks.sum(axis=1)
        inter = np.array([np.count_nonzero(masks[i] & masks[j]) for i, j in pairs])
        jac = inter / np.array([sizes[i] + sizes[j] - inter[n] for n, (i, j) in enumerate(pairs)])
        top.append({'k': int(k), 'realized_counts': sizes.tolist(),
                    'union_n': int(masks.any(axis=0).sum()), 'intersection_n': int(masks.all(axis=0).sum()),
                    **stats(jac, 'jaccard'),
                    'pairs': [{'i': i, 'j': j, 'intersection_n': int(inter[n]), 'jaccard': float(jac[n])}
                              for n, (i, j) in enumerate(pairs)],
                    'strata': [{'groups': list(key), 'scope': 'within' if key[0] == key[1] else 'between',
                                'pairs': len(ix), **stats(rhos[ix], 'spearman'), **stats(jac[ix], 'jaccard')}
                               for key, ix in strata.items()]})
    return {'population': population, 'rankers': len(s), 'groups': labels,
            'grouping_supplied': groups is not None, 'pairs': pair_records,
            **stats(rhos, 'spearman'), 'undefined_spearman_pairs': int((~np.isfinite(rhos)).sum()),
            'top_k': top, 'interpretation': 'Conditional fixed-score rank agreement; not probability or total uncertainty',
            'tie_policy': 'Keep whole kth-score tie group; average tied ranks for Spearman',
            'count_not_area': True}


def platt_scaling(scores, labels, *, positive):
    """Sigmoid calibration of scores to the recorded-label rate: p = 1 / (1 + exp(-(a * s + b))).

    Fit on held-out scores from models that did not train on these rows. For P/U labels the result is
    the rate of recorded positives, not a probability of occurrence. Returns {'a', 'b', 'n', 'n_positive'}.
    """
    from sklearn.linear_model import LogisticRegression
    s, y = np.asarray(scores, float), np.asarray(labels) == positive
    if s.ndim != 1 or y.shape != s.shape or not np.isfinite(s).all() or not 0 < y.sum() < len(y):
        raise ValueError('Finite scores with both classes required')
    model = LogisticRegression(C=1e6, max_iter=1000).fit(s[:, None], y)
    return {'a': float(model.coef_[0, 0]), 'b': float(model.intercept_[0]), 'n': int(len(s)), 'n_positive': int(y.sum())}


def platt_apply(scores, fit):
    return 1 / (1 + np.exp(-(fit['a'] * np.asarray(scores, float) + fit['b'])))


def conformal_positive_threshold(scores, labels, *, positive, alpha):
    """Split-conformal screen for positives: keep cells scoring >= the k-th lowest calibration positive.

    k = floor(alpha * (n + 1)). Under exchangeability of calibration and new positives, a new positive
    passes with probability >= 1 - alpha. Spatial dependence and a different score generator break that
    assumption, so no guarantee is asserted; report held-out coverage instead. Too few positives
    (k < 1) -> status 'unsupported', never a silent fallback.
    """
    s, y = np.asarray(scores, float), np.asarray(labels) == positive
    if s.ndim != 1 or y.shape != s.shape or not np.isfinite(s).all() or not 0 < alpha < 1:
        raise ValueError('Aligned finite scores and 0 < alpha < 1 required')
    p = np.sort(s[y])
    k = int(np.floor(alpha * (len(p) + 1)))
    base = {'alpha': alpha, 'n_positive': int(len(p)), 'rank': k, 'guarantee': 'none asserted (spatial dependence)'}
    if k < 1:
        return {**base, 'status': 'unsupported', 'threshold': None,
                'reason': f'{len(p)} calibration positives; alpha={alpha} needs at least {int(np.ceil(1 / alpha)) - 1}'}
    return {**base, 'status': 'split_conformal', 'threshold': float(p[k - 1]),
            'calibration_coverage': float(np.mean(p >= p[k - 1]))}


def repeated_split_screen(scores, labels, groups, *, positive, alpha, repeats, seed):
    """Repeated cross calibration of the positive screen: halve the calibration pool by group `repeats` times,
    set the split-conformal threshold on one half and measure positive coverage and retained share on the
    other. The spread shows how stable the threshold is; the median threshold is one way to combine them."""
    s, y, g = np.asarray(scores, float), np.asarray(labels) == positive, np.asarray(groups)
    blocks = np.unique(g)
    rows = []
    for r in range(repeats):
        rng = np.random.default_rng([seed, r])
        half = set(rng.permutation(blocks)[: len(blocks) // 2])
        a = np.isin(g, list(half))
        t = conformal_positive_threshold(s[a], y[a], positive=True, alpha=alpha)
        if t['threshold'] is None or not y[~a].any():
            rows.append({'repeat': r, 'threshold': None, 'coverage': None, 'retained': None})
            continue
        rows.append({'repeat': r, 'threshold': t['threshold'], 'coverage': float(np.mean(s[~a][y[~a]] >= t['threshold'])),
                     'retained': float(np.mean(s[~a] >= t['threshold']))})
    return rows


def classify_zones(scores, *, covered, uncertainty, uncertainty_cut, tiers, mode='lift', weights=None):
    """Priority zones from a score, a positive screen and an uncertainty, in this order:

    1. outside the positive screen (covered False) -> excluded, whatever the score;
    2. inside, in a tier but uncertainty above the cut or not assessed -> 'uncertain';
    3. inside and certain -> the first tier it reaches: mode 'lift' tiers are upper fractions of the
       ranking population (ties kept together, upper_fraction), mode 'prob' tiers are descending
       calibrated-score thresholds;
    4. inside but in no tier -> 'lower'.
    Codes: 0..len(tiers)-1 tiers, len(tiers) uncertain/lower, len(tiers)+1 excluded. The tiers, the cut
    and the screen come from the purpose and budget, not from this function.
    """
    s = np.asarray(scores, float)
    covered, u = np.asarray(covered, bool), np.asarray(uncertainty, float)
    tiers = list(tiers)
    if mode == 'lift':
        if sorted(tiers) != tiers or not all(0 < t <= 1 for t in tiers):
            raise ValueError('lift tiers are increasing upper fractions in (0, 1]')
        position = upper_fraction(s, weights=weights)
        tier = np.full(len(s), len(tiers))
        for i, t in reversed(list(enumerate(tiers))):
            tier[position <= t + 1e-12] = i
    elif mode == 'prob':
        if sorted(tiers, reverse=True) != tiers:
            raise ValueError('prob tiers are decreasing score thresholds')
        tier = np.full(len(s), len(tiers))
        for i, t in reversed(list(enumerate(tiers))):
            tier[s >= t] = i
    else:
        raise ValueError("mode is 'lift' or 'prob'")
    code = np.where(covered, tier, len(tiers) + 1)
    in_tier = covered & (tier < len(tiers))
    unsure = in_tier & ~(u <= uncertainty_cut)  # NaN (not assessed) counts as unsure
    code[unsure] = len(tiers)
    reason = np.select([~covered, unsure, in_tier], ['outside positive screen', 'uncertainty above cut or not assessed',
                                                     'tier'], 'below tiers')
    return code, reason


def zone_capture(codes, labels, folds, *, positive, n_zones):
    """Per zone: share of cells and of recorded positives, per fold and as mean and SD over folds."""
    import pandas as pd
    frame = pd.DataFrame({'zone': np.asarray(codes), 'p': np.asarray(labels) == positive, 'fold': np.asarray(folds)})
    rows = []
    for f, part in frame.groupby('fold'):
        for z in range(n_zones):
            inside = part['zone'] == z
            rows.append({'fold': f, 'zone': z, 'cell_share': float(inside.mean()),
                         'capture': float(part.loc[inside, 'p'].sum() / part['p'].sum()) if part['p'].any() else np.nan})
    per_fold = pd.DataFrame(rows)
    summary = per_fold.groupby('zone').agg(cell_share_mean=('cell_share', 'mean'), cell_share_sd=('cell_share', 'std'),
                                           capture_mean=('capture', 'mean'), capture_sd=('capture', 'std')).reset_index()
    return per_fold, summary

