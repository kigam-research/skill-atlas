"""Nested spatial evaluation of a binary baseline and a bagging-PU model on the same folds, with
calibration, a positive screen, uncertainty and priority zones - from a block_design split.

    uv run python pu_workflow.py <spec.json> --split <split/split_manifest.csv> \
        --tiers <upper fractions or calibrated thresholds> --alpha <tolerated miss rate> --rel-iqr-cut <cut> \
        [--zone-mode lift|prob [--rank-fractions ...]] [--zone-names ...] [--models binary bagging_pu] [--primary bagging_pu] \
        [--members 8] [--u-fractions 0.25 0.5] [--depths 2 4] [--trees 100 200] [--bootstrap 20] \
        [--new-gap 2] [--seed 42] [--n-jobs 2] [--out DIR]

--tiers, --alpha and --rel-iqr-cut are decisions from the purpose and budget; the command has no
defaults for them. With --zone-mode prob the tiers are calibrated thresholds, and --rank-fractions (upper
fractions for the far-target ranking and the zone-rule comparison) is needed as well; in lift mode those use
the tiers. Predictors are the spec's "predictors" columns; missing values stay missing (the
learner, XGBoost, handles them), so no statistics cross folds.

Per outer fold k (rows with outer_fold == k are never used to fit anything made for fold k):
1. Tuning: every candidate (learner depth x trees, and for bagging PU the U fraction) is fitted on
   the fold's inner training folds and scored by average precision on each inner validation fold; the
   best mean is selected within each model family.
2. The selected pipeline is fitted on the outer training set and scores the outer test (held-out).
3. Calibration pool = the selected candidate's inner out-of-fold scores (models that saw neither those
   rows nor the outer test). Platt scaling and the split-conformal positive screen (raw-score threshold;
   --screen repeated takes the median over 20 block-wise halvings) are set on it and applied to the outer
   test. Held-out coverage of test positives is reported per fold; too few pool positives leave the fold
   without a screen, reported as such.
4. Uncertainty: B block-bootstrap refits of the selected pipeline on the outer training set (the same
   procedure for both families); relative IQR of their outer-test scores, assessed for cells inside
   the widest tier.
5. Held-out zones of the outer test with the fold's own screen, uncertainty and fold-local ranks.
Deployment (full-fit map): selection with the outer folds as tuning folds (a variant of the evaluated
rule, recorded), fit on all rows, calibration and screen on the selected candidate's outer
out-of-fold scores, bootstrap on all rows, zones for the map - not an evaluation.

New ground: every cell gets its grid steps to the nearest recorded positive (held-out rows: to the nearest
positive of their outer training set; 1 = one of the 8 surrounding cells). distance_capture.csv gives the
held-out tier capture per distance band - whether the ranking finds positives away from known ones. Far
targets rank the cells at least --new-gap steps from every recorded positive among themselves (the tiers
as fractions of those cells, same screen and uncertainty cut); far_target_capture.csv applies the same
rule in each held-out fold. Use them when the tiers hold no new candidate, or give another rule its reason.

Outputs in DIR (default <spec out>/models): oof_scores.csv, inner_results.csv, fold_metrics.csv,
calibration.csv, calibration_pool.csv, screen_repeats.csv, zone_capture.csv, distance_capture.csv,
far_target_capture.csv, full_fit.csv, candidates.csv and candidate_patches.csv (connected patches of the primary
model's deployment tier cells: new ones N01, N02, ... and re-checks of recorded positives R01, R02, ..., each
ranked by the highest score), far_targets.csv and far_target_patches.csv (F01, F02, ...), pu_workflow.json,
render_spec.json (the spec with assignment, heldout, scores, stability, zones, zone_rules, candidates and
far_targets filled for the render command), m5_calibration.png and m6_zone_capture.png.

Revising the decision values after seeing the results (e.g. an uncertainty cut that removes most tier
cells) needs no refit:

    uv run python pu_workflow.py rezone <DIR> --tiers ... --alpha ... --rel-iqr-cut ... --reason "..." \
        [--new-gap K] [--out NEW]

It redoes calibration, screen and zones from the saved train-only pools and bootstrap spread, writes the same
outputs to NEW (default <DIR>_rezoned) with the previous values and the reason, and leaves DIR unchanged.
Options left out (zone mode, screen rule, far-target gap, custom zone names) keep the source run's. Render NEW/render_spec.json
(it draws into NEW/figures) so the zone maps follow the revised rule. A revision chosen after looking at
held-out capture or coverage turns those held-out results into development evidence.

U is unlabeled, not a confirmed negative: calibrated values are rates of recorded positives, the
screen has no exact coverage guarantee under spatial dependence, and the bootstrap spread is model
instability, not total uncertainty.
"""
from pathlib import Path
import argparse
import copy
import importlib.util
import json
import os
import sys

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent


def _load(name):
    spec = importlib.util.spec_from_file_location(name, HERE / f'{name}.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


stage_evidence = _load('stage_evidence')
figure_style = stage_evidence.figure_style
decision_support, pu_sampling = _load('decision_support'), _load('pu_sampling')
FIT_LOG = None  # tests set a list to record (context, training row indices) of every fit


def _learner(params, n_jobs):
    from xgboost import XGBClassifier

    def make(seed):
        return XGBClassifier(n_estimators=params['trees'], max_depth=params['depth'], learning_rate=.05,
                             subsample=.8, colsample_bytree=.8, tree_method='hist', n_jobs=n_jobs,
                             random_state=int(seed) % (2 ** 31), verbosity=0)
    return make


def candidates(models, depths, trees, u_fractions, members):
    out = []
    for m in models:
        for d in depths:
            for t in trees:
                if m == 'binary':
                    out.append({'model': m, 'depth': d, 'trees': t})
                elif m == 'bagging_pu':
                    out += [{'model': m, 'depth': d, 'trees': t, 'u_fraction': f, 'members': members} for f in u_fractions]
                else:
                    raise ValueError(f'unknown model family {m}')
    return out


def _fit(c, X, y, rows, seed, n_jobs, context):
    if FIT_LOG is not None:
        FIT_LOG.append((context, np.asarray(rows)))
    make = _learner(c, n_jobs)
    model = make(seed) if c['model'] == 'binary' else pu_sampling.BaggingPU(
        make, n_members=c['members'], unlabeled_fraction=c['u_fraction'], seed=seed)
    return model.fit(X[rows], y[rows])


def _ap(y, s):
    from sklearn.metrics import average_precision_score
    return float(average_precision_score(y, s)) if 0 < y.sum() < len(y) else np.nan


def _roc(y, s):
    from sklearn.metrics import roc_auc_score
    return float(roc_auc_score(y, s)) if 0 < y.sum() < len(y) else np.nan


def select(cands, X, y, rows, folds, seed, n_jobs, context):
    """Per family: the candidate with the best mean validation AP, its out-of-fold scores and the table."""
    table, best = [], {}
    for ci, c in enumerate(cands):
        oof = np.full(len(rows), np.nan)
        aps = []
        for f in np.unique(folds):
            tr, va = rows[folds != f], rows[folds == f]
            oof[folds == f] = _fit(c, X, y, tr, seed + 7 * ci + 101 * int(f), n_jobs, context).predict_proba(X[va])[:, 1]
            aps.append(_ap(y[va], oof[folds == f]))
            table.append({**c, 'candidate': ci, 'validation_fold': int(f), 'validation_positive': int(y[va].sum()),
                          'average_precision': aps[-1]})
        mean = float(np.nanmean(aps)) if np.isfinite(aps).any() else -np.inf
        if c['model'] not in best or mean > best[c['model']][1]:
            best[c['model']] = (ci, mean, oof)
    return {m: {'candidate': ci, 'params': cands[ci], 'validation_ap': mean, 'oof': oof}
            for m, (ci, mean, oof) in best.items()}, table


def _block_bootstrap(rows, blocks, y, rng):
    units = np.unique(blocks[rows])
    for _ in range(20):
        pick = rng.choice(units, size=len(units), replace=True)
        sample = np.concatenate([rows[blocks[rows] == b] for b in pick])
        if 0 < y[sample].sum() < len(sample):
            return sample
    raise ValueError('block bootstrap found no sample with both classes')


def _uncertainty(c, X, y, rows, target, blocks, *, bootstrap, seed, n_jobs, context):
    """Relative IQR of every target cell over block-bootstrap refits (the zones use it inside the tiers only)."""
    rng = np.random.default_rng(seed)
    matrix = np.array([_fit(c, X, y, _block_bootstrap(rows, blocks, y, rng), seed + 13 * b, n_jobs, context)
                       .predict_proba(X[target])[:, 1] for b in range(bootstrap)])
    return decision_support.bootstrap_summary(np.clip(matrix, 0, 1), min_mean=1e-12)['rho']


def _policy(raw, pool_scores, pool_labels, pool_blocks, *, alpha, positive, seed, screen_rule='pool', repeats=20):
    """Platt calibration and the positive screen, both from the train-only pool. The screen threshold is set on
    raw scores (a monotone calibration cannot move it, and a negative Platt slope cannot invert it):
    'pool' = split-conformal on every pool positive; 'repeated' = median of the thresholds from `repeats`
    block-wise halvings (repeated cross calibration). With too few pool positives the screen is 'unsupported':
    nothing is excluded and held-out coverage is left unevaluated."""
    platt = decision_support.platt_scaling(pool_scores, pool_labels, positive=positive)
    reps = decision_support.repeated_split_screen(pool_scores, pool_labels, pool_blocks, positive=positive,
                                                  alpha=alpha, repeats=repeats, seed=seed)
    screen = decision_support.conformal_positive_threshold(pool_scores, pool_labels, positive=positive, alpha=alpha)
    screen['rule'] = screen_rule
    if screen_rule == 'repeated':
        values = [r['threshold'] for r in reps if r['threshold'] is not None]
        if values:
            screen.update(status='repeated_split_conformal', threshold=float(np.median(values)), repeats_used=len(values))
        else:
            screen.update(status='unsupported', threshold=None, reason='no repeat had enough positives')
    elif screen_rule != 'pool':
        raise ValueError("screen rule is 'pool' or 'repeated'")
    cal = decision_support.platt_apply(raw, platt)
    screened = screen['threshold'] is not None
    covered = raw >= screen['threshold'] if screened else np.ones(len(raw), bool)
    return platt, screen, reps, cal, covered, screened


def _tier_mask(raw, cal, tiers, mode):
    """Cells the tiers can reach: the top max(tiers) of the ranking ('lift'), or cal >= min(tiers) ('prob')."""
    if mode == 'lift':
        return decision_support.upper_fraction(raw) <= max(tiers) + 1e-12
    return cal >= min(tiers)


def _zones(raw, cal, covered, rho, args):
    score = raw if args['zone_mode'] == 'lift' else cal
    return decision_support.classify_zones(score, covered=covered, uncertainty=rho,
                                           uncertainty_cut=args['rel_iqr_cut'], tiers=args['tiers'], mode=args['zone_mode'])


def _decide(raw, pool, rel_all, args, *, seed):
    """Calibration, positive screen, tier reach, uncertainty mask and zones of one scored set, all set from its
    train-only pool (score, label, block). rel_all is the bootstrap rel IQR of every scored cell."""
    platt, screen, reps, cal, covered, screened = _policy(raw, pool['score'], pool['label'], pool['block'],
                                                          alpha=args['alpha'], positive=1, seed=seed,
                                                          screen_rule=args['screen_rule'])
    widest = _tier_mask(raw, cal, args['tiers'], args['zone_mode'])
    rho = np.where(widest, rel_all, np.nan)
    code, reason = _zones(raw, cal, covered, rho, args)
    return {'platt': platt, 'screen': screen, 'repeats': reps, 'cal': cal, 'covered': covered, 'screened': screened,
            'widest': widest, 'rho': rho, 'code': code, 'reason': reason}


def _scored(id_col, ids, raw, rel_all, d, labels_, **extra):
    """Rows of a scored set with the decision columns; extra = outer_fold/model before and label after."""
    label = extra.pop('label', None)
    frame = pd.DataFrame({id_col: ids, **extra, 'score': raw, 'calibrated': d['cal'], 'rel_iqr': d['rho'],
                          'rel_iqr_all': rel_all, 'covered': d['covered'], 'screen_assessed': bool(d['screened']),
                          'zone': d['code'],
                          'zone_name': [labels_[z] for z in d['code']], 'zone_reason': d['reason']})
    if label is not None:
        frame['label'] = label
    return frame


def _cal_row(k, m, d, test_labels, rule, policy_seed):
    screened, covered, platt, screen = d['screened'], d['covered'], d['platt'], d['screen']
    return {'outer_fold': int(k), 'model': m, 'platt_a': platt['a'], 'platt_b': platt['b'],
            'pool_n': platt['n'], 'pool_positive': platt['n_positive'], 'screen_status': screen['status'],
            'screen_rule': rule, 'threshold_raw': screen['threshold'],
            'test_positive_coverage': float(covered[test_labels == 1].mean()) if screened and test_labels.any() else np.nan,
            'test_retained': float(covered.mean()) if screened else np.nan, 'policy_seed': int(policy_seed)}


def _demoted(reason, widest, covered, rho):
    """How many cells ranked inside the tiers were moved out by the uncertainty cut or the screen, and the
    rel IQR spread among them (to choose a cut that fits the data)."""
    reason = np.asarray(reason)
    r = rho[widest & np.isfinite(rho)]
    return {'cells_ranked_in_tiers': int(widest.sum()),
            'tier_cells_moved_by_uncertainty': int((widest & (reason == 'uncertainty above cut or not assessed')).sum()),
            'tier_cells_outside_screen': int((widest & ~covered).sum()),
            'tier_rel_iqr_p10_p50_p90': [float(v) for v in np.quantile(r, [.1, .5, .9])] if len(r) else None}


def _gap(value):
    gap = int(value)
    if gap != value or gap < 2:
        raise ValueError('--new-gap is a whole number of grid steps, at least 2 (2 = not in or next to a recorded '
                         'positive cell, the rule of the new candidates N)')
    return gap


def zone_names(tiers, mode, given=None):
    if given:
        if len(given) != len(tiers) + 2:
            raise ValueError(f'--zone-names needs {len(tiers) + 2} names: one per tier, uncertain or lower, excluded')
        return list(given)
    tier = [f'tier {i + 1} (top {t:g})' if mode == 'lift' else f'tier {i + 1} (calibrated >= {t:g})' for i, t in enumerate(tiers)]
    return tier + ['uncertain or lower', 'excluded (outside positive screen)']


def run(spec, split, *, tiers, alpha, rel_iqr_cut, zone_mode='lift', names=None, models=('binary', 'bagging_pu'),
        primary='bagging_pu', members=8, u_fractions=(.25, .5), depths=(2, 4), trees=(100, 200), bootstrap=20,
        seed=42, out=None, n_jobs=None, screen_rule='pool', new_gap=2, rank_fractions=None):
    import matplotlib
    matplotlib.use('Agg')
    figure_style.apply_style()
    c = stage_evidence.Cells(spec)
    if c.grid_problem:  # candidates, grid steps and far targets need the grid; stop before any fitting
        raise ValueError(f'pu_workflow needs the analysis grid: {c.grid_problem}')
    _grid(c)
    n_jobs = n_jobs or min(2, os.cpu_count() or 1)
    cols = [p['column'] for p in spec.get('predictors', [])]
    if not cols:
        raise ValueError('spec has no predictors')
    categorical = [p['column'] for p in spec['predictors'] if stage_evidence.is_categorical(p)]
    numeric = c.frame[[x for x in cols if x not in categorical]].apply(pd.to_numeric, errors='coerce')
    # one indicator per class of each categorical predictor (no label information; missing stays all-zero)
    dummies = [pd.get_dummies(c.frame[x].astype('string'), prefix=x, dtype=float) for x in categorical]
    features = pd.concat([numeric, *dummies], axis=1)
    X = features.to_numpy(float)
    y = (c.frame[c.label] == c.positive).to_numpy().astype(int)
    ids = c.frame[c.id].astype(str).to_numpy()
    spatial_contract = _load('spatial_contract')
    outer, inner_split, blocks = spatial_contract.check_split_manifest(
        pd.read_csv(split, dtype={c.id: str, 'block': str}), ids, y, positive=1, id_column=c.id)
    blocks = blocks.astype(str)
    if primary not in models:
        raise ValueError('--primary must be one of --models')
    args = {'tiers': list(tiers), 'alpha': alpha, 'rel_iqr_cut': rel_iqr_cut, 'zone_mode': zone_mode,
            'screen_rule': screen_rule, 'new_gap': _gap(new_gap), 'rank_fractions': _rank_fractions(zone_mode, rank_fractions)}
    labels_ = zone_names(tiers, zone_mode, names)
    out = Path(out or Path(spec.get('out', 'figures')) / 'models')
    out.mkdir(parents=True, exist_ok=True)
    cands = candidates(models, depths, trees, u_fractions, members)

    oof_rows, inner_rows, fold_rows, cal_rows, repeat_rows, pool_rows = [], [], [], [], [], []
    for k in np.unique(outer):
        train, test = np.flatnonzero(outer != k), np.flatnonzero(outer == k)
        inner = inner_split[int(k)][train]
        chosen, table = select(cands, X, y, train, inner, seed + 1000 * k, n_jobs, ('outer', int(k)))
        inner_rows += [{'outer_fold': int(k), **r} for r in table]
        for m, sel in chosen.items():
            fk = seed + 1000 * k + 17
            raw = _fit(sel['params'], X, y, train, fk, n_jobs, ('outer', int(k))).predict_proba(X[test])[:, 1].astype(float)
            rel_all = _uncertainty(sel['params'], X, y, train, test, blocks, bootstrap=bootstrap, seed=fk, n_jobs=n_jobs,
                                   context=('outer', int(k)))
            pool = {'score': sel['oof'], 'label': y[train], 'block': blocks[train]}
            d = _decide(raw, pool, rel_all, args, seed=fk)
            pool_rows.append(pd.DataFrame({'role': 'outer', 'outer_fold': int(k), 'model': m, c.id: ids[train], **pool}))
            oof_rows.append(_scored(c.id, ids[test], raw, rel_all, d, labels_, outer_fold=int(k), model=m, label=y[test]))
            fold_rows.append({'outer_fold': int(k), 'model': m, 'selected': {x: sel['params'][x] for x in sel['params'] if x != 'model'},
                              'inner_ap': sel['validation_ap'], 'outer_ap': _ap(y[test], raw), 'outer_roc_auc': _roc(y[test], raw),
                              'test_n': int(len(test)), 'test_positive': int(y[test].sum()),
                              'prevalence': float(y[test].mean())})
            fold_rows[-1].update(_demoted(d['reason'], d['widest'], d['covered'], d['rho']))
            cal_rows.append(_cal_row(k, m, d, y[test], screen_rule, fk))
            repeat_rows += [{'outer_fold': int(k), 'model': m, **r} for r in d['repeats']]

    # deployment (full-fit): outer folds as tuning folds, fit on all rows
    everything = np.arange(len(y))
    chosen, table = select(cands, X, y, everything, outer, seed + 99, n_jobs, ('full',))
    full_rows, deploy = [], {}
    for m, sel in chosen.items():
        raw = _fit(sel['params'], X, y, everything, seed + 98, n_jobs, ('full',)).predict_proba(X)[:, 1].astype(float)
        rel_all = _uncertainty(sel['params'], X, y, everything, everything, blocks, bootstrap=bootstrap, seed=seed + 96,
                               n_jobs=n_jobs, context=('full',))
        pool = {'score': sel['oof'], 'label': y, 'block': blocks}
        d = _decide(raw, pool, rel_all, args, seed=seed + 97)
        pool_rows.append(pd.DataFrame({'role': 'deployment', 'outer_fold': -1, 'model': m, c.id: ids, **pool}))
        full_rows.append(_scored(c.id, ids, raw, rel_all, d, labels_, model=m))
        deploy[m] = {**_demoted(d['reason'], d['widest'], d['covered'], d['rho']),
                     'selected': {x: sel['params'][x] for x in sel['params'] if x != 'model'}, 'selection_ap': sel['validation_ap'],
                     'platt': d['platt'], 'screen': d['screen'], 'policy_seed': seed + 97,
                     'selection_folds': 'outer folds (deployment variant of the evaluated rule)'}

    config = {'models': list(models), 'primary': primary, 'members': members, 'u_fractions': list(u_fractions),
              'depths': list(depths), 'trees': list(trees), 'bootstrap': bootstrap, 'seed': seed,
              'tiers': list(tiers), 'zone_mode': zone_mode, 'alpha': alpha, 'rel_iqr_cut': rel_iqr_cut,
              'screen_rule': screen_rule, 'new_gap': args['new_gap'], 'rank_fractions': args['rank_fractions'],
              'zone_names': labels_, 'predictors': cols,
              'categorical_predictors': categorical,
              'features': list(features.columns), 'split': str(split)}
    pd.DataFrame(inner_rows).to_csv(out / 'inner_results.csv', index=False)
    return _write(out, spec, c, split, oof=pd.concat(oof_rows, ignore_index=True), fold_rows=fold_rows, cal_rows=cal_rows,
                  repeat_rows=repeat_rows, full=pd.concat(full_rows, ignore_index=True), deploy=deploy,
                  pools=pd.concat(pool_rows, ignore_index=True), config=config, labels_=labels_, args=args, primary=primary)


NOTES = ['U is unlabeled, not a confirmed negative; calibrated values are recorded-positive rates',
         'class indicators of categorical predictors use the class list of the whole input table '
         '(no labels); a class seen only in a test fold has an indicator the model never split on',
         'screen threshold on raw scores from the train-only pool; with too few pool positives the screen '
         'is unsupported: nothing is excluded and held-out coverage is not evaluated',
         'split-conformal screen: no exact coverage under spatial dependence; held-out coverage is reported per fold',
         'calibration pool scores come from inner out-of-fold models; the applied score comes from the model '
         'fitted on the whole outer training set (same parameters, larger training set)',
         'rel IQR over block-bootstrap refits of the selected pipeline: model instability only',
         'pooled OOF AP mixes fold-specific models; per-fold AP is the primary comparison',
         'held-out zones use fold-local ranks and screens; deployment zones use ranks over all cells',
         'grid steps to the nearest positive: Chebyshev distance on the grid (1 = one of the 8 surrounding cells); '
         'held-out rows use the positives of their outer training set (distance_capture.csv)',
         'far targets rank the cells at least new_gap grid steps (Chebyshev) from every recorded positive among '
         'themselves (in lift mode the same fractions as the tiers, of the far cells only; in prob mode the given '
         '--rank-fractions); far_target_capture.csv applies the same rule to each held-out fold (the pooled far_ap is '
         'the mean of the fold APs). The held-out far capture shows whether the ranking finds positives without nearby '
         'training positives; it is not the expected rate of the far targets on the map',
         'grid steps are not ground distances (a diagonal step is longer), and area shares are shares of cells']


def _write(out, spec, c, split, *, oof, fold_rows, cal_rows, repeat_rows, full, deploy, pools, config, labels_, args,
           primary, extra_notes=(), render_out=None):
    """Tables, record, render spec and the two decision figures of a run or a rezone."""
    capture = []
    for m, part in oof.groupby('model'):
        per_fold, summary = decision_support.zone_capture(part['zone'], part['label'], part['outer_fold'], positive=1,
                                                          n_zones=len(labels_))
        capture.append(summary.assign(model=m, zone_name=[labels_[z] for z in summary['zone']]))
    capture = pd.concat(capture, ignore_index=True)
    # distance to the nearest (training) positive and the far-target ranking, on the map and in each held-out fold
    gap, fractions = args['new_gap'], far_fractions(args)
    far_names = far_zone_names(fractions, gap)
    ids = c.frame[c.id].astype(str).to_numpy()
    oof = _with_far(oof, _heldout_distance(c, oof), args, far_names)
    steps = pd.Series(cells_to_positive(c, c.is_p), index=ids)
    full = _with_far(full, steps[full[c.id].astype(str)].to_numpy(), args, far_names)
    by_distance, far_check = distance_capture(oof, len(args['tiers']), gap), far_capture(oof, args)
    files = {'oof_scores.csv': oof, 'fold_metrics.csv': pd.DataFrame(fold_rows), 'calibration.csv': pd.DataFrame(cal_rows),
             'screen_repeats.csv': pd.DataFrame(repeat_rows), 'zone_capture.csv': capture, 'full_fit.csv': full,
             'calibration_pool.csv': pools, 'distance_capture.csv': by_distance, 'far_target_capture.csv': far_check}
    for name, frame in files.items():
        frame.to_csv(out / name, index=False)
    metrics, cal = pd.DataFrame(fold_rows), pd.DataFrame(cal_rows)
    summary = {m: {'inner_ap_mean': float(g['inner_ap'].mean()), 'outer_ap_mean': float(g['outer_ap'].mean()),
                   'outer_ap_sd': float(g['outer_ap'].std()), 'outer_roc_auc_mean': float(g['outer_roc_auc'].mean()),
                   'pooled_oof_ap': _ap(oof.loc[oof.model == m, 'label'].to_numpy(), oof.loc[oof.model == m, 'score'].to_numpy()),
                   'positive_coverage_mean': float(cal.query('model == @m')['test_positive_coverage'].mean()),
                   'folds_without_screen': int(cal.query('model == @m')['test_positive_coverage'].isna().sum())}
               for m, g in metrics.groupby('model')}
    for m in summary:
        pooled = by_distance[(by_distance['model'] == m) & (by_distance['outer_fold'] == 'all')]
        summary[m]['capture_by_distance'] = {r['band']: {x: r[x] for x in ('test_positive', 'positive_capture', 'area_share')}
                                             for r in pooled.to_dict('records')}
        widest = far_check[(far_check['model'] == m) & (far_check['outer_fold'] == 'all')].tail(1).to_dict('records')[0]
        summary[m]['far_rule_heldout'] = {x: widest[x] for x in ('fraction', 'far_cells', 'far_positive', 'far_prevalence',
                                                                  'capture_ranked', 'area_ranked', 'capture_in_zone')}
        summary[m]['far_rule_heldout']['far_ap_fold_mean'] = widest['far_ap']
    primary_full = full[full['model'] == primary].set_index(c.id).reindex(ids)
    cand, patches = candidate_patches(c, primary_full['zone'].to_numpy(), primary_full['score'].to_numpy(), len(args['tiers']))
    pd.DataFrame({c.id: ids, 'candidate': cand}).to_csv(out / 'candidates.csv', index=False)
    patches.to_csv(out / 'candidate_patches.csv', index=False)
    deploy[primary]['candidates'] = {'patches': int(len(patches)),
                                     'new': int(patches['kind'].str.startswith('new').sum()),
                                     'recheck': int(patches['kind'].str.startswith('re-check').sum())}
    assessed = bool(primary_full['screen_assessed'].all())
    far_id, far_table = far_target_patches(c, primary_full['far_zone'].to_numpy(), primary_full['far_rank'].to_numpy(),
                                           primary_full['score'].to_numpy(), fractions,
                                           primary_full['cells_to_recorded_positive'].to_numpy(), cand, assessed)
    pd.DataFrame({c.id: ids, 'far_target': far_id}).to_csv(out / 'far_targets.csv', index=False)
    far_table.to_csv(out / 'far_target_patches.csv', index=False)
    # the held-out far cells lie in folds that hold positives by design; the map's far cells are where none was recorded
    far_map = primary_full[primary_full['cells_to_recorded_positive'] >= gap]
    far_out = oof[(oof['model'] == primary) & (oof['cells_to_training_positive'] >= gap)]
    held = far_out[far_out['screen_assessed']]  # folds without a screen exclude nothing: not a share inside a screen
    kept = {'map': float(far_map['covered'].mean()) if assessed and len(far_map) else np.nan,
            'heldout': float(held['covered'].mean()) if len(held) else np.nan,
            'heldout_folds_without_screen': int(far_out.loc[~far_out['screen_assessed'], 'outer_fold'].nunique())}
    deploy[primary]['far_targets'] = {'status': 'far cells ranked' if len(far_map) else 'no far cells',
                                      'gap_steps': gap, 'fractions': fractions, 'far_cells': int(len(far_map)),
                                      'targets': int(len(far_table)), 'target_cells': int(far_table['cells'].sum()),
                                      'target_cells_passing': int(far_table['cells_passing'].sum()),
                                      'map_screen_assessed': assessed, 'far_cells_kept_by_screen': kept,
                                      'far_score_median': {'map': float(far_map['score'].median()) if len(far_map) else np.nan,
                                                           'heldout': float(far_out['score'].median()) if len(far_out) else np.nan}}
    extra_notes = list(extra_notes)
    if kept['map'] < kept['heldout'] / 2:  # a diagnostic rule of thumb, not a test
        extra_notes.append(f"far cells kept by the positive screen: {kept['map']:.0%} on the map against {kept['heldout']:.0%} "
                           'in the held-out folds, each against its own screen threshold (record far_score_median). The two '
                           'sets differ in more than one way: the map\'s far cells are unlabeled cells the full-fit model was '
                           'trained on (in-sample), the held-out ones were not; the held-out folds hold recorded positives by '
                           'design; the thresholds come from different pools')
    if len(patches) and not deploy[primary]['candidates']['new']:
        extra_notes.append('no new candidate inside the tiers: every tier patch holds or touches a recorded positive. '
                           f'Say so in the report. The far targets (F01, ...) rank the cells at least {gap} grid steps from '
                           'every recorded positive among themselves - a lower bar than the tiers - and far_target_capture.csv '
                           'checks the same rule on the held-out folds; give new targets that rule or another from the purpose')
    record = {'config': config, 'summary': summary, 'deployment': deploy, 'notes': NOTES + extra_notes}
    (out / 'pu_workflow.json').write_text(json.dumps(_finite(record), indent=2, ensure_ascii=False, allow_nan=False) + '\n')
    render = _render_spec(spec, c, split, out, primary, labels_, args['tiers'], args['zone_mode'], args)
    if render_out is not None:  # a revision draws into its own folder, beside its tables
        render['out'] = str(render_out)
    (out / 'render_spec.json').write_text(json.dumps(render, indent=1, ensure_ascii=False) + '\n')
    figures = [_calibration_figure(oof, cal, args['alpha'], out, c), _capture_figure(capture, labels_, out, c)]
    return {'out': str(out), 'record': record, 'figures': [str(f) for f in figures]}


def _finite(value):
    """Plain JSON values: numpy scalars to Python, NaN and infinities to null."""
    if isinstance(value, dict):
        return {k: _finite(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_finite(v) for v in value]
    if isinstance(value, np.generic):
        value = value.item()
    if isinstance(value, float) and not np.isfinite(value):
        return None
    return value


RENDER_KEYS = ('assignment', 'heldout', 'scores', 'stability', 'zones', 'zone_rules', 'candidates', 'far_targets')


def candidate_patches(c, zone, score, n_tiers):
    """Local candidates of the deployment map: connected patches (cells sharing an edge) of tier cells. New patches
    (no recorded positive inside or in a neighbouring cell) are N01, N02, ... and re-checks of recorded positives are
    R01, R02, ..., each ranked by the highest score: a full-fit map ranks recorded positives high, so one ranking
    would put the re-checks first. zone and score follow the order of c.frame. Returns (candidate id per cell or
    None, one row per patch)."""
    patch, n = _patches(c, zone < n_tiers)
    near = cells_to_positive(c, c.is_p) <= 1
    rows = []
    for k in range(1, n + 1):
        m = patch == k
        inside = int((m & c.is_p).sum())
        kind = ('re-check: recorded positive inside' if inside else
                're-check: next to a recorded positive' if near[m].any() else
                'new: no recorded positive inside or next to it')
        rows.append({'patch': k, 'cells': int(m.sum()), 'max_score': float(score[m].max()),
                     'mean_score': float(score[m].mean()), 'recorded_positive_inside': inside, 'kind': kind,
                     'x_centre': float(c.x[m].mean()), 'y_centre': float(c.y[m].mean())})
    table = pd.DataFrame(rows, columns=['patch', 'cells', 'max_score', 'mean_score', 'recorded_positive_inside', 'kind',
                                        'x_centre', 'y_centre'])
    table['new'] = table['kind'].str.startswith('new')
    table = table.sort_values(['new', 'max_score', 'cells'], ascending=False, ignore_index=True)
    rank = table.groupby('new').cumcount() + 1
    table.insert(0, 'candidate', [f"{'N' if n else 'R'}{r:02d}" for n, r in zip(table['new'], rank)])
    table = table.drop(columns='new')
    name = dict(zip(table['patch'], table['candidate']))
    return np.array([name.get(k) for k in patch], dtype=object), table.drop(columns='patch')


def _grid(c):
    """Row and column of each cell on the regular grid of c (spacing from the spec) and the grid shape. Cells must
    sit on the grid (within a quarter cell) and one to a position; missing cells are allowed."""
    dx, dy = c.spacing
    if not (dx > 0 and dy > 0):
        raise ValueError('grid spacing must be positive')
    fx, fy = (c.x - c.x.min()) / dx, (c.y - c.y.min()) / dy
    col, row = np.rint(fx).astype(int), np.rint(fy).astype(int)
    off = max(np.abs(fx - col).max(), np.abs(fy - row).max()) if len(col) else 0
    if off > .25 or len(set(zip(row.tolist(), col.tolist()))) != len(row):
        raise ValueError(f'cells are not on one regular grid of spacing {c.spacing} (largest offset {off:.2f} cells, '
                         f'or two cells at one position): grid steps, patches and far targets need one')
    return row, col, (int(row.max()) + 1, int(col.max()) + 1)


def _patches(c, member):
    """Connected patches (cells sharing an edge) of the member cells: patch number per cell (0 = none) and count."""
    from scipy import ndimage
    row, col, shape = _grid(c)
    grid = np.zeros(shape, bool)
    grid[row[member], col[member]] = True
    labels, n = ndimage.label(grid)
    return labels[row, col], n


def cells_to_positive(c, mask):
    """Grid steps from each cell to the nearest cell in mask: 0 = the cell itself, 1 = one of the 8 surrounding cells
    (Chebyshev distance on the grid), infinite when mask is empty. Follows the order of c.frame."""
    from scipy import ndimage
    row, col, shape = _grid(c)
    mask = np.asarray(mask, bool)
    if not mask.any():
        return np.full(len(row), np.inf)
    grid = np.zeros(shape, bool)
    grid[row[mask], col[mask]] = True
    return ndimage.distance_transform_cdt(~grid, metric='chessboard')[row, col].astype(float)


def distance_bands(gap):
    """Bands of grid steps to the nearest (training) positive: next to one, in between, and at least gap away."""
    bands = [('1: next to', 1, 1)]
    if gap > 2:
        bands.append((f'2-{gap - 1}', 2, gap - 1))
    return bands + [(f'>={gap}: far', gap, np.inf)]


def far_fractions(args):
    """Upper fractions of the far-target ranking and the zone-rule comparison: the lift tiers, or the given
    --rank-fractions when the zones use calibrated thresholds."""
    return list(args['tiers']) if args['zone_mode'] == 'lift' else list(args['rank_fractions'])


def _rank_fractions(zone_mode, given):
    if zone_mode == 'prob' and not given:
        raise ValueError('--zone-mode prob needs --rank-fractions: upper fractions for the far-target ranking and the '
                         'zone-rule comparison, from the purpose or budget (the calibrated tiers are not fractions)')
    if given and (sorted(given) != list(given) or not all(0 < f <= 1 for f in given)):
        raise ValueError('--rank-fractions are increasing upper fractions in (0, 1]')
    return list(given) if given else None


def far_zone_names(fractions, gap):
    return ([f'far tier {i + 1} (top {t:g} of far cells)' for i, t in enumerate(fractions)] +
            ['uncertain or lower', 'excluded (outside positive screen)', f'not far (within {gap - 1} step(s) of a positive)'])


def _far_zones(score, covered, rel_all, far, args):
    """Zones of the far cells ranked among themselves (upper fractions of the far cells only), with the same screen
    and uncertainty cut as the main zones. Codes as classify_zones, and len(fractions) + 2 = not far; plus the
    rank (upper fraction among far cells, NaN elsewhere)."""
    fr = far_fractions(args)
    code, rank = np.full(len(score), len(fr) + 2), np.full(len(score), np.nan)
    if far.any():
        code[far], _ = decision_support.classify_zones(score[far], covered=covered[far], uncertainty=rel_all[far],
                                                       uncertainty_cut=args['rel_iqr_cut'], tiers=fr, mode='lift')
        rank[far] = decision_support.upper_fraction(score[far])
    return code, rank


def _with_far(frame, distance, args, names):
    """Add the distance to the nearest (training) positive and the far-target zone columns to a scored set. The far
    cells are ranked within each model, and in held-out rows within each outer fold (fold-local, as the zones)."""
    col = 'cells_to_training_positive' if 'label' in frame else 'cells_to_recorded_positive'
    frame[col] = distance
    code, rank = np.zeros(len(frame), int), np.full(len(frame), np.nan)
    keys = ['model', 'outer_fold'] if 'outer_fold' in frame else ['model']
    for _, rows in frame.groupby(keys, sort=False).indices.items():
        part = frame.iloc[rows]
        code[rows], rank[rows] = _far_zones(part['score'].to_numpy(float), part['covered'].to_numpy(bool),
                                            part['rel_iqr_all'].to_numpy(float), distance[rows] >= args['new_gap'], args)
    frame['far_rank'], frame['far_zone'], frame['far_zone_name'] = rank, code, [names[z] for z in code]
    return frame


def _heldout_distance(c, oof):
    """Per held-out row: grid steps to the nearest positive of its outer training set (all positives outside its
    fold), the analogue of the distance to recorded positives on the deployment map."""
    ids = c.frame[c.id].astype(str).to_numpy()
    where = pd.Series(np.arange(len(ids)), index=ids)
    out = np.full(len(oof), np.nan)
    for k in oof['outer_fold'].unique():
        train_p = oof.loc[(oof['outer_fold'] != k) & (oof['label'] == 1), c.id].astype(str).unique()
        d = cells_to_positive(c, np.isin(ids, train_p))
        rows = (oof['outer_fold'] == k).to_numpy()
        out[rows] = d[where[oof.loc[rows, c.id].astype(str)].to_numpy()]
    return out


def distance_capture(oof, n_tiers, gap):
    """Held-out capture of test positives by the tiers, per band of distance to the training positives: does the
    ranking find positives away from known ones, or mostly next to them? Per fold and pooled ('all')."""
    rows = []
    for (m, k), part in oof.groupby(['model', 'outer_fold'], sort=False):
        d = part['cells_to_training_positive'].to_numpy(float)
        y, t = (part['label'] == 1).to_numpy(), (part['zone'] < n_tiers).to_numpy()
        for name, lo, hi in distance_bands(gap):
            b = (d >= lo) & (d <= hi)
            rows.append({'model': m, 'outer_fold': int(k), 'band': name, 'test_cells': int(b.sum()),
                         'test_positive': int((b & y).sum()), 'cells_in_tiers': int((b & t).sum()),
                         'positive_in_tiers': int((b & t & y).sum())})
    return _pooled(pd.DataFrame(rows), ['model', 'band'], [('area_share', 'cells_in_tiers', 'test_cells'),
                                                            ('positive_capture', 'positive_in_tiers', 'test_positive')])


def far_capture(oof, args):
    """Held-out check of the far-target rule: in each outer test fold, the cells at least new_gap steps from every
    training positive are ranked among themselves as on the map; how many of the test positives among them each
    far tier holds (by rank alone, and after the screen and uncertainty cut) against its share of the far cells."""
    rows = []
    for (m, k), part in oof.groupby(['model', 'outer_fold'], sort=False):
        far = (part['cells_to_training_positive'] >= args['new_gap']).to_numpy()
        y, score, code, rank = ((part['label'] == 1).to_numpy(), part['score'].to_numpy(float),
                                part['far_zone'].to_numpy(), part['far_rank'].to_numpy(float))
        base = {'model': m, 'outer_fold': int(k), 'far_cells': int(far.sum()), 'far_positive': int((far & y).sum()),
                'far_ap': _ap(y[far].astype(int), score[far]) if far.any() else np.nan}
        for i, t in enumerate(far_fractions(args)):
            r, z = far & (rank <= t + 1e-12), far & (code <= i)
            rows.append({**base, 'fraction': t, 'cells_ranked': int(r.sum()), 'positive_ranked': int((r & y).sum()),
                         'cells_in_zone': int(z.sum()), 'positive_in_zone': int((z & y).sum())})
    per = pd.DataFrame(rows)
    table = _pooled(per.drop(columns='far_ap'), ['model', 'fraction'],
                    [('far_prevalence', 'far_positive', 'far_cells'), ('area_ranked', 'cells_ranked', 'far_cells'),
                     ('capture_ranked', 'positive_ranked', 'far_positive'),
                     ('capture_in_zone', 'positive_in_zone', 'far_positive')])
    fold_ap = per.drop_duplicates(['model', 'outer_fold']).set_index(['model', 'outer_fold'])['far_ap']
    mean_ap = fold_ap.groupby(level='model').mean()  # the pooled row carries the mean of the fold APs
    table['far_ap'] = [mean_ap.get(m, np.nan) if k == 'all' else fold_ap.get((m, k), np.nan)
                       for m, k in zip(table['model'], table['outer_fold'])]
    return table


def _pooled(per_fold, keys, ratios):
    """Per-fold count rows plus pooled rows (outer_fold 'all', counts summed over folds) and the given ratios."""
    counts = [x for x in per_fold.columns if x not in keys + ['outer_fold']]
    pooled = per_fold.groupby(keys, sort=False)[counts].sum().reset_index().assign(outer_fold='all')
    table = pd.concat([per_fold.astype({'outer_fold': object}), pooled[per_fold.columns]], ignore_index=True)
    for name, num, den in ratios:
        table[name] = table[num] / table[den].where(table[den] > 0)
    return table


def far_target_patches(c, code, rank, score, fractions, distance, main_candidate, screen_assessed=True):
    """Connected patches of the far cells ranked inside the far tiers, F01, F02, ... ranked by the highest score. A
    patch is kept whether or not its cells pass the positive screen and the uncertainty cut, and says which do
    (status): when nothing far passes them, the ranked list is still the rule's answer, with that weakness in view.
    Without a screen (too few pool positives) nothing is excluded and the status says the screen was not assessed.
    Also the best far tier, the nearest recorded positive (grid steps) and any main-tier candidate it lies in."""
    passes = 'passes screen and cut' if screen_assessed else 'passes cut (screen not assessed)'
    n = len(fractions)
    ranked = np.isfinite(rank) & (rank <= max(fractions) + 1e-12)
    patch, count = _patches(c, ranked)
    tier = np.full(len(rank), np.nan)
    for i, t in reversed(list(enumerate(fractions))):
        tier[ranked & (rank <= t + 1e-12)] = i + 1
    rows = []
    for k in range(1, count + 1):
        m = patch == k
        passing, unsure, outside = int((code[m] < n).sum()), int((code[m] == n).sum()), int((code[m] == n + 1).sum())
        status = (passes if passing == m.sum() else 'outside screen' if outside == m.sum() else
                  'uncertain' if unsure == m.sum() else f'mixed: {passing} pass, {unsure} uncertain, {outside} outside screen')
        inside = sorted({str(v) for v in main_candidate[m] if v is not None})
        rows.append({'patch': k, 'cells': int(m.sum()), 'far_tier': int(np.nanmin(tier[m])), 'status': status,
                     'cells_passing': passing, 'cells_uncertain': unsure, 'cells_outside_screen': outside,
                     'max_score': float(score[m].max()), 'mean_score': float(score[m].mean()),
                     'steps_to_recorded_positive': int(distance[m].min()), 'in_main_tier_candidate': ' '.join(inside),
                     'x_centre': float(c.x[m].mean()), 'y_centre': float(c.y[m].mean())})
    table = pd.DataFrame(rows, columns=['patch', 'cells', 'far_tier', 'status', 'cells_passing', 'cells_uncertain',
                                        'cells_outside_screen', 'max_score', 'mean_score', 'steps_to_recorded_positive',
                                        'in_main_tier_candidate', 'x_centre', 'y_centre'])
    table = table.sort_values(['max_score', 'cells'], ascending=False, ignore_index=True)
    table.insert(0, 'far_target', [f'F{r:02d}' for r in range(1, len(table) + 1)])
    name = dict(zip(table['patch'], table['far_target']))
    return np.array([name.get(k) for k in patch], dtype=object), table.drop(columns='patch')


def rezone(source, *, tiers, alpha, rel_iqr_cut, reason, zone_mode=None, names=None, screen_rule=None, new_gap=None,
           rank_fractions=None, out=None):
    """Revise the decision values (tiers, alpha, uncertainty cut, zone mode, screen rule, far-target gap) on the saved
    scores of a pu_workflow run, without refitting any model. The held-out part redoes each fold's calibration, screen and
    zones from that fold's saved train-only pool, the deployment part from the full-fit pool, and the uncertainty
    cut applies the saved bootstrap rel IQR of every cell. zone mode, screen rule, gap and zone names left out (None)
    keep the source run's; custom names are kept only while the number of tiers is unchanged. The source folder stays
    unchanged, and the new render spec draws into <out>/figures."""
    import matplotlib
    import shutil
    matplotlib.use('Agg')
    figure_style.apply_style()
    source = Path(source)
    names_needed = ('pu_workflow.json', 'render_spec.json', 'oof_scores.csv', 'full_fit.csv', 'calibration_pool.csv',
                    'calibration.csv', 'fold_metrics.csv', 'inner_results.csv')
    missing = [n for n in names_needed if not (source / n).exists()]
    if missing:
        raise ValueError(f'{source} lacks {missing}: re-run pu_workflow.py (runs made before rezone kept no calibration pools)')
    if not str(reason or '').strip():
        raise ValueError('give the reason for the revision (--reason): what in the data or the purpose changed the values')
    out = Path(out or source.parent / f'{source.name}_rezoned')
    if out.resolve() == source.resolve():
        raise ValueError('write the revision to a new folder; the source run stays as it was')
    out.mkdir(parents=True, exist_ok=True)
    old = json.loads((source / 'pu_workflow.json').read_text())
    was = old['config']
    zone_mode = zone_mode or was.get('zone_mode', 'lift')
    screen_rule = screen_rule or was.get('screen_rule', 'pool')
    new_gap = _gap(was.get('new_gap', 2) if new_gap is None else new_gap)
    if rank_fractions is None and zone_mode == 'prob':
        rank_fractions = was.get('rank_fractions')
    rank_fractions = _rank_fractions(zone_mode, rank_fractions)
    custom = was.get('zone_names') != zone_names(was['tiers'], was.get('zone_mode', 'lift'))
    if names is None and custom and len(tiers) == len(was['tiers']) and zone_mode == was.get('zone_mode', 'lift'):
        names = was['zone_names']
    spec = {k: v for k, v in json.loads((source / 'render_spec.json').read_text()).items() if k not in RENDER_KEYS}
    c = stage_evidence.Cells(spec)
    # exact values: pandas' default float parser can be one unit in the last place off, which moves ties at a threshold
    read = lambda name: pd.read_csv(source / name, dtype={c.id: str, 'block': str}, float_precision='round_trip')
    oof, full, pools = read('oof_scores.csv'), read('full_fit.csv'), read('calibration_pool.csv')
    if 'role' not in pools:
        raise ValueError(f'{source}/calibration_pool.csv has no role column: re-run pu_workflow.py')
    cal_old, metrics_old = read('calibration.csv'), read('fold_metrics.csv')
    args = {'tiers': list(tiers), 'alpha': alpha, 'rel_iqr_cut': rel_iqr_cut, 'zone_mode': zone_mode, 'screen_rule': screen_rule,
            'new_gap': new_gap, 'rank_fractions': rank_fractions}
    labels_ = zone_names(tiers, zone_mode, names)

    def pool_of(role, k, m):
        rows = pools[(pools.role == role) & (pools.outer_fold == k) & (pools.model == m)]
        if role == 'outer' and rows[c.id].isin(oof.loc[(oof.outer_fold == k) & (oof.model == m), c.id]).any():
            raise ValueError(f'calibration pool of outer fold {k} holds its own test cells')
        return {x: rows[x].to_numpy() for x in ('score', 'label', 'block')}

    oof_rows, fold_rows, cal_rows, repeat_rows = [], [], [], []
    for (k, m), part in oof.groupby(['outer_fold', 'model'], sort=False):
        policy_seed = int(cal_old.loc[(cal_old.outer_fold == k) & (cal_old.model == m), 'policy_seed'].iloc[0])
        raw, rel_all, labels = part['score'].to_numpy(), part['rel_iqr_all'].to_numpy(), part['label'].to_numpy()
        d = _decide(raw, pool_of('outer', k, m), rel_all, args, seed=policy_seed)
        oof_rows.append(_scored(c.id, part[c.id].to_numpy(), raw, rel_all, d, labels_, outer_fold=int(k), model=m, label=labels))
        row = metrics_old[(metrics_old.outer_fold == k) & (metrics_old.model == m)].iloc[0].to_dict()
        row.update(_demoted(d['reason'], d['widest'], d['covered'], d['rho']))
        fold_rows.append(row)
        cal_rows.append(_cal_row(k, m, d, labels, screen_rule, policy_seed))
        repeat_rows += [{'outer_fold': int(k), 'model': m, **r} for r in d['repeats']]
    full_rows, deploy = [], {}
    for m, part in full.groupby('model', sort=False):
        prev = old['deployment'][m]
        raw, rel_all = part['score'].to_numpy(), part['rel_iqr_all'].to_numpy()
        d = _decide(raw, pool_of('deployment', -1, m), rel_all, args, seed=int(prev['policy_seed']))
        full_rows.append(_scored(c.id, part[c.id].to_numpy(), raw, rel_all, d, labels_, model=m))
        deploy[m] = {**_demoted(d['reason'], d['widest'], d['covered'], d['rho']),
                     **{x: prev[x] for x in ('selected', 'selection_ap', 'selection_folds', 'policy_seed')},
                     'platt': d['platt'], 'screen': d['screen']}
    decision_keys = ('tiers', 'zone_mode', 'alpha', 'rel_iqr_cut', 'screen_rule', 'new_gap', 'rank_fractions')
    config = {**old['config'], **{x: args[x] for x in decision_keys}, 'zone_names': labels_,
              'rezoned_from': str(source), 'rezone_reason': str(reason),
              'previous_decision_values': {x: old['config'].get(x) for x in decision_keys}}
    shutil.copy2(source / 'inner_results.csv', out / 'inner_results.csv')
    notes = [f'decision values revised by rezone from {source} without refitting: {reason}',
             'if the revision followed the held-out zone capture or coverage, the held-out results of the revised rule '
             'are development evidence, not an untouched evaluation; say which in the report']
    return _write(out, spec, c, old['config']['split'], oof=pd.concat(oof_rows, ignore_index=True), fold_rows=fold_rows,
                  cal_rows=cal_rows, repeat_rows=repeat_rows, full=pd.concat(full_rows, ignore_index=True), deploy=deploy,
                  pools=pools, config=config, labels_=labels_, args=args, primary=old['config']['primary'], extra_notes=notes,
                  render_out=out / 'figures')


def _render_spec(spec, c, split, out, primary, labels_, tiers, zone_mode, args):
    r = copy.deepcopy(spec)
    oof, full = str(out / 'oof_scores.csv'), str(out / 'full_fit.csv')
    r['assignment'] = {'table': str(split), 'id': c.id, 'group': 'outer_fold', 'block': 'block'}
    r['heldout'] = {'table': oof, 'id': c.id, 'group': 'outer_fold', 'model': 'model', 'score': 'score'}
    r['scores'] = {'table': full, 'id': c.id, 'columns': [
        {'name': f'{primary} held-out', 'table': oof, 'id': c.id, 'column': 'score', 'where': {'model': primary}, 'role': 'held-out'},
        {'name': f'{primary} full-fit', 'table': full, 'id': c.id, 'column': 'score', 'where': {'model': primary}, 'role': 'full-fit'}]}
    r['stability'] = {'table': full, 'id': c.id, 'where': {'model': primary}, 'column': 'rel_iqr', 'score': 'score',
                      'what': f"relative IQR over block-bootstrap refits of the selected {primary} pipeline, cells in the "
                              f"widest tier only (model instability, not data or label uncertainty)"}
    from matplotlib import colormaps
    reds = [colormaps['Reds'](v) for v in np.linspace(.85, .3, len(tiers))]
    colors = [f'#{int(r * 255):02x}{int(g * 255):02x}{int(b * 255):02x}' for r, g, b, _ in reds] + ['#c6dbef', '#d9d9d9']
    r['zones'] = {'table': full, 'id': c.id, 'where': {'model': primary}, 'column': 'zone_name', 'order': labels_, 'colors': colors,
                  'score_role': 'full-fit', 'rule': f"{zone_mode} tiers {tiers}, screen alpha {args['alpha']}, "
                                                    f"rel IQR cut {args['rel_iqr_cut']}"}
    r['candidates'] = {'table': str(out / 'candidates.csv'), 'id': c.id, 'column': 'candidate',
                       'score': {'table': full, 'id': c.id, 'column': 'score', 'where': {'model': primary}},
                       'score_name': primary, 'score_role': 'full-fit', 'max': 3}
    patches = pd.read_csv(out / 'far_target_patches.csv', dtype={'far_target': str})
    r['far_targets'] = {'table': str(out / 'far_targets.csv'), 'id': c.id, 'column': 'far_target',
                        'score': {'table': full, 'id': c.id, 'column': 'score', 'where': {'model': primary}},
                        'score_name': primary, 'score_role': 'full-fit', 'max': 3,
                        'notes': dict(zip(patches['far_target'], patches['status'])),
                        'rule': f"cells at least {args['new_gap']} grid steps from every recorded positive, ranked among "
                                f"themselves (top {far_fractions(args)}), same screen and uncertainty cut"}
    r['zone_rules'] = {'score': {'table': oof, 'id': c.id, 'column': 'score', 'where': {'model': primary}},
                       'score_name': f'{primary} held-out', 'score_role': 'held-out', 'fractions': far_fractions(args)}
    return r


def _calibration_figure(oof, cal, alpha, out, c):
    import matplotlib.pyplot as plt
    models = list(dict.fromkeys(oof['model']))
    fig, (left, right) = plt.subplots(1, 2, figsize=(12, 5.2), layout='constrained')
    reach = 0.0
    for i, m in enumerate(models):
        part = oof[oof['model'] == m].sort_values('calibrated')
        bins = np.array_split(np.arange(len(part)), 10)  # equal-count bins
        x = [part['calibrated'].iloc[b].mean() for b in bins]
        yv = [part['label'].iloc[b].mean() for b in bins]
        n_p = [int(part['label'].iloc[b].sum()) for b in bins]
        reach = max(reach, max(x), max(yv))
        left.plot(x, yv, marker='o', color=stage_evidence.GROUP_COLORS[i], label=f'{m} (10 equal-count bins; P per bin {min(n_p)}-{max(n_p)})')
    lim = 1.1 * reach if reach > 0 else 1.0  # the range the bins use, not the largest single score
    left.plot([0, lim], [0, lim], color='#999999', linestyle='--', label='Calibrated = observed')
    left.set(xlim=(0, lim), ylim=(0, lim))
    left.set(xlabel='Calibrated score (held-out, Platt from inner out-of-fold scores)',
             ylabel=f'Observed share of recorded {c.short[0]}', title='Calibration of held-out scores')
    left.legend(fontsize=8, loc='upper center', bbox_to_anchor=(.5, -.12))  # below, off the points
    folds = sorted(cal['outer_fold'].unique())
    width = .8 / len(models)
    for i, m in enumerate(models):
        part = cal[cal['model'] == m].set_index('outer_fold').reindex(folds)
        right.bar(np.arange(len(folds)) + i * width, part['test_positive_coverage'], width=width,
                  color=stage_evidence.GROUP_COLORS[i], label=m)
    right.axhline(1 - alpha, color='#b2182b', linestyle='--', label=f'Target 1 - alpha = {1 - alpha:g} (no exact guarantee)')
    right.set_xticks(np.arange(len(folds)) + width * (len(models) - 1) / 2, [f'fold {f}' for f in folds])
    right.set(ylim=(0, 1.05), ylabel=f'Share of test {c.short[0]} inside the screen',
              title='Held-out coverage of the positive screen per outer fold')
    right.legend(fontsize=8, loc='upper center', bbox_to_anchor=(.5, -.1), ncol=len(models) + 1)  # below, off the bars
    return figure_style.save_figure(fig, out / 'm5_calibration', record={
        'stage': 'M5', 'question': 'Are held-out scores calibrated to the recorded-positive rate, and does the screen keep the test positives',
        'sources': [out / 'oof_scores.csv', out / 'calibration.csv']})


def _capture_figure(capture, labels_, out, c):
    import matplotlib.pyplot as plt
    models = list(dict.fromkeys(capture['model']))
    import textwrap
    fig, ax = plt.subplots(figsize=(max(9, 2.3 * len(labels_)), 4.8), layout='constrained')
    width = .8 / (2 * len(models))
    xs = np.arange(len(labels_))
    for i, m in enumerate(models):
        part = capture[capture['model'] == m].set_index('zone').reindex(range(len(labels_)))
        ax.bar(xs + (2 * i) * width, part['capture_mean'], width, yerr=part['capture_sd'], capsize=3,
               color=stage_evidence.GROUP_COLORS[i], label=f'{m}: share of test {c.short[0]} (mean, SD over folds)')
        ax.bar(xs + (2 * i + 1) * width, part['cell_share_mean'], width, color=stage_evidence.GROUP_COLORS[i], alpha=.35,
               label=f'{m}: share of test cells')
    ax.set_xticks(xs + width * (2 * len(models) - 1) / 2, ['\n'.join(textwrap.wrap(n, 16)) for n in labels_], fontsize=8)
    ax.set(ylabel='Share within each outer test fold', title='Held-out zones: recorded positives captured against cells used')
    figure_style.outside_legend(ax, fontsize=8)
    return figure_style.save_figure(fig, out / 'm6_zone_capture', record={
        'stage': 'M6', 'question': 'How many held-out positives each zone captures for how many cells',
        'sources': [out / 'zone_capture.csv']})


def _report(result):
    for m, d in result['record']['deployment'].items():
        print(f"{m} map: {d['tier_cells_moved_by_uncertainty']} of {d['cells_ranked_in_tiers']} cells ranked in the tiers "
              f"moved out by the uncertainty cut, {d['tier_cells_outside_screen']} by the screen; tier rel IQR p10/p50/p90 "
              f"{d['tier_rel_iqr_p10_p50_p90']}")
        if d['cells_ranked_in_tiers'] and d['tier_cells_moved_by_uncertainty'] == 0:
            print(f'note: the rel IQR cut moves none of the tier cells of {m}; say why this cut is kept (or choose it from '
                  'the spread above)')
        if d['tier_cells_moved_by_uncertainty'] > d['cells_ranked_in_tiers'] / 2:
            print(f'warning: the rel IQR cut removes most tier cells of {m}; revisit it against the spread above and the '
                  'purpose (pu_workflow.py rezone changes it without refitting)')
    primary = result['record']['config']['primary']
    found = result['record']['deployment'][primary].get('candidates', {})
    print(f"candidates ({primary} tier patches): {found.get('new', 0)} new, {found.get('recheck', 0)} re-checks of recorded "
          'positives (candidate_patches.csv)')
    far = result['record']['deployment'][primary].get('far_targets', {})
    kept = far.get('far_cells_kept_by_screen', {})
    print(f"far targets ({primary}, cells at least {far.get('gap_steps')} grid steps from every recorded positive, ranked "
          f"among {far.get('far_cells')} such cells): {far.get('targets')} patches of {far.get('target_cells')} cells, "
          f"{far.get('target_cells_passing')} of them pass the screen and the uncertainty cut (far_target_patches.csv); "
          f"far cells kept by the screen: {_share(kept.get('map'))} on the map, {_share(kept.get('heldout'))} held-out")
    if _num(kept.get('map')) != 'n/a' and _num(kept.get('heldout')) != 'n/a' and kept['map'] < kept['heldout'] / 2:
        print('warning: the screen keeps far fewer far cells on the map than in the held-out folds (see the note in '
              'pu_workflow.json); report both shares and the reasons they may differ')
    if found.get('patches') and not found.get('new'):
        print('warning: no new candidate inside the tiers; say so in the report. The far targets are the standard rule '
              'for new ground here (their held-out check is below and in far_target_capture.csv); a different rule '
              'needs its reason from the purpose')
    for m, s in result['record']['summary'].items():
        if s['folds_without_screen']:
            print(f"warning: {m}: {s['folds_without_screen']} outer folds had too few pool positives for alpha; "
                  'no screen there (nothing excluded, coverage not evaluated)')
        print(f"{m}: inner AP {s['inner_ap_mean']:.3f}, outer AP {s['outer_ap_mean']:.3f} (SD {s['outer_ap_sd']:.3f}), "
              f"ROC AUC {s['outer_roc_auc_mean']:.3f}, held-out positive coverage {s['positive_coverage_mean']:.3f}")
        bands = '; '.join(f"{b}: {_share(v['positive_capture'])} of {v['test_positive']} positives in "
                          f"{_share(v['area_share'])} of the cells" for b, v in s['capture_by_distance'].items())
        print(f'  held-out tier capture by grid steps to the training positives - {bands} (distance_capture.csv)')
        f = s['far_rule_heldout']
        print(f"  held-out far rule (top {f['fraction']:g} of the far test cells): {_share(f['capture_ranked'])} of "
              f"{f['far_positive']} far positives by rank, {_share(f['capture_in_zone'])} after screen and uncertainty; "
              f"far AP {_num(f['far_ap_fold_mean'])} vs prevalence {_num(f['far_prevalence'])}")
    print('tables and render_spec.json in', result['out'])
    for f in result['figures']:
        print('figure', f)
    print('Next: stage_evidence.py render <out>/render_spec.json, then open every PNG.')


def _share(v):
    return 'n/a' if v is None or not np.isfinite(v) else f'{v:.0%}'


def _num(v):
    return 'n/a' if v is None or not np.isfinite(v) else f'{v:.3f}'


def _decision_args(parser, inherit=False):
    parser.add_argument('--tiers', type=float, nargs='+', required=True)
    parser.add_argument('--alpha', type=float, required=True)
    parser.add_argument('--rel-iqr-cut', type=float, required=True)
    parser.add_argument('--zone-mode', choices=('lift', 'prob'), default=None if inherit else 'lift')
    parser.add_argument('--zone-names', nargs='+')
    parser.add_argument('--screen', choices=('pool', 'repeated'), default=None if inherit else 'pool',
                        help="positive screen: split-conformal on the whole train-only pool, or the median of 20 "
                             "block-wise halvings (repeated cross calibration)")
    parser.add_argument('--rank-fractions', type=float, nargs='+',
                        help='with --zone-mode prob: upper fractions for the far-target ranking and the zone-rule '
                             'comparison (lift mode uses the tiers)')
    parser.add_argument('--new-gap', type=int, default=None if inherit else 2,
                        help='far targets: cells at least this many grid steps from every recorded positive, ranked '
                             'among themselves (default 2 = not in or next to a recorded positive cell)')


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if argv[:1] == ['rezone']:
        parser = argparse.ArgumentParser(prog='pu_workflow.py rezone', description=rezone.__doc__)
        parser.add_argument('source', help='the models folder of a pu_workflow run')
        _decision_args(parser, inherit=True)  # zone mode, screen and names left out keep the source run's
        parser.add_argument('--reason', required=True, help='why the decision values change (kept in the record)')
        parser.add_argument('--out', help='new folder (default <source>_rezoned)')
        a = parser.parse_args(argv[1:])
        _report(rezone(a.source, tiers=a.tiers, alpha=a.alpha, rel_iqr_cut=a.rel_iqr_cut, reason=a.reason,
                       zone_mode=a.zone_mode, names=a.zone_names, screen_rule=a.screen, new_gap=a.new_gap,
                       rank_fractions=a.rank_fractions, out=a.out))
        return 0
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('spec')
    parser.add_argument('--split', required=True)
    _decision_args(parser)
    parser.add_argument('--models', nargs='+', default=['binary', 'bagging_pu'])
    parser.add_argument('--primary', default='bagging_pu')
    parser.add_argument('--members', type=int, default=8)
    parser.add_argument('--u-fractions', type=float, nargs='+', default=[.25, .5])
    parser.add_argument('--depths', type=int, nargs='+', default=[2, 4])
    parser.add_argument('--trees', type=int, nargs='+', default=[100, 200])
    parser.add_argument('--bootstrap', type=int, default=20)
    parser.add_argument('--seed', type=int, default=42)
    parser.add_argument('--n-jobs', type=int, help='threads per model fit (default 2)')
    parser.add_argument('--out')
    a = parser.parse_args(argv)
    spec = json.loads(Path(a.spec).read_text())
    result = run(spec, a.split, tiers=a.tiers, alpha=a.alpha, rel_iqr_cut=a.rel_iqr_cut, zone_mode=a.zone_mode,
                 names=a.zone_names, models=a.models, primary=a.primary, members=a.members, u_fractions=a.u_fractions,
                 depths=a.depths, trees=a.trees, bootstrap=a.bootstrap, seed=a.seed, out=a.out, n_jobs=a.n_jobs,
                 screen_rule=a.screen, new_gap=a.new_gap, rank_fractions=a.rank_fractions)
    _report(result)
    return 0


if __name__ == '__main__':
    sys.exit(main())
