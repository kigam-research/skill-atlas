# 단계별 그림 패턴

지도 기반 MPM 그림이 각 단계에서 맡는 역할을 일반화한 패턴이다. **단계의 목적을 보여 주는 품질 기준**이지 색·알고리즘·수치·그림 개수를 복제하는 규격이 아니다.

## 데이터 진단

관측 위치만으로는 predictor가 무엇을 알려 주는지 볼 수 없다. 공간 좌표와 유효한 predictor가 있으면 **대표 predictor의 공간 값과 missing 위치**도 보여 준다. 동일 extent에서 연속 변수는 단위 있는 colorbar, 범주형 변수는 명시적 범례를 사용한다. P/U overlay는 필요할 때 별도 panel이나 작은 marker로 겹친다. 결측률 막대/히스토그램은 보완 자료이지 공간 구조 지도의 대체가 아니다.

**MPM 분석 격자(cell 중심 좌표와 해상도/지지 범위가 명시된 자료)는 기본적으로 여백 없는 raster형 cell 지도**로 그린다. `assets/grid_map.py`의 `raster_map`을 참고해 연속 predictor/score는 수치 색상, fold/zone은 범주색으로 cell 전체를 채운다. `pcolormesh`의 cell edges, flat shading, edgecolors none/antialias off로 점 사이 공백과 가짜 보간을 없앤다. nodata는 별도 색/범례로 유지한다. 양성은 그 위에 작은 overlay로 표시한다. 일반 산점도로 격자 지도 요구를 대체하지 않는다.

실제 독립 점 관측에는 점 지도를 쓴다. 격자 형태로 배열되었다는 사실만으로 모든 면적을 대표하는 cell 자료라고 가정하지 않는다. 지질 배경·행정 경계는 실제 자료와 CRS가 제공될 때만 사용하고 없는 배경을 만들어 넣지 않는다.

## 공간 평가

실제 split 표에서 fold 색상과 block geometry를 그린다. block은 평가를 묶는 단위, cell/site는 관측 단위다. 작은 cell marker를 큰 block처럼 그리지 않는다. 절차 도식은 outer test가 fit/튜닝에 들어가지 않음을 설명하고 실제 코드와 일치해야 한다. 지도의 양성 marker와 fold별 양성 수를 대조한다.

## 점수·불확실성·선별

같은 대상을 비교하는 panel은 extent·mask·색상 척도를 공유한다. 예측 score, conformal membership, priority zone은 별도 layer와 의미를 갖는다. 계산하지 않은 불확실성이나 zone을 장식용으로 만들지 않는다. 참조 그림의 'probability' 표현을 새 분석의 검증되지 않은 광상 확률로 옮기지 않는다.

연속 score에는 순차형 colormap, 범주에는 고정된 category→color mapping과 범례를 쓴다. NaN/nodata는 낮은 score나 미표지(U)와 다른 의미다. 색상bar 범위에서 clipping을 한다면 실제 최소/최대·clipped 비율과 이유를 밝힌다.

## 국소 확대

다음 항목은 이미지뿐 아니라 코드/표로 대조한다. `assets/grid_map.py`는 cell 의미·간격을 이미 확정한 투영 격자에만 쓰는 선택형 뼈대다. 입력 행 순서와 무관한 배치, half-cell edges, 빠진 cell mask, 중복/불규칙 격자 거부를 제공한다.
- cell 데이터라면 중심 좌표와 경계 좌표를 구분한다. 반 cell만큼 정확히 확장한 edges와 `pcolormesh` 등을 사용한다. 중심 min/max를 그대로 raster extent로 쓰면 경계가 축소될 수 있다.
- 행을 임의 reshape하지 않고 좌표 키로 정렬/join한다. duplicate cell 값은 정책을 정한 뒤 처리한다. 없는 cell은 mask다.
- 양성 marker는 해당 cell/site 중심에 위치해야 한다. row 수, 고유 site 수, 양성 cell 수를 혼용하지 않는다. 중복 marker가 겹치는 경우 count 단위와 중복 표시를 설명한다.
- 같은 구역 비교는 같은 영역·지점·범주색을 유지한다. 확대 영역을 왜 골랐는지도 설명한다.

## 성능 비교·누적 포착률

fold별 비교, 지지도를 드러내는 표식, 누적 포착률을 함께 보여 준다. 다른 연구의 방법명·구역 수·목표 coverage 선을 옮기지 않는다. fold 표의 실제 ID로 정렬하고 표준편차를 신뢰구간으로 부르지 않는다. 단일 baseline에는 여러 방법 비교 패널을 억지로 만들지 않는다.

포착률의 분모는 기록된 양성 단위다. 구역 번호를 균등 간격으로 배치한 축을 면적 축으로 해석하거나 그 위에 임의의 random 대각선을 넣지 않는다. score 순위의 평가라면 x축을 실제 선택 관측/고유 cell/면적 분율로 계산한다. 동률을 자의적으로 잘라 성능을 높이지 말고 선택 규칙과 실제 선택량을 남긴다. `assets/evaluation_view.py`는 이 원리를 모델과 무관한 선택형 PR/fold/capture 뼈대로 제공한다.

## 지리·편집 검수

다른 연구 그림의 CRS·cell 크기·block 크기·scale bar 길이는 기본값이 아니다. 이 자료의 좌표 CRS·거리 왜곡·분석 해상도에 맞춰 정한다. metre를 km로 변환하면 데이터·overlay·boundary·축을 함께 변환한다. coordinate km와 ground-distance km를 혼동하지 않는다. north arrow와 scale bar는 근거가 있을 때만 넣는다.

읽을 수 있는 제목·축·단위·colorbar·범례를 쓰고 관측을 가리지 않게 배치한다. 최종 응답과 caption의 범위·개수·변수명은 실제 표와 대조한다. 그림이 예쁘다는 이유로 데이터 정렬·지리 의미가 맞다고 판정하지 않는다.
