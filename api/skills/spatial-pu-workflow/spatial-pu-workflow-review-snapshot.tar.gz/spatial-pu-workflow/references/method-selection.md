# 근거에서 방법으로: MPM 의사결정 가이드

이 문서는 일반 분석의 선택 기준이다. 알고리즘 목록을 순서대로 실행하는 체크리스트가 아니다. 현재 모듈의 표와 상세 문서를 읽고 **관찰 → 후보/가정 → 선택 또는 제외 → 실행 검증 → 재검토 조건**을 연결한다. 참조 연구 재현 요청이 없으면 다른 연구의 숫자·방법 조합을 자동 채택하지 않는다.

## 공통 선택 절차

1. 목적·추정 대상·관측 support·label 생성 과정을 확정한다. 예: 동일 지역 U 순위, 먼 지역 전이, 기록된 P 포함집합은 서로 다른 문제다.
2. M1/M2 실제 표·그림·통계 경로를 근거로 적합한 후보를 좁힌다. 이름이 알려진 방법보다 필요한 자료와 가정을 먼저 점검한다.
3. 선택과 기각 이유, 검증 방법·한계·재검토 조건을 상태에 기록하고 코드를 생성/조정한다. 아래 후보는 예시이며 다른 방법은 필요한 가정과 검증을 같은 수준으로 제공하면 된다.
4. 실패하면 실패 기록을 보존하고 대안으로 돌아간다. 자원 한도는 후보/튜닝 규모를 줄일 근거이지, 공간 평가·불확실성 판단을 몰래 생략하거나 전체 domain을 crop할 근거가 아니다. `not_applicable`은 과학적 이유, `blocked`는 자료/환경 부족, `partial`은 미완료다.
5. 탐색 결과로 설계를 바꾸면 버전을 올리고 평가 역할을 갱신한다. 이미 열어본 outer test는 새 설계의 미사용 최종 검증으로 되돌릴 수 없다. 가능하면 독립 지역/시간 holdout을 남긴다. 없으면 탐색적 성능이라고 명시한다.

## M0 — 목적과 관측 과정

| 관찰/필요 자료 | 선택 후보·적용 조건 | 검증·대안·한계/재검토 |
|---|---|---|
| P와 U만 있고 미발견 가능성이 있음 | P/U 순위 baseline; PU는 기록 과정 가정을 검토한 뒤 후보로 | label 정의/시점·조사 편향 확인. U를 음성으로 해석하지 않음. 확인된 음성 확보 시 지도학습 계약 재검토 |
| 대표성 있는 확인된 P/N | 지도학습 비교; 불균형 가중은 목적에 따라 | 음성 판정의 검출한계/조사강도 확인. PU를 관례상 추가하지 않음 |
| P만 있고 배경 표본이 없음 | 적합한 배경 모집단 확보 또는 presence-background/전문가 지식 기반 탐색 | background와 absence 구분. 배경선택 편향/공간 coverage 검증; 근거 없는 부존확률 보고 금지 |
| cell vs site, 같은 지역 vs 전이 | 실제 support와 예측 거리/대상 영역을 계약에 기록 | point count를 면적으로 환산하지 않음. 신규 목적/해상도이면 M2/M3와 budget 정의 재검토 |

## M1 — EDA가 바꾸는 선택

| 실제 관찰 | 처리/후속 방법 후보 | 검사·대안·재검토 |
|---|---|---|
| 비음수 긴 꼬리, 거리/농도 물리 의미 | log1p/robust scaling 또는 원척도 tree; linear/distance 모델에 scaling 검토 | 0/음수 의미 확인, train-only fit; 긴 꼬리 P를 제거하지 않음. 변환 전후 관계·inner 성능/잔차 비교 |
| 유효한 signed anomaly/다봉성 | 원값 유지, 필요시 robust scale; 비선형 후보 | log 강제 금지. 분포 모드의 지질/조사 출처와 성능 안정성 확인 |
| 높은 공선성, 적은 P/많은 변수 | 지질 그룹 축약·정규화 linear 또는 제한된 tree 복잡도 | 상관만으로 기계적 삭제 금지. train-only 선택, 변수군 ablation/민감도; 해석 안정성 실패 시 재선택 |
| 결측이 survey 경계와 동반 | train-local 대치/native missing, availability indicator의 통제 비교 | 고정 결측률 자동 규칙 없음. 누출/시점·전이에서 사용 가능성 확인. geology와 availability 효과 분리 |
| P의 조사 편향/공간 집중 | PU selection 가정 재검토, survey/지역별 검증 | SCAR(양성 기록확률 일정)를 당연시하지 않음. 편향 진단은 실제 propensity 추정과 다름 |
| 외삽·분포 이동/강한 방향성 | 적용가능영역 표시, 지역 전이 평가·방향성 M2 | 새로운 지질/survey에서 지원 부족이면 확률/발견률 주장 축소, 추가 자료 제안 |

표/atlas만 만들지 말고 각 주요 관찰이 **변수·전처리·모델/PU·분할·불확실성·탐사 정책 중 무엇을 바꾸는지** decision ID로 연결한다. 변화가 필요 없다는 결론도 근거를 남긴다.

## M2 — 공간 진단의 적용 조건

| 조건 | 방법 후보 | 검증·대안·한계 |
|---|---|---|
| 수치 predictor, 충분한 거리/방향 pair | empirical variogram + spherical/exponential/Gaussian 등 타당한 fit | sill 도달·range 정의·bin별 pair/표본/방향 민감도. 최저 RMSE만으로 선택하지 않음 |
| 희소 P/U binary | 모든 셀 쌍의 observed-label variogram, label 분산에 처음 닿는 거리를 label range로(`block_design.py`). predictor 진단은 사용자가 요청할 때 | disagreement pair, prevalence, 표본편향(양성 농축 표본 금지) 확인. 참 광상 range로 해석하지 않음. 계속 오르면 광역 추세로 보고 적합 r95를 block에 쓰지 않음 |
| 추세/비정상성·fit 경계·plateau 없음 | 단거리/방향/지역별 진단, geologic/survey 규모·거리 기반 평가 대안 | 실패 fit 보존. detrending 시 학습 경계/목적 공개. 무근거 r95 또는 다른 연구의 block 값 대입 금지 |
| 범주 지질 단위 | indicator별 구조/지역 경계 진단 | 임의 category ID 차이를 semivariance로 계산하지 않음. 과소지지 범주는 거리/지역 holdout 대안 |

공간 의존 진단 자체를 비용/편의만으로 건너뛰지 않는다. variogram은 위 후보 중 하나이며, 거리별 label/잔차 비교·지역/방향별 진단·독립 지역 holdout 근거 등 목적에 맞는 대안도 같은 무게로 검토한다. variogram을 택했다면 표본/쌍 추출로 계산을 제한하되 전체 support를 대표하고 실패/불확실성을 전달한다.

## M3 — 일반화 목표에 맞춘 공간 평가

| 목표/근거 | 선택 후보 | 검증·대안·한계 |
|---|---|---|
| 같은 영역의 미관측 위치 | label range 이상 block, 양성 균등 무작위 최적화 배정의 nested 공간 block CV + 거리 진단 | range·지질 규모와 후보 크기, origin 민감도, 실제 test→train 거리; block 폭≠최소거리 |
| 떨어진 새로운 지역/조사 | 지역/survey holdout, buffered spatial CV | 전이 distance/support 재현, P/N(U) 지지도·buffer 후 fit IDs; 전체 domain에 대한 평가 가능한 범위를 구분 |
| 미래 발견 예측 | 발견/자료 시점 cutoff + 공간 그룹/필요시 buffer | 미래 생성 predictor 누출 제외. temporal만으로 공간 누출 제거 주장 금지 |
| P가 일부 그룹에만 존재 | 더 적은 folds, 반복 지역 holdout/불확실성 보고 | 정의 불가 지표를 null 처리. 편한 random split으로 공간 일반화 주장하지 않음 |

튜닝은 nested spatial inner 또는 독립 개발영역에서 한다. 명시적인 튜닝 없는 baseline도 가능하지만 그 이유와 대안 비교 필요성을 기록한다. split 선택에 outer score를 사용하지 않는다.

주 활용 목적과 stress 평가 목적, 후보 선택 절차와 개별 family 성능을 [평가 계약](evaluation-contracts.md)으로 구분한다. 참고 지역 holdout을 주 목적의 유일한 평가로 자동 승격하지 않는다.

## M4 — 모델/PU 선택

| 자료·가정 | 후보/조건 | 검증·제외 근거와 한계 |
|---|---|---|
| 적은 P, 단순성/해석 우선 | 정규화 logistic/GAM 등의 baseline | scale·비선형 관계·희소 P·train-local fit; 부적합 관계이면 tree 대안 |
| 비선형/상호작용·혼합 predictor | 제한된 tree/RF/boosting 비교 | 과적합·survey proxy·외삽, 같은 outer folds 비교. 특정 boosting 구현은 고정 선택 아님 |
| P/U, U 오염 가능·class prior 불명 | P/U baseline + bagging PU 등 prior 불요 순위 후보 | train P 보존/U 표집·다양성·T 민감도. 실제 확률 보정/SCAR 보장을 자동 주장하지 않음 |
| class prior/selection mechanism에 외부 근거 | prior/propensity 보정 PU, 조건이 맞는 risk estimator | prior 추정 불확실성/식별가능성·민감도 필요. 근거 없으면 확률 해석 제한/다른 후보 |
| Spy/EM 선택 | 원 방법의 target·posterior·가정/수렴 구현 가능할 때 | 가려진 P비율≠기록 propensity. 가짜 반복fit 금지. 가정·구현 불성립이면 명시적 대안 |
| 대표 P/N 존재 | 지도학습/imbalance 후보 비교 | PU 제외 이유는 관측 계약. 모든 연구에 PU 강제하지 않음 |

방법/후보 선택은 inner held-out 또는 독립 개발영역에서 하고, **outer held-out OOF는 평가 전용**이다. “OOF로 선택”처럼 역할을 생략하지 않는다. outer 결과로 바꾼 방법은 새 개발 선택이며 같은 outer를 미사용 최종 평가라고 재사용하지 않는다.

코드가 실행되는 것과 알고리즘을 실제 구현한 것을 분리해 검증한다. 전체 분석은 과학적으로 타당한 baseline/대안을 비교하거나 불가 사유·남은 검증을 남긴다. 예산 때문에 비교 못 한 것을 `not_applicable`로 쓰지 않는다.

## M5 — 불확실성과 보정의 필요성/성립성

| 의사결정 질문·자료 | 선택 후보 | 검증·대안·한계 |
|---|---|---|
| 순위/후보가 재학습에 얼마나 안정적인가 | 공간 block/cluster bootstrap, 적절한 반복 split; iid 목적에서만 row bootstrap 해석 | P 지지도·단위·replicate 민감도. IQR/mean 외 SD·rank/선택 빈도도 가능. denominator 불안정이면 rho 강제 금지 |
| 관측 label 확률이 필요한가 | train-local holdout/OOF Platt; 충분한 calibration 자료에서 isotonic 등 | score-generator 분리, n/P·reliability/Brier. 순위만 필요하면 보정 불필요 판단 가능; PU true probability 아님 |
| 알려진 P 누락 위험/포함집합이 필요한가 | empirical screen 또는 가정이 맞는 split-conformal/tolerance 방법 | alpha/delta는 정책, n/P·의존성·exchangeability·correction 확인. 정확한 보장과 경험적 coverage 구분 |
| P 부족/공간 의존으로 보장 불성립 | 한계를 밝힌 경험적 평가·안정성/민감도·추가 독립 검증 | 전부 포함/지원 부족을 우수 coverage로 보고하지 않음. conformal 미적용이어도 불확실성 질문 자체를 생략하지 않음 |

불확실성 종류(자료/모델/재표집/외삽/label)를 기록한다. bootstrap→Platt→conformal 같은 특정 연구의 조합을 모든 자료의 필수 조합으로 삼지 않는다. 선택하지 않은 종류가 남기는 한계는 M7에 유지한다.

## M6 — 탐사 행동으로 번역

| 목적·필요 자료 | 정책 후보 | 검증·대안·한계 |
|---|---|---|
| 조사 가능 면적/지점 수 예산 | 명시적 support-weighted top-budget, 동률 처리 | 전체/유효/U 후보 분모, 실제 선택량; U 후보와 P포함 평가 순위 구분 |
| 추가 증거 확보 vs 집중 탐사 | score와 stability/외삽을 분리한 2축 분류 또는 후보 선택 빈도 | 변수가 행동을 실제 바꾸는지, threshold/예산 민감도; 안정성≠경제성 |
| 비용·접근성·보호구역 자료 있음 | 제약/비용 고려 순위/utility | 비용/편익 근거와 단위 필요. 없으면 예상 경제이익 생성 금지 |
| 사용자가 명시한 참조 연구의 구역 정책 | 스킬 `reference-cases/`의 해당 사례 정책을 선택 기록 후 조정 | 순위·안정성·포함집합 신호의 전제와 임계 근거 검토. 사례의 구역 수·tier·cut을 숨은 default로 쓰지 않음 |

구역이 필요 없으면 연속 score+안정성+예산 후보표도 완전한 의사결정 표현이 될 수 있다. 색상 가이드는 정책과 독립이다. 목적에 맞는 정책을 선택하지 않은 채 지도 색만 적용하지 않는다.

## M7 — 검증과 재검토

지질 가설/예외, held-out 지역별 실패, 중요도의 정의·상관 한계, 정책 민감도를 연결한다. 성능/안정성/시각 품질을 따로 판정한다. 지역별 성능 붕괴→M0/M3, proxy 지배→M1/M4, calibration/coverage 실패→M5, 예산/정책 변화→M6으로 돌아갈 조건을 남긴다. outer 성능을 보고 선택을 바꿨으면 기존 평가를 개발 증거로 재분류하고 새 독립 평가 없음을 공개한다.

## 상태에 보존할 최소 decision record

간결한 표/JSON으로 **근거(경로·주장·출처 등급) → 선택/대안과 이유·가정/한계 → 검증 결과·평가 역할 → 재검토 조건**을 연결한다. 명명한 decision ID로 downstream을 추적한다. 매번 12개의 빈 칸/n/a를 채우는 형식 작업은 필요 없다. 중요한 매개변수의 출처와 제외 사유는 생략하지 않는다.

출처 등급은 `documented`(제공 문서 정의), `observed`(계산/관측), `inferred`(해석/가설), `unknown`을 구분한다. inferred를 확인된 지질 정의로 승격하지 않는다. 가정에 기반한 분석 선택은 허용하되 검증/민감도와 한계를 연결한다. 생성한 profile/그림의 문장을 다시 인용하는 것은 독립적인 의미 검증이 아니다. 정정된 판단은 이전 claim과 downstream을 무효화/재검토한다.

[선택형 상태 뼈대](../assets/analysis-state.template.json)는 형식 예시일 뿐 runner가 아니다. 선택 전 가설과 검증 후 결과, 변경 이전 평가 역할을 보존한다.
