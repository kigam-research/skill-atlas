# 변경 가능한 시각 표현 기본 가이드

사용자 스타일 지정이 없으면 아래를 시작점으로 사용하고 실제 PNG 가독성에 맞게 조정한다. **권고표이지 분석 코드에 고정하는 정책이 아니다.** workspace의 style dict/JSON/함수 인자로 선택값을 분리하고 사용자 변경을 우선한다. 렌더 설정 변경은 score·구역 정의·임계값·구역 수·fit을 바꾸지 않는다. style hash와 분석 policy hash를 별도로 남길 수 있다.

## 우선순위 범주: 번호 대신 의미에 색을 연결

구역·tier를 만들었다면 색은 범주 번호가 아니라 **채택한 정책에서의 의미**에 연결한다. 사용자 지정이 없을 때의 시작점:

| 의미 | 기본 추천색 | 해석 주의 |
|---|---|---|
| 서열형 우선순위(높음→낮음) | 3단계 `#970026`, `#fc5b2e`, `#fed976`; 4단계 `#970026`, `#e92720`, `#fd923e`, `#fed976`; 5단계 `#970026`, `#db141e`, `#fc5b2e`, `#fea446`, `#fed976` (YlOrRd에서 추출) | 높은 우선순위일수록 진하게. 범주 수와 이름은 채택한 정책이 정한다 |
| 정책상 제외(포함집합 밖 등) | `#9467bd` 보라 | **정책상 제외**; 광상 부재·nodata 아님. 우선순위 색과 다른 색상 |
| 미산출·ID join 실패 | missing 색(아래 표) | 제외 범주로 채우지 않는다 |

실제 정책의 범주 수에 맞는 색만 사용한다. 임의 ID 0에 가장 진한 색을 붙이지 않는다. 범례에는 현재 정의와 표의 실제 count/support를 연결한다. colorblind/인쇄 요구이면 대비·명도·보조 기호 또는 다른 palette로 변경한다. 특정 참조 연구의 구역 이름·색 매핑은 그 사례를 명시적으로 선택했을 때만 쓴다.

## 공통 시작값 (자료와 출력 크기에 맞게 변경)

| 요소 | 사용자 지정이 없을 때 | 검증/변경 이유 |
|---|---|---|
| score | `viridis` 순차색, alpha 1 | 실제 범위·단위/score 역할; 비교 패널 공통 척도 |
| dispersion/rho | `magma` 순차색, alpha 1 | mean floor/유효 mask·단위; score와 별도 colorbar |
| signed anomaly/잔차 | `RdBu_r`, 의미 있는 0 중심 | 부호가 의미 있을 때만. 잘린 범위/극단값 공개 |
| P overlay | 검정 `*`, 흰 edge, scatter s=20 pt², lw=.4 pt, alpha=.95 | 고밀도 전체 지도는 s=12–20, 확대도는 30–50부터 조절; count는 실제 자료 |
| U 관측점 | 회색 `o`, s=6 pt², alpha=.25, edge 없음 | point map에서만. cell score 지도의 U를 회색으로 덮지 않음 |
| EDA P/U | P `#d62728`, U `#7f7f7f`; line 1.4 pt, fill alpha=.25 | density/ECDF vs count 목적 분리, 표본수 범례 |
| 비교모델/fold | 명시적으로 고정한 `tab10` 매핑 + 다른 line style | ID→label 매핑 보존, zone palette를 성능 우열처럼 쓰지 않음 |
| cell | alpha 1, edge 없음, nearest/flat fill | 실제 cell corner, nodata와 row 없음 구분; cell 여백 금지 |
| missing 값 | 밝은 회색 `#d9d9d9` + 별도 범례/필요시 mask panel | 과학적 제외/낮은 값과 다름 |
| 입력 행 없음 | 흰색 `#ffffff` + 다른 범례/mask | 자동 AOI 밖이라고 부르지 않음 |
| 실제 경계 | `#333333`, lw=.6 pt | 제공된 boundary만. 좌표 변환/extent 확인 |
| grid/축 | 옅은 `#dddddd`, lw=.4, alpha=.5; metric equal aspect | 자료를 가리지 않게. 좌표 CRS·단위 명시 |
| 제목/축/범례 | 약 12/10/9 pt, 밝은 배경, 범례 plot 밖 | 패널 실측 가독성 우선. scatter s는 pt², legend markersize는 pt로 구분 |
| 저장 | PNG 200–300 dpi + SVG/PDF, single 7×6 또는 비교 12×6 inch부터 | 실제 출력에서 label/legend/colorbar 겹침 확인 |

실제 코드·값·coordinates/corners·단위·legend mapping을 먼저 검증하고 저장 PNG도 연다. PNG가 존재하거나 픽셀 분산이 있다는 자동 검사만으로 visual pass를 선언하지 않는다. vision 없는 대상 모델이면 검수 한계를 밝히고 main/reviewer가 실제 PNG를 검수한다. 원본 figure의 레이아웃은 지질 설명/전체 범위/확대도 목적을 위한 패턴이며 고정 패널 복제 규칙이 아니다.

고밀도 P overlay가 바탕 값을 가리면 s/테두리 굵기/alpha를 줄이거나 테두리를 없애고, 필요하면 overlay 없는 값 확인 패널을 함께 둔다. 같은 P 의미의 cell fill/marker를 중복 범례로 나열할 때는 역할을 구분하거나 통합한다. 변수군별로 읽을 수 있는 크기의 그림을 나누며 전체 atlas를 한 PNG에 모두 넣는 것을 완료 기준으로 삼지 않는다. 부호 자료는 0 중심 발산 척도뿐 아니라 목적에 맞는 다른 척도도 가능하나 유효 대비·기준점·실제 값 의미를 확인한다.

데이터·수치·코드를 고쳤으면 저장 표에서 그림을 다시 렌더하고 **새 PNG**를 확인한다. 이전 그림을 완료 산출물로 연결하지 않는다. histogram 값을 끝 bin으로 clip하면 `≥상한` overflow와 개수·전체 범위를 표시하거나 전체 범위/명시적 확대를 사용한다. 격자 거리의 이산 spike는 bin 선택에 따라 생길 수 있으므로 연속 분포의 모드처럼 해석하지 않는다. 지도 block 격자선은 cell centre가 아니라 실제 block edge에 맞춘다. 수치형 변수의 단위·0 처리/log 변환과 진단 기준선의 가정을 범례/캡션에 드러낸다.

범주형 fold/zone/availability는 범주별 색·정수/의미 라벨을 사용하며, 연속 colorbar의 분수 tick이나 존재하지 않는 색으로 범주를 표시하지 않는다. `grid_map.raster_map`이 반환한 `legend_handles`는 category/nodata의 의미다. overlay 범례를 만들 때 버리지 말고 함께 전달한다(선택형 `figure_style.map_legend(ax, raster_info, ...)`). overlay가 배경색과 겹쳐 사라지지 않는지 실제 PNG에서 확인한다. symlog의 0 부근 tick이 겹치면 locator/개수를 조정하거나 읽을 수 있는 패널로 나눈다. 전체 값 범위 표현도 유효하며, 대비 개선을 위해 clip/비선형 norm을 선택했다면 범위·extend·단위를 공개하고 비교 패널의 의미를 유지한다.
