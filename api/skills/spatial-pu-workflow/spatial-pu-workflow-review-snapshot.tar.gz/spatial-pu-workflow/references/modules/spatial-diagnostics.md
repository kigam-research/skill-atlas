# M2 — 공간 의존을 계산·진단하고 평가 설계에 연결한다

[방법 선택 가이드](../method-selection.md)의 M2 조건표를 읽고 관찰·후보·가정·선택/제외 이유·검증·재검토 조건을 decision record로 연결한다. 아래 계산 계약은 선택한 방법에 적용하며 모든 참조 알고리즘을 강제하지 않는다.

## 거리의 정의와 왜곡

길이 단위가 m인 projected CRS도 지상 거리를 보존하지 않을 수 있다. 특히 정각 원통 투영(normal-aspect Mercator, 예: Web Mercator)의 grid 간격·lag·buffer를 지상 km로 읽지 않는다. 투영의 성질(등각·등적·등거리)과 영역 내 축척 계수는 CRS 정의에서 확인한다. 연구 목적에 따라 projected-coordinate 거리 또는 ground/geodesic 거리를 선언하고 영역 내 대표 위치·방향의 왜곡을 확인해 수치·축·캡션에 적용한다. 지상 분리 거리가 필요한 경우 적합한 지역 metric projection이나 geodesic 방식을 선택·검증한다. **equal-area라는 이유만으로 거리 보존을 가정하지 않는다.** 원래 regular grid의 FFT를 선택했다면 그 grid 좌표 거리에서의 진단임을 밝힌다. 변환 후 불규칙해진 좌표를 여전히 regular grid처럼 취급하지 않는다.

## 무엇을 계산하는가

M0/M1의 좌표·support·광상 가설과 평가 목적부터 읽는다. 적절한 투영 또는 거리 함수를 선택하고 좌표상의 m와 지상 m를 구분한다. binary observed label의 variogram은 알려진 양성의 공간 패턴이며 미발견 광상의 참 의존 범위가 아니다. label 외에 대표 predictor, 적절한 학습 경계 내 잔차의 진단을 선택할 수 있다. 진단 방법(variogram, 거리별 비교, 지역·방향별 진단 등)은 자료와 평가 목적에 맞게 고른다. 아래 계산 계약은 variogram을 택했을 때의 것이다.

variogram을 택하면 empirical semivariance `0.5 * mean((z_i-z_j)^2)`를 거리 lag별로 계산한다. 대상 변수, 단위, lag edges/평균거리, pair 수, 중복 pair/방향 필터, maxlag, sampling·seed와 유효 표본을 남긴다. 규칙 격자는 좌표-key로 pivot하고 dx/dy·축 방향·빈셀을 검증한 뒤 `grid_empirical`의 exact lag 집계도 사용할 수 있다. 비규칙 자료를 임의 보간해 이 함수에 넣지 않는다. 대규모 비격자 자료는 전체 영역에 걸친 **label-independent** 표본/쌍 추출을 우선한다. P를 모두 추가하는 식의 outcome-dependent sampling을 무근거하게 그대로 쓰지 않는다. 필요한 경우 추출확률/가중 및 estimand 변화를 설명한다. 표본 지도를 전체 분석 지도와 구분한다.

## 적합과 판단

variogram model을 적합한다면 Gaussian/exponential 등 타당한 후보를 empirical points에 fit하고 nugget·partial sill·range 및 수식을 저장한다. 패키지 `range`의 뜻을 확인한다. `r95`라면 structured sill의 95% 도달 거리인지 명시하고 **적합과 같은 함수로 곡선을 그린다.** 작은 RMSE는 안정된 range나 공간 독립성의 증명이 아니다.

희소 binary label에서는 전체 pair 수뿐 아니라 값이 다른 pair 수와 표본 민감도를 같이 본다. 많은 pair가 독립 관측을 뜻하지 않는다. 함수의 방향은 +x에서 반시계 0–180°이고 지질학적 북쪽 기준 방위각과 다르므로 변환을 기록한다.

0/1 pair의 항등식은 `gamma(h)=(p_head(h)+p_tail(h))/2-p_both(h)`다. 같은 lag의 실제 끝점 주변확률을 사용한다. 동일한 Bernoulli p와 독립을 가정할 때 `gamma=p(1-p)`, `(p-gamma)/p=p`이지 0이 아니다. 새 lift/의존 지표를 만들면 수식·독립 가정 아래 기준값을 먼저 확인한다. `grid_empirical`의 `binary_pair_moments`는 이 lag별 모멘트와 product-marginal 기준을 제공한다. 지역별 p가 다른 혼합에서는 이 기준조차 공간 이질성을 보정한 null test가 아니며 0 covariance가 독립성을 증명하지 않는다. 전체 분산 선은 기술적 참조로 그릴 수 있으나 가정 확인 없이 independence line이라고 이름 붙이지 않는다.

규칙 격자는 희소 binary label의 짧은 lag를 보존하는 exact grid 집계를 우선 고려한다. 비격자 global pair sampling에서는 총 pair 수가 많아도 짧은 lag의 disagreement pair가 적을 수 있으므로 지원도를 별도로 확인한다.

높은 nugget 비율 또는 장거리 semivariance가 표본 분산을 넘으며 계속 증가하면 단일 stationary model이 추세를 흡수했을 가능성을 검토한다. 이는 비정상성의 확정 검정이 아니다. 셀 간격에 가까운 finer lag, maxlag/short-range fit, 대표 predictor·방향에 대한 민감도를 비교하고 하나의 r95를 자동 block 근거로 삼지 않는다. helper의 0.75 nugget 비율·마지막 3 bin이 분산의 1.05배를 넘으며 증가하는 경고는 명시적 휴리스틱일 뿐 보편적 임계값이 아니다.

pair 부족, 희소 label, zero variance, 경계에 걸린 fit, 최대 lag까지 plateau 미도달, 방향/표본/lag별 range 불안정을 드러낸다. 표본 방식/seed 또는 lag, 대표 변수·방향을 바꿔 중요한 결론의 민감도를 확인한다. 모든 방향의 완전한 variogram을 의무화하지는 않지만 구조의 방향성을 무시한 경우 한계를 밝힌다.

lag window와 전체 domain 크기를 구분한다. r95를 제한된 plotting grid에 보간하여 끝값으로 잘라 보고하지 않는다. bin centre와 실제 pair 평균거리를 구별한다. 지역별 곡선 envelope는 지역 이질성의 기술통계이며 leave-one-region-out 재계산이 아닌데 jackknife 신뢰구간이라 하지 않는다. 단위별 상수인 수치 연령도 물리적 차이와 경계 구조를 분석할 수 있으므로 그 특성만으로 variogram 부적합이라 단정하지 않는다.

선택형 `assets/variogram.py`는 bounded pair sampling 또는 규칙 격자 exact all-pair FFT 집계, empirical curve, 일관된 r95 fit/그림을 제공한다. domain·label/변수 의미를 선택하거나 block 크기를 확정하지 않는다. sampled pair 간 독립성을 가정한 신뢰구간을 만들지 않는다.

## 다음 단계와 시각적 완료

택한 진단의 근거(variogram이면 경험점·fit·pair counts)와 거리/단위를 함께 보여 준다. 가능한 range의 범위, 추정 실패/민감도, block 후보와 지질 규모·양성 지원도/예측 거리의 관계를 `spatial-diagnostics`에 남긴다. 다른 연구의 range·block 값을 고정값으로 이식하지 않는다. range가 불안정하면 그 사실을 유지하고 여러 block 크기·거리 분포 기반/지역 holdout 등 평가 목적에 맞는 대안으로 M3를 진행한다.

block 폭은 train-test 최소거리와 다르다. 결과 점수가 좋아지는 크기를 outer label 성능으로 선택하지 않는다. 전체 label을 읽어 variogram/stratification으로 설계했다는 사실을 기록하고 모델 성능을 본 사후 최적화와 구분한다.
