# M5 — 점수, 모델 안정성, 보정·coverage를 분리한다

[방법 선택 가이드](../method-selection.md)의 M5 조건표를 읽고 관찰·후보·가정·선택/제외 이유·검증·재검토 조건을 decision record로 연결한다. 아래 계산 계약은 선택한 방법에 적용하며 모든 참조 알고리즘을 강제하지 않는다.

M4의 고정 split/모델 선택 결과와 fit 역할을 사용한다. 하나의 score 표에서 존재하지 않는 불확실성을 만들어내지 않는다. 방법이 성립하지 않으면 미실행/대안과 이유를 남긴다.

## 점수 척도와 순위 안정성

서로 다른 fit/설정/member/fold의 raw decision score를 평균·SD·IQR로 결합하기 전에 **비교 가능한 척도인지** 확인한다. 각 모델이 순위만 뜻하면 절편·양의 재척도만 바뀌어도 raw 산포가 달라지므로 이를 순위 불안정으로 해석하지 않는다. 같은 ID·support에서 순위 산포·순위 상관·예산별 선택 빈도를 선택하거나, 원점수 산포의 제한된 척도 의미를 명시한다. fold별 조건부 SD를 전역 percentile로 바꾸는 것도 비교가능성을 해결하지 않는다. fold 단차를 지질학적 불확실성 경계로 해석하지 않는다.

선택형 `assets/decision_support.py::rank_stability`는 같은 ordered ID의 model×item 점수를 명시한 모집단 내 upper-rank fraction으로 바꿔 요약한다. ID join·동률·가중 support와 점수 생성 역할은 호출자가 검증한다. 양의 재척도/행 순서 변경에 대해 순위 기반 결론이 보존되는지 저장 score로 검사할 수 있다. fold마다 모집단이 다르면 fold 내 비교로 남기며, rank 변환이 전체 영역의 동일한 탐사 정책이나 확률 척도를 만든다고 하지 않는다.

고정 설정의 bootstrap은 **선택된 설정에 조건부인** 안정성이다. 매 replicate에서 전체 선택 절차를 반복하지 않았다면 선택 불확실성까지 평가했다고 쓰지 않는다. 이미 있는 유효 prediction ensemble로 현재 질문을 답할 수 있으면 재학습하지 않는다.

저장 점수의 pairwise 순위 상관·top-k 겹침에는 선택형 `assets/decision_support.py::rank_agreement`를 검토한다. 명시한 k는 **개수 진단**이지 면적 예산이 아니다. 이 뼈대는 kth-score 동률 전체를 유지해 실제 집합이 k보다 커질 수 있으며, Spearman은 평균 동률 순위, 요약은 표준 median을 쓴다. 다른 동률 정책을 선택했다면 정의와 영향을 기록한다. 상수 점수의 상관은 undefined다. 순위/상관은 한 번, 집합은 k별 한 번 계산해 재사용한다. 중앙값 등을 직접 구현할 때는 짝수/홀수·동률을 표준 통계와 대조한다.

여러 설정의 member를 함께 쓴다면 `groups` 등에 설정을 기록하고 **설정 내 member 민감도**와 **설정 간 민감도**를 나눈다. 전체 혼합 요약을 순수 재표집 효과로 부르지 않는다. 표/상태에도 score 역할, 평가한 선택 절차와 배포 변형의 차이, 모집단, 그룹·동률·진단 cut 출처를 보존한다. 공간 집중도 bin은 CRS와 `projected_m`/지상 거리 여부를 표 열이나 metadata에 명시하며 단순히 'descriptive'라고만 적어 단위를 대신하지 않는다.

## Bootstrap 안정성

outer train 안에서 B회 재표집하여 outer test의 예측 행렬(B×test IDs)을 저장한다. 재표집 단위(행/공간 block/군집), seed, 고정/재fit된 전처리/하이퍼파라미터를 명시한다. 행 bootstrap을 공간 독립 재표집처럼 주장하지 않는다. PU 내부 T개 평균과 외부 bootstrap B회를 구분한다.

상대 변동을 선택했다면 평균·Q25/Q75와 상대 IQR=(Q75-Q25)/mean(뼈대의 `rho`)을 계산한다. 목적에 따라 SD·순위 안정성·선택 빈도 등 다른 요약도 가능하다. rho는 작은 mean에서 폭증하므로 해석할 점수 범위를 미리 정하고 mask로 남긴다. 해석할 점수 구간(예: 상위 구간)은 목적에 따라 미리 정한다. 이는 finite-sample model instability이지 자료 오차·미발견 P·모델 구조·외삽 불확실성 전체가 아니다. B/T/표본 예산이 다른 모델의 낮은 rho를 PU 고유 효과라고 단정하지 않는다.

mean 하한과 rho cut은 적용한 점수 생성 방식·분포에서 근거를 설명한다. 관측 P비율을 미보정 점수의 자연스러운 하한으로 간주하지 않는다. 작은 B의 분위수 해상도와 score–rho 관계를 확인하되, 두 진단이 통계적으로 독립이라고 주장하지 않는다.

## 보정 입력의 출처

outer train 내부의 held-out/OOF 점수로 Platt 등 보정기를 fit하고 outer test에 적용한다. **calibration pool 점수와 적용 점수의 생성 방식(단일모델/ensemble mean·전처리·학습 크기)을 일치시키거나 불일치를 명시·검증한다.** 단일모델 OOF로 보정하고 bootstrap 평균에 무설명 적용하지 않는다. 적용 모델의 in-sample train 점수로 보정하지 않는다.

보정 행만 outer train에 속한다고 충분하지 않다. **그 행의 점수를 만든 모델의 fit 자료도 해당 outer test를 제외해야 한다.** 다른 outer folds의 OOF 점수를 모으면 그 모델들이 현재 test fold를 학습에 사용했을 수 있으므로, 단순히 현재 fold의 행을 빼는 것으로 해결되지 않는다. 해당 outer train 안에서 별도로 교차예측하거나 독립 calibration split을 확보하고, 기존 모델의 OOF 재사용 가능성은 행과 score-generator 양쪽의 provenance로 판단한다.

이 경계는 보정기뿐 아니라 inclusion threshold·정책 선택에도 적용한다. fold별 train pool이 각각 적법하더라도 이를 다시 합친 global threshold에는 현재 test의 행·label이 들어갈 수 있다. held-out 성능은 해당 fold의 train-only 정책으로 평가하고, 전체 자료 기반 활용 정책은 별도로 표시한다.

inner partition을 hyperparameter 선택과 보정에 재사용했는지 기록한다. reuse·공간 의존 아래 exact coverage를 주장하지 않는다. 새로운 full-fit 활용 모델에도 별도 OOF calibration 근거가 필요하다. 알려진 P/U 기준 보정이지 실제 광상 부존 확률 보정이 아니다.

## 양성 포함집합과 검증

FNR tolerance alpha와 필요시 confidence delta·보정식·양성 수·threshold를 기록한다. 경험적 분위수/교정된 tolerance/다른 conformal 방법을 혼합하지 않는다. 예를 들어 Hoeffding correction과 split-conformal의 (n+1) 유한표본 분위수는 서로 다른 절차이며 이 helper의 additive correction으로 모두 대체할 수 없다. 양성 부족으로 correction이 alpha보다 크면 불가능/비선별적 상태를 표시한다. alpha를 몰래 바꾸거나 fallback 전체 포함을 우수 coverage로 보고하지 않는다.

보정 전후 reliability/ECE 또는 Brier, outer fold별 알려진 P coverage와 FNR, retained fraction을 함께 보고한다. 불균형이 심하면 equal-mass bin 등 타당한 binning과 bin별 n/P를 보여 준다. 전체영역 낮은 ECE만으로 매우 불균형한 자료의 우수 보정을 주장하지 않는다. 필요하면 decision region 내 진단을 병기한다. 실제 면적과 cell 비율을 구분한다.

각 fold의 test_n/P_n/retained_n/coverage는 같은 ID 정렬 평가표와 mask에서 계산해 합계를 대조한다. inner calibration 표본 수를 outer 평가 분모로 재사용하지 않는다. pooled 목표를 넘더라도 지역별 미달과 P 지지도는 최종 본문에 남긴다.

## 선택형 실행 경로

`assets/pu_workflow.py`는 위 경계를 다음처럼 구현한다. 선택한 후보의 inner out-of-fold 점수를 보정 pool로 써서 Platt(`decision_support.platt_scaling`)와 split-conformal 양성 선별(`conformal_positive_threshold`, k = floor(alpha·(n+1)))을 정하고 outer test에 적용한다. 선별 임계값은 원점수에서 정한다(단조 보정이 바꾸지 못하고 기울기가 음수여도 뒤집히지 않는다). `--screen repeated`는 pool을 group 단위로 반씩 20회 나눠 얻은 임계값의 중앙값을 쓰는 반복 교차 보정이며, 기본(`pool`)에서도 그 분포를 안정성 진단으로 남긴다. pool의 양성이 alpha에 비해 너무 적으면 그 fold에는 선별이 없고(아무것도 배제하지 않음) held-out 커버리지는 미평가로 남긴다. 분할표는 적합 전에 `spatial_contract.check_split_manifest`로 검사한다. 불확실성은 두 모델에 같은 block bootstrap(선택한 파이프라인 재적합)을 적용한 rel IQR이며, 가장 넓은 tier 안의 셀만 평가한다. 보정 pool 점수(inner 모델)와 적용 점수(outer 학습 전체 모델)의 생성 차이는 기록에 남긴다. 보정 pool과 모든 셀의 rel IQR을 저장하므로 `pu_workflow.py rezone`이 재학습 없이 alpha·선별 규칙·불확실성 기준·tier·원거리 후보 거리(`--new-gap`)를 바꿔 다시 나눈다(원래 결과는 그대로 두고 새 폴더에 이전 값과 이유를 기록). 예를 들어 양성이 적은 자료에서 tier 셀의 rel IQR 중앙값이 1 안팎이면 참조 예시값 같은 작은 기준은 tier 셀을 거의 다 빼낸다. 기준은 이 분포와 목적에서 다시 정한다.

## 시각적 완료와 연결

그림 단계에서는 [MPM 시각화 기준](../visualization.md)을 읽고, 지도는 [raster 뼈대](../../assets/grid_map.py)와 [좌표축·배치 뼈대](../../assets/figure_style.py)를 먼저 검토한다. 일반적인 디자인 가이드만으로 지도 CRS·cell 경계·score 역할 확인을 대신하지 않는다. 함수 사용은 선택이며 자료와 목적에 맞게 수정·대체할 수 있다.

선택한 불확실성 질문에 해당하는 실제 산출물(예: 전체 score·dispersion/순위 안정성 지도)을 제공한다. 보정/포함집합을 선택했을 때만 calibration curve와 fold별 coverage/retained fraction을 추가한다. 적용하지 않은 방법은 이유·대안·남은 한계를 기록하며 형식적인 rho/membership을 만들지 않는다. 명목 기준선과 실측값·분모를 구분한다. `assets/decision_support.py`는 summary/empirical screening/ranking의 선택형 함수이며 conformal 보장 이론 구현이나 전체 모델 trainer가 아니다. M6로 ID별 score와 실제로 산출한 안정성·포함집합 신호, 유효성 mask, 역할·설정을 전달한다. 선택하지 않은 신호와 계산 실패·누락을 구별해 표시한다.
