# M3 — 무엇에 일반화하는지를 평가 설계로 표현한다

[방법 선택 가이드](../method-selection.md)의 M3 조건표를 읽고 관찰·후보·가정·선택/제외 이유·검증·재검토 조건을 decision record로 연결한다. 아래 계산 계약은 선택한 방법에 적용하며 모든 참조 알고리즘을 강제하지 않는다.

사용 목적(동일 영역 미조사지/다른 지역/미래 탐사), 양성의 지지도, 공간 자기상관·자료 해상도·survey 경계를 바탕으로 split을 선택한다. 무작위 CV만으로 공간 일반화를 주장하지 않는다. 다른 연구의 block 크기 같은 참조 상수를 기본값으로 삼지 않는다.

[평가 계약](../evaluation-contracts.md)에 따라 주 평가 목적과 stress test, inner 비교 support, interior/전체 영역 지표를 구분한다. 거리 mask를 적용했다는 이유로 leakage-free라고 부르지 않는다. 전체 label로 M2/분할을 탐색했다면 뒤에 test가 된 행도 읽은 것이므로 그 이력을 유지한다.

거리와 buffer는 [M2의 거리 정의](spatial-diagnostics.md#거리의-정의와-왜곡)를 이어받는다. projected-coordinate km와 실제 ground km를 구별하고, ground separation이 목적이면 변환/왜곡 근거를 남긴다.

## 공간 진단에서 설계로

M2의 실제 공간 의존 진단 결과(예: variogram fit과 불안정성)·지질 규모·거리 분포를 읽고 분할 후보(block 크기 포함)를 비교한다. 진단 결과가 없다면 먼저 M2를 수행하거나 불가능한 이유/대안을 설명한다. 단순 가까운 P 거리와 공간 의존 범위는 다른 양이다. block 크기·origin·shape·assignment 알고리즘·seed·label-informed 여부를 남긴다.

희소 label의 기본 설계는 다음과 같다(`assets/block_design.py`).
1. **block 크기는 label range에서 정한다.** 모든 셀 쌍의 label 반변동도에서 label 분산에 처음 닿는 거리(경험적 분산 도달 거리)를 range로 쓴다. 정상성을 가정할 때만 이 거리가 상관 0을 뜻하며, 추세가 있으면 설계용 거리일 뿐 fold 독립성의 근거가 아니다. 닿지 않으면 lag 창 안에서 경고 없이 식별된 적합 r95를 쓰고, 둘 다 없으면 미식별로 멈춰 근거를 받는다. 적합 r95는 lag 창과 광역 추세에 따라 크게 달라지므로 둘째 규칙이다. block 한 변은 range 이상인 셀 배수다. feature 반변동도는 계산량 때문에 사용자가 요청할 때만 한다.
2. **block은 양성이 fold마다 가능한 균등하도록 무작위 최적화 배정한다.** 목표는 fold별 양성 수의 차이(1순위), 행 수의 차이(2순위)이며 fold마다 최소 양성 수를 둔다. block별 label 개수만 쓰고 모델 점수는 쓰지 않는다. 이는 설계 단계의 층화이며, test 성능을 보고 split을 고르는 일과 다르다.
3. **inner fold도 같은 방식으로 각 outer 학습 자료 안에서 만든다.** 양성이 부족하면 fold 수를 줄이고 그 이유를 남긴다.

`spatial_contract.py`의 `group_folds`는 label을 보지 않는 대안이다. 희소 양성에서는 fold별 양성 수가 크게 달라져 지표가 불안정할 수 있다.

튜닝·선택·보정은 평가 자료와 분리된 개발 자료 안에서만 한다. 회전식 CV라면 outer train마다 **inner spatial folds**를 실제 생성하고 outer test와 분리하며, 보정 OOF도 그 경계 안에서 생성한다. 독립 개발영역·지역 holdout 설계라면 개발 영역 안에서만 선택하고 평가 영역은 최종 평가에만 쓴다. split manifest는 개발/평가 역할·buffer 제외/유지 ID를 복원할 수 있어야 한다. 전체 영역의 평가 배정 지도(fold 또는 holdout 영역)를 제공하고 한 fold crop으로 대체하지 않는다. 공간 split이 평가하려는 동일영역 보간/먼 지역 전이와 맞는지 판단한다.

## 구현 계약
- M0–M1의 데이터 계약을 읽는다. 거리·block은 적절한 projected CRS와 단위로 계산한다. 변환 전/후 좌표와 원본 row identity를 보존한다.
- 중복 지점과 같은 표본/광상 그룹은 train/test에 나뉘지 않도록 group을 만든다. 단순 행 인덱스 split 후 좌표 중복을 놓치지 않는다.
- row_id, spatial_group과 평가 역할(예: outer_fold, 또는 개발/평가 영역)을 저장한다. 회전식 CV라면 명시된 평가 대상 행은 정확히 한 outer test에 속한다. 지역 holdout·독립 개발영역이라면 두 영역의 행 배정과 그 근거를 남긴다. 평가 단위(fold/영역)마다 train/test P/U 수와 공간 extent를 보고한다. 양성 0 또는 단일 class fold에서는 정의되지 않는 지표를 null과 이유로 표시한다. 불가능한 fold 수를 강행하지 않는다.
- feature 선택·imputation·scaling·튜닝·threshold 선택은 해당 평가 단위의 학습(개발) 자료 안에서만 수행한다. 비교할 방법끼리 같은 평가 분할을 공유한다. 조정이 필요하면 inner spatial split이나 독립 개발영역을 사용하거나 튜닝 없는 명시적 baseline을 만든다.
- 같은 영역 안의 공간 CV는 다른 지역·광상 시스템으로의 전이를 입증하지 않는다. 필요시 buffer/독립 지역 검증을 검토한다. 좌표 block만으로 geology·survey·label 생성 과정의 누출이 모두 사라지지 않는다.

## 시각과 검증
fold 지도에 양성 위치를 겹쳐 coverage와 빈 fold를 확인한다. 좌표/단위·block 크기 근거·fold별 양성 수를 같이 제공한다. 코드로 group 겹침 0, row 누락/중복, 각 fold 양성 지지도를 점검한다. test 값을 바꿔도 train 전처리 fit 통계가 바뀌지 않는 독립 검증을 준비한다. 그림만으로 누출 없음을 주장하지 않는다.

M3에서 같은 train 부분집합의 통계를 재계산하는 것은 분할 사용 예시일 뿐, 아직 구현하지 않은 학습 파이프라인의 누출 검증이 아니다. M4에서 실제 입력→fit entrypoint를 교란 재실행해 확인한다.

## 재사용
이 모듈은 classifier 없이 실행 가능하다. 출력 split manifest를 다른 모델링 스킬이 받아 동일한 outer 평가를 할 수 있어야 한다.

## 선택형 뼈대와 추가 근거
`assets/block_design.py`는 label range → block 크기 → 양성 균등 nested 배정 → 검사·그림을 한 번에 만든다. `assets/spatial_contract.py`는 그 부품(`block_size_for_range`, `balanced_block_folds`, `nested_block_folds`, `check_nested`)과 projected grid group/fold 배정, row/group 누출 checker를 제공한다. 필요하면 workspace로 복사·수정한다. 알고리즘이나 block 크기의 정당성을 대신하지 않는다. 경험적 공간 상관 범위·survey 규모 등 근거가 있으면 사용하고, 없으면 탐색적 선택이라고 기록한다. 두 개 이상 block 규모의 민감도는 데이터가 뒷받침하는 단계에서 비교하되 test 성능이 좋은 규모를 최종 보고용으로 골라내지 않는다. 양성 지지도가 약하면 fold 수를 줄이거나 평가 범위를 축소한다.

## 경계에서 남는 공간 의존을 실측한다
block 크기가 최근접 양성 거리보다 크다는 사실은 가까운 쌍이 같은 fold에 들어간다는 보장이 아니다. block 경계를 사이에 둔 지점은 여전히 인접할 수 있다. 양성 최근접 거리(중복 위치 제외)는 sampling/군집의 기술통계이며 variogram의 상관 범위를 대신하지 않는다. label 분포를 보고 block 크기를 정했다면 전체 설계를 'label 미사용'이라고 부르지 말고, **정한 block에 대한 fold 배정만 label-blind**인지 구별한다.

fold별 test→train 최근접 거리(최소·하위 분위 등)를 실제 계산해 residual adjacency를 보고한다. 각 test 위치에서 가장 가까운 train까지의 거리 분포를 요약한다. 반대 방향인 train→test의 평균·중앙값은 일반적으로 다르므로 이름과 계산 방향을 맞춘다. buffer가 있으면 실제 fit에 남은 train에 대한 거리도 구분한다. 필요하면 `assets/spatial_contract.py`의 `nearest_split_distances`를 쓴다. 사용 목적이 인접 학습지점으로부터 일정 거리 떨어진 예측이면 buffer/embargo를 적용하거나 그 목적을 현재 split이 충족하지 못한다고 명시한다. buffer로 제외된 train row와 남은 P/U 수를 fold별 저장한다. 선택형 buffered_split은 원본 행 순서의 test/유지 train/제외 index와 test→유지 train 거리를 반환한다. 이 index에 안정적 row ID를 연결해 학습 단계가 실제 fit한 ID 집합과 대조한다. buffer는 셀 중심 거리인지 경계 거리인지 명시한다.

평가 단위가 point/site인지 cell/area인지 먼저 정한다. point 상위 10%는 표본/위치 비율이지 면적 10%가 아니다. area/capture 지표를 설계하는 M3 단계부터 실제 cell support와 면적 분모가 있어야 한다. 중복을 유지하면 row-weighted와 site-weighted 평가 의미를 구별한다.

배정 결과가 연속 띠인지 교차 block인지 실제 지도로 확인하고 의도한 일반화 목적과의 관계를 설명한다. 고유 group만 helper에 넣으면 행 수 균형과 다른 결과가 날 수 있다. label 개수로 최소 지지도를 확보하는 사전 stratification과 test 성능을 보고 split을 고르는 일을 구별한다. 전자는 설계에 공개할 수 있고 후자는 평가 편향을 만든다.
