# M4 — 모델의 계산과 과학적 의미를 함께 검증한다

[방법 선택 가이드](../method-selection.md)의 M4 조건표를 읽고 관찰·후보·가정·선택/제외 이유·검증·재검토 조건을 decision record로 연결한다. 아래 계산 계약은 선택한 방법에 적용하며 모든 참조 알고리즘을 강제하지 않는다.

데이터 계약과 M3의 split manifest를 입력으로 받는다. 특정 라이브러리·XGBoost·PU 알고리즘을 강제하지 않는다. 최소 baseline으로 데이터와 평가 경로를 먼저 확인한다.

선택기·순위 지표를 구현하기 전 [평가 계약](../evaluation-contracts.md)을 읽는다. 특히 공통 inner validation support, fold-local selected-procedure OOF, 배포 절차와의 차이, 면적 분모·경계 동률·pAUC 정의를 확인한다. 직접 구현하거나 선택형 `assets/evaluation_view.py`를 조정해도 이 계약은 같다. 이전 M1/M3 계획과 실제 feature/변환/PU·학습 구성을 대조하여 타당한 변경 이유 또는 남은 미구현 항목을 state에 반영한다.

## 모델 선택의 의미
- P vs U classifier는 유용한 **관측 label 구분 baseline**이나 순위 점수다. U를 음성 class로 수치 인코딩했다고 확인된 부재가 되지 않는다. 예측은 일반적으로 실제 광상 존재 확률이 아니다. P/U 지표와 진짜 양성/음성 지표의 차이는 label selection·class prior에 의존하므로, 근거 없이 편향의 방향을 항상 과대/과소평가라고 단정하지 않는다.
- PU 방법을 쓰면 class prior/label selection 가정, bagging/negative sampling 방식과 한계를 기록한다. 단순 classifier를 PU learning이라고 부르지 않는다. 반복형 PU라면 label·weight·표본 중 무엇이 다음 fit에 반영되는지 실제 코드와 저장 이력으로 확인한다. 같은 seed·입력·target을 반복 fit하는 것은 EM이 아니다. 반복 수 변경에 대한 동일 결과는 진단 신호이지 단독 실패 판정은 아니다(정상 수렴·동일 예측도 가능하다).
- 작은 양성 수에 맞춰 복잡도·튜닝 범위를 줄인다. 전체 분석이면 [M5](uncertainty-calibration.md)에서 안정성/보정의 필요성과 성립 여부를 판단한다. baseline만 실행해 전체 워크플로우를 완료했다고 하지 않는다.
- baseline은 비교 출발점이지 달성 가능한 성능의 수학적 하한이 아니다. 신뢰구간을 계산하지 않았다면 '미계산'으로 밝히고 그 폭·coverage를 실측한 것처럼 쓰지 않는다. 작은 양성 지지도의 불안정성과 지표가 무의미하다는 단정은 구별한다. 검증한 경로·교란만 보고하고 모든 누출을 배제했다고 확대하지 않는다.

선택형 `assets/pu_sampling.py`는 bagging PU의 train-local P 보존·U 부분표집(`bagging_indices`, 복원 추출 선택 가능)과 앙상블(`BaggingPU`)을 제공하며 특정 PU 방법을 강제하지 않는다. `assets/pu_workflow.py`는 희소 P/U의 검증된 기본 경로다. `block_design.py`의 분할에서 같은 학습기(XGBoost)의 binary 기준선과 bagging PU를 같은 outer·inner fold로 튜닝(inner 평균 AP)·평가하고, fold별 inner·outer AP와 ROC AUC를 남긴다. 모든 적합은 해당 outer test 행을 보지 않는다(`tests/test_pu_workflow.py`). estimator·표본 크기·선택·집계·저장은 에이전트가 구현한다. 반환 index는 전달한 train 배열의 지역 index이며 내부 T는 M5의 공간 bootstrap B가 아니다. 원 논문과의 차이 및 full-fit/OOB 활용 선택지는 뼈대 docstring을 확인한다.

Spy/EM·label-propensity 보정을 선택했다면 숨긴 **기록된 P의 비율**과 실제 양성인 관측 단위가 카탈로그에 기록될 확률을 구별한다. 원래 기록확률이 알려지지 않았는데 P 일부를 가렸다고 그 확률이 알려지는 것은 아니다. spy 오분류율도 U의 양성 비율 추정치가 아니다. 관측-label 점수와 잠재 true-label 점수는 서로 다른 조건부 확률이므로 E/M 단계의 target과 posterior 식을 원 방법·가정에 맞춰 확인한다. 추정할 수 없는 양을 임의로 대입한 반복 fit보다 가정과 한계를 설명할 수 있는 대안이 적절하다.

## 실행 계약
1. 고정 row/split/seed에서 fit과 test 예측을 분리한다. buffer가 있으면 M3에 보존한 유지 train ID 집합과 실제 fit 행을 대조한다. 각 fold의 전처리와 모델을 train에서만 fit한다. Pipeline이나 명시적인 fit/transform 분리로 구현한다. 전 데이터 feature imputation/selection 후 CV하지 않는다.
2. held-out 표에 row_id, fold, 원본 label, score를 남긴다. 어떤 행의 점수도 그 행의 label로 fit한 모델의 출력이 아니어야 한다. fold별 sample/P 수, PR-AUC(정의: AP인지 trapezoidal인지), ROC-AUC 등 대상에 맞는 지표를 계산한다.
3. 독립 코드로 저장한 label/score에서 지표를 재계산한다. fold 평균과 pooled OOF 지표를 구별한다. PR의 무정보 기준선은 관측 양성 비율이다. 이를 유한 표본에서 무작위 순위를 매긴 AP의 정확한 기대값과 동일시하지 않는다. sampling으로 비율이 바뀌었으면 해석에 반영한다.
4. OOF 평가가 끝난 뒤 전체 자료로 fit한 배포용 모델은 별도로 저장한다. 그 모델의 in-sample score를 held-out 성능이라고 보고하지 않는다. feature schema, missing 처리, CRS, 라이브러리 버전, seed와 hash를 저장한다.
5. 새 데이터는 feature/CRS/단위·nodata·분포 이동을 검사한다. 평가 영역 밖 extrapolation을 표시한다. 코드가 계산했다는 이유만으로 신뢰 가능하다고 하지 않는다.
6. 학습과 저장 결과의 시각화·보고 재생성을 분리한다. 학습 코드를 import하거나 그림만 수정했을 때 fit이 자동 실행되지 않게 실행 진입점을 둔다. 예: 그림·캡션은 저장된 OOF 표와 지표 JSON만 읽는 별도 함수/스크립트로 둔다. 후속 모듈은 저장 OOF/지표/모델을 읽어 학습 없이 이어갈 수 있어야 한다.

pooled OOF 순위/포착률은 서로 다른 fold 모델 점수의 비교 가능성을 가정한다. 특히 fold마다 가중·알고리즘 후보가 다르게 선택되면 raw 점수 척도가 섞일 수 있다. fold별·평균 지표를 함께 읽고 절편/label 비율·선택 차이를 밝히며, 비교가능성 문제만으로 편향 방향·크기를 단정하지 않는다.

각 완료 fold의 stable ID/선택 config·예측·핵심 지표와 재개 상태를 먼저 저장한다. 배포 fit이 끝나면 모델·전처리/schema를 함께 직렬화하고 저장 모델로 predict를 확인한다. 전 fold·그림·보고가 모두 끝날 때까지 저장을 미루지 않는다. 학습은 명시적 함수와 `if __name__ == '__main__':` 등의 진입점으로 분리하고 workspace 경로를 인자로 받아 이동/재개 시 이전 작업 폴더에 쓰지 않는다. 기존 비동기 프로세스를 관찰할 때 긴 고정 sleep 대신 짧은 상한의 wait/status로 종료를 확인한다. 저장 산출물·미완료 항목을 요약해 시간 내 partial 반환할 수 있어야 한다.

M3의 cell 평가 계약과 행 단위 manifest를 혼동하지 않는다. 반복 기록은 같은 test fold에 묶는 것만으로 충분하지 않다. cell/면적 성능에는 고유 cell당 하나의 label·예측과 명시적 결합 정책을 사용한다. row-weighted 학습/성능을 별도로 쓰면 그 의미를 밝힌다. 양성이 한 fold에 집중되면 pooled 지표가 어느 fold의 지지도를 크게 반영하는지 보고한다.

성능 그림은 fold 변동과 양성 지지도를 보여 준다. 알고리즘 차이보다 label·sampling·spatial split의 해석을 먼저 설명한다. 불확실성은 모델 점수와 다른 산출물이며 cross-conformal의 명목 coverage는 공간 의존 하 보장이 아니다.

선택형 `assets/evaluation_view.py`는 모델·열 이름과 독립적으로 OOF PR, fold별 AP/P/U 지지도, 동률을 함께 묶은 포착률 그림을 만든다. 데이터를 읽거나 학습하지 않는다. 행/고유 site/cell 단위를 먼저 결정하고 해당 label·score·fold를 전달한다. 불균일 cell 면적은 검증한 support weight와 분모 이름을 전달한다. point 개수는 면적이 아니다. 양성 없는 fold의 지표를 0으로 대체하지 않는다. 이 뼈대 사용은 필수가 아니며 목적에 맞는 대체 그림을 허용한다.

AP 수치와 PR 그림의 계단 정의를 일치시킨다. sklearn `precision_recall_curve`의 내림차순 recall을 그대로 그리면 `step(..., where='post')`가 AP 정의와 맞는다. 여러 fold 곡선의 색/선은 실제 fold ID 범례와 연결한다. 서로 다른 fold의 관측 P 비율을 전체 P 비율 기준선 하나로 대체해 fold별 우열을 해석하지 않는다.

고정 split/seed로 재실행 가능한 fit→OOF entrypoint를 제공한다. 외부 검증에서 한 outer test의 predictor/label만 바꾸어 해당 fold의 fitted imputer/scaler/선택 feature/모델 학습 상태가 바뀌지 않는지 확인할 수 있게 한다. 이 검사는 분할을 다시 생성하지 않고 고정하며, 다른 fold의 훈련 자료까지 불변이라고 요구하지 않는다.

test를 제외한 동일 train을 다시 fit하는 것만으로 전체 파이프라인 누출 검증을 했다고 하지 않는다. 원본 입력의 복사본을 교란한 뒤 실제 entrypoint를 재실행하고 fit 상태를 대조한다. 교란이 실제 경로에 도달했는지도 입력 hash·해당 test 예측 변화 또는 다른 fold fit 변화로 확인한다.

기존 M3 계약도 과학적으로 점검한다. point 자료의 top-k는 관측 또는 고유 위치 기준으로 이름을 붙이고, cell support 없는 면적 비율은 사용하지 않는다. 분할이 공간 독립성을 보장한다는 설명이나 label 생성 가정이 틀렸으면 수정 이유를 기록한다.

## 비교와 계산 예산

전체 요청에서는 label 계약에 맞는 baseline과 타당한 모델 대안을 (P/U 자료이면 PU 후보의 가정/적합성도 검토하여) 같은 평가 분할(예: 고정 outer folds 또는 같은 holdout 영역)·전처리 정책·주 지표로 비교한다. 튜닝은 평가 자료와 분리된 개발 자료(inner 공간 CV 또는 독립 개발영역)에서 하고 평가 자료는 최종 평가에만 쓴다. 지도학습 baseline의 튜닝 결과를 고정하고 PU 표집 매개변수(bag 수·U 표본 크기)만 탐색하는 방식은 선택 가능한 통제 설계다. 모델 우열·PU 효과를 test 성능만으로 반복 최적화하지 않는다. 복잡한 방법이 적합하지 않으면 그 이유와 대체 baseline을 명시한다.

비교한 것은 선택된 **전체 파이프라인**이다. 기본 learner가 같아도 class weighting·표집·멤버 수·seed가 함께 달라지면 각 요소의 기여를 분리해 추정한 것이 아니다. 별도 통제 실험 없이 성능 차이를 PU 표집의 인과 효과나 실측 분산 감소로 설명하지 않는다. 후보 간 inner 점수 차이는 선택 근거이며 독립된 ablation 결과가 아니다.

계산 계획에는 후보 수·튜닝 반복(예: inner folds)·PU 반복 T·평가 분할 수, bootstrap B 및 calibration 재학습 비용, thread/seed와 실제 수행 수를 남긴다. pilot은 trial/T/B 등을 줄일 수 있지만 축소 항목을 공개한다. 모델 fit 예산과 예측 domain은 별개다. 전체 요청에서 평가 대상 ID의 held-out 예측(회전식 CV라면 모든 적격 ID의 OOF)을 보존하고, 일부 fold/지역만 했으면 partial로 표시한다. 별도 최종 full-fit model/ensemble은 활용용이며 그 성능을 OOF와 혼합하지 않는다.

선형 계열만 비교했다면 EDA에서 관찰한 관계 형태와 실제 feature/변환을 대조한다. robust scaling은 크기 조정이지 비선형 관계를 표현하는 변환이 아니다. 관찰 근거가 있는 비선형/상호작용을 표현하거나, 검증하지 못한 모델 능력과 재검토 조건을 한계로 남긴다. 이것은 특정 tree/boosting을 의무로 실행하라는 뜻이 아니며, 다른 자료에서 본 관계를 현재 자료에 옮길 근거도 아니다.
