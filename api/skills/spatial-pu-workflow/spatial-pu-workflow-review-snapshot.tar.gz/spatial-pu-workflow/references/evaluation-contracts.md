# 비교·선택·면적 지표의 계약 (M3–M4)

공간 평가를 설계하거나 순위 지표/모델 선택기를 구현할 때 읽는다. 계산법을 고정하는 문서가 아니라 **무엇을 비교하고 평가했는지**를 일치시키는 기준이다.

## 평가 목적과 지지도

- 동일 영역 미관측 지점의 순위와 먼 지역 전이는 다르다. 주 평가 목적과 지역 전이 등의 stress test를 구분하고, 실제 test→train 거리·공간 support가 활용 상황에 맞는지 설명한다. 큰 연속 지역 holdout을 항상 틀린 설계로 보지는 않지만 목표와의 차이를 숨기지 않는다.
- inner split도 선택하려는 활용 상황과 맞춰 설계한다. 인접 검증과 먼 지역 outer 평가가 다르면 그 한계를 밝힌다. 같은 inner 분할을 썼다는 사실만으로 후보별 근접 정보 의존/누출 영향이 같아지지 않는다.
- inner–outer 차이는 튜닝 선택·거리·지역 이동·P 지지도·분모 차이가 함께 반영된 진단이다. 양수든 음수든 누출의 유무/크기만으로 해석하지 않는다. 실제 block 크기를 바꾸지 않았다면 block-size sensitivity라고 부르지 않는다.
- buffer/interior mask는 명시한 거리 조건을 만족시킨다. 그것만으로 공간 독립성이나 모든 누출 제거를 보장하지 않는다. interior와 전체 영역의 P/지역 구성이 달라지는지 함께 보고한다. P 군집이 있으면 iid 이항 SE를 유효 신뢰구간처럼 쓰지 말고 공간 단위 재표집 또는 기술적 fold 변동·미계산 한계를 선택한다.

## 어떤 선택 절차를 평가했는가

아래는 회전식(nested) 공간 CV를 택했을 때의 표현이다. 독립 개발영역·지역 holdout을 택했다면 같은 원칙(후보별 같은 검증 support·지표, 평가 자료를 선택에 쓰지 않음, 평가한 절차와 배포 절차의 구분)을 그 개발 영역 안에서 적용한다.

각 outer train 안에서 후보별 **같은 inner validation IDs·support·지표·집계법**을 비교한다. 계산량이 부족하면 모든 비교 후보에 공통으로 쓸 작은 inner subset을 사전에 정하거나 튜닝 규모를 줄인다. 다른 support로 얻은 점수는 별도 probe이며 그대로 하나의 argmax에 넣지 않는다. 후보마다 grid 크기/학습 비용이 다른 것은 허용하되 탐색 예산을 공개한다. inner의 max-of-grid 점수는 선택에 사용된 낙관적 값이지 독립 성능이 아니다.

family까지 선택한다면 각 outer fold에서 **그 fold의 inner 결과로 선택한 전체 pipeline**의 outer 예측을 `selected_procedure`로 연결한다. 별도 per-family OOF 비교표와 역할을 구별한다. 여러 outer-train의 inner 점수를 합쳐 나중에 고른 한 family의 OOF는 모든 test label이 그 통합 선택으로부터 독립인 것처럼 설명할 수 없다. row ID·fold·선택 family/config·전처리·선택 근거를 저장한다.

최종 full-fit에서는 같은 선택 규칙·후보 공간으로 전체 자료 안에서 튜닝하므로 **최종 hyperparameter 값이 fold마다 다른 것은 정상**일 수 있다. 다만 inner folds 수/기하·후보·전처리·선택 규칙을 바꾸면 평가한 절차에서 벗어난 차이를 기록한다. 큰 차이는 미평가 deployment variant로 분리한다. 근거 없는 “점수 차이가 잡음” 판정이나 outer 설정으로 강제 회귀는 하지 않는다. 근접한 점수의 안정성은 사전 단순성 tie policy/inner 반복·민감도 등 적용 가능한 근거로 판단한다.

M1 계획과 실제 fit의 변환·feature·missing 처리·PU 선택을 대조한다. 원척도 tree처럼 타당한 변경은 이유를 기록하고 계획/state를 갱신한다. P/U baseline만 선택할 수 있으나 PU 후보의 가정·장단점·제외/보류 이유를 남긴다. class prior가 미상이라고 prior 불요 순위 후보까지 자동 제외하지 않는다. 비용으로 못 한 비교는 과학적 부적합이 아니라 `partial/deferred`다.

배포 단계에서는 실제 선택 규칙을 평가한 규칙과 대조하고 `evaluated_rule` 또는 `unevaluated_variant` 등 동등한 상태를 명시한다. 예를 들어 각 outer-train에서 inner argmax를 평가했는데, full-fit 설정을 outer-context 선택의 다수결로 정했다면 별도 선택 변형이다. 전체 자료로 fit하는 것 자체는 누출이 아니지만 기존 selected-procedure OOF가 그 투표 규칙의 검증이 되지는 않는다. 재계산하지 않을 때는 저장 결과를 유지하고 이 한계를 보고한다.

서로 다른 fold/family의 원점수를 합친 pooled AP/ROC도 공통 점수 척도를 전제한다. 비교가능성이 미확인되면 fold별 지표·지지도와 요약을 우선하고 pooled 값은 별도 기술값/가정으로 남긴다. 작은 점수차나 fold SD만으로 통계적 동등·잡음이라고 판정하지 않는다. paired inner 근거·반복 또는 사전에 정한 간결성 규칙을 사용할 수 있지만 outer 결과를 본 뒤 tie 규칙을 만들지 않는다.

## 순위 지표의 단위·동률·정의

- 구현 전에 점수 역할(outer OOF/full-fit), ranking 모집단, 양성 포착 분모, 예산 분모, 동률 정책을 정한다. q는 명시한 정책/평가 해상도이지 다른 연구에서 가져온 숨은 상수가 아니다.
- 같은 크기의 **투영 좌표 셀**이 같은 **지상 면적**을 뜻하지 않는다. 특히 Mercator에서 행 수 비율을 ground-area 비율로 쓰지 않는다. 실제 cell footprint를 적절한 equal-area CRS 또는 geodesic 방식으로 계산·검증해 가중한다. 선택형 `assets/grid_map.py::transformed_cell_areas`는 검증한 equal-area 변환에 대한 모서리 다각형 근사다. 면적 근거가 없으면 cell/site fraction으로 정확히 이름 붙인다.
- 경계 동률의 행/P/support 수를 센다. threshold group 전체를 유지·제외하거나 정당한 보조 기준/명시적 무작위 정책과 민감도를 사용한다. 좌표 순 CSV의 stable sort를 과학적 동률 정책으로 숨기지 않는다. 동률 때문에 달성 불가능한 예산과 실제 선택량을 표시한다.
- 선택형 `assets/evaluation_view.py::capture_curve/capture_at`은 **동률 그룹을 자르지 않는** threshold 포착률이다. `select_candidates`는 적격 후보만 고르되 전체 support를 예산 분모로 둘 수 있다. 다른 정책도 허용하며 정의를 밝힌다.
- pAUC는 FPR 상한과 raw integral/standardized 정의를 정한다. `partial_roc_auc(..., max_fpr=...)`는 동률을 합친 ROC segment를 적분해 두 값을 구분한다. P/U에서 FPR은 U를 reference class로 한 수치이지 확인된 무광 지점의 오탐률이 아니다. 동률 내부를 개별 행 순으로 연결한 ROC는 쓰지 않는다.
- fold별 percentile 변환 후 pooled rank는 fold 내 상대순위 정책이다. raw-score pooled 순위와 다르며 서로 다른 fold 점수를 확률처럼 비교 가능하게 만든 것이 아니다. fold별 값/지지도와 함께 보고한다.

저장 label/score/support/정책으로 독립 재계산한다. 동률 행 순서를 섞어 metric이 변하는지 확인하고 변화가 정책상 의도된 경우 그 변동을 보고한다. 정의 불가 지표는 null과 이유로 남긴다. 관측 P/U enrichment의 편향을 무조건 참 광상 enrichment의 하한이라고 하지 않는다.
