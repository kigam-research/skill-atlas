---
name: spatial-pu-workflow
description: 희소 양성 label(P/U·P/N)의 2D 격자 공간 예측을 자료와 목적에 맞게 설계·구현·검증한다. 주 적용은 광상 부존 가능성 분석(Mineral Prospectivity Mapping, MPM)과 탐사 대상 선정이며, 기록된 발생 셀과 미표지 셀로 이루어진 다른 희소 사건 지도에도 같은 구조로 쓸 수 있다. 자료 계약·EDA, label range 기반 공간 block과 양성을 균등하게 나눈 nested 평가, PU를 포함한 모델 비교, 보정·양성 선별·불확실성, 우선순위 구역과 후보 해석을 단계별로 다룬다. 특정 연구 설정의 재현 도구가 아니며 자원량·매장량 인증이나 확률 보장에는 사용하지 않는다.
---

# Spatial PU workflow — 희소 label 공간 예측

사용자의 도메인 모델(MPM이면 광상 시스템)·자료·질문에 맞게 **분석을 설계·실행·검증한다.** 희소 양성 label의 전체 분석은 아래 [기본 분석 경로](#기본-분석-경로)의 검증된 명령으로 시작하고, 자료·목적에 맞지 않는 부분만 고치거나 코드를 새로 쓴다. 다른 연구의 설정·코드는 실행할 프로그램이나 복제할 정답이 아니다. 대상(광종 등)·자료·알고리즘·시각화에 맞게 구현을 바꿀 수 있다.

## 기본 분석 경로

```
S=<이 스킬 폴더>/assets
uv run python $S/stage_evidence.py template <입력 표> --metadata <자료 설명> > evidence-spec.json   # 1. 초안을 확인·수정
uv run python $S/stage_evidence.py render evidence-spec.json                                         # 2. M0–M2 그림
uv run python $S/block_design.py evidence-spec.json --outer <K> --inner <J> --seed <N>               # 3. label range block, 양성 균등 nested 분할
uv run python $S/pu_workflow.py evidence-spec.json --split <out>/split/split_manifest.csv \
    --tiers <상위 비율들> --alpha <양성 선별 허용 누락률> --rel-iqr-cut <불확실성 기준>                # 4. 평가·보정·불확실성·구역·후보(N·R·F)
uv run python $S/stage_evidence.py render <out>/models/render_spec.json                              # 5. M3–M7 그림
uv run python $S/stage_evidence.py check <그림 폴더> --report <보고서>                                # 7. 검사와 contact sheet
```

전체 분석 요청의 기본 경로다. 분석 코드를 쓰기 전에 시작하고, 표를 저장할 때마다 이어 간다. 명령은 `<이 스킬 폴더>/assets/`에 있다. `stage_evidence.py`는 저장 표로 단계 증거 그림을 만들 뿐 학습하거나 방법을 고르지 않는다. `block_design.py`는 평가 분할을, `pu_workflow.py`는 모델 평가·보정·불확실성·구역·후보를 계산한다.

기본 경로와 다른 분할·모델·보정을 쓰는 단계는 그 이유를 상태와 보고서에 적는다. 그 단계도 해당하는 산출물을 남긴다: 행 단위 held-out 점수와 fold, fold별 P, 보정·선별의 held-out 커버리지, 셀별 불확실성과 구역 판단에서의 쓰임, 구역의 held-out 포착, 후보의 재확인·새 후보 구분. 목적상 적용하지 않는 항목(예: 구역 없이 연속 지도와 후보 표만 제공)은 그 이유와 대신한 검증을 적는다.

1. 입력 표를 확인하면 `uv run python <이 스킬 폴더>/assets/stage_evidence.py template <입력 표> --metadata <metadata> > <작업 폴더>/evidence-spec.json`으로 spec 초안을 만든다. id·좌표·label·단위·간격·CRS와 predictor 목록(label 파생·조사 대리 열 제외)을 확인해 고친다. 광상 모델(M0)이 방향을 예상하는 predictor에는 `expect`(high/low)와 `basis`(근거)를 적는다. M1 P/U 비교와 M7 후보 표가 이 예상과 대조된다. metadata에 EPSG 코드가 없으면 초안은 WKT 이름을 적는다. 자료 설명으로도 CRS를 정할 수 없으면 좌표 단위 가정을 담은 이름(예: `local projected metres (CRS not given)`)을 적고, 확인하지 못한 점을 보고서에 밝힌 채 진행한다.
2. `uv run python <이 스킬 폴더>/assets/stage_evidence.py render <spec>`으로 M0–M2 그림(셀 지도, P/U 분포, 상관, 거리별 의존과 쌍 수)과 값 점검 표를 먼저 만든다. 출력의 `note`(음수·sentinel 등)는 보고서에서 해석한다.
3. 평가 분할은 `uv run python <이 스킬 폴더>/assets/block_design.py <spec> --outer <K> --inner <J> --seed <N>`으로 만든다. 모든 셀 쌍의 label 반변동도에서 label range(label 분산에 처음 닿는 거리, 없으면 쓸 수 있는 적합 r95)를 정하고, range 이상인 셀 배수로 block을 나눈다. 그다음 양성이 fold마다 가능한 균등하도록 block을 무작위 최적화 배정한다(outer와 각 outer 학습 자료 안의 inner 모두, label 개수만 사용). `split/split_manifest.csv`의 `outer_fold`·`inner_fold_<k>`를 학습·튜닝에 그대로 쓰고, range 규칙·block 크기·fold별 P를 보고한다. range가 식별되지 않으면 명령이 멈춘다: 사용자에게 알리고 근거와 함께 `--block-size`를 준다. outer·inner fold 수(K, J)는 P 수·block 수와 목적에서 정해 이유를 적는다(fold마다 held-out P와 inner 검증 P가 충분히 남는지, block 수가 fold 수보다 넉넉한지). 명령의 기본값(5, 4)은 이 판단을 대신하지 않는다. feature 반변동도는 사용자가 요청할 때만 계산한다.
4. 모델 평가·보정·불확실성·구역·후보는 `uv run python <이 스킬 폴더>/assets/pu_workflow.py <spec> --split <split_manifest.csv> --tiers <상위 비율들> --alpha <양성 선별 허용 누락률> --rel-iqr-cut <불확실성 기준>`으로 계산한다.
   - 같은 fold에서 binary 기준선과 bagging PU를 nested로 튜닝·평가한다. inner out-of-fold 점수로 보정(Platt)과 양성 선별(split-conformal)을 정한다. block bootstrap으로 불확실성(rel IQR)을 구하고, 선별 → 불확실성 → tier 순서로 구역을 나눈다.
   - 후보는 배포 지도 tier 셀의 연결 조각이다. 새 후보(N)와 기록 P 재확인(R)으로 나눈다.
   - 원거리 후보(F)는 기록 P에서 격자 `--new-gap`칸(Chebyshev, 기본 2 = P 셀과 그 8방향 이웃 밖) 이상 떨어진 셀끼리 순위를 매긴 조각이다. N과 구분해 보고한다. 조각마다 양성 선별·불확실성 기준을 통과했는지(`status`)를 함께 적는다. 통과하지 않은 조각은 순위 진단이지 추천 대상이 아니다.
   - 같은 규칙을 held-out fold에 적용한 결과(`far_target_capture.csv`: 학습 P에서 떨어진 test 양성의 포착과 셀 비율)도 적는다. 이 결과는 가까운 학습 P 없이도 순위가 양성을 찾는지를 보여 줄 뿐, F의 기대 발견률이 아니다. 지도의 원거리 셀은 full-fit 학습에 쓴 U이고, held-out fold는 설계상 P가 있는 block을 품으며, 선별 임계값도 다르다. 선별이 남긴 원거리 셀의 비율이 지도와 held-out에서 크게 다르면 명령이 알린다.
   - tier에 새 후보가 없다는 경고가 나오면 그 사실과 F를 보고하고, 다른 새 대상 규칙을 쓰면 목적에서 정한 이유를 적는다. 격자 칸 기준을 바꿀 때는 `rezone --new-gap`을 쓴다. 칸 수는 지상 거리가 아니다(대각 한 칸이 더 길다). 목적이 km 반경을 요구하면 알맞은 좌표계의 거리로 규칙을 따로 만든다.
   - `distance_capture.csv`는 held-out 양성의 tier 포착을 학습 P와의 거리 구간별로 나눈다. 모델이 알려진 P 옆만 찾는지, 떨어진 곳도 찾는지 보고한다.
   - tier, alpha, 불확실성 기준은 명령에 기본값이 없다. 구역을 보정 점수 기준(`--zone-mode prob`)으로 나누면 원거리 후보와 구역 규칙 비교에 쓸 순위 비율도 `--rank-fractions`로 준다. 값마다 목적·예산·자료에서 정한 이유를 보고서에 적는다(`check --report`가 쓴 값을 알린다). tier에서 불확실성 기준으로 빠진 셀 수도 보고한다.
   - 결과(예: tier 셀의 rel IQR 분포, 후보 수)를 보고 값을 바꿀 때는 다시 학습하지 않는다. `uv run python <이 스킬 폴더>/assets/pu_workflow.py rezone <models 폴더> --tiers ... --alpha ... --rel-iqr-cut ... --reason "<바꾼 이유>"`로 새 폴더에 다시 나누고 그 `render_spec.json`으로 다시 렌더한다(그림은 새 폴더의 `figures`에 그려진다. 적지 않은 구역 방식·선별 규칙은 원 실행을 따른다). held-out 포착을 보고 바꿨다면 그 결과는 개발 증거라고 적는다.
   - 출력 `render_spec.json`으로 `render`한다. 자료·목적에 맞지 않으면 이 명령을 고쳐 쓰거나 다른 모델을 쓰되 같은 fold·보정 경계를 지킨다.
5. 평가 배정(`split_manifest.csv`의 `outer_fold`와 `block`), held-out 예측, 점수(역할 포함), 안정성, 구역, 구역 규칙 비교(`zone_rules`: 선택형 예시. held-out 점수로 목적·예산에서 정한 상위 비율들의 포착·면적 비교, `score_role` 명시), 후보 표를 저장할 때마다 spec에 더하고 다시 `render`한다(`pu_workflow.py`의 `render_spec.json`은 이 항목을 채워 둔다). 긴 형식 표는 `where`로 행을 고른다. 후보는 셀이 모인 국소 후보(연결된 조각 등)로 넘기며, predictor에 `role`(지질·지구물리·지화학·가용성 등)을 적으면 후보 증거 표·그림(`m7_candidate_*`)이 역할별로 나뉜다.
6. `not drawn`으로 남은 단계는 직접 그리거나 보고서에 이유를 적는다. 최종 구역·점수·후보 지도는 결과 표를 spec에 넣어 `render`로 그린다. 자료에 맞는 다른 그림을 직접 그릴 때는 `figure_style.save_figure(fig, stem, maps=[...], dependence=..., record={...})`로 저장해 같은 검사를 받는다.
   - 지도는 분석 격자의 CRS 그대로 축에 나란한 직사각형 raster(정사각형 셀)로 그린다. 표시를 위해 재투영해 휘거나 기운 모양으로 그리지 않는다(`save_figure`가 경고한다).
   - 셀 raster는 `grid_map.raster_map`으로 그린다(좌표로 셀을 놓는다). 다른 방식(`imshow` 등)으로 그린 raster는 `save_figure(..., cells=(x, y, 그린 값))`로 저장 표와 셀 위치를 대조해야 한다. 대조하지 않으면 위치 미검증 경고가 남는다.
7. 반환 전 `uv run python <이 스킬 폴더>/assets/stage_evidence.py check <그림 폴더> --report <보고서>`를 실행한다. 보고서에 링크·언급된 그림은 어느 폴더에 있든 함께 검사한다. check가 만든 contact sheet(`<첫 폴더>/_contact_sheets/`)를 열어 모든 그림을 훑고, 이상해 보이는 그림과 결론이 기대는 그림은 원본을 연다. 보고서·상태에는 실제로 한 확인만 적는다(예: "contact sheet 2장과 구역·후보 지도 원본 3장을 열어 확인"). 열지 않은 그림을 확인했다고 쓰지 않는다. `report reminder`는 단어 일치로 찾은 알림이다. 해당하는 것(값 해석, 후보 논의, 좌표 단위)은 보고서에서 다루되, 이름을 적는 것만으로 해석이 되지는 않는다.

## 이번 요청의 범위와 반환

시작/재개할 때 **사용자가 이번에 요청한 범위**와 저장 상태를 대조한다. 상태의 `next`는 제안이지 다음 모듈 실행 허가가 아니다. 예를 들어 M0 마무리 요청에서 M0가 이미 저장되어 있으면 필요한 확인·정정과 요약만 하고 M1을 새로 시작하지 않는다. 전체 분석 요청이면 합의된 전체 범위 안에서 이어간다.

요청 범위의 [완료 기준](references/completion-contract.md)이 채워지면(채울 수 없는 항목은 축소·미실행과 이유를 적고) **짧은 최종 응답으로 결과·한계·파일 경로를 반환한다.** 필수 검증 실패는 고치거나 partial로 밝히며 완료로 숨기지 않는다. 미관/표기 보강은 남은 항목으로 분리한다. 비핵심 수정이 반복되어도 해결되지 않으면 현재 결과와 미해결 항목을 반환한다. 사용자가 시간 한도를 주면 시작 시 기록하고 절반 무렵 저장/남은 범위를 점검하여 반환 시간을 남긴다. 시간이 부족하다고 과학적 필수 단계를 성공 처리하지 않는다.

MPM이 아닌 희소 양성 label 문제는 [적용 범위](references/domain-scope.md)의 대응표로 읽는다.

## 근거를 읽고 방법을 선택한다

일반 분석은 **M0 계약 → EDA/공간 진단 → 방법 선택과 근거 → 생성 코드 실행 → 검증/해석 → 필요시 재선택**으로 연결한다. 분석을 시작하거나 목적/자료가 바뀌면 [구체적 방법 선택 가이드](references/method-selection.md)의 공통 절차와 현재 모듈 표를 읽는다. 조건·가정·대안·검증 기준에 따라 선택하며 어려운 단계를 편의상 생략하지 않는다. 선택/제외 이유와 재검토 조건을 상태에 남긴다. 전체 분석의 완료는 특정 알고리즘 목록 실행이 아니라 각 과학적 질문에 검증 가능한 답을 제공하는 것이다.

`analysis_mode=general`이 기본이다. 특정 참조 연구의 재현은 사용자가 명시했을 때만 별도 mode로 구분한다. 다른 연구의 range·block 크기·임계값·분위수·예산·구역 정책은 일반 분석의 default가 아니며 이 자료의 진단과 목적에서 정한다. 계산 뼈대는 선택적으로 복사·조정하고 분석 코드는 에이전트가 작성한다.

M0에서 metadata에 정의가 없는 predictor를 해석하기 전 [자료 의미 참조](references/variable-semantics.md)를 확인한다. 출처가 맞는 정의만 사용하고 없으면 unknown으로 둔다. M3–M4에서 선택기나 순위/면적 지표를 만들 때는 [평가 계약](references/evaluation-contracts.md)을 읽는다. 모듈을 전환할 때 해당 문서를 확인하고 이전의 계획을 실제 구현/검증 결과와 대조한다.

## 현재 질문에 필요한 모듈부터

| 목적 | 읽을 모듈 | 다음 단계에 전달할 증거 |
|---|---|---|
| 연구 목적·영역·자료 의미 | [M0 연구·자료 계약](references/modules/study-design.md), [자료 QC](references/modules/data-diagnosis.md) | 광상 가설, predictor 사전, domain ledger, 전체 지질/관측 지도 |
| 자료 탐색과 전처리 결정 | [M1 지질학적 EDA](references/modules/geological-eda.md) | 분포·관계·꼬리·공간 구조, 변환/보존 근거 |
| 공간 의존성·분할 규모 근거 | [M2 공간 진단](references/modules/spatial-diagnostics.md) | 택한 진단의 실제 결과(예: variogram이면 empirical/fit·pair 수·range 정의)·민감도/실패 |
| 일반화 평가 설계 | [M3 공간 평가](references/modules/spatial-evaluation.md) | 전체 평가 배정(fold 또는 holdout 영역)과 개발/평가 분리, P/U 지지도·거리·fit 역할 |
| 학습·모델/PU 비교 | [M4 모델링](references/modules/modeling.md) | train-only fit·튜닝, held-out 예측/지표(평가 전용), 개발 자료 안의 선택 기록, 모델 schema |
| 안정성·보정·포함집합 | [M5 불확실성·보정](references/modules/uncertainty-calibration.md) | bootstrap 분포·calibration provenance·coverage와 retained fraction |
| 지도·탐사 우선순위 | [M6 지도·구역](references/modules/maps-report.md) | 전체 점수/안정성/구역 지도, 포착률·면적·후보표 |
| 설명·민감도·최종 보고 | [M7 해석·보고](references/modules/interpretation-report.md) | 지질학적 설명·변수 역할·trade-off·한계·재현 경로 |

현재 단계의 문서만 읽고, 기존 산출물을 재사용한다. 재개·계산 재사용 요청에는 [재사용 계약](references/reuse-contract.md)으로 역할·변경 영향을 확인해 필요한 계산만 수행한다. 전체 MPM 요청이라면 baseline 지도에서 끝내지 말고 공간 평가→모델 비교→불확실성/의사결정까지 목적에 맞게 연결한다. 특정 단계만 요청받았다면 그 범위에서 멈춘다. 자료 부족으로 방법이 성립하지 않으면 부족한 근거와 대안을 제시한다. 알고리즘을 형식적으로 강제하지 않는다.

## 과학적 공통 계약

- 광상 시스템과 predictor의 지질학적 의미가 출발점이다. 결측/CRS/누출 QC는 필요하지만 연구 성과를 대신하지 않는다. availability indicator는 지질 변수와 구분한다.
- **U는 확인된 음성이 아니다.** P/U baseline의 수치 인코딩과 광상 부재 판정은 다르다. score·보정된 observed-label 확률·모델 변동·coverage·경제성을 구분한다.
- 원자료를 보존하고 metadata부터 확인한다. 이미 있는 정보는 재질문하지 않는다. label/CRS/feature 출처가 없으면 모른다고 기록하고 의존 작업에 필요한 것만 묻는다.
- 전처리·선택·튜닝은 해당 train에서만 fit한다. outer test는 선택에 재사용하지 않는다. block 크기는 데이터·목적의 근거로 정하며 독립성을 보장하지 않는다.
- 전체 영역, 계산용 표본, CV fold, 지도 확대도를 구분한다. 계산량을 줄였다고 분석 영역을 몰래 crop하지 않는다. 전체 요청에 대한 작은 pilot은 전체 완료가 아니다.
- 설치된 스킬과 원본은 수정하지 않는다. 구현·실행·그림은 사용자 workspace에 작성한다. 실행 환경은 workspace의 환경 지침을 따른다(예: `uv run python`). 실행하지 않은 단계나 검증을 완료로 쓰지 않는다.

## 재개 가능한 상태와 시각 증거

`analysis-state.json` 또는 동등한 구조에 입력/hash·stable ID·관측 단위·domain ledger, 완료/미완료 모듈, 코드/표/그림/모델 경로, seed/환경, 판단 근거와 남은 제약을 연결한다. 학습 이후 split/fit membership, score 역할, calibration 입력 방식, ranking 모집단을 보존한다. 숫자와 hash는 실제 계산 결과만 기록한다. 선택 상태에는 evidence 경로, 후보/가정, 선택·기각 이유, 매개변수 출처, fit/evaluation 경계, 검증 결과, 한계와 revisit 조건을 보존한다. [상태 뼈대](assets/analysis-state.template.json)는 선택형이다. outer 결과를 본 뒤 방법을 바꾸면 기존 평가를 개발 증거로 재분류한다.

긴 단계에서는 계산표·간단한 해석·재개 상태를 먼저 저장하고 그림을 보강한다.

단계 증거 그림은 위 [기본 분석 경로](#기본-분석-경로)로 만든다. 저장한 그림은 모두 직접 열어 확인한다([그림 확인](references/completion-contract.md#그림-확인)). 그림 미세 조정 때문에 분석 인계가 사라지지 않게 한다. 표에서 유도한 수치는 같은 저장 결과로 본문과 캡션에 넣으며, 모듈 간 모집단·분모·점수 역할을 대조한다.

각 단계는 **그림으로 확인하려는 과학적 질문**이 있어야 한다. 셀 자료는 셀 support가 드러나게 표현하고(예: 셀을 채우는 raster형 지도) point/nodata와 구별한다. 전체 지도와 확대도를 함께 읽을 수 있게 한다. [시각화 기준](references/visualization.md)과 [변경 가능한 표현 기본 가이드](references/visual-defaults.md)를 필요한 때 읽는다. 우선순위 범주 색은 의미에 연결하며 구역 정책·임계값을 정하지 않는다. 학습과 저장 결과 렌더링을 분리하고 그림 수정만으로 재학습하지 않는다.

## 반환 전 확인

결과를 반환하기 전에, 어떤 방법을 골랐든 아래가 저장 산출물에서 성립하는지 확인한다. 성립하지 않으면 고치거나 partial로 밝힌다.
- **지도 위치:** 셀 위치는 좌표나 검증된 격자 변환에서 정하고, 행·열 번호와 지리 좌표의 대응을 확인한다. 배열의 첫 행이 어느 방향으로 그려지는지 가정하지 않는다. 실제로 그린 배열과 경계를 저장 표의 좌표·값과 대조한다(선택형 `grid_map.check_cell_placement`). 입력 자료에 확인용 그림이 있으면 같은 변수의 방향·패턴도 비교한다.
- **지표 재계산:** 보고한 평가 지표를 저장한 행 단위 held-out 예측(ID·평가 단위·label·score)에서 다시 계산할 수 있다. 지표 요약이나 full-fit 지도 점수만으로는 이를 대신하지 못한다.
- **서술과 실행의 일치:** 보고서의 방법 서술(사용·제외 변수, 결측 처리, 반복·집계 방식, 후보 선택 규칙, 구역 기준)이 실행 코드·설정과 같다. 평가 자료로 후보를 비교했다면 그 사실과 그 평가가 개발 증거로 바뀐 점을 적는다.
- **판단의 근거:** 보고서에 다음이 있다. (0) block 크기·fold 수·tier·선별 alpha·불확실성 기준마다 목적·예산·자료에서 정한 이유. (1) 값 점검 note의 열마다 유효 값인지 결측 표시인지, 긴 꼬리·한 값 쏠림을 어떻게 다뤘는지, P/U 비교가 어떤 결정을 바꿨는지. (2) 같은 평가 배정에서 간단한 기준선과의 비교, 또는 비교하지 않은 이유. (3) 구역·후보 선정 규칙을 held-out 포착·면적과 대안 규칙으로 설명(`m6_zone_rules` 또는 같은 비교). held-out 결과를 보고 규칙을 골랐다면 그 결과는 개발 증거라고 적는다. (4) 후보마다 실제 변수 값을, 요청·자료 설명이 밝힌 광종의 광상 모델에서 기대하는 신호와 맞춰 본 설명(맞지 않는 값과 자료에 없는 증거 포함), 알려진 P를 포함·인접한 재확인 후보와 새 후보(N·F)의 구분, 지질 변수와 가용성·조사 변수의 구분(`m7_candidate_evidence`, `m7_far_target_evidence`). 변수가 무엇인지(이름·자료 설명으로 식별되는 대상)가 확인되면 단위·척도를 몰라도 광상 모델과의 연결을 적는다: 광상 모델이 기대하는 것, 후보가 보이는 값, 그 설명을 확인할 자료. 자료로 확인할 수 없는 연결은 가설로 표시한다. 무엇인지 확인할 수 없는 변수는 해석을 보류하고, 해석에 필요한 정의·자료를 적는다. (5) 수행·축소·미실행 단계와 이유(축소한 단계마다 자료·방법상 이유).
- **그림 기록:** `stage_evidence.py check <그림 폴더>`가 오류 없이 끝난다. 남은 경고나 기록 없는 그림은 고치거나, 그림을 열어 CRS·쌍 수·글자·겹침을 확인한 결과와 남긴 이유를 보고서에 적는다. 그림 확인은 실제로 연 그림(contact sheet 포함)만 적는다.
- **제외 이유:** 모델에서 뺀 열마다 실제 이유(식별자, 누출, 조사 proxy, 결측 등)를 적는다. 평가 대상 label이 생성 과정에 들어간 열(예: 같은 광상 기록으로 센 개수·거리)은 누출로 설명한다. 평가 단위의 학습 자료 안에서 다시 만들 수 있는 변수와 label을 사실상 복제한 변수를 구분한다. metadata의 역할 표기만 옮겨 적지 않는다.

기본 경로 명령은 `assets/stage_evidence.py`(그림)·`block_design.py`(분할)·`pu_workflow.py`(평가·보정·불확실성·구역·후보)이며 사용법은 각 파일 머리말에 있다. 나머지는 선택형 뼈대(작은 함수)이며 전체 연구 runner가 아니다. M1 `assets/eda_view.py`, M2 `assets/variogram.py`, M3 `assets/spatial_contract.py`, M4 `assets/pu_sampling.py`, M5–6 `assets/decision_support.py`, 공통 `grid_map.py`·`figure_style.py`·`evaluation_view.py`를 복사/수정하거나 목적에 맞게 대체한다. 뼈대를 호출한 것만으로 모듈이 완료되지는 않는다.

## 참조 사례

`reference-cases/`에는 특정 연구의 요약·자료 사전·재현 helper·정책 예시가 격리되어 있다. 사용자가 그 연구의 재현·비교를 명시했거나 입력 자료의 출처가 등록된 사례와 같다고 metadata로 확인된 경우에만 [사례 색인](reference-cases/README.md)을 읽는다. 일반 분석에서는 읽지 않으며 사례의 수치·정책을 이식하지 않는다. `references/upstream/`은 사례의 읽기 전용 원본 코드다.
