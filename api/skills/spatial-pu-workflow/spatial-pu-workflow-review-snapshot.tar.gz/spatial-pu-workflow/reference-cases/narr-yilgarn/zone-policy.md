# 명시적으로 선택하는 NARR practical lift 참조 정책

**일반 MPM 기본값이 아니다.** [사례 색인](../README.md)의 조건대로 사용자가 NARR 재현·비교를 명시했거나 이 정책을 직접 선택했을 때만 사용한다. 일반 분석에서 에이전트가 스스로 채택하지 않는다. 다른 예산 순위/2축 안정성/비용 제약 정책은 이 다섯 범주를 만들 필요가 없다.

참조 lift 예시는 rank fraction tier `[0.01, 0.05, 0.10]`, rho cut `0.30`이다. 지원하는 membership 밖은 Excluded, 안에서는 top1%/낮은 rho→Immediate, top1%/높은 rho 또는 top5%/낮은 rho→Priority, top5%/높은 rho 또는 top10%/낮은 rho→Follow-up, 나머지→Potential이다. **Excluded는 광상 부재가 아니라 선택된 포함집합 밖**이다. rank는 선언한 모집단에서 해당 점수 이상 support 비율이며 동률을 유지한다. 경계 포함 `<=`를 사용한다.

선택형 [narr_reference_policy.py](assets/narr_reference_policy.py)의 `narr_practical_zones(..., tiers=..., rho_cut=...)`는 이 조합만 계산한다. 모든 매개변수를 호출자가 명시한다. 일반 `decision_support.py`에는 구역 정책이 없다. 함수 결과 0–4의 의미는 위 순서이며 -1은 미산출이다. 높은 tier에서 rho 미산출이면 -1, 최하위 Potential에는 rho가 필요 없으므로 유효할 수 있다. membership/score join 실패를 Excluded로 채우지 않는다.

rho의 mean 하한·유효 mask, membership 방법/alpha/가정, rank 모집단·support 가중과 score provenance는 별도 선택이다. 1/5/10과 .30의 적합성을 해당 자료/탐사 예산에서 검토하고 다른 threshold 민감도를 저장한다. 색은 아래 사례 매핑이나 스킬 루트 `references/visual-defaults.md`의 일반 우선순위 팔레트를 쓰거나 바꾼다. 색을 선택했다고 이 정책이 채택되지 않는다.

출처: 고정 원본 `references/upstream/scripts/utils/conformal_utils.py` 및 이 사례의 `scripts/workflow.py::REFERENCE_STATIC_CONFIG`의 lift 참조. 다른 historical prob/FNR 정책도 존재하므로 이름만 같은 zone 번호를 혼합하지 않는다. 코드 원본/논문 버전 차이는 source-map과 연구 audit에서 확인한다.

## 사례의 구역 색

| 실제 정책에서의 의미 키 | 기본 추천색 | 해석 주의 |
|---|---|---|
| Immediate | `#d62728` 빨강 | 채택한 정책의 집중 검토 우선순위 |
| Priority | `#ff7f0e` 주황 | 채택한 정책의 높은 우선순위 |
| Follow-up | `#ffbb78` 연주황 | 추가 확인/후속 조사 |
| Potential | `#2ca02c` 초록 | 정책 내 나머지 잠재 대상 |
| Excluded | `#9467bd` 보라 | **정책상 제외**; 광상 부재·nodata 아님 |

실제 정책이 세 범주이면 그 의미에 맞는 세 색만 사용한다. 임의 ID 0에 빨강을 붙이지 않는다. 의미가 다르면 새 색/명칭을 정한다. 범례에는 현재 정의와 표의 실제 count/support를 연결한다. colorblind/인쇄 요구이면 대비·명도·보조 기호 또는 다른 palette로 변경한다.

근거: NARR revision3 `generate_figure6.py::ZONE_COLORS`, `generate_figure_a1.py::ZONE_LABELS/ZONE_COLORS`에서 위 의미/색 순서를 대조했다. 보존된 resubmission2 최종 Figure 6의 실제 PNG에서도 동일 palette·검은 star/흰 테두리·채운 셀 지도를 확인했다. revision3 최종 PDF의 픽셀 동일성까지 검증한 것은 아니다. 프로젝트 출처/검수 기록: 개발 저장소 `docs/research/adaptive-agent-audit.md`. 원본의 missing→Excluded 채우기, 중심 extent, 고정 scalebar는 복사하지 않는다.
