# NARR 사례 변수 사전

일반 규칙은 스킬 루트의 `references/variable-semantics.md`를 따른다. 아래 정의는 입력 자료가 이 연구와 같은 출처임을 metadata로 확인했을 때만 적용한다. 이름이 비슷한 다른 지역·DB의 변수에 옮기지 않는다. 이 사전을 조회했다고 이 연구의 방법·정책·상수를 채택하는 것은 아니다.

## 이 연구 자료에 한정된 변수 정의

자료가 해당 출처와 일치할 때만 적용한다. 새로운 이름/지역에 무조건 이식하지 않는다. 아래는 알고리즘·전처리 권고가 아니라 자료 사전이다.

| 변수 | 확인된 의미 | 잘못된 추정 |
|---|---|---|
| AuSREM (km) | Australian Seismological Reference Model에서 가져온 lithosphere–asthenosphere boundary/lithosphere 두께 계열의 지구물리량 | Au 약자를 금/하천퇴적물 지화학 또는 광상까지 거리로 해석 |
| Tectonic Bedrock Age (MA) | 지질 단위에 부여한 연령 Ma; 공간적으로 단위별 상수일 수 있음 | 고유값이 적다는 이유로 임의 범주 코드/나이 차이 무의미 선언 |
| DGIR (mGal) | De-trended Global Isostatic Residual gravity 계열 | 근거 없이 일반 Bouguer gravity와 동일시 |
| worms mag/grav | 해당 DB의 1/4.6/11/50 km 다중 스케일 edge-response magnitude, 무차원 | 이름의 km를 응답값의 단위로 사용 |

출처: NARR `paper/Final/revision3/study_area_data_final_nrr.md` 본문·Table 1 및 전처리 설명. 프로젝트의 고정 출처 조사 `docs/research/narr-revision3-workflow-audit.md`에 원문 locator가 보존되어 있다. 배포 환경에 원문이 없으면 이 참조의 출처 범위와 원 metadata의 일치 여부를 밝힌다. 알고리즘 재현 요청 없이 이 데이터 정의를 참고할 수 있다.
