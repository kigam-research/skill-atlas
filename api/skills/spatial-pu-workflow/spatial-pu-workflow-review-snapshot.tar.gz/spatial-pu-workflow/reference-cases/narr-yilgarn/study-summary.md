# 참조 방법과 일반화 시 주의점

이 문서는 NARR revision3 과학 흐름의 참조다. 고정 코드 위치는 [source-map](reproduction/source-map.md), 원본 provenance는 스킬 루트의 `references/upstream/SOURCE.json`을 본다. 원본 runner와 새 에이전트 구현은 다르며 새 결과는 논문 성능을 물려받지 않는다. 일반 분석에서는 모듈 지침을 우선한다.

## 연구의 연결

Yilgarn komatiite-hosted Ni sulfide 연구는 21 thematic predictors, P818/U69,382의70,200셀에서 자료/전처리→variogram→nested spatial CV→XGBoost/BaggingPU 비교→bootstrap 안정성·OOF calibration→5단계 탐사 구역을 연결한다. 그림은 지질/입력, variogram, nested fold, 전체 score/membership/zone, 확대도·capture·SHAP의 역할이 다르다.

outer PR-AUC는 두 모델이 거의 같았고 논문의 주요 차이는 높은 점수 구역의 bootstrap 안정성과 tier 재분배였다. 결측이나 PU가 엄청난 식별 성능 향상을 만들었다고 해석하지 않는다. 네 missing indicator는 availability로 구분하여 지질 SHAP 요약에서 제외했다. 이 판단을 다른 자료에서 indicator가 언제나 무의미하다는 법칙으로 쓰지 않는다.

## 그대로 이식하지 않을 참조 설정/코드

- 5 km/EPSG:3857, 31.5 km range와50 km block, outer/inner5fold, Optuna30회, PU T10–50/s0.10–0.50, bootstrap50회, alpha0.15/delta0.05, rho30%, top1/5/10은 연구 설정이며 보편 상수가 아니다.
- 변이도 참조 코드는 systematic thinning에 모든 P를 더한다. label-dependent sampling이 prevalence·pair 구성에 영향을 준다. 또 설치 skgstat Gaussian은 exp(-4h²/r²), 논문 r95식은 exp(-3h²/r²), Fig1의 변환은 exp(-9h²/r²)로 다르다. range 정의와 같은 fitted 함수로 그리는지 검증한다. 주어진31.5 km를 새 데이터에서 확인한 것처럼 쓰지 않는다.
- 논문은 P count 정렬 후 greedy fold, 원본 코드 일부는 shuffle 후 greedy다. origin·seed·label 사용·실제 배정을 기록한다. block 크기가 train-test gap이나 독립성을 보장하지 않는다.
- OOF calibration 코드의 단일 XGB/단일 PU ensemble 점수와 outer bootstrap 평균의 생성 절차가 다를 수 있다. 이름에 OOF가 있다고 입력 통계량 일치가 보장되지 않는다.
- FNR correction의 논문 ln(1/delta)와 helper ln(2/delta)는 다르다. 쓰는 식을 명시하고 적용 조건/양성 부족을 확인한다. 이름만 cross-conformal이라고 해서 공간 의존 하 정확한 보장을 주장하지 않는다.
- full-grid percentile 서술과 fold-local 구현을 구별한다. merged prediction의 오래된 zone 열과 후속 lift zone이 다르며 ID join 실패를 과학적 제외로 채우지 않는다.
- rho는 finite-sample model instability다. PU 내부 T개 평균과 외부 B회 bootstrap을 구별한다. 낮은 dispersion의 이유를 label 모호성 해결 하나로 단정하지 않는다.
- 코드 이름 `jorc30`은 원본 식별자일 뿐 자원량 분류/보고 규정 인증이 아니다. 이 참조는 경제성·매장량·실제 발견률 보장을 제공하지 않는다.

## 재사용할 과학적 계약

1. P는 알려진 광상 cell이고 U는 미발견 P를 포함할 수 있다. 발견/표지 선택 편향을 구분한다. P/U 지표의 true-label 지표 대비 편향 방향을 가정 없이 단정하지 않는다.
2. 설명용 EDA와 train-only preprocessing/feature selection을 분리한다. 공변량을 전체에 걸쳐 측정했다는 사실만으로 누출은 아니다. 전역 fitted 변환이나 label-derived 생성 과정이 경계를 넘는지 확인한다.
3. 튜닝·보정은 outer train 안에서 수행하고 outer 결과를 임계 선택에 다시 쓰지 않는다. inner 재사용 여부와 보정 score의 생성 절차를 밝힌다.
4. 전체 OOF(각 cell은 해당 fit 밖), full-fit 활용 점수(학습 cell은 in-sample), 확대도를 구분한다. crop/smoke run을 전체 영역 완료로 대신하지 않는다.
5. nominal positive coverage, 실측 known-P coverage/FNR, retained support를 함께 보고한다. correction이 alpha보다 크거나 P가 없으면 비선별적/미지원 상태와 대안을 제시한다.
6. 예측 점수/관측 label 보정, bootstrap 변동, prior/label noise, 외삽·자료 가용성, 실제 경제적 탐사 가치는 서로 다른 주장이다.

새 지역 활용에는 feature/CRS/단위·support/분포 이동 검토, 학습 안의 OOF 보정 근거, 모델/변환 저장과 별도 검증이 필요하다. 동일 영역 CV가 다른 광상 시스템으로의 전이를 입증하지 않는다.
