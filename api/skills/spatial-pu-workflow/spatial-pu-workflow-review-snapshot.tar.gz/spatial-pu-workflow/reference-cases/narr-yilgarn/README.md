# 참조 사례: NARR (Yilgarn Ni sulfide MPM)

**NARR**는 이 프로젝트가 참조 연구를 부르는 이름이다(원고·조사 기록의 저장소 이름). 공개 코드는 `kigam-research/mpm-pu-conformal-yilgarn`이며 고정 commit과 파일 hash는 스킬 루트의 `references/upstream/SOURCE.json`에 있다. 원고 본문은 이 스킬에 포함하지 않는다.

연구 개요: Western Australia Yilgarn craton의 komatiite-hosted Ni sulfide, 21 thematic predictors, 5 km 격자(EPSG:3857) 70,200셀(P 818, U 69,382). 자료/전처리 → variogram → nested spatial CV → XGBoost/BaggingPU 비교 → bootstrap 안정성·OOF calibration → 5단계 탐사 구역.

## 언제 읽는가

[사례 색인](../README.md)의 조건(명시적 재현·비교 요청, 또는 입력 자료 출처가 이 연구와 같음)을 만족할 때만 읽는다. 일반 분석에는 스킬 루트의 `SKILL.md`와 `references/`를 쓴다.

## 파일

| 파일 | 내용 | 읽는 때 |
|---|---|---|
| [study-summary.md](study-summary.md) | 연구 흐름, 이식하지 않을 설정, 원본 코드의 적용 함정 | 이 연구와 비교하거나 원본 방법을 쓸 때 |
| [variable-dictionary.md](variable-dictionary.md) | 이 연구 자료의 변수 정의(AuSREM, DGIR 등) | 입력 자료가 같은 출처일 때 |
| [visual-patterns.md](visual-patterns.md) | 일반 그림 패턴의 출처가 된 최종 그림과 옮기지 않을 요소 | 원 그림과 비교할 때 |
| [zone-policy.md](zone-policy.md) | 5단계 practical zone 정책과 색 | 사용자가 이 정책을 명시적으로 선택했을 때 |
| [reproduction/](reproduction/reproduction.md) | 고정 원본 재현 경로, source map, helper 입력 계약 | 원본 재현·이식 요청일 때 |
| `assets/`, `scripts/` | `narr_reference_policy.py`, 재현 config template, `workflow.py`·`selftest.py` helper | 위 재현·정책 선택 시 |

경로 표기: 이 폴더 문서에서 `references/...`·`assets/...`는 스킬 루트 기준, `scripts/...`(upstream 코드)는 고정 원본 또는 그 workspace 복사본(`WORKSPACE/pipeline/`) 기준이다.

## 일반 분석에 옮기지 않는 값

5 km·EPSG:3857 격자, 31.5 km range와 50 km block, outer/inner 5-fold, Optuna 30회, PU T 10–50·s 0.10–0.50, bootstrap 50회, alpha 0.15·delta 0.05, rho 0.30, top 1/5/10% tier, winsorize 1/99%, missing indicator 5%, log-distance 변환. 모두 이 연구의 설정이며 보편 상수가 아니다.
