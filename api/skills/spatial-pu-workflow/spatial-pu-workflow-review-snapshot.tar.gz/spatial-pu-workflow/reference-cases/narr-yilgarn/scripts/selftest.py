#!/usr/bin/env python3
"""Self-test for workflow.py using synthetic temporary fixtures (stdlib only).

    uv run --no-project python selftest.py

Synthetic data only: passing says the helper behaves as documented, nothing
about any real dataset or about the reference pipeline's scientific validity.
"""

import contextlib
import csv
import io
import json
import random
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import workflow  # noqa: E402


def write_grid_csv(path, n=40, cell=1000.0, positives=60, seed=7, sentinel=False, degrees=False, label_values=("1", "0")):
    rng = random.Random(seed)
    cells = [(i, j) for i in range(n) for j in range(n)]
    pos = set(rng.sample(cells, positives))
    with open(path, "w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["east", "north", "deposit", "mag", "dist_fault", "notes"])
        for i, j in cells:
            x, y = (500000 + i * cell, 4100000 + j * cell) if not degrees else (127.0 + i * 0.01, 36.0 + j * 0.01)
            mag = "" if rng.random() < 0.1 else f"{rng.gauss(0, 50):.3f}"
            if sentinel and rng.random() < 0.05:
                mag = "-9999"
            writer.writerow([x, y, label_values[0] if (i, j) in pos else label_values[1], mag, f"{rng.random() * 9000:.1f}", "x"])


def base_config(csv_path):
    return {
        "schema_version": 1,
        "analysis_mode": "narr-reproduction",
        "project_name": "selftest",
        "data": {"csv_path": str(csv_path), "delimiter": ",", "encoding": "utf-8", "missing_tokens": [""]},
        "coordinates": {"x_column": "east", "y_column": "north", "crs": "EPSG:32652", "projected": True, "unit": "m",
                        "crs_verified_by": "synthetic fixture: generator writes UTM zone 52N metre coordinates"},
        "grid": {"cell_size": 1000, "equal_area_cells": True},
        "label": {
            "column": "deposit", "positive_value": 1, "unlabeled_value": 0,
            "positive_definition": "synthetic", "unlabeled_is_verified_negative": False,
        },
        "features": {
            "columns": ["mag", "dist_fault"], "units": {"mag": "nT", "dist_fault": "m"},
            "log1p_columns": ["dist_fault"], "winsorize_columns": ["mag"], "missing_indicator_threshold": 0.05,
        },
        "spatial_cv": {
            "block_size": 5, "block_size_unit": "km", "block_size_rationale": "synthetic",
            "n_outer_folds": 4, "n_inner_folds": 3, "random_state": 11,
        },
        "methods": ["xgboost", "baggingpu_xgboost"],
        "optuna": {"n_trials": 3},
        "bootstrap": {"n_bootstraps": 5, "random_state": 11},
        "conformal": {"alpha": 0.15, "delta": 0.05, "n_iterations": 6, "path": "both"},
    }


def run_cli(*argv):
    out, err = io.StringIO(), io.StringIO()
    with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
        code = workflow.main(list(argv))
    return code, out.getvalue(), err.getvalue()


class WorkflowHelperTest(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.tmp = Path(self._tmp.name)
        self.csv = self.tmp / "source" / "grid.csv"
        self.csv.parent.mkdir()
        write_grid_csv(self.csv)
        self.ws = self.tmp / "ws"

    def tearDown(self):
        self._tmp.cleanup()

    def write_config(self, config):
        self.ws.mkdir(exist_ok=True)
        path = self.ws / "mpm-config.json"
        path.write_text(json.dumps(config), encoding="utf-8")
        return path

    def codes(self, level=None):
        report = json.loads((self.ws / "validation-report.json").read_text(encoding="utf-8"))
        return {f["code"] for f in report["findings"] if level is None or f["level"] == level}

    def test_init_copies_reference_and_refuses_overwrite(self):
        code, out, _ = run_cli("init", "--mode", "narr-reproduction", str(self.ws))
        self.assertEqual(code, 0, out)
        self.assertTrue((self.ws / "pipeline" / "scripts" / "fold_generation" / "create_outer_folds.py").is_file())
        self.assertTrue((self.ws / "pipeline" / "config" / "config.reference-study.yaml").is_file())
        self.assertTrue((self.ws / "pipeline" / "LICENSE").is_file())
        template = json.loads((self.ws / "mpm-config.json").read_text(encoding="utf-8"))
        self.assertEqual(template["features"]["columns"], [])
        code, _, err = run_cli("init", "--mode", "narr-reproduction", str(self.ws))
        self.assertEqual(code, 2)
        self.assertIn("refusing to overwrite", err)

    def test_init_rejects_workspace_inside_skill(self):
        # SKILL_ROOT is the whole installed skill, not only this reference case.
        for parent in (workflow.SKILL_ROOT, workflow.SKILL_ROOT / "assets", workflow.SKILL_ROOT / "references",
                       workflow.CASE_ROOT, workflow.CASE_ROOT / "assets"):
            target = parent / "ws-should-not-exist"
            code, _, err = run_cli("init", "--mode", "narr-reproduction", str(target))
            self.assertEqual(code, 2, target)
            self.assertFalse(target.exists(), target)

    def test_unverified_crs_blocks_apply_without_pyproj(self):
        try:
            import pyproj  # noqa: F401
            has_pyproj = True
        except ImportError:
            has_pyproj = False
        run_cli("init", "--mode", "narr-reproduction", str(self.ws))
        config = base_config(self.csv)
        config["coordinates"]["crs_verified_by"] = ""
        config["coordinates"]["crs"] = "EPSG:5186"  # projected, outside every fallback list
        path = self.write_config(config)
        code, out, _ = run_cli("plan", "--config", str(path), "--apply")
        report = json.loads((self.ws / "validation-report.json").read_text(encoding="utf-8"))
        if has_pyproj:
            self.assertEqual(report["crs_check"]["status"], "verified")
            self.assertEqual(code, 0, out)
        else:
            self.assertEqual(report["crs_check"]["status"], "declared-unverified")
            self.assertEqual(code, 1, out)
            self.assertIn("--apply refused", out)
            plan = json.loads((self.ws / "plan.json").read_text(encoding="utf-8"))
            self.assertTrue(any(b.startswith("BLOCKER CRS properties unverified") for b in plan["blockers"]))
            reference = (self.ws / "pipeline" / "config" / "config.reference-study.yaml").read_text(encoding="utf-8")
            self.assertEqual(reference, (self.ws / "pipeline" / "config" / "config.yaml").read_text(encoding="utf-8"))

    def test_blank_template_fails_without_guessing(self):
        run_cli("init", "--mode", "narr-reproduction", str(self.ws))
        code, out, _ = run_cli("validate", "--config", str(self.ws / "mpm-config.json"))
        self.assertEqual(code, 1)
        for expected in ("data.csv_path", "coordinates.crs", "coordinates.projected", "label.column",
                         "label.unlabeled_is_verified_negative", "features.columns", "spatial_cv.block_size",
                         "spatial_cv.block_size_rationale"):
            self.assertIn(expected, self.codes("error"))
        code, out, _ = run_cli("plan", "--config", str(self.ws / "mpm-config.json"))
        self.assertEqual(code, 1)
        self.assertIn("BLOCKED", out)
        self.assertFalse((self.ws / "plan.md").exists())

    def test_valid_dataset_passes_and_source_untouched(self):
        before = workflow.sha256_file(self.csv)
        path = self.write_config(base_config(self.csv))
        code, out, _ = run_cli("validate", "--config", str(path))
        self.assertEqual(code, 0, out)
        self.assertIn("not a scientific validation", out)
        report = json.loads((self.ws / "validation-report.json").read_text(encoding="utf-8"))
        self.assertEqual(report["summary"]["n_rows"], 1600)
        self.assertEqual(report["summary"]["n_positive"], 60)
        self.assertEqual(report["summary"]["spatial_support"]["n_blocks"], 64)
        self.assertEqual(report["summary"]["spatial_support"]["hoeffding_min_positives"], 82)
        self.assertIn("features.unused_columns", self.codes("info"))
        # 60 positives: both conformal paths are under the 82-positive Hoeffding floor
        self.assertIn("conformal.support_default", self.codes("warning"))
        self.assertIn("conformal.support_pooled_oof", self.codes("warning"))
        self.assertEqual(before, workflow.sha256_file(self.csv))
        self.assertEqual(sorted(p.name for p in self.csv.parent.iterdir()), ["grid.csv"])

    def test_error_cases(self):
        cases = {}
        c = base_config(self.csv); c["features"]["columns"].append("no_such"); c["features"]["units"]["no_such"] = "m"
        cases["data.columns_missing"] = c
        c = base_config(self.csv); c["features"]["columns"].append("notes"); c["features"]["units"]["notes"] = "text"
        cases["features.non_numeric"] = c
        c = base_config(self.csv); c["features"]["columns"].append("deposit"); c["features"]["units"]["deposit"] = "flag"
        cases["features.reserved"] = c
        c = base_config(self.csv); del c["features"]["units"]["mag"]
        cases["features.units"] = c
        c = base_config(self.csv); c["coordinates"]["crs"] = "EPSG:4326"
        cases["coordinates.crs"] = c
        c = base_config(self.csv); c["coordinates"]["unit"] = "degree"
        cases["coordinates.unit"] = c
        c = base_config(self.csv); c["label"]["unlabeled_is_verified_negative"] = True
        cases["label.unlabeled_is_verified_negative"] = c
        c = base_config(self.csv); c["label"]["positive_value"] = 2
        cases["label.values"] = c
        c = base_config(self.csv); c["spatial_cv"]["block_size"] = 40  # one block only
        cases["spatial_cv.too_few_blocks"] = c
        for expected, config in cases.items():
            with self.subTest(expected):
                code, out, _ = run_cli("validate", "--config", str(self.write_config(config)))
                self.assertEqual(code, 1, out)
                self.assertIn(expected, self.codes("error"))

    def test_degree_like_coordinates_warned(self):
        # small magnitudes can be legitimate local/km coordinates, so this is a warning, not an error
        write_grid_csv(self.csv, degrees=True)
        run_cli("validate", "--config", str(self.write_config(base_config(self.csv))))
        self.assertIn("coordinates.degree_like", self.codes("warning"))

    def test_duplicates_sentinel_and_web_mercator_warn(self):
        write_grid_csv(self.csv, sentinel=True)
        with open(self.csv, "a", newline="", encoding="utf-8") as handle:
            csv.writer(handle).writerow([500000.0, 4100000.0, 0, "1.0", "10.0", "dup"])
        config = base_config(self.csv)
        config["coordinates"]["crs"] = "EPSG:3857"
        config["grid"]["equal_area_cells"] = False
        code, out, _ = run_cli("validate", "--config", str(self.write_config(config)))
        self.assertEqual(code, 0, out)
        for expected in ("coordinates.duplicates", "features.sentinel_like", "coordinates.web_mercator", "grid.equal_area_cells"):
            self.assertIn(expected, self.codes("warning"))

    def test_plan_apply_status_and_staleness(self):
        run_cli("init", "--mode", "narr-reproduction", str(self.ws))
        path = self.write_config(base_config(self.csv))
        code, out, _ = run_cli("plan", "--config", str(path))
        self.assertEqual(code, 0, out)
        self.assertIn("No stage has been run", out)
        reference = (self.ws / "pipeline" / "config" / "config.reference-study.yaml").read_text(encoding="utf-8")
        self.assertEqual(reference, (self.ws / "pipeline" / "config" / "config.yaml").read_text(encoding="utf-8"))
        code, out, _ = run_cli("plan", "--config", str(path), "--apply")
        self.assertEqual(code, 0, out)
        rendered = (self.ws / "pipeline" / "config" / "config.yaml").read_text(encoding="utf-8")
        self.assertIn(f'"original_data": "{self.csv}"', rendered)
        self.assertIn('"target_column": "deposit"', rendered)
        self.assertIn('"feature_columns": ["mag", "dist_fault"]', rendered)
        self.assertIn('"block_size_km": 5.0', rendered)
        self.assertIn("\n  0:\n", rendered)
        self.assertNotIn("Ni_mine", rendered)
        plan = (self.ws / "plan.md").read_text(encoding="utf-8")
        for needle in ("This is a plan, not a result", "cross_conformal_oof_xgboost.py", "cross_conformal_xgboost.py",
                       "evaluate_test_fold_oof.py", "UNLABELED", "not JORC", "NOT AVAILABLE deployment prediction"):
            self.assertIn(needle, plan)
        self.assertEqual(json.loads((self.ws / "plan.json").read_text(encoding="utf-8"))["executed_stages"], [])
        code, out, _ = run_cli("status", "--workspace", str(self.ws))
        self.assertEqual(code, 0, out)
        self.assertIn("boot=-", out)
        with open(self.csv, "a", newline="", encoding="utf-8") as handle:
            csv.writer(handle).writerow([999000.0, 4999000.0, 0, "1.0", "10.0", "new"])
        code, out, _ = run_cli("status", "--workspace", str(self.ws))
        self.assertEqual(code, 1)
        self.assertIn("STALE: data CSV changed", out)

    def test_plan_flags_blockers_for_label_encoding_sentinel_and_units(self):
        write_grid_csv(self.csv, sentinel=True, label_values=("Ni", "none"))
        config = base_config(self.csv)
        config["label"].update({"positive_value": "Ni", "unlabeled_value": "none"})
        config["data"]["missing_tokens"] = ["", "-9999"]
        config["coordinates"]["unit"] = "km"  # declared km: a 5 km block is 5 coordinate units
        config["spatial_cv"]["block_size"] = 5000
        config["spatial_cv"]["block_size_unit"] = "km"
        path = self.write_config(config)
        code, out, _ = run_cli("plan", "--config", str(path))
        self.assertEqual(code, 0, out)
        self.assertIn("NOT RUNNABLE AS-IS: 2 blocker(s)", out)
        plan = json.loads((self.ws / "plan.json").read_text(encoding="utf-8"))
        self.assertEqual(plan["effective_block_size_km_for_reference_code"], 5.0)
        self.assertEqual(len(plan["blockers"]), 2)

    def test_rendered_yaml_parses_if_pyyaml_available(self):
        try:
            import yaml
        except ImportError:
            self.skipTest("PyYAML not importable under --no-project (expected); structure is asserted textually elsewhere")
        _, spec, report = workflow.run_validation(self.write_config(base_config(self.csv)))
        text, _ = workflow.render_pipeline_config(base_config(self.csv), spec, Path(report["csv_path"]))
        parsed = yaml.safe_load(text)
        self.assertEqual(parsed["zone_definitions"][0]["name"], "IMMEDIATE")
        self.assertEqual(parsed["data"]["coordinate_columns"], ["east", "north"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
