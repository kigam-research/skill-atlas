#!/usr/bin/env python3
"""Explicit NARR reproduction helper: init / validate / plan / status (stdlib only).

Usage (never needs a project environment):

    uv run --no-project python workflow.py init WORKSPACE --mode narr-reproduction
    uv run --no-project python workflow.py validate --config WORKSPACE/mpm-config.json
    uv run --no-project python workflow.py plan --config WORKSPACE/mpm-config.json [--apply]
    uv run --no-project python workflow.py status --workspace WORKSPACE

What it does
  init      Create a user workspace. Copies the pinned reference pipeline
            (references/upstream) to WORKSPACE/pipeline and a config template to
            WORKSPACE/mpm-config.json. The installed skill is never edited.
  validate  Check the user's CSV against the JSON config: columns, PU labels,
            projected CRS declaration, coordinate units, explicit feature
            selection and units, missingness, duplicate coordinates, spatial
            block and positive support. Writes validation-report.json.
  plan      Re-run validate, then write plan.md / plan.json with the actual
            stage commands, adaptation-needed items and unvalidated points.
            With --apply, also renders WORKSPACE/pipeline/config/config.yaml.
  status    Show which stage artifacts exist and whether data/config changed
            since the plan (the reference pipeline skips stages by file
            existence only).

What it does NOT do
  It never modifies or copies the source CSV, never installs packages, never
  trains a model and never starts a pipeline stage. A passing validate means
  "the declared contract matches the file", not "the science is sound".

Exit codes: 0 ok, 1 validation errors / blocked plan, 2 usage or I/O error.
"""

import argparse
import csv
import hashlib
import json
import math
import os
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path

CASE_ROOT = Path(__file__).resolve().parent.parent  # reference-cases/narr-yilgarn
SKILL_ROOT = CASE_ROOT.parent.parent
UPSTREAM_DIR = SKILL_ROOT / "references" / "upstream"
TEMPLATE_PATH = CASE_ROOT / "assets" / "narr-reproduction-config.template.json"

SCHEMA_VERSION = 1
UNIT_TO_METRE = {"m": 1.0, "km": 1000.0, "ft": 0.3048, "us-ft": 1200.0 / 3937.0}
METHODS = ("xgboost", "baggingpu_xgboost")
CONFORMAL_PATHS = ("default", "pooled_oof", "both")

# Keys the reference scripts read from config.yaml but that do not describe the
# user's data. Values are the reference study's settings, kept so the copied
# code runs; they are not recommendations for a new area.
REFERENCE_STATIC_CONFIG = {
    "output_dirs": {
        "folds": "outputs/folds",
        "optuna": "outputs/optuna",
        "models": "outputs/models",
        "conformal": "outputs/conformal",
        "test_evaluation": "outputs/test_evaluation",
        "aggregated": "outputs/aggregated",
        "figures": "outputs/figures",
        "reports": "reports",
    },
    "zone_method": "jorc30",
    "practical_zone_modes": ["prob", "lift"],
    "zone_thresholds": {
        "jorc30": {"rel_iqr_threshold": 0.30, "prob_z0": 0.50, "prob_z1": 0.25, "prob_z2": 0.10},
        "lift": {"rel_iqr_threshold": 0.30, "lift_z0": 0.01, "lift_z1": 0.05, "lift_z2": 0.10},
        "percentile_std": {
            "prob_percentile_high": 98, "prob_percentile_mod": 90, "prob_percentile_low": 70,
            "std_low": 0.0765, "std_moderate": 0.1020, "std_high": 0.1276,
        },
    },
    "zone_definitions": {
        0: {"name": "IMMEDIATE", "description": "prob tier 0 AND rel_IQR <= threshold", "color": "#d62728"},
        1: {"name": "PRIORITY", "description": "high prob OR mid prob with low dispersion", "color": "#ff7f0e"},
        2: {"name": "FOLLOW_UP", "description": "mid prob OR low-mid prob with low dispersion", "color": "#ffbb78"},
        3: {"name": "POTENTIAL", "description": "remaining in_set_1 samples", "color": "#2ca02c"},
        4: {"name": "EXCLUDED", "description": "in_set_1 = 0", "color": "#9467bd"},
    },
    "visualization": {
        "figure_formats": ["png", "pdf"], "dpi": 300,
        "figsize_single": [8, 6], "figsize_wide": [12, 6], "figsize_map": [10, 10],
        "colormap_prob": "magma", "colormap_std": "viridis",
        "colormap_zone": ["#d62728", "#ff7f0e", "#ffbb78", "#2ca02c", "#9467bd"],
    },
    "logging": {
        "level": "INFO",
        "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        "file_logging": True,
        "log_dir": "logs",
    },
}


class UsageError(Exception):
    pass


# --------------------------------------------------------------------------
# small utilities
# --------------------------------------------------------------------------

def now_iso():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def sha256_file(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_json_file(path):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except FileNotFoundError:
        raise UsageError(f"file not found: {path}")
    except json.JSONDecodeError as exc:
        raise UsageError(f"invalid JSON in {path}: {exc}")


def write_json_file(path, payload):
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2, ensure_ascii=False)
        handle.write("\n")


def rel_to(path, base):
    """A path as recorded in helper outputs: relative to the recording file's directory, never absolute."""
    if path is None:
        return None
    return os.path.relpath(Path(path), Path(base))


def report_for_disk(report, base):
    """The validation report with its input paths made relative to the directory it is written to."""
    return {**report, "paths_relative_to": "this file's directory",
            "config_path": rel_to(report["config_path"], base), "csv_path": rel_to(report["csv_path"], base)}


def is_blank(value):
    return value is None or (isinstance(value, str) and value.strip() == "")


def to_float(text):
    try:
        value = float(text)
    except (TypeError, ValueError):
        return None
    return value if math.isfinite(value) else None


def same_value(cell, declared):
    """Compare a CSV cell with a declared label value (numeric when possible)."""
    a, b = to_float(cell), to_float(declared)
    if a is not None and b is not None:
        return a == b
    return str(cell).strip() == str(declared).strip()


def yaml_scalar(value):
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (int, float)):
        return repr(value)
    return json.dumps(str(value), ensure_ascii=False)  # JSON string == YAML double-quoted


def to_yaml(value, indent=0):
    """Minimal block-style YAML emitter for dict / list / scalar trees."""
    pad = "  " * indent
    lines = []
    if isinstance(value, dict):
        for key, item in value.items():
            key_text = str(key) if isinstance(key, int) else yaml_scalar(key)
            if isinstance(item, dict) and item:
                lines.append(f"{pad}{key_text}:")
                lines.extend(to_yaml(item, indent + 1))
            elif isinstance(item, list) and item and any(isinstance(x, (dict, list)) for x in item):
                lines.append(f"{pad}{key_text}:")
                lines.extend(to_yaml(item, indent + 1))
            elif isinstance(item, list):
                lines.append(f"{pad}{key_text}: [{', '.join(yaml_scalar(x) for x in item)}]")
            elif isinstance(item, dict):
                lines.append(f"{pad}{key_text}: {{}}")
            else:
                lines.append(f"{pad}{key_text}: {yaml_scalar(item)}")
    elif isinstance(value, list):
        for item in value:
            if isinstance(item, (dict, list)):
                sub = to_yaml(item, indent + 1)
                lines.append(f"{pad}- {sub[0].lstrip()}")
                lines.extend(sub[1:])
            else:
                lines.append(f"{pad}- {yaml_scalar(item)}")
    return lines


class Findings:
    def __init__(self):
        self.items = []
        self.crs_check = None

    def add(self, level, code, message):
        self.items.append({"level": level, "code": code, "message": message})

    def error(self, code, message):
        self.add("error", code, message)

    def warn(self, code, message):
        self.add("warning", code, message)

    def info(self, code, message):
        self.add("info", code, message)

    def count(self, level):
        return sum(1 for item in self.items if item["level"] == level)


# --------------------------------------------------------------------------
# init
# --------------------------------------------------------------------------

WORKSPACE_README = """# MPM workspace

Created by the reference-case reproduction helper. Everything here is yours to edit;
the installed skill and your source data are never modified by the helper.

- `mpm-config.json`  dataset contract. Fill every empty string / null. The
  helper does not guess column names, labels, CRS or units.
- `pipeline/`        copy of the pinned reference research code (MIT, see
  pipeline/LICENSE). Its shipped config/config.yaml is the reference study's
  (Yilgarn Ni) setting; the untouched original is config/config.reference-study.yaml.
  Adapt this copy, not the skill. Record every change in `adaptations.md`.
- `adaptations.md`   log of code changes you (or the agent) make to pipeline/.
- `validation-report.json`, `plan.md`, `plan.json`  written by validate / plan.

Commands (HELPER = path printed by init):

    uv run --no-project python HELPER validate --config mpm-config.json
    uv run --no-project python HELPER plan --config mpm-config.json
    uv run --no-project python HELPER plan --config mpm-config.json --apply
    uv run --no-project python HELPER status --workspace .

`plan --apply` renders pipeline/config/config.yaml from mpm-config.json. Stage
commands listed in plan.md run inside pipeline/ with `uv run python ...`; the
first such run makes uv create pipeline/.venv from pipeline/uv.lock (local to
this workspace, needs network or a warm uv cache). The helper never does this
for you and never starts training.

A passing validate is a data-contract check. It is not evidence that the
reference method is appropriate for your area, commodity or labels.
"""

ADAPTATIONS_HEADER = """# Adaptations to pipeline/

Record each change to the copied reference code: date, file, what and why,
and how it was checked. Unrecorded changes make results irreproducible.

| date | file | change | reason | check |
|------|------|--------|--------|-------|
"""


def cmd_init(args):
    if args.mode != "narr-reproduction":
        raise UsageError("This helper only supports explicit NARR reproduction")
    workspace = Path(args.workspace).expanduser().resolve()
    if not UPSTREAM_DIR.is_dir():
        raise UsageError(f"reference code not found in skill: {UPSTREAM_DIR}")
    if not TEMPLATE_PATH.is_file():
        raise UsageError(f"config template not found in skill: {TEMPLATE_PATH}")
    try:
        workspace.relative_to(SKILL_ROOT)
    except ValueError:
        pass
    else:
        raise UsageError("workspace must be outside the installed skill directory")

    pipeline_dir = workspace / "pipeline"
    config_path = workspace / "mpm-config.json"
    existing = [p for p in (pipeline_dir, config_path, workspace / "workspace.json") if p.exists()]
    if existing:
        raise UsageError(
            "refusing to overwrite existing workspace content: "
            + ", ".join(str(p) for p in existing)
            + " (choose a new directory or remove these yourself)"
        )

    workspace.mkdir(parents=True, exist_ok=True)
    shutil.copytree(
        UPSTREAM_DIR, pipeline_dir,
        ignore=shutil.ignore_patterns("__pycache__", "*.pyc", ".venv", "outputs", "data", "logs"),
    )
    reference_config = pipeline_dir / "config" / "config.yaml"
    if reference_config.is_file():
        shutil.copy2(reference_config, pipeline_dir / "config" / "config.reference-study.yaml")
    shutil.copy2(TEMPLATE_PATH, config_path)
    if not (workspace / "README.md").exists():
        (workspace / "README.md").write_text(WORKSPACE_README, encoding="utf-8")
    adaptations = workspace / "adaptations.md"
    if not adaptations.exists():
        adaptations.write_text(ADAPTATIONS_HEADER, encoding="utf-8")

    provenance = {}
    provenance_path = UPSTREAM_DIR / "SOURCE.json"
    if provenance_path.is_file():
        provenance = load_json_file(provenance_path)
    code_hashes = {
        str(p.relative_to(pipeline_dir)): sha256_file(p)
        for p in sorted(pipeline_dir.rglob("*"))
        if p.is_file() and p.suffix in (".py", ".yaml", ".toml", ".lock")
    }
    write_json_file(workspace / "workspace.json", {
        "schema_version": SCHEMA_VERSION,
        "created": now_iso(),
        "helper": "reference-cases/narr-yilgarn/scripts/workflow.py",
        "helper_sha256": sha256_file(Path(__file__)),
        "reference_provenance": provenance,
        "pipeline_file_sha256_at_init": code_hashes,
    })

    print(f"workspace created: {workspace}")
    print(f"  reference code copy : {pipeline_dir}")
    print(f"  config to fill      : {config_path}")
    print(f"  helper              : {Path(__file__).resolve()}")
    print("next: fill mpm-config.json, then run validate. Nothing was installed or trained.")
    return 0


# --------------------------------------------------------------------------
# validate
# --------------------------------------------------------------------------

# Used only when pyproj cannot be imported (stdlib run); not a complete list.
FALLBACK_GEOGRAPHIC_CRS = ("EPSG:4326", "EPSG:4269", "EPSG:4283", "EPSG:7844", "CRS:84", "WGS84")
FALLBACK_MERCATOR_CRS = ("EPSG:3857", "EPSG:900913", "EPSG:3395")
AXIS_UNIT_TO_DECLARED = {"metre": "m", "meter": "m", "kilometre": "km", "kilometer": "km",
                         "foot": "ft", "us survey foot": "us-ft"}
MERCATOR_WARNING = (
    "is a normal-aspect Mercator CRS: coordinate distances are inflated by about 1/cos(latitude); "
    "block sizes and cell areas in coordinate units are not ground distances/areas. Record the "
    "latitude range and state the ground-equivalent block size, or use a regional projected CRS."
)


def check_crs_properties(crs_value, declared_unit, findings, verified_by=None):
    """Judge the declared CRS by its properties, not by a list of codes.

    Records findings.crs_check = {backend, status, ...}. Status is one of
    verified (pyproj parsed a projected 2D CRS), declared-unverified (no pyproj:
    only a short fallback list was checked), declared-verified-externally
    (no pyproj, but coordinates.crs_verified_by names an independent check) or
    invalid. Import absence and parse failure are different outcomes.
    """
    try:
        import pyproj
        from pyproj import CRS
    except ImportError:
        pyproj = CRS = None
    text = str(crs_value)
    if CRS is None:
        check = {"backend": "none (pyproj not importable)", "crs": text, "status": "declared-unverified"}
        compact = text.upper().replace(" ", "")
        if compact in FALLBACK_GEOGRAPHIC_CRS:
            findings.error("coordinates.crs", f"{text} is geographic (degrees), not projected")
            check["status"] = "invalid"
        if compact in FALLBACK_MERCATOR_CRS:
            findings.warn("coordinates.web_mercator", f"{text} {MERCATOR_WARNING}")
        if check["status"] == "declared-unverified":
            if not is_blank(verified_by):
                check.update(status="declared-verified-externally", verified_by=str(verified_by))
            findings.info("coordinates.crs_properties_unchecked",
                          "pyproj is not importable in this run; CRS type/units were checked only against a short "
                          "list. plan marks this as a blocker and refuses --apply unless coordinates.crs_verified_by "
                          "names an independent check (for example the GIS layer properties or a pyproj run).")
        findings.crs_check = check
        return
    check = {"backend": f"pyproj {pyproj.__version__}", "crs": text}
    try:
        crs = CRS.from_user_input(text)
    except Exception as exc:  # pyproj raises CRSError; keep the helper free of pyproj imports at load time
        findings.error("coordinates.crs", f"{text} is not a CRS that pyproj recognises: {exc}")
        findings.crs_check = {**check, "status": "invalid", "reason": "unparsable"}
        return
    check["name"] = crs.name
    if crs.is_compound:
        findings.error("coordinates.crs", f"{text} ({crs.name}) is a compound CRS; declare its horizontal projected CRS")
        findings.crs_check = {**check, "status": "invalid", "reason": "compound"}
        return
    if crs.is_geographic or not crs.is_projected:
        kind = "geographic" if crs.is_geographic else crs.type_name
        findings.error("coordinates.crs", f"{text} ({crs.name}) is {kind}, not a projected 2D CRS")
        findings.crs_check = {**check, "status": "invalid", "reason": kind}
        return
    method = crs.coordinate_operation.method_name if crs.coordinate_operation else ""
    axes = [(axis.direction, AXIS_UNIT_TO_DECLARED.get((axis.unit_name or "").lower(), axis.unit_name))
            for axis in crs.axis_info]
    check.update(status="verified", method=method, axes=[{"direction": d, "unit": u} for d, u in axes])
    if "mercator" in method.lower() and "transverse" not in method.lower():
        findings.warn("coordinates.web_mercator", f"{text} ({method}) {MERCATOR_WARNING}")
    axis_units = {u for _, u in axes}
    if declared_unit in UNIT_TO_METRE and axis_units and axis_units != {declared_unit}:
        findings.warn("coordinates.unit_mismatch",
                      f"coordinates.unit '{declared_unit}' differs from the axis unit of {text}: {sorted(map(str, axis_units))}. "
                      "Declare the unit of the coordinate columns actually supplied and record any rescaling.")
    if axes and str(axes[0][0]).lower() in ("north", "south"):
        findings.warn("coordinates.axis_order",
                      f"{text} lists a northing axis first; confirm that coordinates.x_column holds easting values.")
    findings.crs_check = check


def check_config_shape(config, findings):
    """Check declared values only (no file access). Returns normalised dict or None."""
    if not isinstance(config, dict):
        findings.error("config.type", "config root must be a JSON object")
        return None
    if config.get("analysis_mode") != "narr-reproduction":
        findings.error("config.analysis_mode", "Explicit analysis_mode=narr-reproduction required; this is not the general MPM entrypoint")
    if config.get("schema_version") != SCHEMA_VERSION:
        findings.error("config.schema_version", f"schema_version must be {SCHEMA_VERSION}")

    def section(name):
        value = config.get(name)
        if not isinstance(value, dict):
            findings.error(f"{name}.missing", f"section '{name}' is missing or not an object")
            return {}
        return value

    data, coords, label = section("data"), section("coordinates"), section("label")
    features, cv = section("features"), section("spatial_cv")
    grid = config.get("grid") if isinstance(config.get("grid"), dict) else {}
    conformal = config.get("conformal") if isinstance(config.get("conformal"), dict) else {}

    if is_blank(data.get("csv_path")):
        findings.error("data.csv_path", "data.csv_path is empty")
    tokens = data.get("missing_tokens")
    if not isinstance(tokens, list) or not all(isinstance(t, str) for t in tokens):
        findings.error("data.missing_tokens", "data.missing_tokens must be a list of strings (use [\"\"] for empty cells only)")
        tokens = [""]

    for key in ("x_column", "y_column", "crs", "unit"):
        if is_blank(coords.get(key)):
            findings.error(f"coordinates.{key}", f"coordinates.{key} is empty; it must be declared, not guessed")
    unit = coords.get("unit")
    if not is_blank(unit) and unit not in UNIT_TO_METRE:
        findings.error(
            "coordinates.unit",
            f"coordinates.unit '{unit}' not supported; use one of {sorted(UNIT_TO_METRE)}. "
            "Degrees are not a distance unit: reproject to a projected CRS first.",
        )
    if coords.get("projected") is not True:
        findings.error(
            "coordinates.projected",
            "coordinates.projected must be true. Spatial blocks are cut in coordinate units, so a "
            "geographic (lon/lat) CRS is not accepted. Reproject in GIS and keep the original file.",
        )
    if not is_blank(coords.get("crs")):
        check_crs_properties(coords.get("crs"), unit, findings, coords.get("crs_verified_by"))

    if is_blank(label.get("column")):
        findings.error("label.column", "label.column is empty")
    for key in ("positive_value", "unlabeled_value"):
        if is_blank(label.get(key)):
            findings.error(f"label.{key}", f"label.{key} is empty")
    if same_value(label.get("positive_value"), label.get("unlabeled_value")):
        findings.error("label.distinct", "positive_value and unlabeled_value must differ")
    if is_blank(label.get("positive_definition")):
        findings.error(
            "label.positive_definition",
            "label.positive_definition is empty: state how positives were assigned "
            "(e.g. cell contains a known deposit of commodity X, source, date, buffer rule)",
        )
    if label.get("unlabeled_is_verified_negative") is not False:
        findings.error(
            "label.unlabeled_is_verified_negative",
            "this workflow is positive-unlabeled: set label.unlabeled_is_verified_negative to false. "
            "If you truly have verified negatives, that is a different problem design and needs its own plan.",
        )

    columns = features.get("columns")
    if not isinstance(columns, list) or not columns or not all(isinstance(c, str) and c for c in columns):
        findings.error("features.columns", "features.columns must be a non-empty list of column names chosen by you")
        columns = []
    if len(set(columns)) != len(columns):
        findings.error("features.duplicates", "features.columns contains duplicate names")
    units = features.get("units") if isinstance(features.get("units"), dict) else {}
    missing_units = [c for c in columns if is_blank(units.get(c))]
    if missing_units:
        findings.error(
            "features.units",
            "features.units needs an entry for every feature (use \"dimensionless\" or \"category-code\" when apt): "
            + ", ".join(missing_units),
        )
    for key in ("log1p_columns", "winsorize_columns"):
        listed = features.get(key, [])
        if not isinstance(listed, list):
            findings.error(f"features.{key}", f"features.{key} must be a list")
            continue
        unknown = [c for c in listed if c not in columns]
        if unknown:
            findings.error(f"features.{key}", f"features.{key} lists columns not in features.columns: {unknown}")
    threshold = features.get("missing_indicator_threshold")
    if not isinstance(threshold, (int, float)) or not 0 <= threshold <= 1:
        findings.error("features.missing_indicator_threshold", "features.missing_indicator_threshold must be a number in [0, 1]")
    reserved = {coords.get("x_column"), coords.get("y_column"), label.get("column")}
    if len(reserved) != 3:
        findings.error("coordinates.distinct", "x, y and label must use distinct columns")
    leaked = [c for c in columns if c in reserved]
    if leaked:
        findings.error("features.reserved", f"label/coordinate columns must not be features: {leaked}")

    block_size = cv.get("block_size")
    if not isinstance(block_size, (int, float)) or isinstance(block_size, bool) or not math.isfinite(block_size) or block_size <= 0:
        findings.error("spatial_cv.block_size", "spatial_cv.block_size must be a positive number chosen for your area")
    if cv.get("block_size_unit") not in ("m", "km"):
        findings.error("spatial_cv.block_size_unit", "spatial_cv.block_size_unit must be 'm' or 'km'")
    if is_blank(cv.get("block_size_rationale")):
        findings.error(
            "spatial_cv.block_size_rationale",
            "spatial_cv.block_size_rationale is empty: say where the size comes from (variogram range, "
            "geological domain scale, or 'provisional, not yet analysed'). The reference 50 km is not a default.",
        )
    for key in ("n_outer_folds", "n_inner_folds"):
        if not isinstance(cv.get(key), int) or isinstance(cv.get(key), bool) or cv.get(key) < 2:
            findings.error(f"spatial_cv.{key}", f"spatial_cv.{key} must be an integer >= 2")
    if not isinstance(cv.get("random_state"), int) or isinstance(cv.get("random_state"), bool):
        findings.error("spatial_cv.random_state", "spatial_cv.random_state must be an integer (recorded seed)")

    methods = config.get("methods")
    if not isinstance(methods, list) or not methods or any(m not in METHODS for m in methods):
        findings.error("methods", f"methods must be a non-empty subset of {list(METHODS)}")
    alpha, delta = conformal.get("alpha"), conformal.get("delta")
    for key, value in (("alpha", alpha), ("delta", delta)):
        if not isinstance(value, (int, float)) or isinstance(value, bool) or not 0 < value < 1:
            findings.error(f"conformal.{key}", f"conformal.{key} must be a number in (0, 1)")
    if conformal.get("path") not in CONFORMAL_PATHS:
        findings.error("conformal.path", f"conformal.path must be one of {list(CONFORMAL_PATHS)}")

    if conformal.get("path") in ("default", "both") and isinstance(cv.get("n_inner_folds"), int) and cv["n_inner_folds"] < 3:
        findings.error("conformal.inner_folds", "default path needs >=3 inner folds for separate train/calibration/test; pooled_oof can use 2")
    if grid.get("equal_area_cells") is not True:
        findings.warn(
            "grid.equal_area_cells",
            "grid.equal_area_cells is not true: cell-count percentages (zone area %, lift tiers, capture per area) "
            "cannot be read as area fractions. Report counts, or weight by true cell area.",
        )
    if findings.count("error"):
        return None
    return {
        "data": data, "coords": coords, "label": label, "features": features,
        "cv": cv, "grid": grid, "conformal": conformal, "tokens": set(tokens),
        "columns": columns,
    }


def scan_csv(csv_path, spec, findings):
    """Single streaming pass over the CSV. Returns summary dict or None."""
    data, coords, label = spec["data"], spec["coords"], spec["label"]
    tokens, columns = spec["tokens"], spec["columns"]
    x_col, y_col, label_col = coords["x_column"], coords["y_column"], label["column"]
    delimiter = data.get("delimiter") or ","
    encoding = data.get("encoding") or "utf-8"
    unit_m = UNIT_TO_METRE[coords["unit"]]
    block_m = spec["cv"]["block_size"] * (1000.0 if spec["cv"]["block_size_unit"] == "km" else 1.0)
    block_coord = block_m / unit_m

    try:
        handle = open(csv_path, "r", encoding=encoding, newline="")
    except OSError as exc:
        findings.error("data.open", f"cannot open CSV: {exc}")
        return None
    with handle:
        reader = csv.reader(handle, delimiter=delimiter)
        try:
            header = next(reader)
        except StopIteration:
            findings.error("data.empty", "CSV is empty")
            return None
        except UnicodeDecodeError as exc:
            findings.error("data.encoding", f"cannot decode CSV as {encoding}: {exc}")
            return None
        header = [h.lstrip("﻿") if i == 0 else h for i, h in enumerate(header)]
        if len(set(header)) != len(header):
            dup = sorted({h for h in header if header.count(h) > 1})
            findings.error("data.header_duplicates", f"duplicate column names in CSV header: {dup}")
            return None
        required = [x_col, y_col, label_col] + columns
        absent = [c for c in required if c not in header]
        if absent:
            findings.error(
                "data.columns_missing",
                f"declared columns not in CSV: {absent}. (The reference code silently drops missing "
                "features in get_feature_matrix; this helper refuses instead.)",
            )
            return None
        index = {name: header.index(name) for name in required}

        n_rows = n_pos = n_unl = 0
        bad_label, bad_coord, short_rows = [], [], 0
        coord_seen, dup_coords = {}, 0
        xs_min = ys_min = math.inf
        xs_max = ys_max = -math.inf
        rows_xy_label = []
        stats = {c: {"missing": 0, "non_numeric": 0, "min": math.inf, "max": -math.inf, "examples": []} for c in columns}

        try:
            for line_no, row in enumerate(reader, start=2):
                if not row or all(cell.strip() == "" for cell in row):
                    continue
                if len(row) < len(header):
                    short_rows += 1
                    row = row + [""] * (len(header) - len(row))
                n_rows += 1

                cell = row[index[label_col]].strip()
                is_pos = same_value(cell, label["positive_value"]) and cell not in tokens
                is_unl = same_value(cell, label["unlabeled_value"]) and cell not in tokens
                if is_pos:
                    n_pos += 1
                elif is_unl:
                    n_unl += 1
                elif len(bad_label) < 5:
                    bad_label.append((line_no, cell))
                x = to_float(row[index[x_col]])
                y = to_float(row[index[y_col]])
                if x is None or y is None:
                    if len(bad_coord) < 5:
                        bad_coord.append(line_no)
                    rows_xy_label.append(None)
                else:
                    xs_min, xs_max = min(xs_min, x), max(xs_max, x)
                    ys_min, ys_max = min(ys_min, y), max(ys_max, y)
                    key = (x, y)
                    if key in coord_seen:
                        dup_coords += 1
                    else:
                        coord_seen[key] = line_no
                    rows_xy_label.append((x, y, is_pos))

                for col in columns:
                    text = row[index[col]].strip()
                    entry = stats[col]
                    if text in tokens:
                        entry["missing"] += 1
                        continue
                    value = to_float(text)
                    if value is None:
                        entry["non_numeric"] += 1
                        if len(entry["examples"]) < 3:
                            entry["examples"].append(text)
                        continue
                    entry["min"] = min(entry["min"], value)
                    entry["max"] = max(entry["max"], value)
        except UnicodeDecodeError as exc:
            findings.error("data.encoding", f"cannot decode CSV as {encoding}: {exc}")
            return None
        except csv.Error as exc:
            findings.error("data.csv", f"CSV parse error: {exc}")
            return None

    if n_rows == 0:
        findings.error("data.empty", "CSV has a header but no data rows")
        return None
    if short_rows:
        findings.warn("data.short_rows", f"{short_rows} rows have fewer cells than the header (treated as empty cells)")

    n_other = n_rows - n_pos - n_unl
    if n_other:
        findings.error(
            "label.values",
            f"{n_other} rows have a label that is neither positive_value nor unlabeled_value "
            f"(first cases line,value: {bad_label}). Missing or third-class labels must be resolved explicitly.",
        )
    if n_pos == 0:
        findings.error("label.no_positives", "no positive rows found with the declared positive_value")
    if n_unl == 0:
        findings.error("label.no_unlabeled", "no unlabeled rows found with the declared unlabeled_value")

    n_bad_coord = sum(1 for item in rows_xy_label if item is None)
    if n_bad_coord:
        findings.error("coordinates.values", f"{n_bad_coord} rows have missing/non-numeric coordinates (first lines: {bad_coord})")
    elif abs(xs_min) <= 180 and abs(xs_max) <= 180 and abs(ys_min) <= 90 and abs(ys_max) <= 90:
        findings.warn(
            "coordinates.degree_like",
            f"coordinate ranges x[{xs_min}, {xs_max}] y[{ys_min}, {ys_max}] look like degrees although a "
            "projected CRS is declared. Check the columns/CRS.",
        )
    if dup_coords:
        findings.warn(
            "coordinates.duplicates",
            f"{dup_coords} rows repeat an earlier (x, y). They always fall in the same block, but they double-count "
            "cells and positives in every metric and area share. "
            "Decide: aggregate, drop, or justify.",
        )

    feature_summary = {}
    for col in columns:
        entry = stats[col]
        n_valid = n_rows - entry["missing"] - entry["non_numeric"]
        rate = entry["missing"] / n_rows
        feature_summary[col] = {
            "missing_rate": round(rate, 6),
            "non_numeric": entry["non_numeric"],
            "min": entry["min"] if n_valid else None,
            "max": entry["max"] if n_valid else None,
            "unit": spec["features"]["units"].get(col),
        }
        if entry["non_numeric"]:
            findings.error(
                "features.non_numeric",
                f"feature '{col}': {entry['non_numeric']} non-numeric values not listed in data.missing_tokens "
                f"(e.g. {entry['examples']}). Encode categories yourself or add the token explicitly.",
            )
        if n_valid == 0:
            findings.error("features.all_missing", f"feature '{col}' has no valid values")
        elif entry["min"] == entry["max"]:
            findings.warn("features.constant", f"feature '{col}' is constant ({entry['min']})")
        if rate > 0.5:
            findings.warn("features.high_missing", f"feature '{col}' is {rate:.1%} missing; mean imputation will dominate it")
        if col in spec["features"].get("log1p_columns", []) and n_valid and entry["min"] <= -1:
            findings.error("features.log1p_domain", f"feature '{col}' is in log1p_columns but has min {entry['min']} <= -1")
    sentinel_like = [c for c, s in feature_summary.items() if s["min"] in (-9999.0, -99999.0, -999.0) or s["max"] in (9999.0, 99999.0)]
    if sentinel_like:
        findings.warn(
            "features.sentinel_like",
            f"features with sentinel-looking extremes (-9999/-999/9999...): {sentinel_like}. If these mean 'no data', "
            "add them to data.missing_tokens AND note that the reference code reads the CSV with pandas defaults, "
            "so the sentinel must also be handled in pipeline/ (see plan).",
        )
    unused = [h for h in header if h not in required]
    if unused:
        findings.info("features.unused_columns", f"columns present but not selected (by your choice): {unused}")

    # spatial block and positive support
    support = None
    if not n_bad_coord and n_pos:
        blocks = {}
        for item in rows_xy_label:
            x, y, is_pos = item
            key = (int((x - xs_min) // block_coord), int((y - ys_min) // block_coord))
            total, pos = blocks.get(key, (0, 0))
            blocks[key] = (total + 1, pos + (1 if is_pos else 0))
        n_blocks = len(blocks)
        pos_blocks = sum(1 for total, pos in blocks.values() if pos > 0)
        k_out, k_in = spec["cv"]["n_outer_folds"], spec["cv"]["n_inner_folds"]
        alpha, delta = spec["conformal"]["alpha"], spec["conformal"]["delta"]
        hoeffding_min = math.ceil(math.log(2.0 / delta) / (2.0 * alpha * alpha))
        train_pos = n_pos * (k_out - 1) / k_out
        expected = {
            "outer_test_fold": n_pos / k_out,
            "default_path_calibration_fold": train_pos / k_in,
            "pooled_oof_path_calibration_pool": train_pos,
        }
        support = {
            "block_size_in_coordinate_units": block_coord,
            "extent_in_blocks": [int((xs_max - xs_min) // block_coord) + 1, int((ys_max - ys_min) // block_coord) + 1],
            "n_blocks": n_blocks,
            "n_blocks_with_positives": pos_blocks,
            "largest_block_share_of_positives": round(max(pos for _, pos in blocks.values()) / n_pos, 4),
            "hoeffding_min_positives": hoeffding_min,
            "expected_positives_if_balanced": {k: round(v, 1) for k, v in expected.items()},
        }
        if n_blocks < k_out or n_blocks - math.ceil(n_blocks / k_out) < k_in:
            findings.error(
                "spatial_cv.too_few_blocks",
                f"{n_blocks} blocks leave too few training blocks for {k_in} inner folds in at least one of {k_out} outer splits. Use fewer folds, "
                "or accept that nested spatial CV is not feasible for this extent.",
            )
        if pos_blocks < k_out:
            findings.error(
                "spatial_cv.positive_blocks",
                f"positives occur in only {pos_blocks} blocks but n_outer_folds={k_out}: some test folds would have no positives.",
            )
        elif pos_blocks < k_out * k_in:
            findings.warn(
                "spatial_cv.positive_blocks",
                f"positives occur in {pos_blocks} blocks: inspect actual inner-fold positive counts after partitioning; "
                "the product of fold counts is not a necessary feasibility bound.",
            )
        if support["largest_block_share_of_positives"] > 0.5:
            findings.warn("spatial_cv.clustered_positives", "one block holds more than half of all positives; fold metrics will be dominated by where it lands")
        paths = spec["conformal"]["path"]
        if paths in ("default", "both") and expected["default_path_calibration_fold"] < hoeffding_min:
            findings.warn(
                "conformal.support_default",
                f"default cross-conformal path: about {expected['default_path_calibration_fold']:.0f} positives per calibration fold, "
                f"but alpha={alpha}, delta={delta} needs >= {hoeffding_min} before ANY threshold can satisfy FNR+Hoeffding <= alpha. "
                "Below that, fnr_control_direct falls back to the minimum calibration score; all calibration samples are included, but inclusion of unseen samples is not guaranteed.",
            )
        if paths in ("pooled_oof", "both") and expected["pooled_oof_path_calibration_pool"] < hoeffding_min:
            findings.warn(
                "conformal.support_pooled_oof",
                f"pooled-OOF path: about {expected['pooled_oof_path_calibration_pool']:.0f} training positives per outer fold "
                f"< {hoeffding_min} needed for a non-vacuous threshold at alpha={alpha}, delta={delta}.",
            )
        if expected["outer_test_fold"] < 10:
            findings.warn(
                "label.test_support",
                f"about {expected['outer_test_fold']:.0f} positives per outer test fold: PR-AUC, coverage and capture will have wide, "
                "unstable fold-to-fold variation. Report per-fold counts next to every metric.",
            )
    prevalence = n_pos / n_rows
    if n_pos and n_pos < 30:
        findings.warn("label.few_positives", f"only {n_pos} positives in total; treat any model result as exploratory")

    return {
        "n_rows": n_rows,
        "n_positive": n_pos,
        "n_unlabeled": n_unl,
        "labelled_positive_rate": round(prevalence, 6),
        "extent": {"x": [xs_min, xs_max], "y": [ys_min, ys_max]} if not n_bad_coord else None,
        "duplicate_coordinate_rows": dup_coords,
        "features": feature_summary,
        "spatial_support": support,
    }


def run_validation(config_path):
    config_path = Path(config_path).expanduser().resolve()
    config = load_json_file(config_path)
    findings = Findings()
    spec = check_config_shape(config, findings)
    summary, csv_path, csv_hash = None, None, None
    if spec is not None:
        csv_path = Path(spec["data"]["csv_path"]).expanduser()
        if not csv_path.is_absolute():
            csv_path = (config_path.parent / csv_path).resolve()
        if not csv_path.is_file():
            findings.error("data.csv_path", f"CSV not found: {csv_path}")
        else:
            summary = scan_csv(csv_path, spec, findings)
            csv_hash = sha256_file(csv_path)
    report = {
        "schema_version": SCHEMA_VERSION,
        "generated": now_iso(),
        "config_path": str(config_path),
        "config_sha256": sha256_file(config_path),
        "csv_path": str(csv_path) if csv_path else None,
        "csv_sha256": csv_hash,
        "passed": findings.count("error") == 0,
        "scope_note": (
            "Checks the declared data contract only. It does not test label quality, feature relevance, "
            "spatial independence of folds, or suitability of the reference method."
        ),
        "counts": {level: findings.count(level) for level in ("error", "warning", "info")},
        "crs_check": findings.crs_check,
        "findings": findings.items,
        "summary": summary,
    }
    return config, spec, report


def print_findings(report):
    for item in report["findings"]:
        print(f"[{item['level'].upper():7}] {item['code']}: {item['message']}")
    counts = report["counts"]
    print(f"-- errors={counts['error']} warnings={counts['warning']} info={counts['info']}")


def cmd_validate(args):
    _, _, report = run_validation(args.config)
    report_path = Path(args.report) if args.report else Path(report["config_path"]).parent / "validation-report.json"
    write_json_file(report_path, report_for_disk(report, report_path.resolve().parent))
    print_findings(report)
    summary = report["summary"]
    if summary:
        print(
            f"rows={summary['n_rows']} positives={summary['n_positive']} unlabeled={summary['n_unlabeled']} "
            f"labelled-positive rate={summary['labelled_positive_rate']:.4%}"
        )
        if summary["spatial_support"]:
            s = summary["spatial_support"]
            print(f"blocks={s['n_blocks']} with positives={s['n_blocks_with_positives']} extent(blocks)={s['extent_in_blocks']}")
    print(f"report: {report_path}")
    if report["passed"]:
        print("RESULT: data contract checks passed (errors=0). This is not a scientific validation; review warnings, then run plan.")
        return 0
    print("RESULT: FAILED. Fix the errors above; plan is blocked until then.")
    return 1


# --------------------------------------------------------------------------
# plan
# --------------------------------------------------------------------------

def render_pipeline_config(config, spec, csv_path):
    cv, features, conformal = spec["cv"], spec["features"], spec["conformal"]
    unit_m = UNIT_TO_METRE[spec["coords"]["unit"]]
    block_m = cv["block_size"] * (1000.0 if cv["block_size_unit"] == "km" else 1.0)
    # reference code computes block edge = block_size_km * 1000 in COORDINATE units
    effective_block_size_km = block_m / unit_m / 1000.0
    bootstrap = config.get("bootstrap") or {}
    optuna = config.get("optuna") or {}
    seed = cv["random_state"]
    rendered = {
        "paths": {"original_data": str(csv_path), "reference_folds": None},
        "output_dirs": REFERENCE_STATIC_CONFIG["output_dirs"],
        "data": {
            "target_column": spec["label"]["column"],
            "coordinate_columns": [spec["coords"]["x_column"], spec["coords"]["y_column"]],
            "feature_columns": spec["columns"],
            "proximity_features": features.get("log1p_columns", []),
            "winsorize_features": features.get("winsorize_columns", []),
            "missing_indicator_threshold": features["missing_indicator_threshold"],
        },
        "spatial_cv": {
            "block_size_km": effective_block_size_km,
            "n_outer_folds": cv["n_outer_folds"],
            "n_inner_folds": cv["n_inner_folds"],
            "stratify": True,
            "random_state": seed,
        },
        "optuna": {
            "n_trials": optuna.get("n_trials", 30), "sampler": "TPE", "pruner": "MedianPruner",
            "pruner_n_startup_trials": 5, "pruner_n_warmup_steps": 10, "direction": "maximize",
            "objective_metric": "pr_auc", "timeout_seconds": None, "n_jobs": 1,
        },
        "bootstrap": {"n_bootstraps": bootstrap.get("n_bootstraps", 50), "random_state": bootstrap.get("random_state", seed)},
        "conformal": {"alpha": conformal["alpha"], "delta": conformal["delta"], "n_iterations": conformal.get("n_iterations", 20)},
        "zone_method": REFERENCE_STATIC_CONFIG["zone_method"],
        "practical_zone_modes": REFERENCE_STATIC_CONFIG["practical_zone_modes"],
        "zone_thresholds": REFERENCE_STATIC_CONFIG["zone_thresholds"],
        "zone_definitions": REFERENCE_STATIC_CONFIG["zone_definitions"],
        "methods": config["methods"],
        "visualization": REFERENCE_STATIC_CONFIG["visualization"],
        "logging": REFERENCE_STATIC_CONFIG["logging"],
        "random_seeds": {"numpy": seed, "sklearn": seed, "optuna": seed, "bootstrap": bootstrap.get("random_state", seed)},
    }
    header = [
        "# Rendered by the reference-case helper from mpm-config.json. Edit mpm-config.json and re-run plan --apply.",
        "# zone_* / visualization values are the reference study's settings, not recommendations.",
    ]
    if unit_m != 1.0:
        header.append(
            f"# NOTE coordinates are in '{spec['coords']['unit']}': block_size_km below is an EFFECTIVE value "
            f"({effective_block_size_km}) so that block_size_km*1000 coordinate units == {block_m} projected-coordinate metres "
            "(a unit conversion, not a ground-distance guarantee)."
        )
    return "\n".join(header + to_yaml(rendered)) + "\n", effective_block_size_km


def collect_adaptations(config, spec, report):
    """Items where the copied reference code will not do the right thing as-is."""
    items = []
    label = spec["label"]
    if not (same_value(label["positive_value"], 1) and same_value(label["unlabeled_value"], 0)):
        items.append(
            "BLOCKER label encoding: reference code uses the target column as numeric 0/1 (sums it, compares == 1). "
            f"Your values are positive={label['positive_value']!r}, unlabeled={label['unlabeled_value']!r}. Derive a 0/1 column in a "
            "NEW file (keep the source), point data.csv_path at it, and record the derivation."
        )
    if spec["data"].get("delimiter", ",") != "," or spec["data"].get("encoding", "utf-8").lower() not in ("utf-8", "utf-8-sig"):
        items.append("BLOCKER CSV delimiter/encoding: reference pandas loaders use comma and UTF-8 defaults; normalize a separate CSV or adapt every loader before running.")
    custom_tokens = sorted(t for t in spec["tokens"] if t not in ("", "NA", "NaN", "nan", "N/A", "NULL", "null", "#N/A", "n/a", "<NA>", "None"))
    if custom_tokens:
        items.append(
            f"BLOCKER missing tokens {custom_tokens}: reference loaders call pandas.read_csv with defaults "
            "(scripts/utils/data_utils.py:load_original_data, scripts/fold_generation/create_outer_folds.py:main), so these "
            "would be read as real values. Pass na_values in both places in pipeline/ or write a cleaned copy of the CSV."
        )
    crs_check = report.get("crs_check") or {}
    if crs_check.get("status") == "declared-unverified":
        items.append(
            f"BLOCKER CRS properties unverified ({crs_check.get('backend')}): the declared CRS was not parsed, so projected "
            "type, axis unit and axis order are unconfirmed. Re-run validate where pyproj is importable, or set "
            "coordinates.crs_verified_by to the independent check you made. plan --apply is refused until then."
        )
    if UNIT_TO_METRE[spec["coords"]["unit"]] != 1.0:
        items.append(
            "CHECK coordinate unit is not metres: plan --apply writes an effective block_size_km so the block edge is right, "
            "but every log line / figure label in pipeline/ that says 'km' or 'm' will be wrong until adapted."
        )
    if report["summary"] and report["summary"]["duplicate_coordinate_rows"]:
        items.append("DECIDE duplicate coordinates: resolve before fold generation (folds are assigned per row).")
    items.extend([
        "KNOWN reference code identifies rows by pandas positional index of the CSV ('index' / 'original_index' in fold files). "
        "Do not reorder, filter or re-export the CSV after creating folds; status compares the CSV hash for this reason.",
        "KNOWN scripts/fold_generation/create_outer_folds.py reads paths.original_data relative to the current directory while "
        "data_utils.load_original_data resolves it against pipeline/. plan --apply therefore writes an absolute path.",
        "KNOWN orchestration (scripts/orchestration/run_single_outer_fold.py, run_all_outer_folds.py) skips stages when an output "
        "file exists, without checking data/config, and main() does not turn a False return into a non-zero exit code. "
        "Prefer the per-stage commands below and check each stage's artifacts.",
        "KNOWN cross_conformal_*.py fix random_state=42 for the XGBoost fits regardless of config seeds.",
        "NOT AVAILABLE deployment prediction for new, unlabeled-area data (fit on all data, score a new grid). Reference "
        "outputs are outer-test-fold predictions only. A predict adapter must be written and checked; see references/modules/modeling.md (skill root).",
        "NOT PORTABLE scripts/analysis/shap_analysis.py, variogram_analysis.py, r*_*.py and scripts/visualization/generate_figure*.py, "
        "_figure_utils.py contain reference-study data paths, column names or EPSG:3857 map assumptions. Generic plots "
        "(plot_cv_metrics, plot_zone_distribution, plot_deposit_capture, plot_spatial_maps) read outputs/ and config only, but are untested on other data.",
    ])
    return items


UNVALIDATED_POINTS = [
    "No stage of the copied pipeline has been executed on this dataset by the helper. Commands below are the reference "
    "entry points, not a verified run.",
    "Label value other than positive means UNLABELED. PR-AUC / ROC-AUC / Brier / ECE against these labels measure agreement "
    "with known positives, not true deposit probability; undiscovered positives count as 'false positives'.",
    "Spatial blocks reduce, but do not prove the absence of, spatial leakage between train and test. Block size adequacy "
    "(vs. autocorrelation range of features AND labels) has not been analysed by this helper.",
    "Cross-conformal coverage 1-alpha is a nominal target. Under spatial dependence and label noise no finite-sample "
    "coverage guarantee follows; report the achieved per-fold coverage with positive counts.",
    "Bootstrap relative IQR captures finite-sample model variability only. The 0.30 cutoff and zone tiers are the reference "
    "study's heuristic decision aid. They are not JORC (or any reporting code) classification and need local recalibration.",
    "Zone area % and lift tiers are cell-count based; valid as area fractions only for equal-area cells.",
    "Hyperparameter ranges (pipeline/config/hyperparameter_ranges.yaml), 50 bootstraps, 30 Optuna trials and the BaggingPU grid "
    "are reference-study choices with reference-study compute cost.",
]


def stage_commands(config, spec):
    k_out = spec["cv"]["n_outer_folds"]
    methods = config["methods"]
    path = spec["conformal"]["path"]
    fold = "$F"
    tune = {"xgboost": "scripts/optuna_optimization/optuna_xgboost.py", "baggingpu_xgboost": "scripts/optuna_optimization/gridsearch_baggingpu_xgboost.py"}
    train = {"xgboost": "scripts/model_training/train_xgboost_bootstrap.py", "baggingpu_xgboost": "scripts/model_training/train_baggingpu_xgboost_bootstrap.py"}
    conf = {"xgboost": "scripts/conformal_calibration/cross_conformal_xgboost.py", "baggingpu_xgboost": "scripts/conformal_calibration/cross_conformal_baggingpu.py"}
    conf_oof = {"xgboost": "scripts/conformal_calibration/cross_conformal_oof_xgboost.py", "baggingpu_xgboost": "scripts/conformal_calibration/cross_conformal_oof_baggingpu.py"}
    run = "uv run python"
    stages = [
        ("1. outer folds (once)", [f"{run} scripts/fold_generation/create_outer_folds.py"],
         "outputs/folds/outer_fold_assignments.csv — inspect positives per fold before going on"),
        (f"2. inner folds (F = 0..{k_out - 1})", ["F=0  # example outer fold; repeat per-fold stages for all folds before aggregation", f"{run} scripts/fold_generation/create_inner_folds.py --outer-fold {fold}"],
         "outputs/folds/inner_folds/outer_fold_F/inner_fold_assignments.csv"),
        ("3. hyperparameter search on inner folds (expensive)", [f"{run} {tune[m]} --outer-fold {fold}" for m in methods],
         "outputs/optuna/xgboost/... or outputs/gridsearch/baggingpu_xgboost/.../best_params.json"),
        ("4. bootstrap ensemble on outer-train, predict outer-test (expensive)", [f"{run} {train[m]} --outer-fold {fold}" for m in methods],
         "outputs/models/METHOD/outer_fold_F/bootstrap_predictions.npz"),
    ]
    if path in ("default", "both"):
        stages.append((
            "5a. cross-conformal, DEFAULT path (each iteration: inner train / one calibration fold / one inner test fold; median params)",
            [f"{run} {conf[m]} --outer-fold {fold}" for m in methods]
            + [f"{run} scripts/test_evaluation/evaluate_test_fold.py --outer-fold {fold} --method {m}" for m in methods]
            + [f"{run} scripts/test_evaluation/compute_deposit_capture.py --outer-fold {fold} --method {m}" for m in methods],
            "outputs/conformal/, outputs/test_evaluation/, outputs/aggregated/  (this is the path run_single_outer_fold.py calls)",
        ))
    if path in ("pooled_oof", "both"):
        stages.append((
            "5b. cross-conformal, POOLED-OOF path (inner out-of-fold predictions pooled; one Platt fit + one FNR threshold)",
            [f"{run} {conf_oof[m]} --outer-fold {fold}" for m in methods]
            + [f"{run} scripts/test_evaluation/evaluate_test_fold_oof.py --outer-fold {fold} --method {m}" for m in methods],
            "outputs/conformal_oof/, outputs/test_evaluation_oof/, outputs/aggregated_oof/  (hard-coded dirs; never mix with 5a artifacts)",
        ))
    aggregation = []
    if path in ("default", "both"):
        aggregation += [f"{run} scripts/result_aggregation/aggregate_fold_results.py --method {m}" for m in methods]
    if path in ("pooled_oof", "both"):
        aggregation += [f"{run} scripts/result_aggregation/aggregate_oof_results.py --method {m}" for m in methods]
    stages.append(("6. aggregate ONCE, only after every outer fold completed steps 2–5", aggregation,
                   "outputs/aggregated/ for default; outputs/aggregated_oof/ for pooled OOF"))
    if path in ("default", "both"):
        stages.append(("7. DEFAULT-path generic plots (not pooled-OOF plots; untested on non-reference data)",
            [f"{run} scripts/visualization/plot_cv_metrics.py", f"{run} scripts/visualization/plot_zone_distribution.py",
             f"{run} scripts/visualization/plot_deposit_capture.py", f"{run} scripts/visualization/plot_spatial_maps.py"],
            "outputs/figures/; adapt readers explicitly to plot pooled-OOF outputs"))
    else:
        stages.append(("7. pooled-OOF visualization requires reader adaptation", [],
            "Do not run generic default-path plots unchanged: they read outputs/aggregated/. Adapt to aggregated_oof/ and verify schema first."))
    return stages


def cmd_plan(args):
    config, spec, report = run_validation(args.config)
    workspace = Path(report["config_path"]).parent
    write_json_file(workspace / "validation-report.json", report_for_disk(report, workspace))
    if not report["passed"]:
        print_findings(report)
        print("RESULT: plan BLOCKED by validation errors. No plan or pipeline config was written.")
        return 1

    csv_path = Path(report["csv_path"])
    yaml_text, effective_block = render_pipeline_config(config, spec, csv_path)
    adaptations = collect_adaptations(config, spec, report)
    blockers = [a for a in adaptations if a.startswith("BLOCKER")]
    stages = stage_commands(config, spec)
    pipeline_dir = workspace / "pipeline"
    warnings = [f for f in report["findings"] if f["level"] == "warning"]
    summary = report["summary"]

    lines = [
        f"# MPM plan — {config.get('project_name') or workspace.name}",
        "",
        f"Generated {report['generated']} by the reference-case helper. **This is a plan, not a result.** Nothing was installed, trained or evaluated.",
        "",
        "## Inputs (recorded)",
        f"- config: `{rel_to(report['config_path'], workspace)}` sha256 `{report['config_sha256']}` (paths relative to this workspace)",
        f"- data: `{rel_to(report['csv_path'], workspace)}` sha256 `{report['csv_sha256']}` (read-only; never modified by the helper)",
        f"- rows {summary['n_rows']}, positives {summary['n_positive']}, unlabeled {summary['n_unlabeled']} "
        f"(labelled-positive rate {summary['labelled_positive_rate']:.4%})",
        f"- CRS {spec['coords']['crs']} unit {spec['coords']['unit']}; block {spec['cv']['block_size']} {spec['cv']['block_size_unit']} "
        f"— rationale: {spec['cv']['block_size_rationale']}",
        f"- folds {spec['cv']['n_outer_folds']} outer x {spec['cv']['n_inner_folds']} inner, seed {spec['cv']['random_state']}; "
        f"methods {config['methods']}; conformal path `{spec['conformal']['path']}` alpha {spec['conformal']['alpha']} delta {spec['conformal']['delta']}",
        f"- features ({len(spec['columns'])}): {', '.join(spec['columns'])}",
        "",
        "## Readiness",
    ]
    if blockers:
        lines.append(f"**NOT RUNNABLE AS-IS: {len(blockers)} blocker(s) below must be resolved in the workspace first.**")
    else:
        lines.append("No blocker detected by the helper. That only means the copied code should be able to *read* this data; it has not been run.")
    lines += ["", "## Validation warnings to resolve or justify"]
    lines += [f"- `{w['code']}` {w['message']}" for w in warnings] or ["- none"]
    lines += ["", "## Adaptation needed / known limits of the copied reference code"]
    lines += [f"- {a}" for a in adaptations]
    lines += ["", "## Unvalidated points (must stay visible in any report)"]
    lines += [f"- {p}" for p in UNVALIDATED_POINTS]
    lines += [
        "", "## Stage commands",
        f"Run inside `{rel_to(pipeline_dir, workspace)}/` (in this workspace) after `plan --apply` has rendered `config/config.yaml`. The first `uv run python` there "
        "creates `pipeline/.venv` from `pipeline/uv.lock` (local to the workspace; needs network or a warm uv cache). "
        "Start with ONE outer fold and ONE method, reduced `optuna.n_trials` / `bootstrap.n_bootstraps` if you only want a smoke run "
        "— and label such a run as a smoke run.",
        "",
    ]
    for title, commands, artifacts in stages:
        lines.append(f"### {title}")
        lines.append("```bash")
        lines.extend(commands)
        lines.append("```")
        lines.append(f"Artifacts: {artifacts}")
        lines.append("")
    lines += [
        "## Record keeping",
        "- Keep `plan.json`, `validation-report.json`, `pipeline/config/config.yaml` and `adaptations.md` with the outputs.",
        "- If the CSV or mpm-config.json changes, re-run plan and delete or move `pipeline/outputs/` (stages skip on file existence).",
        "- Held-out discipline: outer test folds are for final reporting only. Do not tune features, block size, thresholds or zones on them.",
        "",
    ]
    (workspace / "plan.md").write_text("\n".join(lines), encoding="utf-8")

    applied = False
    rendered_path = workspace / "pipeline-config.rendered.yaml"
    rendered_path.write_text(yaml_text, encoding="utf-8")
    crs_blocked = any(b.startswith("BLOCKER CRS properties unverified") for b in blockers)
    if args.apply and crs_blocked:
        print("RESULT: --apply refused: CRS properties are unverified (see plan.md blocker).")
    if args.apply and not crs_blocked:
        target = pipeline_dir / "config" / "config.yaml"
        if not target.parent.is_dir():
            raise UsageError(f"{target.parent} not found; run init first or apply the rendered YAML yourself: {rendered_path}")
        target.write_text(yaml_text, encoding="utf-8")
        applied = True

    write_json_file(workspace / "plan.json", {
        "schema_version": SCHEMA_VERSION,
        "generated": report["generated"],
        "config_sha256": report["config_sha256"],
        "paths_relative_to": "this file's directory",
        "csv_path": rel_to(report["csv_path"], workspace),
        "csv_sha256": report["csv_sha256"],
        "seeds": {"spatial_cv": spec["cv"]["random_state"], "bootstrap": (config.get("bootstrap") or {}).get("random_state", spec["cv"]["random_state"]),
                  "conformal_xgboost_fit": "fixed 42 in reference code"},
        "effective_block_size_km_for_reference_code": effective_block,
        "methods": config["methods"],
        "conformal_path": spec["conformal"]["path"],
        "n_outer_folds": spec["cv"]["n_outer_folds"],
        "blockers": blockers,
        "pipeline_config_applied": applied,
        "pipeline_config_sha256": sha256_file(pipeline_dir / "config" / "config.yaml") if applied else None,
        "executed_stages": [],
    })

    print_findings(report)
    print(f"plan: {workspace / 'plan.md'}")
    print(f"rendered pipeline config: {rendered_path}" + (f" (applied to {pipeline_dir / 'config' / 'config.yaml'})" if applied else " (not applied; use --apply)"))
    if blockers:
        print(f"RESULT: plan written, but NOT RUNNABLE AS-IS: {len(blockers)} blocker(s). See plan.md.")
    else:
        print("RESULT: plan written. No stage has been run; the plan lists adaptation items and unvalidated points.")
    return 1 if args.apply and crs_blocked else 0


# --------------------------------------------------------------------------
# status
# --------------------------------------------------------------------------

def cmd_status(args):
    workspace = Path(args.workspace).expanduser().resolve()
    plan_path = workspace / "plan.json"
    if not plan_path.is_file():
        print(f"no plan.json in {workspace}: run validate and plan first")
        return 1
    plan = load_json_file(plan_path)
    stale = []
    config_path = workspace / "mpm-config.json"
    if not config_path.is_file():
        stale.append("mpm-config.json missing since plan")
    elif sha256_file(config_path) != plan["config_sha256"]:
        stale.append("mpm-config.json changed since plan")
    csv_path = workspace / plan["csv_path"]  # relative to the workspace; older plans stored an absolute path
    if not csv_path.is_file():
        stale.append(f"data file missing: {csv_path}")
    elif sha256_file(csv_path) != plan["csv_sha256"]:
        stale.append("data CSV changed since plan")

    applied_path = workspace / "pipeline" / "config" / "config.yaml"
    if plan.get("pipeline_config_applied"):
        if not applied_path.is_file() or sha256_file(applied_path) != plan.get("pipeline_config_sha256"):
            stale.append("applied pipeline/config/config.yaml missing or changed since plan")
    outputs = workspace / "pipeline" / "outputs"
    print(f"workspace: {workspace}")
    print(f"plan generated: {plan['generated']}  conformal path: {plan['conformal_path']}  config applied: {plan['pipeline_config_applied']}")
    for blocker in plan.get("blockers", []):
        print(f"  unresolved at plan time: {blocker}")
    print(f"outer folds file: {'present' if (outputs / 'folds' / 'outer_fold_assignments.csv').is_file() else 'absent'}")
    for method in plan["methods"]:
        tune_dir = "optuna" if method == "xgboost" else "gridsearch"
        for fold in range(plan["n_outer_folds"]):
            name = f"outer_fold_{fold}"
            checks = {
                "inner": outputs / "folds" / "inner_folds" / name / "inner_fold_assignments.csv",
                "tune": outputs / tune_dir / method / name / "best_params.json",
                "boot": outputs / "models" / method / name / "bootstrap_predictions.npz",
                "conf": outputs / "conformal" / method / name / "median_params.json",
                "eval": outputs / "test_evaluation" / method / name / "metrics.json",
                "conf_oof": outputs / "conformal_oof" / method / name / "median_params.json",
                "eval_oof": outputs / "test_evaluation_oof" / method / name / "metrics.json",
            }
            marks = " ".join(f"{key}={'Y' if path.is_file() else '-'}" for key, path in checks.items())
            print(f"  {method:18} {name}: {marks}")
    print("note: 'Y' means the file exists, not that the stage was correct or used the current data/config.")
    if stale:
        for reason in stale:
            print(f"STALE: {reason}")
        print("RESULT: existing outputs may not correspond to current inputs. Re-run plan and move pipeline/outputs/ aside before continuing.")
        return 1
    print("RESULT: inputs unchanged since plan.")
    return 0


# --------------------------------------------------------------------------

def build_parser():
    parser = argparse.ArgumentParser(
        prog="workflow.py",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    sub = parser.add_subparsers(dest="command", required=True)
    p_init = sub.add_parser("init", help="create a workspace with a copy of the reference code and a config template")
    p_init.add_argument("--mode", required=True, choices=["narr-reproduction"], help="explicitly select reference-study reproduction, not general MPM")
    p_init.add_argument("workspace", help="new or empty directory outside the installed skill")
    p_init.set_defaults(func=cmd_init)
    p_val = sub.add_parser("validate", help="check CSV + JSON config (data contract only)")
    p_val.add_argument("--config", required=True, help="path to mpm-config.json")
    p_val.add_argument("--report", help="where to write the JSON report (default: next to the config)")
    p_val.set_defaults(func=cmd_validate)
    p_plan = sub.add_parser("plan", help="write plan.md/plan.json with commands, adaptation items and unvalidated points")
    p_plan.add_argument("--config", required=True, help="path to mpm-config.json")
    p_plan.add_argument("--apply", action="store_true", help="also write pipeline/config/config.yaml in the workspace")
    p_plan.set_defaults(func=cmd_plan)
    p_status = sub.add_parser("status", help="list stage artifacts and detect changed data/config")
    p_status.add_argument("--workspace", required=True)
    p_status.set_defaults(func=cmd_status)
    return parser


def main(argv=None):
    args = build_parser().parse_args(argv)
    try:
        return args.func(args)
    except UsageError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
