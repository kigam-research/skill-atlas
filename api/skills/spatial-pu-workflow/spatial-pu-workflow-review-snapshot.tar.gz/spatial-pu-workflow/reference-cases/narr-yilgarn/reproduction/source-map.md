# Source map — 참조 코드의 단계·경로·이식 장애 요소

대상: `references/upstream/` (고정된 MIT 원본, 공개 저장소 `kigam-research/mpm-pu-conformal-yilgarn`). 읽기 전용이다. `workflow.py init --mode narr-reproduction`이 이를 `WORKSPACE/pipeline/`에 복사하며, 아래 경로는 그 복사본 기준으로도 같다. 줄 번호는 고정된 원본 기준이다.

이 문서는 코드를 **읽어서** 확인한 내용이다. 이 프로젝트에서 참조 파이프라인을 실행해 확인한 내용은 없다.

## 1. 단계와 진입점

모든 스크립트는 `pipeline/`에서 `uv run python <path>`로 실행하며 `config/config.yaml`을 고정 경로로 읽는다(`scripts/utils/data_utils.py:21 load_config`). config 경로를 인자로 받는 스크립트는 없다.

| # | 단계 | 스크립트 | 인자 | 주요 산출물 (`outputs/` 아래) |
|---|------|----------|------|------|
| 1 | outer spatial block fold | `scripts/fold_generation/create_outer_folds.py` | 없음 | `folds/outer_fold_assignments.csv` (`index,X,Y,block_id,fold_id,target`) |
| 2 | inner fold (outer-train 내부) | `scripts/fold_generation/create_inner_folds.py` | `--outer-fold` | `folds/inner_folds/outer_fold_F/inner_fold_assignments.csv` |
| 3a | XGBoost 탐색 (Optuna, inner fold PR-AUC) | `scripts/optuna_optimization/optuna_xgboost.py` | `--outer-fold --n-trials` | `optuna/xgboost/outer_fold_F/best_params.json` |
| 3b | BaggingPU-XGBoost grid search | `scripts/optuna_optimization/gridsearch_baggingpu_xgboost.py` | `--outer-fold` | `gridsearch/baggingpu_xgboost/outer_fold_F/best_params.json` (경로 하드코딩) |
| 4 | bootstrap ensemble 학습 + outer-test 예측 | `scripts/model_training/train_xgboost_bootstrap.py`, `train_baggingpu_xgboost_bootstrap.py` | `--outer-fold` | `models/METHOD/outer_fold_F/{bootstrap_models/*.joblib, bootstrap_predictions.npz, preprocessor_params.json, training_summary.json}` |
| 5a | cross-conformal **default 경로** | `scripts/conformal_calibration/cross_conformal_xgboost.py`, `cross_conformal_baggingpu.py` | `--outer-fold` | `conformal/METHOD/outer_fold_F/{median_params.json, zone_thresholds.json, iteration_results.csv}` |
| 5b | cross-conformal **pooled-OOF 경로** | `scripts/conformal_calibration/cross_conformal_oof_xgboost.py`, `cross_conformal_oof_baggingpu.py` | `--outer-fold` 또는 `--all` | `conformal_oof/METHOD/outer_fold_F/{oof_predictions.csv, median_params.json, ...}` (경로 하드코딩) |
| 6a | outer-test 평가 (default) | `scripts/test_evaluation/evaluate_test_fold.py`, `compute_deposit_capture.py`, `recompute_zones.py` | `--outer-fold --method` | `test_evaluation/METHOD/outer_fold_F/metrics.json` 등 |
| 6b | outer-test 평가 (pooled-OOF) | `scripts/test_evaluation/evaluate_test_fold_oof.py`, `recompute_zones_oof.py` | `--outer-fold --method` / `--all` | `test_evaluation_oof/...` |
| 7 | 집계 | `scripts/result_aggregation/aggregate_fold_results.py`(6a), `aggregate_oof_results.py`(6b), `compute_roc_auc.py`, `generate_summary_statistics.py` | `--method` | `aggregated/`, `aggregated_oof/` |
| 8 | 그림 | `scripts/visualization/plot_*.py` (범용에 가까움), `generate_figure*.py` (논문 전용) | 대부분 없음 | `figures/` |
| – | 분석 | `scripts/analysis/*.py` | – | 참조 연구 전용 |
| – | orchestration | `scripts/orchestration/run_single_outer_fold.py`, `run_all_outer_folds.py`, `run_final_aggregation.py` | – | `fold_status.json` |

공통 유틸: `scripts/utils/data_utils.py`(로딩), `model_utils.py`(`BaggingPUClassifier`, bootstrap), `conformal_utils.py`(`PlattCalibrator`, `fnr_control_direct`, zone 할당), `metrics_utils.py`, `preprocessing_utils.py`, `visualization_utils.py`. 전처리: `scripts/preprocessing/leakage_free_preprocessor.py`.

## 2. 전처리가 실제로 하는 일

`LeakageFreePreprocessor.fit` (`leakage_free_preprocessor.py:54`)은 **train 데이터에서만** 다음을 구한다.

1. 결측률 > `missing_indicator_threshold`인 열에 `<col>_missing` indicator 추가
2. 모든 열의 **평균** 대치값
3. `winsorize_features`의 1%·99% 분위 경계
4. `proximity_features`에 `log1p` (config 키 이름만 proximity일 뿐 "log1p를 적용할 열 목록"이다)
5. `RobustScaler`

호출 위치는 모두 fit=train, transform=나머지다: `train_xgboost_bootstrap.py:94-95`, `optuna_xgboost.py:112-113`, `cross_conformal_xgboost.py:175-177`, OOF 스크립트의 inner fold 루프. 이 train-only 구조는 수정할 때도 유지한다.

주의: `log1p`는 x ≤ −1에서 정의되지 않는다(−1은 −inf, 그 미만은 NaN. helper가 최솟값 ≤ −1을 error로 검사). −1 < x < 0은 계산되지만 거리류 feature라면 값의 의미를 확인한다. 범주형 열 처리는 없다(숫자만 가정). 평균 대치는 결측이 공간적으로 몰린 열에서 편향을 만든다.

## 3. conformal 두 경로 — 구분해서 다룬다

**default 경로** (`cross_conformal_xgboost.py:155-198`): inner fold 쌍 (calib, test) `n_iterations`개에 대해, 나머지 inner fold로 모델을 학습 → calib fold에서 Platt fit과 FNR 임계 도출 → inner test fold에서 coverage 측정. 즉 **inner train / calibration / inner test가 분리**되어 있다. 최종 파라미터는 iteration들의 **중앙값**(`:227-229`)이다. `run_single_outer_fold.py:202-234`가 호출하는 것은 이 경로와 `evaluate_test_fold.py`다.

**pooled-OOF 경로** (`cross_conformal_oof_xgboost.py`): inner K-fold의 out-of-fold 예측을 outer-train 전체에 대해 모은 뒤, **Platt 한 번 + FNR 임계 한 번**을 pooled OOF에 맞춘다. 같은 pooled 표본에서 Platt fit과 임계 도출, OOF coverage 계산을 모두 한다. orchestration은 이 경로를 호출하지 않는다. 직접 실행해야 하며 평가·집계도 `_oof` 짝을 써야 한다.

어느 쪽이 "정식"인지는 코드만으로 결정되지 않는다. 참조 연구 문서는 최종 decision layer를 OOF 쪽으로 설명하지만, 자동 실행 경로는 default다. 새 데이터에서는 둘을 별도 산출물로 돌려 비교하고, 선택 근거를 기록한다. 두 경로의 산출물을 섞지 않는다.

두 경로에 공통인 점(해석에 영향):

- Platt·임계는 **inner 부분집합으로 학습한 단일 모델**의 점수에서 구하지만, 적용 대상은 **outer-train 전체로 학습한 bootstrap ensemble의 평균**(`evaluate_test_fold.py:113`)이다. 점수 분포가 같다는 보장이 없다. outer-test의 실측 coverage로만 판단한다.
- default 경로의 `zone_thresholds.json`(legacy `percentile_std` 방식)은 bootstrap 모델의 **train 예측**(`train_mean`, `:286-292`)에서 계산된다. 이 값은 in-sample이다. `zone_method: jorc30`/lift 모드에서는 config의 고정 임계를 쓴다.
- `fnr_control_direct` (`conformal_utils.py:71`): Hoeffding 항 `sqrt(ln(2/δ)/(2·n_pos))`를 FNR에 더해 α 이하인 가장 높은 임계를 찾는다. `n_pos`가 `ln(2/δ)/(2α²)` 미만이면(α=0.15, δ=0.05에서 82개) 어떤 임계도 조건을 만족할 수 없고, **calibration 표본의 최소 점수로 떨어진다**(`:107-114`). calibration 표본은 전부 set에 들어가고 선별력이 사라진다. 그보다 점수가 낮은 새 표본은 여전히 제외될 수 있으므로 coverage가 보장되는 것도 아니다. 이때의 높은 coverage는 성과가 아니다. 양성이 0인 calibration fold는 임계 0.0을 반환한다(`:81-83`, n_pos == 0). helper의 `conformal.support_*` warning이 이 조건을 미리 계산한다.
- conformal 스크립트의 XGBoost `random_state`는 42로 고정이다(`cross_conformal_xgboost.py:111`).

## 4. 이식 장애 요소 (새 데이터에 그대로 쓰면 안 되는 지점)

| # | 위치 | 문제 | helper / 대응 |
|---|------|------|------|
| B1 | `config/config.yaml` | `Ni_mine`, `TMX/TMY`, Yilgarn predictor 21개, 50 km, 5×5, B=50은 참조 연구 설정 | `plan --apply`가 사용자 선언으로 새로 렌더링. 원본은 `config.reference-study.yaml`로 보존 |
| B2 | `create_outer_folds.py:32`, `create_inner_folds.py:35` | block 한 변 = `block_size_km*1000` **좌표 단위**. 미터 좌표를 암묵 가정. 도(degree)·feet면 잘못된 분할 | validate가 투영 CRS·단위 선언을 강제하고 지리 CRS 선언을 거부, 도처럼 보이는 좌표 범위는 warning. 미터가 아니면 effective `block_size_km`를 렌더링하고 CHECK 표시 |
| B3 | 참조 연구의 EPSG:3857 | Web Mercator 거리는 약 1/cos(위도)배 부풀려진다(위도 30°에서 약 1.15배). 좌표상 50 km block의 지상 길이는 그보다 짧다. cell 면적도 위도에 따라 달라진다 | validate warning. 지역 투영 CRS 권장 |
| B4 | `data_utils.py:137 get_feature_matrix` | config에 있지만 CSV에 없는 feature를 **조용히 제외** | validate가 누락 열을 error로 처리 |
| B5 | `create_outer_folds.py:128-130` vs `data_utils.py:42-46` | 앞은 `original_data`를 CWD 기준, 뒤는 project root 기준으로 읽는다 | 렌더링 시 절대경로 기록 |
| B6 | `pd.read_csv` 기본값(위 두 곳, `leakage_free_preprocessor.py:212`) | `-9999` 등 sentinel 결측을 실제 값으로 읽는다. 구분자·인코딩 옵션 없음 | plan이 BLOCKER로 표시. `na_values` 추가 또는 정제본 작성 |
| B7 | target 열 사용 (`y.sum()`, `== 1`) | 0/1 숫자 가정 | 다른 인코딩이면 plan BLOCKER. 새 파일에 0/1 열 파생 |
| B8 | 행 식별 = CSV의 pandas 위치 index (`index`, `original_index`) | fold 생성 후 CSV를 재정렬·필터링하면 fold가 어긋난다 | plan/status가 CSV sha256 비교 |
| B9 | orchestration의 skip 로직 (`run_single_outer_fold.py:135,164,188,...`) | 산출물 파일 존재만으로 skip. 데이터·config 동일성 미확인 | 단계별 명령 사용, `status`의 STALE 확인, outputs 이동 |
| B10 | `run_single_outer_fold.py:285` | `main()`이 False 반환을 exit code로 전파하지 않는다. 실패해도 0으로 끝날 수 있다 | 단계별 실행 후 산출물 직접 확인 |
| B11 | `create_inner_folds.py:30-41` | inner block 격자의 원점이 outer-train 부분집합의 최소 좌표다. inner block은 outer block과 정렬되지 않을 수 있다 | 알려진 동작. fold별 양성 수를 확인 |
| B12 | `assign_blocks_to_folds_stratified` | 전역 `np.random.seed` + greedy 배정. 양성 block이 적으면 fold 간 양성 수 불균형·0개 fold 발생 | validate가 양성 block 수 검사 |
| B13 | `BaggingPUClassifier` (`model_utils.py:16-66`) | label 0 전부를 U로 보고 `max_samples=0.35` 비율로 비복원 추출, bag 15개 기본. 값은 참조 연구의 grid 결과 맥락 | 새 데이터에서 grid(`gridsearch_baggingpu_xgboost.py`) 재탐색 필요, 비용 큼 |
| B14 | `scripts/analysis/shap_analysis.py`, `variogram_analysis.py`, `r*_*.py`, `scripts/visualization/generate_figure*.py`, `_figure_utils.py` | Yilgarn 데이터 경로·열 이름·EPSG:3857·지도 자산 고정 | 재사용하지 말고 아이디어만 참고해 새로 작성 |
| B15 | `plot_spatial_maps.py:118,198` 등 | 평가 산출물의 `X`,`Y` 열을 scatter로 그린다. 축 단위·종횡비·basemap 없음. 미검증 | smoke run 산출물로 먼저 확인 |
| B16 | 새 영역 예측 | 없음. 산출물은 outer-test 예측뿐이다. 모델(`*.joblib`)과 `preprocessor_params.json`은 fold별로 저장된다 | adapter 신규 작성 (`references/modules/modeling.md`, `references/modules/uncertainty-calibration.md`) |
| B17 | 의존성 | `pipeline/pyproject.toml`: Python ≥3.12, xgboost, optuna, pulearn, shap, scikit-gstat, geopandas, numba 등. `uv.lock` 포함 | 첫 `uv run python`이 `pipeline/.venv` 생성. helper는 설치하지 않는다 |

## 5. 수정 원칙

- 수정은 `WORKSPACE/pipeline/`에서만 한다. 스킬의 `references/upstream/`은 건드리지 않는다.
- 수정마다 `WORKSPACE/adaptations.md`에 날짜·파일·내용·이유·확인 방법을 남긴다. `workspace.json`에 init 시점의 파일 sha256이 있어 변경 파일을 찾을 수 있다.
- train-only 전처리, outer-test 분리, fold 파일의 index 의미는 바꾸지 않는다. 바꿔야 한다면 그것은 방법 변경이므로 보고서에 명시한다.
