# 명시적인 참조 연구 재현

일반 MPM 분석과 구분한다. 사용자가 narr 연구 재현·원본 이식 자체를 요청했을 때만 이 경로를 사용한다.

1. 스킬 루트의 `references/upstream/SOURCE.json`, `README.md`, `DATA-LICENSE.md`에서 코드 출처·고정 commit·데이터 이용 조건을 확인한다.
2. [source-map](source-map.md)의 원본 가정과 실행 경로를 읽는다. 원본은 수정하지 않는다.
3. `reference-cases/narr-yilgarn/scripts/workflow.py init WORKSPACE --mode narr-reproduction`는 원본을 workspace/pipeline에 복사한다. [dataset-contract](dataset-contract.md)와 template(`../assets/narr-reproduction-config.template.json`)의 근거를 채우고 `validate --config CONFIG`를 실행한다.
4. `plan --config CONFIG [--apply]`는 참조 명령과 적용 장애를 보여 준다. 일반 데이터를 위한 완성 runner가 아니다. 수정은 복사본에서 하고 adaptations.md에 차이를 남긴다.
5. 실제 완료한 단계와 원본 결과 대조만 보고한다. 전체 재현은 아직 이 프로젝트에서 입증하지 않았다.

helper는 `uv run --no-project python`으로 실행한다. 원본의 50 km block, rho/zone heuristic, pooled/default conformal 경로는 일반적 정답이 아니다.

초기 template의 missing indicator 5%, 5×5 folds, 두 모델, 30 trials, B=50, alpha=.15/delta=.05와 helper 내부 REFERENCE_STATIC_CONFIG의 zone 정책은 **이 경로만의 참조 설정**이다. 새 분석의 추천값이 아니다. helper의 data contract도 PU·projected CSV라는 원본 제약이며 일반 MPM 자료 계약을 제한하지 않는다. 일반 분석은 SKILL.md의 M0부터 자료에 맞는 코드를 생성한다.
