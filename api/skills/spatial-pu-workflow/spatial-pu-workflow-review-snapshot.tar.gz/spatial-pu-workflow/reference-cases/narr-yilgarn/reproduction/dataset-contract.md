# Dataset contract — 입력 계약과 설정 예시

이 문서는 재현·이식용 workflow.py helper 전용이다. 아래 제한은 일반 에이전트 분석에 적용되지 않는다. 일반 흐름의 계약은 `references/modules/data-diagnosis.md`와 해당 모듈을 따른다.

helper(`reference-cases/narr-yilgarn/scripts/workflow.py`)가 받는 입력은 **CSV 1개 + JSON 설정 1개**다. 설정 값은 근거(데이터 사전·metadata·이전 사용자 지시)에서 채우고 출처를 기록한다. 근거가 없는 연구 결정만 사용자에게 확인한다. helper는 열 이름에서 label·좌표·feature를 추측하지 않는다. 템플릿은 `reference-cases/narr-yilgarn/assets/narr-reproduction-config.template.json`이며 `init`이 workspace에 `mpm-config.json`으로 복사한다.

## 1. CSV 계약

- 한 행 = 한 격자 cell(또는 표본 지점). 헤더 1행, 열 이름 중복 없음. 열 이름은 공백까지 그대로 비교한다(첫 열의 BOM만 제거).
- 좌표 열 2개: **투영 좌표계**의 x, y. 단위는 `m`, `km`, `ft`, `us-ft` 중 하나. 지리 좌표계(도 단위) 선언은 error다. 좌표값이 작아 도처럼 보이는 것만으로는 warning이다(국소 m/km 좌표일 수 있다). 경위도 데이터는 GIS에서 재투영한 **새 파일**을 만들고 원본은 보존한다.
- label 열 1개: 양성 값과 unlabeled 값 두 가지만 허용. 그 외 값·결측이 있으면 error다.
- feature 열: 숫자. 범주형은 사용자가 직접 인코딩한다. 결측 표기는 `data.missing_tokens`에 모두 적는다.
- fold 생성 이후에는 CSV의 행 순서·행 수를 바꾸지 않는다(참조 코드가 행 위치로 식별한다).
- raster·shapefile은 v1에서 직접 받지 않는다. 같은 격자로 sampling한 CSV로 변환한다(변환 과정도 기록).

## 2. 설정 필드

| 필드 | 의미 | 검사 |
|------|------|------|
| `data.csv_path` | CSV 경로. 상대경로는 설정 파일 기준 | 존재, sha256 기록 |
| `data.delimiter`, `data.encoding` | 기본 `,` / `utf-8` | 참조 코드는 pandas 기본값(쉼표, UTF-8)만 쓴다. 다르면 plan BLOCKER: 별도 정규화 CSV를 만들거나 모든 loader를 수정 |
| `data.missing_tokens` | 결측으로 볼 문자열 목록. 빈칸만이면 `[""]` | 목록 밖의 비숫자 값은 error. `-9999` 같은 사용자 token은 plan에서 BLOCKER |
| `coordinates.x_column`, `y_column` | 좌표 열 | 존재, 숫자. 도처럼 보이는 범위는 warning(`coordinates.degree_like`) |
| `coordinates.crs` | 예: `EPSG:32652` | pyproj가 있으면 속성으로 판정: 지리·geocentric·compound·파싱 불가는 error, 정각 원통(Mercator) 계열은 warning, 축 단위 불일치·northing 우선 축은 warning. pyproj가 없으면 짧은 목록만 검사하고 `declared-unverified`로 기록 |
| `coordinates.crs_verified_by` | pyproj 없이 실행할 때 CRS를 독립적으로 확인한 방법(예: GIS 레이어 속성, 별도 pyproj 실행) | 비어 있고 CRS가 미검증이면 plan BLOCKER이며 `--apply`를 거부한다 |
| `coordinates.projected` | `true`여야 함 | 명시 선언 |
| `coordinates.unit` | `m`/`km`/`ft`/`us-ft` | block 크기 환산에 사용 |
| `grid.cell_size`, `grid.equal_area_cells` | cell 크기(좌표 단위), 동일 면적 여부 | `true`가 아니면 area % 해석 warning |
| `label.column`, `positive_value`, `unlabeled_value` | label 열과 두 값 | 두 값은 서로 달라야 하고 좌표·label 열은 서로 달라야 한다. 다른 값 있으면 error. 1/0이 아니면 plan BLOCKER |
| `label.positive_definition` | 양성을 어떻게 정했는지 서술 | 비어 있으면 error |
| `label.unlabeled_is_verified_negative` | `false`여야 함 | PU 전제의 명시 확인 |
| `features.columns` | 사용할 feature. 사용자가 고른다 | 존재, 숫자, 중복·예약 열 금지, 상수·고결측 warning |
| `features.units` | feature별 단위(`"dimensionless"` 허용) | 전부 필요 |
| `features.log1p_columns` | log1p 적용 열(참조 코드의 `proximity_features`) | 최솟값 ≤ −1이면 error(`features.log1p_domain`). −1 < x < 0은 계산되지만 의미를 확인 |
| `features.winsorize_columns` | 1–99% winsorize 열 | `columns`의 부분집합 |
| `features.missing_indicator_threshold` | 이 결측률 초과 시 indicator 추가 | [0, 1] |
| `spatial_cv.block_size`, `block_size_unit` | block 한 변 (`m`/`km`) | 양수 |
| `spatial_cv.block_size_rationale` | 크기의 근거 | 비어 있으면 error. "잠정"도 허용 |
| `spatial_cv.n_outer_folds`, `n_inner_folds`, `random_state` | fold 수, seed | block 수 ≥ outer, 각 outer 분할의 train block 수 ≥ inner(미달 시 error). default/both 경로는 inner ≥ 3(train/calib/test 분리), pooled_oof는 2 가능. 양성 block 수 < outer면 error, 적으면 warning. 이 경계는 필요조건일 뿐이므로 fold 생성 후 실제 fold별 cell·양성 수를 확인한다 |
| `methods` | `xgboost`, `baggingpu_xgboost` | 부분집합 |
| `optuna.n_trials`, `bootstrap.n_bootstraps`, `bootstrap.random_state` | 비용을 좌우하는 값 | smoke run에서 줄인다 |
| `conformal.alpha`, `delta`, `n_iterations`, `path` | 명목 miscoverage, Hoeffding δ, default 경로 반복 수, `default`/`pooled_oof`/`both` | 양성 지지도 warning |

## 3. validate가 보고하는 것

- **error** → `plan`이 막힌다. 원인을 고치고 다시 실행한다.
- **warning** → 실행은 가능하지만 해석에 영향. 과학적 판단 사항이며, 해소하거나 판단 근거를 기록한다. 주요 코드:
  `conformal.support_default` / `conformal.support_pooled_oof`(양성 수가 Hoeffding 최소치 미만 → 임계가 calibration 최소 점수로 떨어져 선별력이 없어짐), `label.test_support`, `label.few_positives`, `spatial_cv.positive_blocks`, `spatial_cv.clustered_positives`, `coordinates.duplicates`, `coordinates.degree_like`, `coordinates.web_mercator`, `coordinates.unit_mismatch`, `coordinates.axis_order`, `grid.equal_area_cells`, `features.high_missing`, `features.constant`, `features.sentinel_like`.
- **info** → 선택하지 않은 열 목록 등.
- `validation-report.json`의 `crs_check`: backend(pyproj 버전 또는 none), status(`verified` / `declared-unverified` / `declared-verified-externally` / `invalid`), CRS 이름·변환 방법·축 방향과 단위. 일반 속성 검사는 영역 내 거리·면적 왜곡 크기를 검증하지 않는다.
- `validation-report.json`: 행·양성 수, feature별 결측률·범위, block 수, 양성 block 수, fold당 기대 양성 수(균등 배정 가정의 근사치).

validate는 label의 정확성, feature의 지질학적 타당성, fold 간 독립성, fold 밖에서 생긴 누출을 검사하지 못한다.

## 4. 작성 예시 (가상의 데이터)

아래는 형식을 보이기 위한 **가상 예시**다. 열 이름·값은 실제 데이터에 맞게 바꾼다. block 25 km는 권장값이 아니다.

```json
{
  "schema_version": 1,
  "project_name": "example-au-prospectivity",
  "data": {
    "csv_path": "/data/survey/grid_1km_utm52n.csv",
    "delimiter": ",",
    "encoding": "utf-8",
    "missing_tokens": ["", "NA"]
  },
  "coordinates": {
    "x_column": "easting",
    "y_column": "northing",
    "crs": "EPSG:32652",
    "projected": true,
    "unit": "m",
    "crs_verified_by": ""
  },
  "grid": {"cell_size": 1000, "equal_area_cells": true},
  "label": {
    "column": "au_deposit",
    "positive_value": 1,
    "unlabeled_value": 0,
    "positive_definition": "cell contains >=1 Au deposit point from <DB name, version/date>; no buffer",
    "unlabeled_is_verified_negative": false
  },
  "features": {
    "columns": ["rtp_nT", "bouguer_mGal", "dist_fault_m", "k_pct"],
    "units": {"rtp_nT": "nT", "bouguer_mGal": "mGal", "dist_fault_m": "m", "k_pct": "%"},
    "log1p_columns": ["dist_fault_m"],
    "winsorize_columns": ["rtp_nT"],
    "missing_indicator_threshold": 0.05
  },
  "spatial_cv": {
    "block_size": 25,
    "block_size_unit": "km",
    "block_size_rationale": "provisional; variogram of rtp_nT and label not yet analysed, sensitivity at 15/25/40 km planned",
    "n_outer_folds": 5,
    "n_inner_folds": 5,
    "random_state": 42
  },
  "methods": ["xgboost", "baggingpu_xgboost"],
  "optuna": {"n_trials": 30},
  "bootstrap": {"n_bootstraps": 50, "random_state": 42},
  "conformal": {"alpha": 0.15, "delta": 0.05, "n_iterations": 20, "path": "both"}
}
```

## 5. workspace 구조

```
WORKSPACE/
  mpm-config.json              사용자 선언 (입력)
  README.md, workspace.json    init 기록 (SOURCE.json provenance, 파일 sha256). 기존 README.md는 보존
  adaptations.md               pipeline/ 수정 기록
  validation-report.json       validate / plan이 갱신
  plan.md, plan.json           plan 결과 (입력·적용 config hash, seed, BLOCKER, 실행 기록 자리). 설정·CSV·적용된 config.yaml이 없거나 바뀌면 status가 STALE
  pipeline-config.rendered.yaml  렌더링된 참조 코드용 설정
  pipeline/                    참조 코드 복사본 (수정 대상)
    config/config.yaml              plan --apply가 덮어씀
    config/config.reference-study.yaml  원본 연구 설정(보존)
    outputs/                        단계 산출물 (실행 후 생성)
```

원본 CSV는 복사하지 않는다. 참조 코드가 실행 디렉터리 기준으로 경로를 읽기 때문에 렌더된 `pipeline/config/config.yaml`만 원본 CSV를 절대경로로 가리킨다. 이 파일은 그 작업 공간의 실행 설정이며 배포하지 않는다. `validation-report.json`·`plan.json`·`plan.md`는 기록 파일 기준 상대경로와 hash를 쓴다.
