# NARR 최종 그림과 일반 그림 패턴의 출처

일반 그림 기준은 스킬 루트의 `references/figure-patterns.md`, `visualization.md`, `visual-defaults.md`에 있다. 이 문서는 그 기준을 추출한 원 그림과, 새 분석에 옮기지 않을 요소만 기록한다. 원본 이미지·지도 자산은 이 스킬에 포함하지 않는다.

## 추출 근거

개발자가 narr 재제출 최종 Figure 1/2/4/5/6/8의 실제 렌더와 생성 코드를 확인해 일반 패턴을 추출했다. 성능 비교·누적 포착률 패턴은 upstream `scripts/visualization/plot_cv_metrics.py`, `plot_deposit_capture.py`, `generate_figure7.py`의 구현을 참고했다.

| 원 그림 | 일반 패턴의 절 |
|---|---|
| Figure 1 | 데이터 진단 |
| Figure 2 | 공간 평가 |
| Figure 4/5/6 | 점수·불확실성·선별 |
| Figure 8 | 국소 확대 |
| Figure 7 계열 코드 | 성능 비교·누적 포착률 |

실제 narr Figure 7 최종 PDF와 `assets/evaluation_view.py`의 동일성·재현 성공은 확인하지 않았다.

## 옮기지 않는 요소

- EPSG:3857 좌표, 5 km cell, 50 km block, 200 km scale bar
- 연구 전용 방법명, 5개 zone, 85/90/91% 목표선
- 중심 좌표 min/max extent, missing을 Excluded로 채우는 처리, 고정 scalebar
- 'probability' 범례를 검증되지 않은 광상 확률로 쓰는 표현
