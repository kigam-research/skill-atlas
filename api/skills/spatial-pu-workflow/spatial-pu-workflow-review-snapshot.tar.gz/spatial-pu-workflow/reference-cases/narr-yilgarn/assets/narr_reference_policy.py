"""Explicit NARR-style five-zone recipe, NOT a general MPM default.

Only use after choosing this reference policy and recording alternatives.
Parameters have no defaults. See reference-cases/narr-yilgarn/zone-policy.md.
Colors are intentionally absent: visual semantics are a separate guide.
"""
import numpy as np


def narr_practical_zones(rank_fraction, rho, membership, *, tiers, rho_cut):
    """Illustrative NARR-style priorities; -1 means missing, never Excluded.

    Membership is explicit 0/1/NaN. Low scores inside set are Potential even
    when rho is undefined; top-tier rho must be valid. Caller labels meanings.
    """
    rank=np.asarray(rank_fraction,float);r=np.asarray(rho,float);member=np.asarray(membership,float)
    if rank.ndim!=1 or r.shape!=rank.shape or member.shape!=rank.shape:
        raise ValueError('Aligned rank/rho/membership vectors required')
    if len(tiers)!=3 or not 0<tiers[0]<tiers[1]<tiers[2]<=1 or rho_cut<0 or not np.isfinite(rho_cut):
        raise ValueError('Ordered tiers and finite nonnegative rho cut required')
    if ((np.isfinite(rank))&((rank<=0)|(rank>1))).any() or ((np.isfinite(r))&(r<0)).any():
        raise ValueError('Invalid rank fraction or rho')
    if not np.isin(member[np.isfinite(member)],[0,1]).all(): raise ValueError('Membership must be 0/1/NaN')
    result=np.full(len(rank),-1,dtype=int)
    valid=np.isfinite(rank)&np.isfinite(member)
    result[valid&(member==0)]=4
    inside=valid&(member==1)
    result[inside&(rank>tiers[2])]=3
    known=inside&np.isfinite(r)
    result[known]=3
    low=r<=rho_cut
    result[known&(rank<=tiers[2])&low]=2
    result[known&(rank<=tiers[1])]=2
    result[known&(rank<=tiers[1])&low]=1
    result[known&(rank<=tiers[0])]=1
    result[known&(rank<=tiers[0])&low]=0
    return result
