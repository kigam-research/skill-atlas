# Geoprocessing — data support and spatial product properties

These principles apply whether the work uses the optional code examples in `assets/` or another implementation, and whatever form the user asked for (source files, a filtered layer, a sample table, a grid). Record actual data support, transformations, and limitations; code execution alone does not establish scientific validity.

## 1. Coordinates and analysis domain

- Every spatial product declares its CRS. Compute distance, length, area, and density in a CRS whose axis unit defines them (usually a projected CRS chosen for the area); do not apply metre-sized cells or distances to longitude/latitude coordinates.
- A grid's record states requested and used bounds, cell size and unit, row/column order, cell identifier, and whether coordinates represent cell centres or another location.
- To determine whether a location is inside a geographic AOI, transform the location back to the AOI CRS and test the original bbox or polygon. Do not replace a curved transformed boundary with a polygon made only from four projected corners. A projected bbox computed from boundary samples is an approximation; record the sampling density and the estimated deviation, and do not describe it as exact.
- Keep the full rectangular grid when it is needed for spatial indexing, and carry an explicit AOI mask. A separately handed-off subset documents its inclusion rule and the rows and records it excludes. Records that fall in a cell whose centre is outside the AOI need an explicit policy.
- A projected grid with equal-size map cells does not automatically have equal real ground area. Explain area interpretation from the CRS, scale, and projection distortion; leave it unresolved when not established.
- Distances computed from AOI-clipped source features can miss a nearer feature just beyond the request boundary. Record whether full coverage or only intersecting features were received; avoid describing the result as globally nearest when support is clipped.

## 2. Raster support and nodata

- Transform and sample each raster into the declared CRS and resolution using a method suited to the variable's physical meaning. Averaging suits a continuous quantity; a categorical raster needs a class-preserving method such as the centre or majority value. Record the source CRS, native resolution, band, resampling, and nodata treatment.
- Record each variable's unit together with its basis (service metadata, catalogue record, or a cited agency document). Without a basis, mark the unit as unconfirmed rather than inferring it from a name, value range, or convention. A unit read from a field or product name (for example a `_ppm` suffix) is a hint, not a basis: record it as unconfirmed with the hint ("unconfirmed; field name says ppm") unless a data dictionary or metadata states it. A derived quantity (derivative, ratio, reduced-to-pole grid) gets a unit only when both the source unit and the derivation are documented.
- Convert source nodata to actual missing values. Do not use a sentinel such as `-9999` as if it were an observed measurement.
- Compare source and sampled support or summary ranges when feasible. Increased missingness or range changes are evidence to report, not values to conceal.
- Missingness may describe survey coverage. It is not automatically a geological response or a reason to fabricate fill values.

## 3. Vector, geometry, and CRS

- Establish the source CRS from a service declaration, dataset metadata, or a documented data-format rule. Establish output CRS and axis order explicitly where the service permits it. Never guess a coordinate transform.
- Service requests state their coordinates in the CRS the service interprets them in. A WCS 2.x subset, for example, is read in the coverage's native CRS and axis labels (from DescribeCoverage) unless the server supports and is sent another subsetting CRS.
- Transform geometry to a projected CRS before calculating length, area, or distance. Preserve source coordinates or source files and record the transformation.
- Record the feature subset and property predicate used for proximity or class-based values. Columns derived from the same records (a presence flag, a count, a distance) are related, not independent evidence; record which source and filter each came from.
- Converting polygons or lines to points (centroid, representative point) changes support. Apply it only by an explicit rule and record it.
- Polygon fractions require an explicit class rule and overlap method. Prefer structured legend codes over free-text keyword matching, and preserve the selected classes and legend context.
- A rendered map image is not a numeric grid unless a defensible extraction and validation method is documented.

## 4. Sparse point data and support distance

- Within-cell statistics should leave unsupported cells missing rather than imply an observation. Sample count and coverage are support diagnostics.
- If bounded nearest-neighbour filling is scientifically justified, specify a maximum distance. Preserve which cells were filled, the fill limit, remaining missingness, and each cell's distance to the supporting sample, in the unit of the CRS used. Treat support distance as a diagnostic unless the user states another role.
- Do not perform unlimited nearest-neighbour assignment: it duplicates sparse measurements across unsupported areas and creates unbounded extrapolation.
- Multiple columns derived from one source do not become independent observations merely because the table has more columns. Report independent sources and spatial support as appropriate.

## 5. Records turned into cell or area values

- Filter occurrence, sample, or event records by a documented rule (commodity, status, type, date). State whether a positive cell requires a record inside it or uses a buffer; record source date, coordinate precision, and records outside the grid.
- `1` means at least one selected record met the rule; `0` means no selected record in this source and extraction, not verified absence.
- Report counts plainly (cells, records, cells with records, missing fraction per column). Thresholds that turn these counts into warnings depend on the user's purpose; apply them only as stated by the user or the task and record them.
- Validation checks necessary data properties only. It cannot establish record correctness, geological relevance, catalogue completeness, spatial independence, or suitability for any later analysis. Record which checks were run and which remain unknown.
