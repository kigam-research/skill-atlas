# Geoscience Australia (portal.ga.gov.au · ecat · services) — 확인한 접근 경로

> 이 메모는 과거 작업에서 확인한 서비스 사례이며 수집처 후보 목록이나 작업 순서가 아니다. 수집처는 사용자 지역과 목적으로 먼저 조사하고, 이 서비스를 수집처로 확정했을 때만 현재 metadata·라이선스와 대조하는 참고로 쓴다. 아래 확인은 적힌 날짜의 것이며 현재 작업의 확인으로 승계하지 않는다.

확인일: 2026-09-28(UTC). 아래에 2026-09-22 읽기 전용 조사와 2026-09-28 브라우저·경로 점검을 구분해 적었다. 표기: **[V]** 응답·실제 화면에서 직접 확인, **[D]** catalogue/metadata/capabilities에서 확인(서비스 미실행), **[I]** 추정. 서비스는 바뀔 수 있으므로 사용 전 재확인한다.

## robots·약관·라이선스·로그인

- `https://portal.ga.gov.au/robots.txt` → HTTP 200 `text/html` 37,537 B 앱 셸(state `html_shell`) [V]. 사용자 승인 대상이다.
- 닿은 모든 서비스가 익명이며 라이선스는 CC BY 4.0: WCS/WFS capabilities AccessConstraints "© Commonwealth of Australia (Geoscience Australia) 2022. This product is released under the Creative Commons Attribution 4.0 International Licence. http://creativecommons.org/licenses/by/4.0/legalcode" [V]; eCat 기록 131505, ArcGIS copyrightText, NCI licence.txt도 CC BY 4.0 [V]. `www.ga.gov.au/copyright`은 연결 재설정으로 읽지 못했다(재시도 없음).
- 로그인·토큰 요구는 닿은 경로에서 없었다 [V]. 포털 HTML은 `customerdigitalservices.ga.gov.au`(root 403)와 persona 경로를 참조한다 [V].
- WA 광상 DB(GSWA MINEDEX)는 이전 참조 기록에서 CC BY-NC 4.0이었고, GA의 OZMIN 기반 WFS는 CC BY 4.0이다. 기관마다 다르므로 열별 라이선스를 따로 적는다.

## 포털(SPA)과 catalogue (2026-09-28)

- `portal.ga.gov.au`는 실제 Chromium을 headed로 실행하면 앱이 정상 기동한다. 브라우저에서 Layers, Data & Publications 검색, Clip 메뉴를 확인했고 사용자가 desktop Chrome에서도 확인했다 [V]. UI 검색·Clip 흐름은 아직 자동화하지 않았다.
- 이 포털 앱 자산은 일반 브라우저에 실제 JS/CSS를 주지만 `curl`과 headless Chromium(UA에 `HeadlessChrome`)에는 모든 자산 URL에 HTML 앱 셸이 온다(`X-Cache: Error from cloudfront`, JS 경로의 `content-type: text/html`) [V]. 일반 Chrome UA를 위조하는 대신 실제 headed Chromium을 사용한다. 우회·지문 변경은 하지 않는다.
- 브라우저 안에서 읽은 catalogue: `/config/themes/themes-2d.json` 약 1.7 MB, `/config/layers/layers_configuration_part_layers_basic.json` 약 5.2 MB(24,748개 `uid,name,themeIds,personas` 행), `/config/layers/layers_configuration_part_layers_extended.json` 약 173 MB JSON-lines(행당 layer의 type·서비스 URL·description) [V]. discovery는 basic 목록을 쓴다. extended 173 MB 파일은 매번 받지 않는다. 필요한 uid를 한 번 조회하고 결과를 캐시하며 비용을 기록한다.
- Layer catalogue에서 `M01: Ultramafic or Ultramafic-Mafic Rocks`, `M02: Mafic-Ultramafic Rocks`, `OD06: Nickel and PGE Mineral Occurrences`, `Mapped Features (GSWA)`를 확인했다 [V]. M01/M02와 OD06의 mineral potential service는 WMS이며 화면 렌더링만 제공한다. 숫자 값이 필요하면 원자료나 feature query가 되는 공식 linked service를 찾는다.
- 2026-09-28 catalogue 경로 확인에서는 WA bedrock·structure layer가 WA 정부 SLIP 서비스로 연결된다. 자세한 REST/WFS/WMS·필드·라이선스는 [wa-slip.md](wa-slip.md)를 따른다 [V].

## 카탈로그 eCat (GeoNetwork 4.x, `https://ecat.ga.gov.au/geonetwork`)

- 동작: `POST /srv/api/search/records/_search` (Elasticsearch DSL; index `gn-records`, 필드 `eCatId`, `uuid`, `resourceTitleObject.default`, `resourceType`, `link[]{protocol,url}`, `geom`, `crsDetails`, 라이선스 필드) [V]; CSW `GetRecordById`(ISO 19115-3 `mdb`) [V]; `https://pid.geoscience.gov.au/dataset/ga/{eCatId}` → 303 → 기록 페이지 [V].
- 고장: OGC API Records 500 [V]; CSW `GetRecords` + CQL `like '%…%'`는 서버 예외(`%` 변환 오류) [V].
- 다운로드 CDN: `https://d28rz98at9flks.cloudfront.net/{eCatId}/{eCatId}_NN_M.{zip|pdf|…}` 익명, HEAD 200 [V]. 전국 격자 ZIP은 2–18 GB다 [D].

## `services.ga.gov.au` — 경로별 차단과 열린 경로

- 아래 geology/REST/WMS/WFS 경로는 PC74와 무관한 cloud network에서 `curl`, Python `urllib`, 실제 headless Chromium으로 각각 요청했고 모두 HTTP 403 CloudFront `Request blocked.`였다 [V]. 동일 endpoint를 재시도하거나 다른 User-Agent·실행 모드로 우회하지 않는다.
  - `/gis/rest/services`
  - `/site_1/services/GA_Surface_Geology/MapServer`
  - `/site_3/services/Geological_Provinces_2013/MapServer`
  - `/gis/geology/ows`, `/gis/geoscience/ows`, `/gis/ows` (WFS/WMS GetCapabilities)
- `/gis/earthresource/wfs`는 같은 확인에서 HTTP 200이었다 [V]. 2026-09-22 시험에서 열어 둔 `/gis/geophysical-grids/wcs`, `/gis/critical-minerals/wfs`, `/gis/rest/services/AustralianOperatingMines/MapServer`도 기존 열린 경로다 [V].
- GA `/gis/mineral-potential/wcs`는 HTTP 200, coverage 88개였으며 sediment-hosted Cu/Zn-Pb, carbonatite REE, IOCG 등을 포함하나 magmatic nickel은 없다 [V]. 이 endpoint가 막히거나 상품 계열이 없으면 portal catalogue와 연결된 주 survey 서비스를 확인한다.
- `/gis/services/MineralPotentialMapper/MapServer/WMSServer`는 HTTP 200이며 M01/M02 ultramafic layers와 OD06 Ni-PGE occurrences를 이미지로 렌더링한다 [V]. WMS 이미지는 숫자 값 자료가 아니다.

## 지구물리 격자 — WCS 2.0.1 `https://services.ga.gov.au/gis/geophysical-grids/wcs`

101 coverage, 출력 CRS 43종, `image/tiff` [V]. 확인한 GetCoverage 형식(60×60 float32 GeoTIFF 17,005 B) [V]:

```
?service=WCS&version=2.0.1&request=GetCoverage&coverageId=geophys__magmap_v7_2019_TMI
 &subset=Lat(-31.00,-30.95)&subset=Long(121.00,121.05)&format=image/tiff
```

| 자료 | coverageId | eCat | 격자 CRS·해상도 | nodata |
|---|---|---|---|---|
| TMI Grid of Australia 2019 7th ed. 80 m | `geophys__magmap_v7_2019_TMI` | 131505 (DOI 10.26186/5e9cf3f2c0f1d) | EPSG:4283, 0.0008333°, 58,399×41,886 [V] | −99999 [V, DescribeCoverage] |
| TMI 40 m | `geophys__magmap_v7_2019_TMI_40m` | 131512 | EPSG:4283 [I] | — |
| TMI VRTP | `geophys__magmap_v7_2019_RTP` | 131519 | EPSG:4283 | — |
| TMI 1VD | `geophys__magmap_v7_2019_1VD` | 132275 | EPSG:4283 | — |
| Enhanced products (VRTP 0.5VD/1VD/AS/Phase/pGRAV/pSUSP/VBzz/upward continuation) | `geophys__magmap_v7_2019_VRTP_*` | 140052 | EPSG:4283 | — |
| Radmap v4 2019 filtered K % / Th ppm / U ppm | `geophys__radmap_v4_2019_filtered_pctk` / `_ppmth` / `_ppmu` | (K 미확보) / 131967 / 131974 | EPSG:4283; 112.7175…153.6715, −43.7615…−9.0005 | — |
| Radmap unfiltered, ratios, dose | `geophys__radmap_v4_2019_unfiltered_*`, `_ratio_tk/_uk/_ut/_u2t`, `_filtered_dose` | 131978/131988/131994 | EPSG:4283 | — |
| 2019 national gravity (CSCBA, FAA, DGIR, 0.5VD/1VD/tilt) | `geophys__Gravmap2019-grid-grv_dtgir`, `…-grv_cscba`, `…-grv_fa`, `geophys__2019_A7_DGIR_v2`, … | pid 148676 계열 | — | — |
| 2016 isostatic residual gravity | GA WCS에는 없음. NCI THREDDS NetCDF/OPeNDAP/NCSS, GSKY WCS 1.0.0 `gravmap2016_grid_grv_ir` | 101105 | 0.008333°, 4,100×5,000 | — |
| 2015 편(재현용) | `geophys__magmap_V6_2015`, `geophys__radmap_v3_2015_*` | — | — | — |

nodata가 `—`인 coverage는 DescribeCoverage로 확인하거나 내려받은 GeoTIFF의 nodata 태그·최솟값을 검사한 뒤 `sample_raster(src_nodata=…)`에 넘긴다. 확인(2026-09-22 DescribeCoverage): `geophys__Gravmap2019-grid-grv_dtgir` nilValue −999999, `geophys__radmap_v4_2019_filtered_pctk` nilValue −99999. 내려받은 GeoTIFF에도 같은 nodata 태그가 있었다.

**단위는 WCS로 알 수 없다.** DescribeCoverage의 `swe:uom code`는 두 coverage 모두 `W.m-2.Sr-1`(GeoServer 자리표시자)이다 [V]. 단위는 eCat 기록 본문에서 읽는다. 예: DGIR 격자는 eCat 144778 "National Gravity Compilation 2019 DGIR grid"이며 초록에 "The data are given in units of um/s^2, also known as 'gravity units', or gu"라고 적혀 있다 [V, `_search` 응답]. 즉 GA 2019 중력 격자의 단위는 **µm/s² (gu)**이고 mGal이 아니다(1 mGal = 10 gu). 1VD 단위(nT/m)는 아직 eCat 132275 본문으로 확인하지 않았다. GSKY WCS 1.0.0(`https://gsky.nci.org.au/ows/national_geophysical_compilations`)은 19 coverage를 제공하지만 bounding box를 전역으로 보고하므로 DescribeCoverage를 먼저 본다 [V].

## 광상·광산 기록 — WFS 2.0.0 `https://services.ga.gov.au/gis/earthresource/wfs` (eCat 144672, OZMIN 기반)

- 형식 [V]: `ama:MineralDeposits`(광산·광상), `ama:MineralOccurrences`(주 정부 조사 자료), `ama:MineralOccurrencesDiscoveryAndExploration`, `ama:MineralDepositTemporalControls`, `ama:ReservesAndResources`, EarthResourceML `er:/erl:` 뷰 등 16종. 기본 CRS `urn:ogc:def:crs:EPSG::4283`. BBOX/Intersects/DWithin, 결과 paging(`count`, `startIndex`), 출력 `application/json`, `application/geo+json`, `csv`, `SHAPE-ZIP` 등.
- 확인한 GetFeature(bbox는 **lat,lon 순서** + CRS urn) [V]:

```
?service=WFS&version=2.0.0&request=GetFeature&typeNames=ama:MineralDeposits&count=2
 &outputFormat=application/json&bbox=-32,120,-30,122,urn:ogc:def:crs:EPSG::4283
```
  → `numberMatched: 491`, point geometry(lon, lat), 속성 19개: `ENO, DEPOSIT_NAME, SYNONYMS, STATE, LONG_GDA94, LAT_GDA94, ACCURACY_M, OPERATING_STATUS, COMMODITY_CODES, DEPOSIT_GROUP, DEPOSIT_TYPE, PROVINCES, …` [V].
- 다른 후보: Australian Operating Mines(ArcGIS REST, 점 레이어 3개: Operating/Developing/Care&Maintenance; eCat 147181–147183, 150435) [V]; Critical Minerals WFS `https://services.ga.gov.au/gis/critical-minerals/wfs`(전 세계 광상 지화학·prospectivity model, GA/GSC/USGS, CC BY 4.0) [V].
- 기록의 의미: 이 레코드는 알려진 광상/광산이며 기록이 없음이 부재를 뜻하지 않는다. 이 기록으로 값을 만들면 `ACCURACY_M`(좌표 정밀도)과 `OPERATING_STATUS`, 상품 코드 필터를 정의에 적는다.

## 이 서비스에서 확인한 사용 방법(2026-09 사례)

- 자료군 목록: portal basic catalogue에서 후보 uid를 찾고, 필요한 경우에만 extended layer record 한 건을 조회했다.
- 격자: 이 WCS의 coverage는 경위도 축 `Lat`/`Long`이어서 경위도 subset을 썼다. 다른 coverage는 DescribeCoverage의 축 이름과 CRS를 먼저 확인한다.
- 점 기록: OZMIN WFS를 bbox와 paging으로 받았다.
- 403인 경로는 그 경로에서 멈췄다. 같은 자료를 다른 기관에서 찾는 것은 사용자가 확정한 수집처 범위 안에서만 한다.

## 로컬 종단 확인 (2026-09-22)

공개 WCS coverage와 WFS를 실제로 받아 투영 격자 표를 만들었다. robots timeout을 사이트 전체 장애로 취급하지 않는다. CSW GetRecordById에 숫자 eCatId를 넣으면 HTTP200이어도 빈 XML이 올 수 있으므로 레코드 존재를 검사한다. eCat search API에서 eCatId와 UUID를 구분하여 후속 조회한다. SPA UI 전체 동작과 실제 로그인은 이 시험의 완료 범위가 아니다.
