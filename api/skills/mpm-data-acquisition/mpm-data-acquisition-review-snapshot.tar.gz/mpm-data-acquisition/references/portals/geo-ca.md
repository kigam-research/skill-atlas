# GEO.ca (Natural Resources Canada) — 확인한 접근 경로

> 이 메모는 과거 작업에서 확인한 서비스 사례이며 수집처 후보 목록이나 작업 순서가 아니다. 수집처는 사용자 지역과 목적으로 먼저 조사하고, 이 서비스를 수집처로 확정했을 때만 현재 metadata·라이선스와 대조하는 참고로 쓴다. 아래 확인은 적힌 날짜의 것이며 현재 작업의 확인으로 승계하지 않는다.

확인일: 2026-09-28(UTC). catalogue·약관 조사와 robots 확인은 2026-09-22 읽기 전용 GET 30회(1 req/s), 403/429 없음이며, 아래 GeoYukon layer counts는 2026-09-28 갱신이다. 표기: **[V]** 응답에서 직접 확인, **[I]** 추정(미실행). 서비스는 바뀔 수 있으므로 사용 전 재확인하고 날짜를 갱신한다.

## robots·약관·라이선스

- `https://geo.ca/robots.txt` → `User-agent: * / Disallow:` (present, 전체 허용) [V]. `https://app.geo.ca/robots.txt` → 404 (absent) [V]. 두 host 모두 현재 사용자·작업 범위의 승인이 필요하다.
- 약관: `https://geo.ca/terms-and-conditions/` (FR `https://geo.ca/fr/avis/`). "Use of open data available through GEO.ca is permitted, subject to and in accordance with the terms of the Open Government Licence – Canada, or a provincial or territorial Open Government Licence. A link to the specific terms of the licence is provided in the metadata" [V].
- 라이선스는 **기록별** `useLimits`에 있다. NRCan 기록 4건 = "Open Government Licence - Canada (http://open.canada.ca/en/open-government-licence-canada)"; Yukon 기록 = "Open Government Licence - Yukon (https://open.yukon.ca/open-government-licence-yukon)" [V]. 기록마다 읽고 provenance에 적는다.
- 로그인 요구: 카탈로그 검색·기록 조회·시험한 서비스 metadata에서 없음 [V].

## 구조

- `geo.ca`는 WordPress, `app.geo.ca`는 SvelteKit [V]. UI 검색은 서버 라우트 `https://app.geo.ca/en-ca/map-browser/__data.json?search-terms=…`(devalue 인코딩, 내부용·불안정) [V]. 브라우저 번들 5개에서 `geocore.api.geo.ca` 문자열은 없었고 기록 페이지의 metadata 링크만 `https://geocore.metadata.geo.ca/{uuid}.geojson`을 가리킨다 [V].
- 공개 API host `https://geocore.api.geo.ca` [V]:
  - `GET /geo?keyword=…&lang=en&min=1&max=10&north=…&south=…&east=…&west=…` — **bbox 4개 필수**. 빠지면 HTTP 200에 Lambda 오류 본문(`errorType`, "Invalid WKT")이 온다. 본문을 검사한다 [V]. 응답 `{Items[], Count, total}`; `Items[].options`/`contact`는 **이중 인용된 JSON 문자열**이라 unescape 후 파싱한다 [V]. 경로·매개변수 이름은 오픈소스 geocore 지식에서 가져와 응답으로 확인했다 [I→V].
  - `GET /id/v2?id={uuid}&lang=en` — 기록 1건. `body.Items[0]`에 `options[] {url, protocol, name{en,fr}, description{en,fr}}`, `useLimits`, `refSys`, `distributionFormat_*`, `spatialRepresentation` [V]. `description.en` 형식은 `"<Dataset|Web Service|…>;<ZIP|WMS|ESRI REST|GPKG|SHP|GeoTIF|…>;<eng|fra>"` [V].
  - `GET https://geocore.metadata.geo.ca/{uuid}.geojson` — 같은 내용의 GeoJSON(footprint polygon, 이중 언어) [V].
  - 루트 `/` → 404 `Missing Authentication Token` [V].
- ISO XML: `https://csw.open.canada.ca/geonetwork/srv/csw?service=CSW&version=2.0.2&request=GetRecordById&outputSchema=csw:IsoRecord&ElementSetName=full&id={uuid}` (기록 페이지 링크, 미실행) [V/I].

## 확인한 자료 기록(지구물리·지질·광상)

| 자료 | 기록 id | 배포 형식 | subset | CRS | 라이선스 |
|---|---|---|---|---|---|
| Canada magnetic compilation (RTF, 1VD; 1 km·200 m) | `752fe3fc-d871-5ae1-9bd9-2b6f65880a8d` | ZIP(GRD) 랜딩 페이지 `http://gdr.agg.nrcan.gc.ca/gdrdap/dap/index-eng.php?dapid=129/130/138/140`, WMS `http://wms.agg.nrcan.gc.ca/wms2/wms2.aspx` | 없음(전국 ZIP). WMS는 렌더 이미지 | EPSG:3978 | OGL-Canada |
| Canada gravity compilation (2 km) | `5a4e46fe-3e52-57ce-9335-832b5e79fecc` | ZIP dapid=21,73–78, WMS | 없음 | EPSG:3978 | OGL-Canada |
| Canada radiometric compilation (250 m; K, eTh, eU, ratios) | `289c931c-a1b1-55f8-8d93-4d88e66f1810` | ZIP dapid=132,133,141,134–137, WMS | 없음 | EPSG:3978 | OGL-Canada |
| Bedrock Geological Units (GIN) | `4a8963bd-7833-8cd1-1236-329e5e41556c` | BBOX 다운로드 페이지 `https://gin.gw-info.net/service/api_ngwds:gin2/en/data/standard.download.html?THEME=2&BBOX=…`, WMS | BBOX 매개변수 [I] | EPSG:4326 | OGL-Canada |
| Predictive model of graphite (H3 hexagon prospectivity) | `48d4c7dc-e7a2-1399-4b14-d5acfc23a895` | GPKG(ftp.maps.canada.ca), MapServer `https://maps-cartes.services.geo.ca/server_serveur/rest/services/NRCan/graphite_prospectivity_en/MapServer` | ESRI REST query(envelope) [V metadata: Query/Map/Data, JSON/geoJSON, maxRecordCount 1000] | wkid 3979 | OGL-Canada |
| Yukon Mineral Occurrences 250k (MINFILE point) | `7f095b49-10b6-4f12-96d7-59bcc9a9c070` | MapServer layer `https://mapservices.gov.yk.ca/arcgis/rest/services/GeoYukon/GY_Geological/MapServer/4`, Shapefile 디렉터리 `https://map-data.service.yukon.ca/GeoYukon/Geological/Mineral_Occurrences_250k/` | ESRI REST query: point Feature Layer, JSON/geoJSON/PBF, pagination, maxRecordCount 1000, `supportsDatumTransformation` [V] | wkid 3578(NAD83/Yukon Albers) | OGL-Yukon |

검색 결과 수(semantic, `__data.json`): aeromagnetic 155(상위는 Yukon Geological Survey 조사별 격자, 예 `e5d0a8e0-a200-4bd8-8939-d12e5278f31c` Llewellyn RTF: GeoTIFF/GRD ZIP on `ygsftp.gov.yk.ca`, OGL-Yukon), gravity anomaly 80, radiometric 66, bedrock geology 504, mineral deposits occurrences 281 [V]. 국가 컴필레이션은 `org=Natural+Resources+Canada` 필터를 더해야 상위에 온다 [V].

광상·광점 기록 후보: Yukon MINFILE(필드 `MINFILE_NUMBER, MINFILE_NAME, DEPOSIT_TYPE, DEPOSIT_STATUS, MAIN_COMMODITY, LATITUDE_DD, LONGITUDE_DD, LAST_MODIFIED_DATE` [V]); Yukon Mineral Deposits by Property/Zone(`…/MapServer/120`); NRCan 900A Principal Mineral Areas/Producing Mines(`https://maps-cartes.services.geo.ca/server_serveur/rest/services/NRCan/900A_and_top_100_en/MapServer/1`, 기록 미조회); Alberta·BC·Saskatchewan 지역 자료(라이선스 미확인). 단일 전국 광상 point DB는 첫 페이지 검색에서 찾지 못했다(검색은 비완전).

## 배포 host의 robots (2026-09-22 확인)

- `https://mapservices.gov.yk.ca/robots.txt` → `User-agent: * / Disallow: /` (present, **전체 경로 제한 안내**) [V]. 이 서비스 관측만으로 접근 승인을 추론하지 않는다. 현재 사용자·현재 작업·요청 경로와 일치하는 승인만 적용하며, 이미 같은 범위로 기록된 유효한 승인은 다시 묻지 않는다. 실제 HTTP 인증·접근제어와는 별개다.
- `https://ygsftp.gov.yk.ca/...zip` → 비브라우저 클라이언트에 Cloudflare JS challenge(403 "Just a moment…") [V]. 우회하지 않는다. 사용자가 브라우저로 받은 파일은 recipe `local_file`로 넣는다.
- `https://geocore.api.geo.ca/robots.txt` → 404(absent) [V].

## 제약

1. `wms.agg.nrcan.gc.ca`·`gdr.agg.nrcan.gc.ca`는 plain HTTP이며 이 개발 환경의 프록시에서 503/연결 재설정으로 닿지 못했다 [V, 환경 한정]. 국가 지구물리 격자는 WMS(렌더)와 전국 ZIP만 제공하므로 subset은 내려받은 뒤 로컬에서 자른다.
2. `/geo`의 오류는 HTTP 200 본문에 숨는다. `Items` 유무와 `errorType`을 검사한다.
3. 기록의 `Dataset;ZIP` 링크가 HTML 랜딩 페이지인 경우가 많다(두 번째 hop 필요, 미시험).
4. 라이선스가 연방/주·준주별로 다르다. 표의 열별 라이선스로 기록한다.
5. `__data.json`은 내부 라우트다. helper는 `/geo` + `/id/v2`를 쓴다.

## 이 서비스에서 확인한 사용 방법(2026-09 사례)

- 배포 host: 카탈로그 host(`geo.ca`, `app.geo.ca`, `geocore.api.geo.ca`)와 기록이 가리키는 배포 host(예 `mapservices.gov.yk.ca`, `maps-cartes.services.geo.ca`, `ygsftp.gov.yk.ca`)가 따로 있다.
- 자료군 목록: `/geo`(bbox 필수)로 후보를 찾고 `/id/v2`로 `options`·`useLimits`를 읽었다.
- 받기: ESRI REST 레이어는 envelope query(geoJSON)로, GeoTIFF/GRD ZIP은 크기를 HEAD로 확인한 뒤 예산 안에서 받았다. WMS 이미지는 숫자 값 자료가 아니다.

## GeoYukon geology and structure (2026-09-28)

공식 [`GY_Geological` MapServer](https://mapservices.gov.yk.ca/arcgis/rest/services/GeoYukon/GY_Geological/MapServer)에서 다음 feature layer를 확인했다 [V]. 사용 licence는 Open Government Licence – Yukon (OGL-Yukon)이며 앞의 dataset record에서 확인한다.

| Layer | Dataset | Geometry | Count intersecting lon −135..−134, lat 60..60.5 |
|---:|---|---|---:|
| 113 | Bedrock Geology | Polygon | 260 |
| 114 | Faults | Line | 307 |
| 115 | Contacts | Line | 567 |

세 layer는 모두 `maxRecordCount=1000`이고 위 영역 query의 결과 수는 제한 이하이다 [V]. 각 query에서 AOI envelope와 `outSR=4326` 또는 요청 grid CRS를 명시하고, 반환 CRS를 확인한 뒤 reprojection한다. Layer 113은 lithology polygon coverage, layer 114 faults, layer 115 contacts의 area fraction·line density·predicate-filtered distance 계산에 쓸 수 있다. source record·class rule·licence와 없는 family의 시도를 handoff coverage table에 남긴다.

암상 분류값은 `ROCK_CLASS`·`ROCK_SUBCL` 같은 구조화 필드로 고른다. Yukon 지구물리 격자는 `ygsftp.gov.yk.ca`의 Cloudflare challenge 뒤에 있어(위 배포 host 절, 2026-09-22 확인) 자동 접근하지 않는다. 사용자가 직접 받은 격자는 출처·권리·해시를 확인한 뒤 로컬 자료로 검토할 수 있다.
