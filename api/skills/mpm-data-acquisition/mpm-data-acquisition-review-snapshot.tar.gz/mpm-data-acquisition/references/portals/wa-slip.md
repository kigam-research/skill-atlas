# Western Australia SLIP — geology and structure

> 이 메모는 과거 작업에서 확인한 서비스 사례이며 수집처 후보 목록이나 작업 순서가 아니다. 수집처는 사용자 지역과 목적으로 먼저 조사하고, 이 서비스를 수집처로 확정했을 때만 현재 metadata·라이선스와 대조하는 참고로 쓴다. 아래 확인은 적힌 날짜의 것이며 현재 작업의 확인으로 승계하지 않는다.

확인일: 2026-09-28(UTC). 표기: **[V]** REST response·AOI query에서 직접 확인, **[D]** WA catalogue record에서 확인, **[I]** inferred. Host별 승인·요청 budget을 적용하고, 사용 전에 metadata·license·layer fields를 다시 확인한다.

## Official services

- REST MapServer: [`Geology_and_Soils_Map`](https://public-services.slip.wa.gov.au/public/rest/services/SLIP_Public_Services/Geology_and_Soils_Map/MapServer). `services.slip.wa.gov.au` 별칭도 연결된다. Capabilities `Map,Query,Data`, `maxRecordCount=1000`, pagination 지원, spatial reference WKID 7844(GDA2020) [V]. Feature queries support an AOI envelope and `outSR=4326`; the returned GeoJSON without a CRS member uses RFC 7946 longitude/latitude coordinates [V].
- WMS 대안: [`.../MapServer/WMSServer`](https://public-services.slip.wa.gov.au/public/rest/services/SLIP_Public_Services/Geology_and_Soils_Map/MapServer/WMSServer). 시각화용 이미지이며 속성값 추출을 대체하지 않는다 [V].
- WFS 대안: [`Geology_and_Soils_Map_WFS/MapServer/WFSServer`](https://public-services.slip.wa.gov.au/public/rest/services/SLIP_Public_Services/Geology_and_Soils_Map_WFS/MapServer/WFSServer). 사용 전에 GetCapabilities에서 layer·CRS·출력 형식을 확인한다 [V].

## Useful layers

| ID | Dataset | Geometry | Useful fields / use |
|---:|---|---|---|
| 4 | 1:500 000 State interpreted bedrock geology (DMIRS-016) | Polygon | `objectid, gid, code, unitname, descriptn, symbol`. `code` is the GSWA legend code; build class predicates on it and check them against `descriptn` [V]. |
| 21 | 1:100 000 interpreted bedrock geology (DMIRS-038) | Polygon | Higher map detail where coverage and source scale support the AOI [V]. |
| 22 | Bedrock geology lines 1:100 000 (DMIRS-052) | Line | Geological contacts/lines; inspect layer fields before building a column [V]. |
| 23 | Linear structures 1:100 000 (DMIRS-053) | Line | Mapped structure lines; inspect feature type and fields [V]. |
| 1 | 1:500 000 State linear structures (DMIRS-015) | Line | `feature, type, name, dip, ...`; `feature` includes `Fault or shear zone` [V]. |
| 2 | 1:2 500 000 structural lines (DMIRS-013) | Line | Regional-scale structural context [V]. |
| 3 | 1:2 500 000 bedrock (DMIRS-014) | Polygon | Regional lithology context [V]. |
| 14 | Tectonic units 1:500 000 (DMIRS-037) | Polygon | Tectonic setting [V]. |
| 28 | Major crustal boundaries of WA, 2021 (DMIRS-082) | Line | Regional boundary-distance feature; sparse at local AOI scale [V]. |
| 27 | Large igneous provinces (DMIRS-081) | Polygon | Regional magmatic context [V]. |
| 29 | WA Moho (DMIRS-083) | Surface/grid | Deep-crust diagnostic; confirm available query/export form [V]. |
| 5, 6 | Regolith products | Grid/polygon | Surface cover and weathering context; inspect per-layer metadata [V]. |
| 20 | GSWA geochemistry (DMIRS-047) | Point | Samples/assays; filter records and preserve sample support [V]. |

Layer density differs by scale. Layer 21 can exceed `maxRecordCount` for a regional AOI; use `resultOffset` pagination and confirm expected/received counts and the stop reason. This service observation was checked 2026-09-28 [V].

## Query and grid conversion

Use `/MapServer/{layerId}/query` with AOI geometry, `inSR=4326`, `outSR=4326`, `returnGeometry=true`, `f=geojson`, and only required `outFields`. Page at or below 1,000 records using `resultOffset` and `resultRecordCount`. Do not download or use an entire layer when the AOI query is sufficient.

GeoJSON polygons can become area-weighted `polygon_fraction` columns. For categorical geology, choose named classes with a documented property predicate; do not silently one-hot encode every unit. Lines can become `line_density` or predicate-filtered `distance` features. Transform GeoJSON from EPSG:4326 to the recipe's projected grid CRS before measuring area, length, or distance. Record source scale, predicate, method, role, and limitations in column metadata.

## Catalogue, licence, and attribution

- WA Data catalogue CKAN `package_show` for package id `1-500-000-state-interpreted-bedrock-geology-dmirs-016` records **Creative Commons Attribution-NonCommercial 4.0 (CC BY-NC 4.0)** [D]. This differs from GA CC BY 4.0; keep licence metadata per source/column.
- Catalogue record: [`data.wa.gov.au` package](https://catalogue.data.wa.gov.au/api/3/action/package_show?id=1-500-000-state-interpreted-bedrock-geology-dmirs-016). Use its current publisher and attribution wording. Suggested attribution: “Geological Survey of Western Australia (GSWA), Department of Mines, Industry Regulation and Safety (DMIRS), State interpreted bedrock geology 1:500 000 (DMIRS-016), CC BY-NC 4.0.” Confirm current agency wording from the record before publishing [D].
- The catalogue has full-state download links, but these are national/state-scale files rather than an AOI subset [D]. Query the AOI through REST first; use a state-wide file only when small enough and explicitly within the approved size/licence budget.

## Class rules: codes before free text

`descriptn` is free text and may name minor components, so a keyword match can select units whose main rock is something else. Build the rule on the legend `code` (or another structured field), list the codes it selects with their `descriptn`, check matched and unmatched classes against the legend, and record the rule, the code list and the check in column metadata. A class fraction is a named-class value, not a universal categorical encoding.
