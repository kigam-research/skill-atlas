# Browser control — conditional use and diagnostics

Use a real browser only when a service requires JavaScript rendering, browser-only downloads, or user interaction. When a documented public API, OGC/ArcGIS service, or static file gives the same data or metadata, use a standard HTTP client instead: a page load sends many subresource requests (scripts, styles, images) that also count against the approved hosts and request interval.

## Request control

- Route every browser request through a host allow-list and the request budget before navigation (`browser_session.RequestGate`, installed on the context). Each allowed request waits for the interval, so page loads are serialized; raise navigation timeouts rather than the rate.
- Block resource types that reconnaissance does not need (images, media, fonts by default).
- Fetch each allowed request without following redirects and check the redirect target before requesting it. A redirect to an unapproved host is refused and recorded; stop and ask the user about the scope.
- Block service workers in the browser context; they can issue requests outside routing.
- Known gap: Chromium's own favicon request to the page origin is not routed. Report it rather than claiming every request was spaced.
- Save the gate log (every request, action, wait) with the network log so that the interval and host scope can be verified afterwards. Browser automation libraries and the local `browser_session.py` helper are replaceable implementation examples.

## Safe operating conditions

- Use the browser's normal identification and TLS validation. Do not alter its fingerprint, disable certificate checks, or bypass a WAF/challenge.
- Record the navigation response status. A 401/403 means stop and record; do not retry headed/headless or with another client.
- A confirmed app-shell symptom is an app script/style request answered with `text/html`. Provider-specific headers (for example a CDN error-cache header) are recorded as auxiliary evidence; they do not by themselves establish the symptom. Only when navigation was not 401/403 may a headless attempt retry headed, and only if a display is available. The retry continues the same request budget and host list. Do not retry repeatedly.
- A local browser launch failure is an environment problem, not evidence that the portal is inaccessible. Report the executable/version mismatch or sandbox failure and ask the environment operator to supply a compatible browser or approved launch configuration. Do not automatically relax the browser sandbox.
- When a TLS-intercepting proxy causes a certificate error, have the operator install its CA in the trusted browser/OS store. Do not ignore or disable certificate validation.
- A dedicated profile or CDP connection can retain authentication. Use a task-specific profile; do not attach a normal personal profile. State files containing cookies are secrets and must be stored with restrictive permissions outside tracked files.

## Reconnaissance

1. Check that the current user's approval covers the navigation host and intended paths before sending any request to it, including robots.txt. A prior approval from another task or user is not transferable. Apply a recorded robots crawl-delay to the request interval when it is longer.
2. Open the requested page in the real browser, capture the navigation response status, and wait only as needed. `networkidle` alone does not prove authentication succeeded.
3. Make only the minimum UI interactions needed to identify catalogue or service structure. Record API candidates and response metadata; capture response bodies only when necessary and after considering sensitive values.
4. Verify field names, CRS, licence text, subset support, and distribution URLs from the current response or catalog record. Store the findings in the current workspace with source and check date.
5. If a URL discovered in browser traffic is later requested by another client, apply the same host authorization, rate limit, and provenance requirements to that request.

## App-shell and access-denied diagnostics

The app-shell heuristic applies only to script/style resources answered with HTML in place of JavaScript/CSS. A provider error header alongside it is supporting evidence, not the condition. A 401/403 navigation is an access refusal, not an app-shell retry condition. Store its status and stop. Other errors should be classified from the actual response, not inferred from a robots timeout or a local browser launch failure.

Network logs, snapshots, and screenshots may contain account information or other sensitive content. Redaction is not guaranteed to catch arbitrary secrets. Keep raw evidence private, capture only what is needed, and do not publish browser storage state.
