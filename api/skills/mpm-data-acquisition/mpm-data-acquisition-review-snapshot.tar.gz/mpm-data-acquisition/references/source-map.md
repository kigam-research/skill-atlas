# Source map — pinned browser crawler reference

`references/upstream-web-crawler/` preserves the upstream `byungjunjang/web-crawler` reference at commit `c64cfbf98c3d72054e2960affd663726f4e9d7f6` under its MIT license. It is pinned and read-only; per-file SHA-256 values are recorded in `SOURCE.json`. Generalized code in `assets/` and `scripts/` is maintained separately, so the preserved original is not a required runtime dependency.

## Concepts adapted

| Reference concept | Generalized implementation | Adaptation |
|---|---|---|
| Discover a portal, inspect its service, collect, validate, and report | This skill's workflow | Output is the product the user asks for (source files, lists, spatial tables) with metadata and file provenance |
| Rate limiting and request budgets | `assets/fetch_budget.py` | Configurable interval and request cap; repeated 429/503 stops |
| Consent and robots observations | `assets/robots_gate.py` | User- and task-scoped authorization; robots observations remain advisory evidence |
| Browser session and API discovery | `assets/browser_session.py` | Real-browser session, response metadata, optional user-driven authentication |
| Resume and intermediate evidence | Downloader provenance and table metadata | File hashes and request signatures support verified reuse |

The implementation preserves the principles of transparent identification, restrained requests, user-controlled authentication, and recorded failures. It does not adopt stealth, fingerprint alignment, WAF evasion, or CAPTCHA bypass behavior.

## Maintained components

- `assets/grid_table.py`: projected-grid construction, raster/vector operations, point-record presence and support diagnostics, table checks, metadata, and preview rendering.
- `assets/downloader.py`: streamed file retrieval, byte limits, SHA-256, provenance, and verified reuse.
- `assets/fetch_budget.py`: request interval, total cap, and repeated-failure stop condition.
- `assets/robots_gate.py`: scoped consent records and robots observations.
- `assets/browser_session.py`: optional browser session, response recorder, and environment-only credentials.
- `scripts/acquire.py`: optional recipe-based runner that turns ESRI query, WFS, WCS GeoTIFF, and file sources into a projected grid table.
- `scripts/handoff_check.py`: optional role-based artifact and content checker.
- `references/portals/`: dated service cases from earlier work (access conditions, catalogue details, licensing notes); checked against current metadata before use.

The runner and helper classes are examples, not mandatory interfaces. Any replacement must preserve the access, provenance, spatial, and validation properties described in `SKILL.md` and `acquisition-contract.md`.
