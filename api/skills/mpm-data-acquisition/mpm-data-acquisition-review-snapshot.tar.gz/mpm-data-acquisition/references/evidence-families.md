# Evidence families — from a purpose to the data it needs

This is guidance for discovery, not a fixed list. The families below are common kinds of geoscience data; a purpose decides which of them matter. A missing family means the corresponding evidence was not obtained or is not represented in the selected data; it does not mean the geology, structure, anomaly, alteration, occurrence, or event is absent.

## Deriving families from the purpose

1. Restate what the user wants to describe, map, compare, or explain, and at what scale and area.
2. List the observable properties that bear on it (rock type, structure, physical properties, chemistry, surface condition, recorded occurrences or events, terrain, time).
3. Map each property to the data families that measure it and the forms they come in (numeric grid, vector, sample table, rendered map, document).
4. Note what support each family needs to be useful for the purpose: coverage of the AOI, resolution or map scale, sample density, date, documented units and classes, licence.
5. Present the families you judge necessary with a one-line reason each, and let the user add or drop families (`intake-and-source-discovery.md`). Use the user's own knowledge of the target and cited literature where the purpose is specialised; do not rely on a fixed template.

For every family judged necessary, search the chosen sources' catalogues and linked official services, then the dataset record's AOI download or subset. Record attempts and limitations. Do not call a result complete for the purpose if a necessary family is missing.

| Family | Typical forms | What a gap means |
|---|---|---|
| Geology / lithology | Map polygons with legend codes, unit descriptions, map scale | The mapped unit footprint is unrepresented; not evidence that a unit is absent. |
| Structure | Fault, shear, fold, contact, lineament lines with type and confidence | Structural relations and distances are unresolved, not zero. |
| Geophysics | Numeric grids (magnetic, gravity, radiometric, electromagnetic, seismic), survey footprints | The physical-property evidence is untested; a missing grid is not a low or negative anomaly. |
| Geochemistry | Sample tables with medium, method, detection limits; interpolated grids | Chemical coverage is unknown; no samples does not imply background values. |
| Alteration / mineral mapping | Mapped alteration zones, spectral mineral products, logged alteration | Hydrothermal or mineralogical evidence is unevaluated. |
| Regolith / cover / soil | Regolith, weathering, transported cover, soil maps | Surface conditions that mask or modify other signals are unknown. |
| Occurrence and event records | Points or polygons for deposits, mines, boreholes, samples, landslides, earthquakes, springs | The record set is unavailable or incomplete; an area without records is not verified free of them. |
| Terrain and remote sensing | Elevation models, imagery, derived indices | Terrain or surface-cover context is not represented. |
| Hydrogeology and other thematic data | Aquifer maps, water levels, land use, infrastructure | The thematic context is not represented. |

## Categorical data and class rules

- Keep the source class and its legend. Do not silently one-hot explode every category.
- An area fraction of named classes is a numeric value only when the class rule is explicit. Prefer structured legend codes or class fields over keyword searches in free-text descriptions, which also match minor components ("with minor ultramafic rock"). List the classes a rule selects and check them against the legend before building the column.
- State the property, predicate, source scale, overlap/union method, and role in column metadata.
- Polygon fractions and line density require projected geometry. Distance values record any property predicate used to select the features.
- A catalogue map service may expose only rendered images. Do not treat a WMS image as a numeric grid without a documented extraction and validation method.

## Geochemistry: support, censoring and sampling programmes

- Report sample support per cell or area: the number of samples and the share of in-AOI cells with at least one sample. Leave cells without samples missing; fill only within a stated maximum distance and keep the support distance as a diagnostic.
- Keep sample media apart (rock, soil, stream sediment, laterite, drill core, water). Different media and digestion or analytical methods do not share a scale; combine them only with a documented reason, and otherwise build separate columns or filter to one medium.
- Values below detection are censored, not measured zeros. Detect the service's coding (negative numbers, text such as `<5`, sentinel values like `-9999`) from its documentation or field definitions, convert sentinels to missing, and record how censored values were treated.
- Harmonise units (ppb, ppm, %, oxide wt%) only with a documented basis, and record the basis per column.
- Sampling programmes are not neutral: mine, prospect, and drillhole programmes concentrate samples around known occurrences, while regional surveys sample more evenly. Record the sample programme or type for each column, and when sample values and an occurrence-record column come from related programmes, note the relation for the user rather than silently dropping either.
- Sample density itself reflects survey effort; treat it as a diagnostic unless the user states another role.

## Alteration versus regolith and cover

- Hydrothermal alteration evidence means mapped alteration assemblages or zones, alteration-mineral products (for example spectral mineral maps with documented band ratios), or alteration logged in samples. Regolith, weathering, laterite, and transported-cover maps describe surface conditions, not hydrothermal alteration.
- Name each column by what it represents. A regolith or cover column may be useful context or a diagnostic for masking and support, but it does not fill the alteration family. When no alteration product was obtained, report the family as not obtained and say which products were searched.
- Remote-sensing mineral products need their product definition, spatial resolution, and masks (vegetation, cloud, cover) recorded; masked pixels are missing, not low values.
