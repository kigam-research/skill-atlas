"""Check a grid-table hand-off written in the optional runner's format (`acquire.py`, metadata schema 2).

It reads the table CSV, its metadata (grid, `columns` with a role per column, validation, provenance)
and the hand-off report. Other outputs (source files only, vector layers, sample tables) need their own
checks. No state or analysis configuration file is required.

Usage:
  uv run python handoff_check.py --table PATH --metadata PATH --report PATH \
      [--state PATH] [--preview PATH] [--handoff-table PATH] [--json PATH]

Exit codes: 0 when all required checks pass; 1 for any failed check, missing required
artifact, or required check that could not be performed.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import re
import sys
from pathlib import Path

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(HERE), "assets"))

import artifact_paths  # noqa: E402


def sha256_file(path: str) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as stream:
        for chunk in iter(lambda: stream.read(1 << 16), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _load_json(path: str) -> dict:
    with open(path, encoding="utf-8") as stream:
        value = json.load(stream)
    if not isinstance(value, dict):
        raise ValueError("expected a JSON object")
    return value


def _numeric(value: str) -> float | None:
    if value is None or value == "":
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _read_csv(path: str) -> tuple[list[str], list[dict[str, str]]]:
    with open(path, encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        if not reader.fieldnames:
            return [], []
        return list(reader.fieldnames), list(reader)


def _file_references(report_path: str) -> list[tuple[str, str | None]]:
    text = Path(report_path).read_text(encoding="utf-8")
    candidates: list[str] = []
    for match in re.finditer(r"`([^`\n]+)`|\]\(([^)\s]+)(?:\s+[^)]*)?\)", text):
        value = (match.group(1) or match.group(2) or "").strip().strip("<>")
        if not value or value.startswith(("http://", "https://", "mailto:", "#", "external:")):
            continue
        value = value.split("#", 1)[0]
        if not value or not ("/" in value or "\\" in value or "." in os.path.basename(value)):
            continue
        candidates.append(value)
    results: list[tuple[str, str | None]] = []
    seen: set[str] = set()
    base = os.path.dirname(os.path.abspath(report_path))
    for ref in candidates:
        if ref in seen:
            continue
        seen.add(ref)
        resolved = os.path.abspath(ref) if os.path.isabs(ref) else os.path.abspath(os.path.join(base, ref))
        results.append((ref, resolved if os.path.exists(resolved) else None))
    return results


UNCONFIRMED_UNITS = {"unconfirmed", "unknown", "미확인", "not confirmed"}
HEX64 = re.compile(r"(?<![0-9a-fA-F])[0-9a-fA-F]{64}(?![0-9a-fA-F])")


def _report_hash_mismatches(report_path: str, references: list[tuple[str, str | None]],
                            known: dict[str, str]) -> tuple[int, list[str]]:
    """Compare every SHA-256 written in the report with the files it names or with known artifact hashes.

    A line that names a resolvable file must carry that file's current hash. A hash on a line that
    names no file must equal some known artifact or provenance hash. Returns (hash count, problems).
    """
    base = os.path.dirname(os.path.abspath(report_path))
    resolved = {ref: path for ref, path in references if path and os.path.isfile(path)}
    file_hash: dict[str, str] = {}
    problems: list[str] = []
    count = 0
    for number, line in enumerate(Path(report_path).read_text(encoding="utf-8").splitlines(), 1):
        hashes = [h.lower() for h in HEX64.findall(line)]
        if not hashes:
            continue
        count += len(hashes)
        named = [path for ref, path in resolved.items() if ref in line]
        if not named:
            named = [os.path.join(base, token) for token in re.findall(r"[\w./-]+\.[A-Za-z0-9]+", line)
                     if os.path.isfile(os.path.join(base, token))]
        for value in hashes:
            if named:
                # A line that names files must carry one of those files' current hashes; a hash of some
                # other artifact on that line is a mismatch, not a pass.
                actual = []
                for path in named:
                    if path not in file_hash:
                        file_hash[path] = sha256_file(path)
                    actual.append(file_hash[path])
                if value not in actual:
                    problems.append(f"line {number}: {value[:12]}… does not match "
                                    f"{', '.join(os.path.basename(n) for n in named)}")
            elif value not in known:
                problems.append(f"line {number}: {value[:12]}… matches no artifact or provenance hash")
    return count, problems


def check_handoff(table_path: str, metadata_path: str, report_path: str, *, state_path: str | None = None,
                  preview_path: str | None = None, handoff_table_path: str | None = None) -> dict:
    checks: list[dict] = []
    roles = {"table": table_path, "metadata": metadata_path, "report": report_path}
    if state_path:
        roles["state"] = state_path
    if preview_path:
        roles["preview"] = preview_path
    if handoff_table_path:
        roles["handoff_table"] = handoff_table_path

    def check(name: str, status: str, detail: str = "", required: bool = True) -> None:
        if status not in {"pass", "fail", "missing", "not_checked"}:
            raise ValueError(f"invalid check status: {status}")
        checks.append({"check": name, "status": status, "required": required, "detail": detail})

    warnings: list[str] = []
    loaded: dict[str, dict] = {}
    for role in ("table", "metadata", "report", "state", "preview", "handoff_table"):
        path = roles.get(role)
        if not path:
            continue
        required = role in {"table", "metadata", "report"}
        exists = os.path.isfile(path)
        check(f"{role}_exists", "pass" if exists else "missing", "file exists" if exists else "file not found", required)
        if exists and role in {"table", "metadata", "report", "state", "preview", "handoff_table"}:
            if role in {"table", "report", "preview", "handoff_table"}:
                nonempty = os.path.getsize(path) > 0
                check(f"{role}_non_empty", "pass" if nonempty else "fail",
                      "non-empty file" if nonempty else "empty file", required)
            if role in {"metadata", "state"}:
                try:
                    loaded[role] = _load_json(path)
                    check(f"{role}_json_readable", "pass", "valid JSON object", required)
                except (OSError, ValueError, json.JSONDecodeError) as exc:
                    check(f"{role}_json_readable", "fail", f"{type(exc).__name__}", required)

    metadata = loaded.get("metadata") or {}
    table_exists = os.path.isfile(table_path) and os.path.getsize(table_path) > 0
    if table_exists and metadata:
        expected_hash = ((metadata.get("table") or {}).get("sha256")
                         if isinstance(metadata.get("table"), dict) else None)
        if expected_hash:
            actual_hash = sha256_file(table_path)
            check("table_hash_matches_metadata", "pass" if actual_hash == expected_hash else "fail",
                  "SHA-256 matches" if actual_hash == expected_hash else "SHA-256 mismatch")
        else:
            check("table_hash_matches_metadata", "fail", "metadata table hash is absent")

        try:
            headers, rows = _read_csv(table_path)
            check("table_csv_readable", "pass" if headers else "fail",
                  "CSV header and rows read" if headers else "CSV header is absent")
            grid = metadata.get("grid") or {}
            expected_rows = grid.get("n_cells")
            if expected_rows is None:
                check("table_rows_equal_cells", "not_checked", "metadata grid.n_cells is absent")
            else:
                check("table_rows_equal_cells", "pass" if len(rows) == int(expected_rows) else "fail",
                      f"rows={len(rows)} cells={expected_rows}")

            id_column = grid.get("cell_id_column", "cell_id")
            if id_column not in headers:
                check("cell_ids_unique", "fail", f"cell id column {id_column!r} is absent")
            else:
                ids = [row.get(id_column, "") for row in rows]
                unique = all(value != "" for value in ids) and len(set(ids)) == len(ids)
                check("cell_ids_unique", "pass" if unique else "fail",
                      "all cell identifiers are present and unique" if unique else "missing or duplicate cell identifiers")

            x_column, y_column = grid.get("x_column", "x"), grid.get("y_column", "y")
            bounds = grid.get("bounds_used")
            if not all(name in headers for name in (x_column, y_column)) or not bounds or len(bounds) != 4:
                check("coordinates_inside_grid", "not_checked", "coordinate columns or grid bounds are absent")
            else:
                minx, miny, maxx, maxy = map(float, bounds)
                coordinates_ok = all(
                    (x := _numeric(row.get(x_column))) is not None
                    and (y := _numeric(row.get(y_column))) is not None
                    and minx <= x <= maxx and miny <= y <= maxy
                    for row in rows)
                check("coordinates_inside_grid", "pass" if coordinates_ok else "fail",
                      "coordinates are numeric and inside grid bounds" if coordinates_ok else "invalid or out-of-bounds coordinates")

            columns = metadata.get("columns") if isinstance(metadata.get("columns"), dict) else {}
            grid_columns = {id_column, "row", "col", x_column, y_column}
            undeclared = [h for h in headers if h not in grid_columns
                          and not (isinstance(columns.get(h), dict) and columns[h].get("role"))]
            check("column_roles_declared", "pass" if not undeclared else "fail",
                  "every data column has a role in metadata" if not undeclared else f"no role: {undeclared}")

            value_columns = {n: s for n, s in columns.items() if isinstance(s, dict) and s.get("role") == "value"}
            presence_columns = [n for n, s in columns.items()
                                if isinstance(s, dict) and s.get("type") == "point_presence"]
            if not value_columns:
                check("value_columns_numeric_and_supported", "not_checked", "metadata names no value columns",
                      required=False)
            else:
                invalid = []
                for column in value_columns:
                    if column not in headers:
                        invalid.append(f"{column}: absent")
                        continue
                    values = [row.get(column, "") for row in rows]
                    parsed = [_numeric(value) for value in values]
                    if any(value != "" and numeric is None for value, numeric in zip(values, parsed)):
                        invalid.append(f"{column}: non-numeric")
                    elif not any(value is not None for value in parsed):
                        invalid.append(f"{column}: all missing")
                check("value_columns_numeric_and_supported", "pass" if not invalid else "fail",
                      "all value columns are numeric and not all missing" if not invalid else "; ".join(invalid))
                problems_unit = []
                for column, spec in value_columns.items():
                    unit = str(spec.get("unit") or "").strip()
                    basis = str(spec.get("unit_basis") or "").strip()
                    if not unit:
                        problems_unit.append(f"{column}: no unit")
                    elif unit.casefold() in UNCONFIRMED_UNITS or basis.casefold().startswith("unconfirmed"):
                        continue  # explicitly unconfirmed is an acceptable, honest state
                    elif not basis:
                        problems_unit.append(f"{column}: unit {unit!r} has no stated basis")
                check("value_units_stated", "fail" if problems_unit else "pass",
                      "every value column states a unit with its basis or marks it unconfirmed" if not problems_unit
                      else "; ".join(problems_unit), required=False)
            if not presence_columns:
                check("presence_columns_binary_without_missing", "not_checked", "metadata names no presence columns",
                      required=False)
            else:
                invalid = []
                for column in presence_columns:
                    if column not in headers:
                        invalid.append(f"{column}: absent")
                    elif not all(row.get(column, "") in {"0", "1", "0.0", "1.0"} for row in rows):
                        invalid.append(f"{column}: missing or not 0/1")
                check("presence_columns_binary_without_missing", "pass" if not invalid else "fail",
                      "presence columns are 0/1 with no missing values" if not invalid else "; ".join(invalid))
        except (OSError, csv.Error, UnicodeError, ValueError) as exc:
            check("table_content_validity", "fail", f"{type(exc).__name__}")
    else:
        check("table_content_validity", "not_checked", "table or metadata unavailable")
        for name in ("table_hash_matches_metadata", "table_csv_readable", "table_rows_equal_cells",
                     "cell_ids_unique", "coordinates_inside_grid", "column_roles_declared",
                     "value_columns_numeric_and_supported"):
            if not any(c["check"] == name for c in checks):
                check(name, "not_checked", "table or metadata unavailable")

    if metadata:
        validation = metadata.get("validation")
        if not isinstance(validation, dict) or not any(k in validation for k in ("ok", "errors")):
            check("validation_result", "not_checked", "metadata has no validation result")
        elif validation.get("ok") is False or validation.get("errors"):
            check("validation_result", "fail", "metadata validation reports errors")
        else:
            check("validation_result", "pass", "metadata validation reports no errors")

        provenance = metadata.get("provenance")
        if isinstance(provenance, list):
            provenance_hashes = {record.get("sha256") for record in provenance
                                 if isinstance(record, dict) and record.get("sha256")}
            sourced = {name: spec for name, spec in (metadata.get("columns") or {}).items()
                       if isinstance(spec, dict) and spec.get("source")}
            for column, spec in sourced.items():
                source_hash = spec.get("source_sha256")
                if not source_hash:
                    check(f"column_{column}_provenance", "fail", "source hash is absent")
                elif source_hash not in provenance_hashes:
                    check(f"column_{column}_provenance", "fail", "source hash is not in provenance")
                else:
                    check(f"column_{column}_provenance", "pass", "source hash matches provenance")
            if not sourced:
                check("column_provenance", "not_checked", "metadata names no source-derived columns")
        else:
            check("column_provenance", "not_checked", "metadata provenance list is absent")

        source_status = metadata.get("source_completeness")
        has_paged_sources = any(isinstance(record, dict) and "merged_from_pages" in record
                                for record in (provenance or []) if isinstance(provenance, list))
        if isinstance(source_status, dict) and source_status:
            states = {name: item.get("completeness") if isinstance(item, dict) else None
                      for name, item in source_status.items()}
            if any(value == "partial" for value in states.values()):
                check("paged_source_completeness", "fail", "one or more paged sources are partial")
            elif any(value != "complete" for value in states.values()):
                check("paged_source_completeness", "not_checked", "one or more paged sources are not known complete")
            else:
                check("paged_source_completeness", "pass", "paged sources report complete")
        elif has_paged_sources:
            check("paged_source_completeness", "not_checked", "paged source completeness is absent")
        else:
            check("paged_source_completeness", "not_checked", "no paged source status to verify", required=False)
    else:
        for name in ("validation_result", "column_provenance", "paged_source_completeness"):
            check(name, "not_checked", "metadata unavailable")

    if os.path.isfile(report_path) and os.path.getsize(report_path) > 0:
        try:
            references = _file_references(report_path)
            if not references:
                check("report_file_references", "not_checked", "report contains no extracted file references")
            else:
                missing = [ref for ref, resolved in references if resolved is None]
                status = "missing" if missing else "pass"
                check("report_file_references", status,
                      f"references={len(references)} missing={len(missing)}")
            report_refs = [{"reference_path": ref, "resolved_path": resolved} for ref, resolved in references]
            known_hashes: dict[str, str] = {}
            for role in ("table", "handoff_table", "preview", "metadata", "state"):
                path = roles.get(role)
                if path and os.path.isfile(path):
                    known_hashes[sha256_file(path)] = role
            for record in (metadata.get("provenance") or []) if isinstance(metadata.get("provenance"), list) else []:
                if isinstance(record, dict) and record.get("sha256"):
                    known_hashes[str(record["sha256"]).lower()] = "provenance"
            hash_count, hash_problems = _report_hash_mismatches(report_path, references, known_hashes)
            if hash_count == 0:
                check("report_hashes_match_files", "not_checked", "report states no SHA-256 values", required=False)
            else:
                check("report_hashes_match_files", "fail" if hash_problems else "pass",
                      f"hashes={hash_count} mismatched={len(hash_problems)}"
                      + (": " + "; ".join(hash_problems[:5]) if hash_problems else ""))
            stale = [role for role in ("table", "handoff_table")
                     if roles.get(role) and os.path.isfile(roles[role])
                     and os.path.getmtime(roles[role]) > os.path.getmtime(report_path) + 1]
            if stale:
                warnings.append(f"report is older than {', '.join(stale)}; rewrite or re-check the report after the final table")
        except (OSError, UnicodeError):
            report_refs = []
            check("report_file_references", "not_checked", "report could not be read")
    else:
        report_refs = []
        check("report_file_references", "not_checked", "report unavailable")

    if state_path and os.path.isfile(state_path) and "state" in loaded:
        state = loaded["state"]
        state_table = state.get("table") or {}
        state_refs = []
        for key in ("metadata", "preview"):
            value = state_table.get(key)
            if isinstance(value, str):
                state_refs.append(artifact_paths.resolve_path(value, state_path))
        table_rec = state_table.get("table")
        if isinstance(table_rec, dict) and isinstance(table_rec.get("path"), str):
            state_refs.append(artifact_paths.resolve_path(table_rec["path"], state_path))
        if state_refs:
            unresolved = [path for path in state_refs if not path or not os.path.exists(path)]
            check("state_artifact_paths_resolve", "pass" if not unresolved else "fail",
                  f"paths={len(state_refs)} unresolved={len(unresolved)}")
        else:
            check("state_artifact_paths_resolve", "not_checked", "state contains no artifact path mapping", required=False)

    if handoff_table_path and os.path.isfile(handoff_table_path) and metadata:
        handoff_record = ((metadata.get("domain") or {}).get("handoff_table") or {})
        expected_hash = handoff_record.get("sha256")
        if expected_hash:
            actual_hash = sha256_file(handoff_table_path)
            check("handoff_table_hash", "pass" if actual_hash == expected_hash else "fail",
                  "metadata hand-off hash matches" if actual_hash == expected_hash else "metadata hand-off hash mismatch")
        else:
            check("handoff_table_hash", "not_checked", "metadata hand-off hash is absent")

    result = {"artifacts": {role: {"path": path} for role, path in roles.items()},
              "report_references": report_refs, "checks": checks, "warnings": warnings}
    result["ok"] = (not any(item["status"] == "fail" for item in checks)
                    and not any(item["required"] and item["status"] in {"missing", "not_checked"}
                                for item in checks))
    result["status"] = "pass" if result["ok"] else "fail"
    return result


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--table", required=True, help="grid table file")
    parser.add_argument("--metadata", required=True, help="table metadata document")
    parser.add_argument("--report", required=True, help="hand-off report")
    parser.add_argument("--state", help="optional acquisition state document")
    parser.add_argument("--preview", help="optional preview image")
    parser.add_argument("--handoff-table", help="optional filtered hand-off table")
    parser.add_argument("--json", help="optional JSON result path")
    args = parser.parse_args(argv)
    result = check_handoff(args.table, args.metadata, args.report, state_path=args.state,
                           preview_path=args.preview, handoff_table_path=args.handoff_table)
    if args.json:
        artifact_paths.dump_json(result, args.json)
    serializer = artifact_paths.PathSerializer(args.json or os.path.join(os.getcwd(), "checker.stdout.json"))
    output = serializer.portable(result)
    if not args.json:
        output["paths_relative_to"] = "current working directory (stdout)"
    text = json.dumps(output, ensure_ascii=False, indent=2)
    if args.json:
        # Print the same portable representation as the saved result.
        with open(args.json, encoding="utf-8") as stream:
            text = stream.read()
    print(text)
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
