"""정찰 실행기 — 사용자의 기존 승인 기록을 재사용해 한 URL을 Chromium으로 열고 네트워크·스냅샷·쿠키 이름을 기록한다.

headless 기본 시험용 진입점이다. `--headless auto`는 앱 셸 응답을 감지하면 표시 장치에서 headed로 한 번
재시도하며, 재시도도 같은 요청 예산을 이어 쓴다. 승인 기록이 없으면 robots.txt를 포함해 어떤 요청도 보내지 않는다.
사용자가 보이는 창에서 직접 로그인/조작한 뒤 계속하도록 `--pause`를 제공하고,
환경변수 자격증명(`MPM_ACQ_<HOST>_USER/_PASSWORD`)으로 폼 로그인을 시험하는 `--login`도 있다.
값(쿠키·토큰·비밀번호)은 어디에도 출력하지 않는다. 세션 상태 파일은 저장소 밖 경로를 권장한다.

사용 예:
  uv run python skills/mpm-data-acquisition/scripts/recon.py --url "<승인한 포털 URL>" --workspace runs/recon-x \
      --headed --pause --approve --approved-by "<이름>" --evidence "<근거>" [--approval-scope "<현재 작업>"]
  MPM_ACQ_CDP_URL=http://127.0.0.1:9222 uv run python skills/mpm-data-acquisition/scripts/recon.py --url <URL> --workspace runs/recon-x

종료 코드: 0 완료 · 3 승인 필요 · 1 오류
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
from datetime import datetime, timezone
from urllib.parse import urlsplit

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(HERE), "assets"))

import browser_session  # noqa: E402
import artifact_paths  # noqa: E402
import fetch_budget  # noqa: E402
import robots_gate  # noqa: E402

USER_AGENT = robots_gate.DEFAULT_USER_AGENT


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def gate(url: str, workspace: str, args) -> dict:
    host = robots_gate.host_of(url)
    ledger = robots_gate.ConsentLedger(os.path.join(workspace, "consent-ledger.json"))
    if ledger.status(host) == "review_required":
        print(f"{host}: review_required 원장은 유효한 승인으로 간주하지 않는다. 실제 사용자 결정 근거를 확인한다.")
        return {"host": host, "status": "approval_required_review", "approval_reused": False}
    path = urlsplit(url).path or "/"
    try:
        rec = ledger.require(host, paths=[path], approval_scope=getattr(args, "approval_scope", ""),
                             approved_by=getattr(args, "approved_by", ""))
        return {"host": host, "status": "approved", "approval_reused": True,
                "robots_state": rec.get("robots_state"), "disallowed": rec.get("robots_disallowed_paths", [])}
    except robots_gate.ApprovalRequired:
        pass
    result = robots_gate.cached_observation(workspace, url)
    if args.approve:
        if not args.approved_by or not args.evidence:
            raise SystemExit("--approve에는 --approved-by와 --evidence가 필요하다")
        rec = ledger.record(host, result, approved_by=args.approved_by, paths=[path],
                            approval_scope=args.approval_scope, evidence=args.evidence,
                            note="Explicit user collection approval; robots advisory",
                            approve_disallowed=getattr(args, "approve_disallowed", False),
                            approve_unreadable=getattr(args, "approve_unreadable_robots", False))
        return {"host": host, "status": "approved_now", "approval_reused": False,
                "robots_state": result.state, "disallowed": rec["robots_disallowed_paths"]}
    # No request before approval, robots.txt included; a saved observation is shown if one exists.
    rec_dir = os.path.join(workspace, "recon", host)
    os.makedirs(rec_dir, exist_ok=True)
    summary = robots_gate.summarize(result, [path], USER_AGENT)
    with open(os.path.join(rec_dir, "robots.summary.txt"), "w", encoding="utf-8") as fh:
        fh.write("paths_relative_to: this file's directory\n" + summary + "\n")
    artifact_paths.dump_json(result.to_dict(), os.path.join(rec_dir, "robots.result.json"))
    print(summary)
    return {"host": host, "status": "approval_required", "robots_state": result.state}


def _recorded_crawl_delay(ledger: robots_gate.ConsentLedger, host: str) -> float:
    known = (ledger.get(host) or {}).get("last_present_robots")
    if not known:
        return 0.0
    return robots_gate.crawl_delay(robots_gate.RobotsResult(**known)) or 0.0


def main(argv=None, *, _budget: fetch_budget.FetchBudget | None = None) -> int:
    """`_budget` carries the request budget into the single headed retry so the cap covers both attempts."""
    raw_argv = list(sys.argv[1:] if argv is None else argv)
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--url", required=True)
    ap.add_argument("--workspace", required=True)
    mode = ap.add_mutually_exclusive_group()
    mode.add_argument("--headless", choices=("true", "false", "auto"), default=None,
                      help="브라우저 모드(기본: MPM_ACQ_HEADLESS 또는 auto)")
    mode.add_argument("--headed", dest="headless", action="store_const", const="false",
                      help="보이는 창에서 실행(--headless false와 같음)")
    ap.add_argument("--cdp", default=None, help="실행 중 Chrome의 CDP 주소(MPM_ACQ_CDP_URL과 같음)")
    ap.add_argument("--user-data-dir", default=None, help="전용 프로필 디렉터리(로그인 유지)")
    ap.add_argument("--executable", default=None, help="Chromium 실행 파일(MPM_ACQ_BROWSER_EXECUTABLE과 같음)")
    ap.add_argument("--wait", type=float, default=3.0, help="networkidle 이후 추가 대기 초")
    ap.add_argument("--pause", action="store_true", help="창에서 직접 조작/로그인한 뒤 Enter로 계속")
    ap.add_argument("--login", nargs="+", metavar="SELECTOR",
                    help="환경변수 자격증명으로 폼 로그인: <user_selector> <password_selector> [submit_selector] [wait_for_selector]")
    ap.add_argument("--capture-bodies", action="store_true", help="XHR/JSON 응답 본문을 기록(값 노출 주의)")
    ap.add_argument("--save-state", default=None, help="storage_state 저장 경로(저장소 밖 권장, 커밋 금지)")
    ap.add_argument("--approve", action="store_true", help="명시적 사용자 승인 기록(--approved-by/--evidence 필요, --approval-scope 선택)")
    ap.add_argument("--approve-disallowed", action="store_true")
    ap.add_argument("--approve-unreadable-robots", action="store_true")
    ap.add_argument("--approved-by", default="")
    ap.add_argument("--approval-scope", default="", help="선택 항목: 현재 사용자 작업의 식별자(절대 경로 금지)")
    ap.add_argument("--evidence", default="")
    ap.add_argument("--allow-host", action="append", default=[],
                    help="하위 요청을 허용할 추가 host(현재 작업의 승인 기록이 있어야 한다). 반복 가능")
    ap.add_argument("--interval", type=float, default=1.0, help="브라우저가 보내는 모든 요청 사이의 최소 간격(초)")
    ap.add_argument("--max-requests", type=int, default=300, help="브라우저 요청 총량 상한")
    ap.add_argument("--load-images", action="store_true", help="이미지·미디어·글꼴 요청도 허용(기본은 차단)")
    args = ap.parse_args(argv)
    if args.login and not 2 <= len(args.login) <= 4:
        ap.error("--login에는 selector 2–4개가 필요하다")

    ws = os.path.abspath(args.workspace)
    os.makedirs(ws, exist_ok=True)
    verdict = gate(args.url, ws, args)
    if verdict["status"].startswith("approval_required"):
        return 3
    host = verdict["host"]
    extra_hosts = sorted({h.lower() for h in args.allow_host} - {host})
    ledger = robots_gate.ConsentLedger(os.path.join(ws, "consent-ledger.json"))
    unapproved = []
    for extra in extra_hosts:
        try:
            ledger.require(extra, paths=["/"], approval_scope=args.approval_scope, approved_by=args.approved_by)
        except robots_gate.ApprovalRequired:
            unapproved.append(extra)
    if unapproved:
        print(f"[recon] 승인 기록이 없는 하위 요청 host: {unapproved}. 사용자 승인을 먼저 기록한다.")
        return 3
    rec_dir = os.path.join(ws, "recon", host)
    os.makedirs(rec_dir, exist_ok=True)
    overrides = {}
    if args.headless is not None:
        overrides["headless"] = args.headless
    if args.cdp:
        overrides["cdp_url"] = args.cdp
    if args.user_data_dir:
        overrides["user_data_dir"] = args.user_data_dir
    if args.executable:
        overrides["executable_path"] = args.executable
    cfg = browser_session.BrowserConfig.from_env(**overrides)
    auto_mode = cfg.headless == "auto"
    actual_headless = True if auto_mode else bool(cfg.headless)
    print(f"[recon] mode={cfg.describe()['mode']} headless={actual_headless} host={host} ({verdict['status']})")
    cred = None
    if args.login:
        cred = browser_session.credentials_from_env(host)
        if cred is None:
            names = browser_session.credential_env_names(host)
            raise SystemExit(f"자격증명 환경변수가 없다. 설정할 이름: {names}")
    prior_attempt = os.environ.get("MPM_ACQ_RECON_PRIOR_ATTEMPT")
    out = {"url": browser_session.safe_url(args.url, cred), "host": host, "gate": verdict,
           "started_at": now(), "mode": cfg.describe()["mode"],
           "browser": {"mode": "headless" if actual_headless else "headed",
                       "headless": actual_headless,
                       "display_available": browser_session.has_display()}}
    if prior_attempt:
        try:
            out["browser"]["initial_attempt"] = json.loads(prior_attempt)
        except json.JSONDecodeError:
            out["browser"]["initial_attempt"] = {"record_error": "invalid prior attempt JSON"}
    budget = _budget or fetch_budget.FetchBudget(delay=args.interval, min_delay=min(args.interval, 0.5),
                                                 max_requests=args.max_requests)
    budget.delay = max([budget.delay, *(_recorded_crawl_delay(ledger, h) for h in [host, *extra_hosts])])
    out["request_budget_start"] = budget.snapshot()
    with browser_session.open_session(cfg) as s:
        def path_allowed(request_host: str, request_path: str) -> bool:
            try:
                ledger.require(request_host, paths=[request_path], approval_scope=args.approval_scope,
                               approved_by=args.approved_by)
                return True
            except robots_gate.ApprovalRequired:
                return False

        service_workers_blocked = getattr(s, "mode", None) != "cdp" and cfg.block_service_workers
        request_gate = browser_session.RequestGate(
            [host, *extra_hosts], budget=budget, credentials=cred, path_allowed=path_allowed,
            service_workers_blocked=service_workers_blocked,
            blocked_resource_types=() if args.load_images else browser_session.RequestGate.DEFAULT_BLOCKED_TYPES)
        if not service_workers_blocked:
            print("[recon] 경고: CDP로 재사용한 context는 service worker를 막지 못해 일부 요청이 통제 밖일 수 있다.")
        request_gate.install(s.context)
        rec = browser_session.NetworkRecorder(s.page, capture_bodies=args.capture_bodies, credentials=cred)
        navigation_failed = False
        try:
            navigation_response = s.page.goto(args.url, timeout=300_000)
        except Exception as exc:  # e.g. the gate refused a redirect or the budget stopped the load
            navigation_response = None
            navigation_failed = True
            out["navigation_error"] = f"{type(exc).__name__}: {str(exc).splitlines()[0][:200]}"
        navigation_status = rec.record_navigation_response(navigation_response)
        out["browser"]["navigation_response_status"] = navigation_status
        access_denied = navigation_status in {401, 403}
        if navigation_failed:
            out["stop_reason"] = request_gate.stopped or "navigation_failed"
        elif access_denied:
            out["browser"]["stopped_on_access_denied"] = True
            out["stop_reason"] = f"navigation_http_{navigation_status}"
        else:
            try:
                s.page.wait_for_load_state("networkidle", timeout=30_000)
            except Exception as exc:  # SPA가 계속 polling하면 networkidle이 안 올 수 있다
                out["networkidle"] = f"timeout: {type(exc).__name__}"
            time.sleep(max(args.wait, 0))
            if args.login:
                sel = list(args.login) + [None] * 4
                browser_session.fill_login(s.page, cred, sel[0], sel[1], submit_selector=sel[2], wait_for_selector=sel[3])
                out["login"] = {"submitted": True, "credential_source": cred.source,
                                "verified_by": {"selector": sel[3]} if sel[3] else None}
            if args.pause:
                input("[recon] 창에서 조작/로그인을 마친 뒤 Enter를 누르면 기록을 저장하고 닫는다... ")
            out["title"] = s.page.title()
            out["final_url"] = browser_session.safe_url(s.page.url, cred)
            out["browser"]["user_agent"] = s.page.evaluate("navigator.userAgent")
        out["browser"]["app_shell_symptom_detected"] = bool(rec.app_shell_responses)
        out["browser"]["app_shell_responses"] = rec.app_shell_responses
        network_name = "network.headless.jsonl" if actual_headless else "network.headed.jsonl"
        out["network_log"] = rec.save(os.path.join(rec_dir, network_name))
        out["request_gate"] = request_gate.summary()
        out["request_gate_log"] = request_gate.save(os.path.join(rec_dir, network_name.replace("network", "request-gate")))
        cands = rec.api_candidates()
        artifact_paths.dump_json({"candidates": cands}, os.path.join(rec_dir, "api_candidates.json"))
        out["api_candidates"] = len(cands)
        if not access_denied and not navigation_failed:
            try:
                snap = s.page.locator("body").aria_snapshot()
                with open(os.path.join(rec_dir, "aria_snapshot.txt"), "w", encoding="utf-8") as fh:
                    fh.write("paths_relative_to: this file's directory\n" + browser_session.redact(snap, cred))
                out["aria_snapshot_lines"] = snap.count("\n") + 1
                out["aria_snapshot"] = os.path.join(rec_dir, "aria_snapshot.txt")
            except Exception as exc:
                out["aria_snapshot"] = f"failed: {type(exc).__name__}"
            shot = os.path.join(rec_dir, "screenshot.png")
            s.page.screenshot(path=shot, full_page=False, mask=[s.page.locator('input, textarea')])
            out["screenshot"] = shot
            out["cookie_names"] = browser_session.cookie_names(s.context, host_suffix=host)
            if args.save_state:
                out["storage_state"] = browser_session.save_storage_state(s.context, args.save_state)
    out["finished_at"] = now()
    summary_path = os.path.join(rec_dir, "recon.summary.json")
    portable_out = artifact_paths.portable_payload(out, summary_path)
    text = json.dumps(portable_out, ensure_ascii=False, indent=2)
    with open(summary_path, "w", encoding="utf-8") as fh:
        fh.write(browser_session.redact(text, cred))
    print(browser_session.redact(text, cred))
    if access_denied or navigation_failed:
        return 3
    if request_gate.violations or (request_gate.stopped and not access_denied):
        print(f"[recon] 요청 통제가 멈췄다: {request_gate.stopped}. 범위·예산을 확인한다.")
        return 3
    if (actual_headless and browser_session.should_retry_headed(
            "auto" if auto_mode else cfg.headless, out["browser"]["app_shell_symptom_detected"],
            out["browser"].get("navigation_response_status"))):
        print("[recon] 앱 셸 응답을 감지했습니다. headed Chromium으로 다시 엽니다.")
        previous = os.environ.get("MPM_ACQ_RECON_PRIOR_ATTEMPT")
        os.environ["MPM_ACQ_RECON_PRIOR_ATTEMPT"] = json.dumps(out["browser"], ensure_ascii=False)
        retry_argv = []
        skip_next = False
        for token in raw_argv:
            if skip_next:
                skip_next = False
                continue
            if token == "--headless":
                skip_next = True
                continue
            if token.startswith("--headless=") or token == "--headed":
                continue
            retry_argv.append(token)
        retry_argv.extend(("--headless", "false"))
        try:
            return main(retry_argv, _budget=budget)
        finally:
            if previous is None:
                os.environ.pop("MPM_ACQ_RECON_PRIOR_ATTEMPT", None)
            else:
                os.environ["MPM_ACQ_RECON_PRIOR_ATTEMPT"] = previous
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
