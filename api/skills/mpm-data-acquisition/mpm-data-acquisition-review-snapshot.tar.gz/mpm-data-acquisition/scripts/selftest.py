"""수집 스킬 뼈대의 오프라인 자가 점검. 네트워크를 쓰지 않는다. 격자·CRS 값은 합성 fixture다.

uv run python skills/mpm-data-acquisition/scripts/selftest.py
"""
from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
ASSETS = HERE.parent / "assets"
sys.path.insert(0, str(ASSETS))


def main() -> int:
    report: dict = {"paths_relative_to": "not_applicable (stdout)", "checks": {}}
    ok = True
    try:
        import fetch_budget, robots_gate, downloader, browser_session  # noqa: F401
        report["checks"]["imports_stdlib_modules"] = "ok"
    except Exception as exc:  # pragma: no cover
        report["checks"]["imports_stdlib_modules"] = f"FAIL {exc}"
        ok = False
    c = robots_gate.classify_robots_response
    cases = {
        "present": c(200, "text/plain", "User-agent: *\nDisallow:\n"),
        "html_shell": c(200, "text/html", "<!doctype html><html></html>"),
        "absent": c(404, None, ""),
    }
    report["checks"]["robots_classification"] = "ok" if all(k == v for k, v in cases.items()) else f"FAIL {cases}"
    ok &= report["checks"]["robots_classification"] == "ok"
    b = fetch_budget.FetchBudget(delay=0.1, max_requests=1, sleeper=lambda s: None)
    b.wait()
    try:
        b.wait()
        report["checks"]["budget_limit"] = "FAIL no exception"
        ok = False
    except fetch_budget.BudgetExceeded:
        report["checks"]["budget_limit"] = "ok"
    try:
        import numpy as np
        import rasterio
        from rasterio.transform import from_origin
        import grid_table as gt
        spec = gt.GridSpec(crs="EPSG:32650", cell_size=1000, minx=0, miny=0, maxx=5000, maxy=4000)
        with tempfile.TemporaryDirectory() as tmp:
            arr = np.arange(40 * 50, dtype="float32").reshape(40, 50)
            path = Path(tmp) / "r.tif"
            with rasterio.open(path, "w", driver="GTiff", height=40, width=50, count=1, dtype="float32",
                               crs="EPSG:32650", transform=from_origin(0, 4000, 100, 100)) as dst:
                dst.write(arr, 1)
            vals, info = gt.sample_raster(spec, str(path), method="mean")
            from shapely.geometry import Point
            present, counts, meta = gt.presence_from_points(spec, [Point(500, 3500), Point(9999, 9999)])
            df = gt.assemble_table(spec, {"f": vals}, extra={"record": present})
            rep = gt.validate_table(df, spec, ["f"], presence_columns=["record"])
            good = rep["ok"] and meta["n_present_cells"] == 1 and meta["n_points_outside_grid"] == 1 and len(df) == 20
            report["checks"]["grid_table_synthetic"] = "ok" if good else f"FAIL {rep} {meta}"
            ok &= good
    except Exception as exc:
        report["checks"]["grid_table_synthetic"] = f"FAIL {type(exc).__name__}: {exc}"
        ok = False
    try:
        import playwright  # noqa: F401
        report["checks"]["playwright_importable"] = "ok"
    except ImportError:
        report["checks"]["playwright_importable"] = "missing (browser steps unavailable)"
    report["result"] = "PASS" if ok else "FAIL"
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
