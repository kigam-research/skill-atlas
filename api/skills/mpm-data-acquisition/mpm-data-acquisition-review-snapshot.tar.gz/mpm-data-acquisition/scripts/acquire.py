"""선택형 recipe 실행기 — 표준 경로로 자료를 받아 투영 CRS 정규 격자 표를 만들고 검증·provenance를 기록한다.

지원 범위: ESRI REST feature query(GeoJSON), WFS 2.0 GetFeature(JSON), WCS 2.x GetCoverage(GeoTIFF,
coverage의 native CRS와 축 이름으로 subset), 직접 파일과 사용자가 받은 로컬 파일 → 셀 단위 표. 열은
자료 값(value), 진단(diagnostic), 점 기록의 있음 표시·건수(record_derived), 영역 표시(mask)로 나뉜다.
원자료만 받는 작업, 격자가 아닌 산출물, 다른 서비스 형식은 assets를 조합한 별도 코드로 만든다.

이 스크립트는 흔한 경우를 재현 가능하게 돌리는 뼈대다. 포털마다 다른 접근 경로나 판단이 필요하면
에이전트가 assets를 직접 조합한 코드를 쓴다. 승인은 사용자가 명령행에서 명시할 때만 기록한다.
승인 전에는 어떤 host에도 요청(robots.txt 포함)을 보내지 않는다. 모든 다운로드와 redirect 단계는
승인한 host 안에서, 하나의 요청 예산으로 센다.

사용:
  uv run python skills/mpm-data-acquisition/scripts/acquire.py --recipe recipe.json --workspace WORK \
      [--approve-hosts --approved-by "<사용자>" --evidence "<승인 근거>" [--approval-scope "<현재 작업>"]] [--dry-run]

종료 코드: 0 성공(검증 error 없음) · 2 표는 만들었으나 검증 error · 3 승인 필요/예산 초과로 중단 · 1 기타 오류
"""
from __future__ import annotations

import argparse
import fnmatch
import json
import os
import re
import shutil
import sys
import zipfile
from datetime import datetime, timezone
from urllib.parse import quote, urlsplit

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(HERE), "assets"))

import downloader  # noqa: E402
import artifact_paths  # noqa: E402
import fetch_budget  # noqa: E402
import robots_gate  # noqa: E402

USER_AGENT = robots_gate.DEFAULT_USER_AGENT


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def log(msg: str) -> None:
    print(f"[acquire {datetime.now(timezone.utc).strftime('%H:%M:%S')}] {msg}", flush=True)


# ---------------------------------------------------------------------------
# host 승인
# ---------------------------------------------------------------------------
def hosts_of(recipe: dict) -> dict[str, str]:
    """host → 그 host에 실제로 보낼 URL 하나(scheme·port 보존). extra_hosts는 https 루트로 둔다."""
    hosts: dict[str, str] = {}
    for src in recipe.get("sources", {}).values():
        for key in ("url", "url_template"):
            if src.get(key):
                hosts.setdefault(robots_gate.host_of(src[key]), src[key])
    for h in recipe.get("extra_hosts", []):
        hosts.setdefault(h.lower(), f"https://{h}/")
    return dict(sorted(hosts.items()))


def check_consent(recipe: dict, workspace: str, budget: fetch_budget.FetchBudget, args, report: dict | None = None) -> dict:
    """Reuse or record user consent per host without sending any request.

    A saved robots observation (recon/<host>/robots.result.json) informs the user and its crawl-delay
    raises the request interval; this function never fetches robots.txt itself.
    """
    ledger = robots_gate.ConsentLedger(os.path.join(workspace, "consent-ledger.json"))
    report = {} if report is None else report
    for host, sample_url in hosts_of(recipe).items():
        paths = [urlsplit(src.get("url") or src.get("url_template") or "").path or "/"
                 for src in recipe["sources"].values()
                 if robots_gate.host_of(src.get("url") or src.get("url_template") or "https://x/") == host]
        if not paths:
            paths = [urlsplit(sample_url).path or "/"]
        if ledger.status(host) == "review_required":
            report[host] = {"status": "approval_required_review", "approval_reused": False}
            log(f"{host}: 원장에 review_required 표시가 있다. 과거 원장을 보존하고 실제 사용자 결정 근거를 확인한다.")
            continue
        try:
            rec = ledger.require(host, paths=paths, approval_scope=getattr(args, "approval_scope", ""),
                                 approved_by=getattr(args, "approved_by", ""))
        except robots_gate.ApprovalRequired:
            rec = None
        if rec is not None:
            report[host] = {"status": "approved", "approval_reused": True,
                            "robots_state": rec.get("robots_state"), "approved_at": rec.get("approved_at"),
                            "robots_disallowed_paths": rec.get("robots_disallowed_paths", [])}
            known = rec.get("last_present_robots")
            if known:
                budget.delay = max(budget.delay, robots_gate.crawl_delay(robots_gate.RobotsResult(**known)) or 0)
            continue
        result = robots_gate.cached_observation(workspace, sample_url)
        if args.approve_hosts:
            if not args.approved_by or not args.evidence:
                raise SystemExit("--approve-hosts에는 --approved-by와 --evidence가 필요하다")
            rec = ledger.record(host, result, approved_by=args.approved_by, paths=paths,
                                approval_scope=args.approval_scope, evidence=args.evidence,
                                note="Explicit user collection approval; robots advisory",
                                approve_disallowed=getattr(args, "approve_disallowed", False),
                                approve_unreadable=getattr(args, "approve_unreadable_robots", False))
            report[host] = {"status": "approved_now", "approval_reused": False,
                            "robots_state": result.state, "approved_at": rec["approved_at"],
                            "robots_disallowed_paths": rec["robots_disallowed_paths"]}
            budget.delay = max(budget.delay, robots_gate.crawl_delay(result) or 0)
            continue
        # No request is sent before approval, robots.txt included. A saved observation, if any, is shown.
        rec_dir = os.path.join(workspace, "recon", host)
        os.makedirs(rec_dir, exist_ok=True)
        summary = robots_gate.summarize(result, paths, USER_AGENT)
        with open(os.path.join(rec_dir, "robots.summary.txt"), "w", encoding="utf-8") as fh:
            fh.write("paths_relative_to: this file's directory\n" + summary + "\n")
        artifact_paths.dump_json(result.to_dict(), os.path.join(rec_dir, "robots.result.json"))
        report[host] = {"status": "approval_required", "robots_state": result.state,
                        "robots_disallowed_paths": ledger.disallowed_paths(host, result, paths)}
        print(summary)
    return report


# ---------------------------------------------------------------------------
# 다운로드
# ---------------------------------------------------------------------------
def _licence(src: dict) -> dict:
    lic = dict(src.get("licence") or {})
    lic.setdefault("verified", False)
    return lic


def _reuse(name: str, sig: str, index, reuse: bool, status: dict | None) -> str | None:
    """같은 요청 서명의 검증된 파일이 있으면 네트워크 없이 그 경로를 돌려준다."""
    if not reuse:
        return None
    path = index.verified_path(sig)
    if path:
        log(f"{name}: verified existing file reused (matching request signature; no network): {path}")
        if status is not None:
            status["reused"] = True
            status["request_signature"] = sig
    return path


def _numeric_count(value):
    if isinstance(value, bool) or value is None or str(value).strip().lower() == "unknown":
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _reported_count(data: dict, keys: tuple[str, ...]) -> int | None:
    for key in keys:
        value = data.get(key)
        if value is None and isinstance(data.get("properties"), dict):
            value = data["properties"].get(key)
        count = _numeric_count(value)
        if count is not None:
            return count
    return None


def _feature_identifier(feature: dict) -> str | None:
    if feature.get("id") is not None:
        return str(feature["id"])
    props = feature.get("properties") or {}
    for key in ("OBJECTID", "objectid", "ObjectID", "FID", "fid", "gml_id"):
        if props.get(key) is not None:
            return f"{key}:{props[key]}"
    return None


def _page_fingerprint(features: list) -> str:
    payload = json.dumps(features, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)
    return downloader.request_signature("feature_page", payload=payload)


def _accept_page(features: list, seen_pages: set[str], seen_ids: set[str], merged: list,
                 duplicate_ids: list[str]) -> bool:
    fingerprint = _page_fingerprint(features)
    if fingerprint in seen_pages:
        return True
    seen_pages.add(fingerprint)
    for feature in features:
        identifier = _feature_identifier(feature)
        if identifier is not None:
            if identifier in seen_ids:
                duplicate_ids.append(identifier)
                continue
            seen_ids.add(identifier)
        merged.append(feature)
    return False


def _paging_result(expected: int | None, received: int, stop_reason: str, duplicate_ids: list[str],
                   repeated_page: bool, server_signalled_more: bool = False) -> dict:
    if repeated_page or duplicate_ids or stop_reason in {"request_budget_exhausted", "max_features_reached",
                                                         "next_link_other_host", "empty_page_before_expected_count",
                                                         "server_count_inconsistent"}:
        completeness = "partial"
    elif expected is not None:
        completeness = "complete" if received >= expected and not server_signalled_more else "partial"
    elif stop_reason == "server_no_more_results":
        completeness = "complete"
    else:
        completeness = "unknown"
    warning = None if completeness == "complete" else (
        f"paging {completeness}: expected={expected}, received={received}, stop_reason={stop_reason}")
    return {"completeness": completeness, "expected_count": expected, "received_count": received,
            "stop_reason": stop_reason, "duplicate_ids": duplicate_ids, "repeated_page": repeated_page,
            "warning": warning}


def _response_crs(data: dict, src: dict, output_format: str) -> tuple[str, str]:
    crs_member = data.get("crs")
    name = None
    if isinstance(crs_member, dict):
        properties = crs_member.get("properties") or {}
        name = properties.get("name") or properties.get("href")
    name = name or data.get("srsName") or src.get("response_crs")
    if not name:
        fmt = output_format.lower()
        if "geo+json" in fmt or "geojson" in fmt:
            name = "EPSG:4326"  # RFC 7946 GeoJSON defaults to longitude/latitude.
        else:
            raise downloader.DownloadError(
                "WFS 응답 CRS를 확인할 수 없습니다. 응답 CRS 선언 또는 검증된 response_crs를 recipe에 제공하십시오.")
    try:
        from pyproj import CRS
        name = CRS.from_user_input(name).to_string()
    except Exception as exc:
        raise downloader.DownloadError(f"WFS 응답 CRS를 해석할 수 없습니다: {name!r}: {exc}") from exc
    axis_order = src.get("response_axis_order") or data.get("axisOrder")
    if axis_order is None:
        fmt = output_format.lower()
        if "geo+json" in fmt or "geojson" in fmt:
            axis_order = "xy"  # GeoJSON coordinates use x/y order.
        else:
            try:
                axis_order = _bbox_axis_order(name, None)
            except downloader.DownloadError as exc:
                raise downloader.DownloadError(
                    f"WFS 응답 축 순서를 확인할 수 없습니다. response_axis_order를 명시하십시오: {name}") from exc
    if axis_order not in {"xy", "yx"}:
        raise downloader.DownloadError(f"WFS 응답 축 순서를 확인할 수 없습니다: {axis_order!r}")
    return str(name), axis_order


def _bbox_axis_order(crs_name: str, configured: str | None) -> str:
    if configured:
        mapping = {"lonlat": "xy", "latlon": "yx", "xy": "xy", "yx": "yx"}
        if configured not in mapping:
            raise downloader.DownloadError(f"WFS bbox 축 순서를 확인할 수 없습니다: {configured!r}")
        return mapping[configured]
    try:
        from pyproj import CRS
        axes = CRS.from_user_input(crs_name).axis_info
    except Exception as exc:
        raise downloader.DownloadError(f"WFS bbox CRS 축 순서를 확인할 수 없습니다({crs_name!r}): {exc}") from exc
    if not axes:
        raise downloader.DownloadError(f"WFS bbox CRS 축 순서 정보가 없습니다: {crs_name!r}")
    first = (axes[0].direction or "").lower()
    if first in {"north", "south"}:
        return "yx"
    if first in {"east", "west"}:
        return "xy"
    raise downloader.DownloadError(f"WFS bbox 첫 축 방향을 확인할 수 없습니다: {first!r} ({crs_name})")


def _wfs_bbox(aoi_wgs84: list[float], crs_name: str, axis_order: str, densify: int = 256) -> str:
    """AOI bounds in the WFS bbox CRS from the densified AOI boundary (an approximation; see grid_table)."""
    import grid_table as gt

    try:
        bounds, _ = gt.bbox_bounds_in_crs(aoi_wgs84, crs_name, densify=densify)
    except Exception as exc:
        raise downloader.DownloadError(f"WFS bbox CRS 변환을 만들 수 없습니다(EPSG:4326 → {crs_name}): {exc}") from exc
    if axis_order == "yx":
        return f"{bounds[1]},{bounds[0]},{bounds[3]},{bounds[2]},{crs_name}"
    return f"{bounds[0]},{bounds[1]},{bounds[2]},{bounds[3]},{crs_name}"


def _transform_geojson_features(features: list, source_crs: str, target_crs: str,
                                axis_order: str = "xy") -> list:
    """Transform established source coordinates to the requested CRS; never infer a CRS transform."""
    from pyproj import CRS, Transformer
    from shapely.geometry import mapping, shape
    from shapely.ops import transform as transform_geometry

    try:
        source = CRS.from_user_input(source_crs)
        target = CRS.from_user_input(target_crs)
        transformer = Transformer.from_crs(source, target, always_xy=True)
    except Exception as exc:
        raise downloader.DownloadError(
            f"WFS CRS를 해석할 수 없습니다(source={source_crs!r}, target={target_crs!r}): {exc}") from exc

    def transform_xy(x, y, z=None):
        if axis_order == "yx":
            x, y = y, x
        return transformer.transform(x, y, z) if z is not None else transformer.transform(x, y)

    if source == target and axis_order == "xy":
        return features
    transformed = []
    for feature in features:
        item = dict(feature)
        geometry = feature.get("geometry")
        if geometry is not None:
            item["geometry"] = mapping(transform_geometry(transform_xy, shape(geometry)))
        transformed.append(item)
    return transformed


def _next_link(data: dict) -> str | None:
    direct = data.get("next")
    if isinstance(direct, str):
        return direct
    for link in data.get("links", []) or []:
        if isinstance(link, dict) and str(link.get("rel", "")).lower() == "next" and link.get("href"):
            return str(link["href"])
    return None


def _source_hosts(src: dict, allowed_hosts) -> set[str]:
    """Hosts a source request may reach: the caller's approved list, or only the source URL's own host."""
    if allowed_hosts is not None:
        return downloader.normalise_hosts(allowed_hosts)
    return {robots_gate.host_of(src["url"])}


def esri_page_size(src: dict) -> int:
    """Requested page size: `page_size` (default 1000), capped by a known service `max_record_count`.

    A server returns at most its own maxRecordCount per page and signals more with
    exceededTransferLimit; paging continues on that signal whatever page size was asked for.
    """
    page = int(src.get("page_size", 1000))
    known = src.get("max_record_count")
    return min(page, int(known)) if known else page


def fetch_esri_query(name: str, src: dict, aoi: list[float], raw_dir: str, budget, index,
                     reuse: bool = True, status: dict | None = None, allowed_hosts=None) -> str:
    west, south, east, north = aoi
    hosts = _source_hosts(src, allowed_hosts)
    page = esri_page_size(src)
    max_features = int(src.get("max_features", 50_000))
    where = src.get("where", "1=1")
    out_fields = src.get("out_fields", "*")
    sig = downloader.request_signature("esri_query", url=src["url"], where=where, out_fields=out_fields, aoi=aoi,
                                       page_size=page, max_features=max_features)
    cached = _reuse(name, sig, index, reuse, status)
    if cached:
        rec = index.by_signature(sig) or {}
        if status is not None:
            status["paging"] = {k: rec.get(k) for k in (
                "completeness", "expected_count", "received_count", "stop_reason", "duplicate_ids",
                "repeated_page", "warning")}
        return cached
    features: list = []
    pages = []
    offset = 0
    received = 0
    expected = _numeric_count(src.get("expected_count"))
    duplicate_ids: list[str] = []
    seen_ids: set[str] = set()
    seen_pages: set[str] = set()
    repeated_page = False
    server_signalled_more = False
    stop_reason = "unknown"
    while True:
        if received >= max_features:
            stop_reason = "max_features_reached"
            break
        request_page = min(page, max_features - received)
        url = (f"{src['url'].rstrip('/')}/query?where={quote(where)}&outFields={quote(out_fields)}"
               f"&geometry={west},{south},{east},{north}&geometryType=esriGeometryEnvelope&inSR=4326"
               f"&spatialRel=esriSpatialRelIntersects&outSR=4326&returnGeometry=true&f=geojson"
               f"&resultOffset={offset}&resultRecordCount={request_page}")
        dest = os.path.join(raw_dir, name, f"page_{offset:06d}.geojson")
        try:
            rec = downloader.download(url, dest, budget=budget, user_agent=USER_AGENT, licence=_licence(src),
                                      source=src.get("record", {}), overwrite=True,
                                      max_bytes=int(src.get("max_bytes", 200_000_000)),
                                      request_signature=f"{sig}:page:{offset}", allowed_hosts=hosts)
        except fetch_budget.BudgetExceeded:
            stop_reason = "request_budget_exhausted"
            break
        index.add(rec)
        pages.append(rec)
        with open(dest, encoding="utf-8") as fh:
            data = json.load(fh)
        if "error" in data:
            raise downloader.DownloadError(f"ESRI error for {name}: {data['error']}")
        got = data.get("features", [])
        reported = _reported_count(data, ("totalFeatures", "numberMatched", "count"))
        if reported is not None:
            expected = reported
        repeated_page = _accept_page(got, seen_pages, seen_ids, features, duplicate_ids)
        received += len(got)
        more = bool(data.get("exceededTransferLimit")) or (data.get("properties") or {}).get("exceededTransferLimit")
        server_signalled_more = bool(more)
        if repeated_page:
            stop_reason = "repeated_page"
            break
        if not got:
            stop_reason = "empty_page_before_expected_count" if expected is not None and received < expected else "server_no_more_results"
            break
        offset += len(got)
        if expected is not None and received >= expected and not more:
            stop_reason = "expected_count_reached"
            break
        if len(got) < request_page and not more:
            stop_reason = "server_no_more_results"
            break
    paging = _paging_result(expected, received, stop_reason, duplicate_ids, repeated_page, server_signalled_more)
    merged = os.path.join(raw_dir, f"{name}.geojson")
    with open(merged, "w", encoding="utf-8") as fh:
        json.dump({"paths_relative_to": "this file's directory", "type": "FeatureCollection", "features": features,
                   "_provenance": {"pages": [p["sha256"] for p in pages], "n_features": len(features), **paging}}, fh)
    merged_provenance = {"merged_from_pages": [p["path"] for p in pages], "sha256": downloader.sha256_file(merged),
                         "path": os.path.abspath(merged), "page_sha256": [p["sha256"] for p in pages],
                         "n_features": len(features), "licence": _licence(src), "source": src.get("record", {}),
                         "retrieved_at": now(), "request_signature": sig, **paging}
    downloader.write_provenance(merged_provenance, merged + ".provenance.json")
    index.add(merged_provenance)
    if status is not None:
        status["request_signature"] = sig
        status["paging"] = paging
    log(f"{name}: {len(features)} features in {len(pages)} page(s); paging={paging['completeness']} "
        f"expected={expected} received={received} stop={stop_reason}")
    return merged


def fetch_wfs(name: str, src: dict, aoi: list[float], raw_dir: str, budget, index,
              reuse: bool = True, status: dict | None = None, allowed_hosts=None) -> str:
    hosts = _source_hosts(src, allowed_hosts)
    bbox_crs = src.get("bbox_srs", src.get("srs", "EPSG:4326"))
    bbox_axis = _bbox_axis_order(bbox_crs, src.get("bbox_axis_order"))
    bbox = _wfs_bbox(aoi, bbox_crs, bbox_axis, densify=int(src.get("boundary_densify", 256)))
    target_crs = src.get("target_srs", src.get("output_srs", src.get("srs", "EPSG:4326")))
    page = int(src.get("page_size", 1000))
    max_features = int(src.get("max_features", 50_000))
    output_format = src.get("output_format", "application/json")
    sig = downloader.request_signature("wfs_getfeature", url=src["url"], type_name=src["type_name"], bbox=bbox,
                                       output_format=output_format, target_crs=target_crs,
                                       cql_filter=src.get("cql_filter"), page_size=page,
                                       max_features=max_features)
    cached = _reuse(name, sig, index, reuse, status)
    if cached:
        rec = index.by_signature(sig) or {}
        if status is not None:
            status["paging"] = {k: rec.get(k) for k in (
                "completeness", "expected_count", "received_count", "stop_reason", "duplicate_ids",
                "repeated_page", "warning")}
        return cached
    features: list = []
    pages = []
    start = 0
    received = 0
    expected = _numeric_count(src.get("expected_count"))
    duplicate_ids: list[str] = []
    seen_ids: set[str] = set()
    seen_pages: set[str] = set()
    seen_urls: set[str] = set()
    repeated_page = False
    server_signalled_more = False
    stop_reason = "unknown"
    response_crs = None
    response_axis = None
    current_url = None
    while True:
        if received >= max_features:
            stop_reason = "max_features_reached"
            break
        request_page = min(page, max_features - received)
        if current_url is None:
            url = (f"{src['url']}?service=WFS&version=2.0.0&request=GetFeature&typeNames={quote(src['type_name'])}"
                   f"&outputFormat={quote(output_format)}&bbox={quote(bbox, safe=',:')}"
                   f"&srsName={quote(target_crs, safe=':')}&count={request_page}&startIndex={start}")
            if src.get("cql_filter"):
                url += f"&cql_filter={quote(src['cql_filter'])}"
        else:
            url = current_url
        if url in seen_urls:
            stop_reason = "repeated_page"
            repeated_page = True
            break
        seen_urls.add(url)
        dest = os.path.join(raw_dir, name, f"page_{received:06d}.geojson")
        try:
            rec = downloader.download(url, dest, budget=budget, user_agent=USER_AGENT, licence=_licence(src),
                                      source=src.get("record", {}), overwrite=True,
                                      max_bytes=int(src.get("max_bytes", 200_000_000)),
                                      request_signature=f"{sig}:page:{received}", allowed_hosts=hosts)
        except fetch_budget.BudgetExceeded:
            stop_reason = "request_budget_exhausted"
            break
        index.add(rec)
        pages.append(rec)
        with open(dest, encoding="utf-8") as fh:
            head = fh.read(200)
        if head.lstrip().startswith("<"):
            raise downloader.DownloadError(f"WFS returned XML (exception?) for {name}: {head[:120]}")
        with open(dest, encoding="utf-8") as fh:
            data = json.load(fh)
        got = data.get("features", [])
        declared_crs, declared_axis = _response_crs(data, src, output_format)
        if response_crs is None:
            response_crs, response_axis = declared_crs, declared_axis
        elif response_crs != declared_crs or response_axis != declared_axis:
            raise downloader.DownloadError(
                f"WFS 페이지별 CRS/축 순서가 다릅니다: {response_crs}/{response_axis} vs {declared_crs}/{declared_axis}")
        got = _transform_geojson_features(got, response_crs, target_crs, response_axis)
        reported = _reported_count(data, ("numberMatched",))
        if reported is not None:
            expected = reported
        number_returned = _reported_count(data, ("numberReturned",))
        repeated_page = _accept_page(got, seen_pages, seen_ids, features, duplicate_ids)
        received += len(got)
        matched = expected
        next_href = _next_link(data)
        server_signalled_more = bool(next_href) or (expected is not None and received < expected)
        if repeated_page:
            stop_reason = "repeated_page"
            break
        if number_returned is not None and number_returned != len(data.get("features", [])):
            stop_reason = "server_count_inconsistent"
            break
        if expected is not None and received >= expected:
            stop_reason = "expected_count_reached"
            break
        if next_href:
            from urllib.parse import urljoin
            next_url = urljoin(url, next_href)
            if urlsplit(next_url).netloc.lower() != urlsplit(src["url"]).netloc.lower():
                stop_reason = "next_link_other_host"
                break
            current_url = next_url
            start += len(got)
            continue
        if not got:
            stop_reason = "empty_page_before_expected_count" if expected is not None and received < expected else "server_no_more_results"
            break
        if len(got) < request_page:
            stop_reason = "empty_page_before_expected_count" if expected is not None and received < expected else "server_no_more_results"
            break
        start += len(got)
        current_url = None
    paging = _paging_result(expected, received, stop_reason, duplicate_ids, repeated_page, server_signalled_more)
    if response_crs is None:
        raise downloader.DownloadError(f"WFS에서 {name} 자료의 응답 CRS를 확인하지 못했습니다.")
    merged = os.path.join(raw_dir, f"{name}.geojson")
    with open(merged, "w", encoding="utf-8") as fh:
        json.dump({"paths_relative_to": "this file's directory", "type": "FeatureCollection",
                   "crs": {"type": "name", "properties": {"name": target_crs}}, "features": features,
                   "_provenance": {"pages": [p["sha256"] for p in pages], "n_features": len(features),
                                   "numberMatched": matched, **paging}}, fh)
    merged_provenance = {"merged_from_pages": [p["path"] for p in pages], "sha256": downloader.sha256_file(merged),
                         "path": os.path.abspath(merged), "page_sha256": [p["sha256"] for p in pages],
                         "n_features": len(features), "numberMatched": matched,
                         "bbox_crs": bbox_crs, "source_crs": response_crs, "target_crs": target_crs,
                         "response_axis_order": response_axis, "licence": _licence(src),
                         "source": src.get("record", {}), "retrieved_at": now(), "request_signature": sig, **paging}
    downloader.write_provenance(merged_provenance, merged + ".provenance.json")
    index.add(merged_provenance)
    if status is not None:
        status["request_signature"] = sig
        status["paging"] = paging
    log(f"{name}: {len(features)} features; numberMatched={matched}; paging={paging['completeness']} "
        f"expected={expected} received={received} stop={stop_reason}")
    return merged


WCS_TIFF_FORMATS = {"image/tiff", "image/geotiff", "image/tiff;application=geotiff"}


def wcs_subset(aoi_wgs84: list[float], src: dict) -> dict:
    """AOI(+query_buffer_deg) bounds in the coverage's native CRS, keyed by the coverage's axis labels.

    WCS 2.x core reads subset coordinates in the coverage's native CRS. The recipe states that CRS
    (`subset_crs`) and the labels of its easting/longitude and northing/latitude axes
    (`axes: {"x": ..., "y": ...}`), both taken from DescribeCoverage for the current service.
    """
    import grid_table as gt

    axes = src["axes"]
    (minx, miny, maxx, maxy), info = gt.bbox_bounds_in_crs(query_bbox(aoi_wgs84, src), src["subset_crs"],
                                                           densify=int(src.get("boundary_densify", 256)))
    return {"x_axis": axes["x"], "y_axis": axes["y"], "x": [minx, maxx], "y": [miny, maxy],
            "subset_crs": src["subset_crs"], "bounds_method": info}


def fetch_wcs(name: str, src: dict, aoi: list[float], raw_dir: str, budget, index,
              reuse: bool = True, status: dict | None = None, allowed_hosts=None) -> str:
    sub = wcs_subset(aoi, src)
    fmt = src.get("format", "image/tiff")
    url = (f"{src['url']}?service=WCS&version={src.get('version', '2.0.1')}&request=GetCoverage"
           f"&coverageId={quote(src['coverage_id'])}"
           f"&subset={quote(sub['x_axis'])}({sub['x'][0]!r},{sub['x'][1]!r})"
           f"&subset={quote(sub['y_axis'])}({sub['y'][0]!r},{sub['y'][1]!r})"
           f"&format={quote(fmt)}")
    sig = downloader.request_signature("wcs_getcoverage", url=url)
    cached = _reuse(name, sig, index, reuse, status)
    if cached:
        return cached
    dest = os.path.join(raw_dir, f"{name}.tif")
    rec = downloader.download(url, dest, budget=budget, user_agent=USER_AGENT, licence=_licence(src),
                              source=src.get("record", {}), overwrite=True,
                              max_bytes=int(src.get("max_bytes", 300_000_000)), request_signature=sig,
                              allowed_hosts=_source_hosts(src, allowed_hosts))
    if "tiff" not in (rec.get("content_type") or "").lower():
        with open(dest, "rb") as fh:
            head = fh.read(300)
        raise downloader.DownloadError(f"WCS did not return TIFF for {name}: {rec.get('content_type')} {head[:120]!r}")
    rec["wcs_subset"] = sub
    index.add(rec)
    if status is not None:
        status["request_signature"] = sig
    log(f"{name}: {rec['bytes']} bytes GeoTIFF")
    return dest


def fetch_file(name: str, src: dict, raw_dir: str, budget, index, reuse: bool = True,
               status: dict | None = None, allowed_hosts=None) -> list[str]:
    ext = os.path.splitext(urlsplit(src["url"]).path)[1] or ".bin"
    dest = os.path.join(raw_dir, f"{name}{ext}")
    sig = downloader.request_signature("file", url=src["url"])
    cached = _reuse(name, sig, index, reuse, status)
    if cached:
        return _select_files(cached, src, raw_dir, name)
    rec = downloader.download(src["url"], dest, budget=budget, user_agent=USER_AGENT, licence=_licence(src),
                              source=src.get("record", {}), overwrite=True,
                              max_bytes=int(src.get("max_bytes", 500_000_000)), request_signature=sig,
                              allowed_hosts=_source_hosts(src, allowed_hosts))
    index.add(rec)
    if status is not None:
        status["request_signature"] = sig
    return _select_files(dest, src, raw_dir, name)


def local_file(name: str, src: dict, raw_dir: str, index) -> list[str]:
    """사용자가 직접(예: 브라우저로) 받은 파일. 출처 URL·라이선스는 recipe에 적힌 대로 기록한다."""
    path = src["path"]
    if not os.path.exists(path):
        raise FileNotFoundError(path)
    rec = {"schema_version": 1, "url": src.get("url"), "final_url": None, "http_status": None, "content_type": None,
           "bytes": os.path.getsize(path), "sha256": downloader.sha256_file(path), "retrieved_at": now(),
           "user_agent": None, "path": os.path.abspath(path), "licence": _licence(src), "source": src.get("record", {}),
           "note": "local_file: obtained by the user outside this script"}
    downloader.write_provenance(rec, os.path.join(raw_dir, f"{name}.local.provenance.json"))
    index.add(rec)
    return _select_files(path, src, raw_dir, name)


def _select_files(path: str, src: dict, raw_dir: str, name: str) -> list[str]:
    if src.get("unzip") and zipfile.is_zipfile(path):
        out = os.path.join(raw_dir, name)
        os.makedirs(out, exist_ok=True)
        with zipfile.ZipFile(path) as zf:
            for member in zf.infolist():
                target = os.path.realpath(os.path.join(out, member.filename))
                if not target.startswith(os.path.realpath(out) + os.sep):
                    raise ValueError(f"zip path traversal: {member.filename}")
            zf.extractall(out)
        files = [os.path.join(r, f) for r, _, fs in os.walk(out) for f in fs]
    else:
        files = [path]
    pattern = src.get("select")
    if pattern:
        files = [f for f in files if fnmatch.fnmatch(os.path.basename(f), pattern)]
    return sorted(files)


# ---------------------------------------------------------------------------
# 격자 표
# ---------------------------------------------------------------------------
def _match(props: dict, rule: dict | None) -> bool:
    if not rule:
        return True
    property_name = rule.get("property")
    if not property_name:
        raise ValueError(f"predicate.property가 없다: {rule}")
    val = props.get(property_name)
    sval = "" if val is None else str(val)
    if "equals" in rule:
        return sval == str(rule["equals"])
    if "contains" in rule:
        return str(rule["contains"]) in sval
    if "in" in rule:
        return sval in {str(v) for v in rule["in"]}
    if "regex" in rule:
        return re.search(rule["regex"], sval) is not None
    raise ValueError(f"알 수 없는 filter: {rule}")


FEATURE_TYPES = {"raster", "distance", "polygon_attribute", "polygon_fraction", "line_density", "point_statistic",
                 "point_presence"}
USER_ROLES = {"value", "diagnostic"}
POINT_RULES = {"centroid", "representative_point"}


def default_role(feat: dict) -> str:
    """Column role when the recipe gives none: record-derived for presence, diagnostic for sample counts."""
    if feat.get("type") == "point_presence":
        return "record_derived"
    if feat.get("type") == "point_statistic" and feat.get("stat") == "count":
        return "diagnostic"
    return "value"


def derived_columns(feat: dict, recipe: dict) -> list[str]:
    """Names of the extra columns a feature adds next to its own column."""
    name = feat.get("name")
    extra = []
    if feat.get("type") == "point_presence":
        extra.append(f"{name}_count")
    if feat.get("fill"):
        extra.append(f"{name}_support_distance")
    source = (recipe.get("sources") or {}).get(feat.get("source")) or {}
    if feat.get("type") == "distance" and source.get("type") in ("esri_query", "wfs_getfeature"):
        extra.append(f"{name}_edge_limited")
    return extra


def validate_recipe(recipe: dict) -> list[str]:
    """자리표시자·형식 오류를 네트워크 접근 전에 잡는다."""
    problems = []
    if "label" in recipe:
        problems.append("최상위 label 블록은 쓰지 않는다: 점 기록의 있음 표시는 features에 "
                        "type=point_presence로 적는다")
    if "min_features" in (recipe.get("requirements") or {}):
        problems.append("requirements.min_features는 쓰지 않는다: 요청한 열은 모두 만들어져야 하며 빠지면 오류로 보고한다")
    mmf = (recipe.get("requirements") or {}).get("max_missing_fraction")
    if mmf is not None and (isinstance(mmf, bool) or not isinstance(mmf, (int, float)) or not 0 <= mmf <= 1):
        problems.append("requirements.max_missing_fraction은 0–1 숫자여야 한다")
    aoi = recipe.get("aoi_wgs84")
    if not (isinstance(aoi, list) and len(aoi) == 4 and all(isinstance(v, (int, float)) for v in aoi)):
        problems.append(f"aoi_wgs84는 숫자 4개(west, south, east, north)여야 한다: {aoi!r}")
    elif not (aoi[0] < aoi[2] and aoi[1] < aoi[3]):
        problems.append(f"aoi_wgs84 순서가 잘못됐다(west<east, south<north): {aoi}")
    g = recipe.get("grid") or {}
    for k in ("crs", "cell_size"):
        if k not in g:
            problems.append(f"grid.{k} 없음")
    if not g.get("from_aoi") and not all(k in g for k in ("minx", "miny", "maxx", "maxy")):
        problems.append("grid 경계(minx/miny/maxx/maxy)가 없으면 grid.from_aoi=true를 지정한다")
    b = recipe.get("budget") or {}
    for key in ("max_requests", "max_seconds"):
        v = b.get(key)
        if v is not None and (isinstance(v, bool) or not isinstance(v, (int, float)) or v <= 0):
            problems.append(f"budget.{key}는 양수여야 한다")
    for name, src in (recipe.get("sources") or {}).items():
        required = {"esri_query": ["url"], "wfs_getfeature": ["url", "type_name"],
                    "wcs_getcoverage": ["url", "coverage_id", "subset_crs", "axes"], "file": ["url"],
                    "local_file": ["path"]}
        if src.get("type") not in required:
            problems.append(f"source {name}: 지원하지 않거나 누락된 type")
        else:
            for key in required[src["type"]]:
                if not src.get(key):
                    problems.append(f"source {name}.{key} 없음")
        for key in ("url", "url_template", "path"):
            v = src.get(key)
            if isinstance(v, str) and ("<" in v or ">" in v):
                problems.append(f"source {name}.{key}에 자리표시자가 남아 있다: {v}")
        buffer = src.get("query_buffer_deg")
        if buffer is not None and (isinstance(buffer, bool) or not isinstance(buffer, (int, float)) or buffer < 0):
            problems.append(f"source {name}.query_buffer_deg는 0 이상의 숫자(도)여야 한다")
        if src.get("type") == "esri_query":
            if "where" in src and (not isinstance(src["where"], str) or not src["where"].strip()):
                problems.append(f"source {name}.where는 비어 있지 않은 문자열이어야 한다")
            if "out_fields" in src and (not isinstance(src["out_fields"], str) or not src["out_fields"].strip()):
                problems.append(f"source {name}.out_fields는 '*' 또는 필드 목록이어야 한다")
            for key in ("page_size", "max_record_count"):
                v = src.get(key)
                if key in src and (isinstance(v, bool) or not isinstance(v, int) or v < 1):
                    problems.append(f"source {name}.{key}는 양의 정수여야 한다")
        if src.get("type") == "wcs_getcoverage":
            if "margin_deg" in src:
                problems.append(f"source {name}.margin_deg는 쓰지 않는다: AOI 확장은 query_buffer_deg로 적는다")
            axes = src.get("axes")
            if axes and not (isinstance(axes, dict) and isinstance(axes.get("x"), str) and axes.get("x")
                             and isinstance(axes.get("y"), str) and axes.get("y")):
                problems.append(f"source {name}.axes는 DescribeCoverage의 축 이름 {{\"x\": 동·경도 축, \"y\": 북·위도 축}}이어야 한다")
            if src.get("subset_crs"):
                try:
                    from pyproj import CRS
                    CRS.from_user_input(src["subset_crs"])
                except Exception:
                    problems.append(f"source {name}.subset_crs를 해석할 수 없다: {src['subset_crs']!r}")
            fmt = str(src.get("format", "image/tiff")).lower().replace(" ", "")
            if fmt not in WCS_TIFF_FORMATS:
                problems.append(f"source {name}.format: 이 실행기는 GeoTIFF 응답만 지원한다({sorted(WCS_TIFF_FORMATS)})")
    names_seen = []
    for f in recipe.get("features") or []:
        ftype = f.get("type")
        if ftype not in FEATURE_TYPES:
            problems.append(f"feature {f.get('name')}: 지원하지 않거나 누락된 type")
        if ftype in {"polygon_attribute", "polygon_fraction", "point_statistic"} and not f.get("property"):
            problems.append(f"feature {f.get('name')}.property 없음")
        expected_unit = {"polygon_fraction": "fraction", "line_density": "km/km2"}.get(ftype)
        if expected_unit and f.get("unit", expected_unit) != expected_unit:
            problems.append(f"feature {f.get('name')}.unit은 {expected_unit}여야 한다")
        predicate = f.get("predicate", f.get("filter"))
        if ftype == "polygon_fraction" and not predicate:
            problems.append(f"feature {f.get('name')}.predicate가 필요하다(대상 범주를 명시한다)")
        if predicate is not None:
            if not isinstance(predicate, dict) or not predicate.get("property"):
                problems.append(f"feature {f.get('name')}.predicate는 property와 비교 규칙을 가진 객체여야 한다")
            elif sum(k in predicate for k in ("equals", "contains", "in", "regex")) != 1:
                problems.append(f"feature {f.get('name')}.predicate에는 equals|contains|in|regex 중 하나가 필요하다")
            elif "regex" in predicate:
                try:
                    re.compile(str(predicate["regex"]))
                except re.error as exc:
                    problems.append(f"feature {f.get('name')}.predicate.regex가 잘못됐다: {exc}")
        if ftype == "point_presence":
            if "role" in f and f["role"] != "record_derived":
                problems.append(f"feature {f.get('name')}.role: point_presence 열의 역할은 record_derived로 고정이다")
            buf = f.get("buffer", 0)
            if isinstance(buf, bool) or not isinstance(buf, (int, float)) or buf < 0:
                problems.append(f"feature {f.get('name')}.buffer는 0 이상의 숫자(격자 CRS 단위)여야 한다")
        elif "role" in f and f["role"] not in USER_ROLES:
            problems.append(f"feature {f.get('name')}.role은 value|diagnostic 중 하나여야 한다")
        if "point_rule" in f and (ftype not in {"point_statistic", "point_presence"} or f["point_rule"] not in POINT_RULES):
            problems.append(f"feature {f.get('name')}.point_rule은 point_statistic·point_presence에서 "
                            f"{sorted(POINT_RULES)} 중 하나로만 쓴다")
        fill = f.get("fill")
        if fill is not None:
            if f.get("type") != "point_statistic":
                problems.append(f"feature {f.get('name')}: fill은 point_statistic에만 쓴다")
            md = fill.get("max_distance") if isinstance(fill, dict) else None
            if not isinstance(md, (int, float)) or isinstance(md, bool) or md <= 0:
                problems.append(f"feature {f.get('name')}.fill.max_distance는 양수여야 한다(무제한 외삽 금지)")
        if isinstance(f.get("file"), str) and ("<" in f["file"] or ">" in f["file"]):
            problems.append(f"feature {f.get('name')}.file에 자리표시자가 남아 있다")
        if f.get("source") not in (recipe.get("sources") or {}):
            problems.append(f"feature {f.get('name')}의 source가 없다: {f.get('source')}")
        names_seen += [f.get("name"), *derived_columns(f, recipe)]
    handoff = (recipe.get("output") or {}).get("handoff", "aoi_centre")
    if handoff not in {"aoi_centre", "full_grid"}:
        problems.append("output.handoff는 aoi_centre|full_grid 중 하나여야 한다")
    names = [g.get("x_column", "x"), g.get("y_column", "y"), *names_seen]
    reserved = {"cell_id", "row", "col", "in_aoi"}
    if any(not isinstance(n, str) or not n or n in reserved for n in names) or len(set(names)) != len(names):
        problems.append("좌표·feature 열 이름(파생 열 포함)은 필수·고유하며 cell_id/row/col/in_aoi와 충돌할 수 없다")
    return problems


def query_bbox(aoi_wgs84: list[float], src: dict) -> list[float]:
    """Source query bbox: the AOI widened by the source's optional `query_buffer_deg` (degrees, >= 0)."""
    buffer = float(src.get("query_buffer_deg") or 0.0)
    west, south, east, north = map(float, aoi_wgs84)
    return [max(west - buffer, -180.0), max(south - buffer, -90.0), min(east + buffer, 180.0), min(north + buffer, 90.0)]


def grid_bounds_from_aoi(aoi_wgs84: list[float], crs: str, cell_size: float, densify: int = 256) -> dict:
    """WGS84 bbox(west, south, east, north)를 격자 CRS로 옮겨 셀 크기 배수로 넓힌 경계.

    경계는 촘촘히 나눈 AOI 경계를 투영한 근사이며(`grid_table.bbox_bounds_in_crs`), 근사 방법과
    추정 편차를 `bounds_method`에 남긴다.
    """
    import math
    import grid_table as gt

    (minx, miny, maxx, maxy), info = gt.bbox_bounds_in_crs(aoi_wgs84, crs, densify=densify)
    return {"minx": math.floor(minx / cell_size) * cell_size, "miny": math.floor(miny / cell_size) * cell_size,
            "maxx": math.ceil(maxx / cell_size) * cell_size, "maxy": math.ceil(maxy / cell_size) * cell_size,
            "bounds_method": info}


def _as_points(geoms: list, feat: dict) -> tuple[list, str | None]:
    """Point geometries for point features. Other geometries need an explicit `point_rule`."""
    if all(g.geom_type == "Point" for g in geoms):
        return list(geoms), None
    rule = feat.get("point_rule")
    if rule == "centroid":
        return [g if g.geom_type == "Point" else g.centroid for g in geoms], rule
    if rule == "representative_point":
        return [g if g.geom_type == "Point" else g.representative_point() for g in geoms], rule
    kinds = sorted({g.geom_type for g in geoms if g.geom_type != "Point"})
    raise ValueError(f"{feat['name']}: point가 아닌 geometry {kinds}가 있다. 바꾸는 규칙을 "
                     f"point_rule(centroid|representative_point)로 명시한다")


def build_table(recipe: dict, files: dict[str, list[str]], workspace: str, index,
                source_completeness: dict | None = None) -> tuple[dict, int]:
    import numpy as np
    import pandas as pd
    import grid_table as gt

    g = dict(recipe["grid"])
    bounds_method = None
    if g.get("from_aoi") or not all(k in g for k in ("minx", "miny", "maxx", "maxy")):
        bounds = grid_bounds_from_aoi(recipe["aoi_wgs84"], g["crs"], float(g["cell_size"]),
                                      densify=int(g.get("boundary_densify", 256)))
        bounds_method = bounds.pop("bounds_method")
        g.update(bounds)
        log(f"grid bounds from aoi_wgs84: {[g[k] for k in ('minx', 'miny', 'maxx', 'maxy')]} ({g['crs']}, cell {g['cell_size']})")
    spec = gt.GridSpec(crs=g["crs"], cell_size=g["cell_size"], minx=g["minx"], miny=g["miny"], maxx=g["maxx"],
                       maxy=g["maxy"], x_column=g.get("x_column", "x"), y_column=g.get("y_column", "y"))
    grid = gt.build_grid(spec)
    columns: dict[str, dict] = {}                 # every data column with its role
    values: dict[str, np.ndarray] = {}            # float columns in table order
    extra: dict[str, np.ndarray] = {}             # presence/count columns kept as integers
    units: dict[str, str] = {}
    vectors_cache: dict[str, tuple] = {}
    dropped: list[dict] = []

    def vector(source_name: str):
        if source_name not in vectors_cache:
            geoms, props, crs = gt.read_geojson(files[source_name][0])
            vectors_cache[source_name] = (gt.to_grid_crs(geoms, crs, spec), props, crs)
        return vectors_cache[source_name]

    for feat in recipe["features"]:
        name, ftype, source = feat["name"], feat["type"], feat["source"]
        role = feat.get("role") or default_role(feat)
        src_files = files.get(source, [])
        prov = index.by_sha(downloader.sha256_file(src_files[0])) if src_files else None
        col = {"definition": feat.get("definition", ""), "unit": feat.get("unit", "unknown"),
               "unit_basis": feat.get("unit_basis") or ("unconfirmed" if feat.get("unit", "unknown") == "unknown"
                                                         else "unconfirmed: stated in the recipe without a cited basis"),
               "type": ftype, "role": role,
               "source": source, "source_files": src_files, "source_sha256": prov["sha256"] if prov else None,
               "licence": (recipe["sources"][source].get("licence") or {}), "record": recipe["sources"][source].get("record", {})}
        source_spec = recipe["sources"][source]
        if source_spec.get("type") == "esri_query":
            col["source_query"] = {"where": source_spec.get("where", "1=1"),
                                   "out_fields": source_spec.get("out_fields", "*"),
                                   "page_size": esri_page_size(source_spec)}
        predicate = feat.get("predicate", feat.get("filter"))
        if predicate is not None:
            col["predicate"] = predicate
        extra_cols: dict[str, tuple[np.ndarray, dict]] = {}
        integer_column = False
        if ftype == "raster":
            path = feat.get("file") or (src_files[0] if len(src_files) == 1 else None)
            if path is None:
                raise ValueError(f"{name}: raster 파일이 여러 개다. 'file'로 지정한다: {src_files}")
            column, info = gt.sample_raster(spec, path, band=int(feat.get("band", 1)), method=feat.get("method", "mean"),
                                            src_nodata=feat.get("nodata"))
            col["sampling"] = info
            col["source_sha256"] = downloader.sha256_file(path)
        elif ftype == "distance":
            geoms, props, _ = vector(source)
            if predicate:
                geoms, props = gt.filter_features(geoms, props, lambda p: _match(p, predicate))
            if len(geoms) == 0:
                log(f"{name}: AOI 안에 feature가 0개라 열을 만들지 않는다")
                dropped.append({"feature": name, "reason": "0 features in AOI after filter"})
                continue
            column = gt.distance_to_features(spec, geoms, grid)
            col["unit"] = spec.unit
            col["unit_basis"] = f"computed in the grid CRS {spec.crs}; axis unit {spec.unit}"
            if source_spec.get("type") in ("esri_query", "wfs_getfeature"):
                limited, edge_info = gt.distance_edge_limited(spec, column, query_bbox(recipe["aoi_wgs84"], source_spec),
                                                              grid, densify=int(g.get("boundary_densify", 256)))
                extra_cols[f"{name}_edge_limited"] = (limited.astype(float), {
                    "definition": (f"1 where {name} may be overestimated because features beyond the source query "
                                   "bbox were not requested; diagnostic, not a geological signal"),
                    "unit": "binary flag", "unit_basis": "computed flag", "type": "edge_limited_flag",
                    "role": "diagnostic", "source": source, "derived_from": name, **edge_info})
                col["edge_effect"] = edge_info
                if edge_info["n_cells_edge_limited"]:
                    log(f"{name}: {edge_info['n_cells_edge_limited']} cells may be edge-limited; "
                        "widen query_buffer_deg if this matters")
            col["sampling"] = {"method": "distance from cell centre to nearest feature", "n_features": len(geoms),
                               "predicate": predicate}
        elif ftype == "polygon_fraction":
            geoms, props, _ = vector(source)
            if predicate:
                geoms, props = gt.filter_features(geoms, props, lambda p: _match(p, predicate))
            if not geoms:
                log(f"{name}: predicate를 통과한 polygon이 0개라 열을 만들지 않는다")
                dropped.append({"feature": name, "reason": "0 matching polygons"})
                continue
            column, info = gt.polygon_fraction(spec, geoms, grid)
            col["sampling"] = {"property": feat["property"], "predicate": predicate, **info}
            col["unit"] = "fraction"
            col["unit_basis"] = "computed by the table builder from projected geometry"
        elif ftype == "line_density":
            geoms, props, _ = vector(source)
            if predicate:
                geoms, props = gt.filter_features(geoms, props, lambda p: _match(p, predicate))
            if not geoms:
                log(f"{name}: predicate를 통과한 line이 0개라 열을 만들지 않는다")
                dropped.append({"feature": name, "reason": "0 matching lines"})
                continue
            column, info = gt.line_density(spec, geoms, grid)
            col["sampling"] = {"predicate": predicate, **info}
            col["unit"] = "km/km2"
            col["unit_basis"] = "computed by the table builder from projected geometry"
        elif ftype == "polygon_attribute":
            geoms, props, _ = vector(source)
            if predicate:
                geoms, props = gt.filter_features(geoms, props, lambda p: _match(p, predicate))
            if len(geoms) == 0:
                log(f"{name}: AOI 안에 polygon이 0개라 열을 만들지 않는다")
                dropped.append({"feature": name, "reason": "0 polygons in AOI"})
                continue
            mapping = feat.get("mapping")
            raw_vals = [p.get(feat["property"]) for p in props]
            if mapping:
                vals = [mapping.get(str(v)) for v in raw_vals]
            else:
                vals = []
                for v in raw_vals:
                    try:
                        vals.append(float(v))
                    except (TypeError, ValueError):
                        vals.append(None)
            column, info = gt.attribute_at_centers(spec, geoms, vals, grid)
            col["sampling"] = {"method": "attribute of polygon containing cell centre (last match wins on overlap)",
                               "property": feat["property"], "predicate": predicate, "mapping": mapping, **info}
        elif ftype == "point_statistic":
            geoms, props, _ = vector(source)
            if predicate:
                geoms, props = gt.filter_features(geoms, props, lambda p: _match(p, predicate))
            pts, point_rule = _as_points(geoms, feat)
            raw_vals = []
            for p_ in props:
                try:
                    raw_vals.append(float(p_.get(feat["property"])))
                except (TypeError, ValueError):
                    raw_vals.append(None)
            if len(pts) == 0:
                log(f"{name}: AOI 안에 표본 point가 0개라 열을 만들지 않는다")
                dropped.append({"feature": name, "reason": "0 sample points in AOI after filter"})
                continue
            stat = feat.get("stat", "median")
            column, info = gt.point_statistic(spec, pts, raw_vals, stat=stat, grid=grid)
            info = {"method": f"per-cell {stat} of sample points (NaN where no sample)", "property": feat["property"],
                    "point_rule": point_rule, **info}
            if stat == "count":
                col["unit"] = feat.get("unit", "count")
                col["unit_basis"] = "computed count of records per cell"
            fill = feat.get("fill")
            if fill:
                column, support, finfo = gt.nearest_fill(spec, column, pts, raw_vals, float(fill["max_distance"]), grid=grid)
                info["fill"] = finfo
                extra_cols[f"{name}_support_distance"] = (support, {
                    "definition": f"Distance from cell centre to nearest valid sample used for {name}; survey-support diagnostic, not a geological signal",
                    "unit": spec.unit, "unit_basis": f"computed in the grid CRS {spec.crs}; axis unit {spec.unit}",
                    "type": "support_distance", "role": "diagnostic", "source": source, "derived_from": name})
            col["sampling"] = info
        elif ftype == "point_presence":
            geoms, props, _ = vector(source)
            n_total = len(geoms)
            if predicate:
                geoms, props = gt.filter_features(geoms, props, lambda p: _match(p, predicate))
            pts, point_rule = _as_points(geoms, feat)
            column, counts, pinfo = gt.presence_from_points(spec, pts, buffer=float(feat.get("buffer", 0)), grid=grid)
            integer_column = True
            col["unit"] = "record presence"
            col["unit_basis"] = "computed from the selected records"
            col["sampling"] = {"point_rule": point_rule, "n_features_total": n_total,
                               "n_features_after_filter": len(pts), **pinfo}
            col["absence_semantics"] = pinfo["absence_semantics"]
            extra_cols[f"{name}_count"] = (counts, {
                "definition": f"Number of selected records in the cell used for {name}",
                "unit": "count", "unit_basis": "computed count of records per cell", "type": "record_count",
                "role": "record_derived", "source": source, "derived_from": name,
                "absence_semantics": pinfo["absence_semantics"]})
        else:
            raise ValueError(f"알 수 없는 feature type: {ftype}")
        units[name] = col["unit"]
        columns[name] = col
        if integer_column:
            extra[name] = np.asarray(column).astype(int)
        else:
            values[name] = column
        for sname, (svalues, smeta) in extra_cols.items():
            smeta = {"source_sha256": col["source_sha256"], **smeta}
            if smeta["type"] == "record_count":
                extra[sname] = np.asarray(svalues).astype(int)
            else:
                values[sname] = svalues
            units[sname] = smeta["unit"]
            columns[sname] = smeta

    # 정확한 AOI 소속(셀 중심 역변환). 전체 격자는 보존하고 인계 표는 정책에 따라 고른다.
    in_aoi, dinfo = gt.aoi_mask(spec, recipe["aoi_wgs84"], grid=grid)
    extra["in_aoi"] = in_aoi.astype(int)
    columns["in_aoi"] = {"role": "mask", "unit": "binary flag", "unit_basis": "computed flag",
                         "definition": "1 if the cell centre lies inside the requested AOI (" + dinfo["method"] + "); 0 otherwise."}
    df = gt.assemble_table(spec, values, grid=grid, extra=extra)
    value_cols = [n for n, c in columns.items() if c.get("role") == "value"]
    presence_cols = [n for n, c in columns.items() if c.get("type") == "point_presence"]
    max_missing = (recipe.get("requirements") or {}).get("max_missing_fraction")
    report = gt.validate_table(df, spec, value_cols, presence_columns=presence_cols,
                               max_missing_fraction=max_missing)
    for dname, meta_ in columns.items():
        if meta_.get("role") in ("diagnostic", "record_derived") and dname not in presence_cols:
            if not pd.api.types.is_numeric_dtype(df[dname]):
                report["errors"].append(f"{meta_['role']} column not numeric: {dname}")
            elif df[dname].isna().all():
                report["warnings"].append(f"{meta_['role']} column all missing: {dname}")
    if dropped:
        report["errors"].append(f"requested columns missing: {[d['feature'] for d in dropped]}")
    report["ok"] = not report["errors"]
    out_dir = os.path.join(workspace, "table")
    name = recipe.get("output", {}).get("name", "grid_table")
    table = gt.write_table(df, out_dir, name=name)
    records_inside = {c: int(((df[c] == 1) & in_aoi).sum()) for c in presence_cols}
    records_outside = {c: int(((df[c] == 1) & ~in_aoi).sum()) for c in presence_cols}
    policy = (recipe.get("output") or {}).get("handoff", "aoi_centre")
    domain = {"mask_column": "in_aoi", **dinfo, "present_cells_inside": records_inside,
              "present_cells_outside": records_outside, "handoff_policy": policy,
              "note": ("Rows outside the AOI keep computed values. Sources were queried for the AOI (plus any query "
                       "buffer), so record-derived columns outside it are not evidence of no records. The full grid "
                       "and in_aoi mask preserve boundary-cell choices for later work.")}
    if bounds_method is not None:
        domain["grid_bounds_method"] = bounds_method
    if policy == "aoi_centre":
        handoff_df = df[in_aoi].reset_index(drop=True)
        handoff = gt.write_table(handoff_df, out_dir, name=f"{name}.in-aoi")
        handoff_report = gt.validate_table(handoff_df, spec, value_cols, presence_columns=presence_cols,
                                           require_full_grid=False, max_missing_fraction=max_missing)
        domain["handoff_table"] = {**handoff, "rows_excluded": int(len(df) - len(handoff_df)),
                                   "present_cells_excluded": records_outside, "validation": handoff_report}
        if handoff_report["errors"]:
            report["errors"].extend(f"handoff: {e}" for e in handoff_report["errors"])
            report["ok"] = False
    else:
        handoff = None
        domain["handoff_table"] = {**table, "note": "full grid handed off; rows outside AOI carry in_aoi=0"}
    meta = gt.build_metadata(spec, table, columns, report, provenance=index.records,
                             notes=recipe.get("notes", []), project=recipe.get("project", ""))
    meta["aoi_wgs84"] = recipe.get("aoi_wgs84")
    meta["domain"] = domain
    meta["dropped_features"] = dropped
    meta["source_completeness"] = source_completeness or {}
    for source_name, paging in (source_completeness or {}).items():
        if paging.get("completeness") != "complete":
            warning = paging.get("warning") or f"source {source_name} paging completeness is {paging.get('completeness', 'unknown')}"
            report["warnings"].append(f"source {source_name}: {warning}")
    meta["validation"] = report
    meta_path = gt.write_json(meta, os.path.join(out_dir, f"{name}.metadata.json"))
    boundary = gt.aoi_boundary_in_grid_crs(spec, recipe["aoi_wgs84"])
    shown = [n for n in columns if columns[n].get("role") == "value"] + presence_cols
    png = gt.preview_figure(spec, df, shown, os.path.join(out_dir, f"{name}.preview.png"),
                            marker_column=presence_cols[0] if presence_cols else None, units=units,
                            title=f"{recipe.get('project', name)} (acquisition preview)",
                            mask=in_aoi, boundary=boundary)
    summary = {"table": table, "metadata": meta_path, "preview": png, "handoff": handoff,
               "domain": {k: domain[k] for k in ("n_inside", "n_outside", "present_cells_inside",
                                                 "present_cells_outside", "handoff_policy")},
               "validation": report, "n_value_columns": len(value_cols),
               "n_diagnostics": sum(1 for c in columns.values() if c.get("role") == "diagnostic"),
               "record_columns": presence_cols, "source_completeness": source_completeness or {},
               "dropped_features": dropped}
    return summary, (0 if report["ok"] else 2)


# ---------------------------------------------------------------------------
def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--recipe", required=True)
    ap.add_argument("--workspace", required=True)
    ap.add_argument("--approve-hosts", action="store_true", help="현재 사용자의 승인을 --approved-by/--evidence 및 선택적 --approval-scope로 기록")
    ap.add_argument("--approve-disallowed", action="store_true",
                    help="이전 명령 호환용: 별도 robots 승인 gate 없음")
    ap.add_argument("--approve-unreadable-robots", action="store_true",
                    help="이전 명령 호환용: robots 읽기 실패는 유효한 승인을 막지 않음")
    ap.add_argument("--approved-by", default="")
    ap.add_argument("--approval-scope", default="", help="선택 항목: 현재 작업 식별자(기본: current workspace task; 절대 경로 금지)")
    ap.add_argument("--evidence", default="")
    ap.add_argument("--dry-run", action="store_true", help="승인 확인과 계획만 출력")
    ap.add_argument("--no-reuse", action="store_true", help="검증된 기존 파일이 있어도 다시 요청한다(기본은 요청 서명·sha256 일치 시 재사용)")
    args = ap.parse_args(argv)
    with open(args.recipe, encoding="utf-8") as fh:
        recipe = json.load(fh)
    problems = validate_recipe(recipe)
    if problems:
        print("recipe 오류(네트워크 접근 전 중단):\n  - " + "\n  - ".join(problems))
        return 1
    ws = os.path.abspath(args.workspace)
    raw_dir = os.path.join(ws, "raw")
    os.makedirs(raw_dir, exist_ok=True)
    b = recipe.get("budget", {})
    budget = fetch_budget.FetchBudget(delay=float(b.get("delay", 1.0)), max_requests=b.get("max_requests", 120),
                                      max_seconds=b.get("max_seconds"))
    state_path = os.path.join(ws, "acquisition-state.json")
    recipe_path = os.path.abspath(args.recipe)
    state = {"schema_version": 1, "project": recipe.get("project", ""),
             "recipe": recipe_path, "recipe_sha256": downloader.sha256_file(recipe_path),
             "started_at": now(), "hosts": {}, "downloads": {}, "table": None,
             "validation": None, "open_issues": [], "budget": None, "result_status": "in_progress"}

    def save_state():
        state["updated_at"] = now()
        state["budget"] = budget.snapshot()
        artifact_paths.dump_json(state, state_path)

    try:
        check_consent(recipe, ws, budget, args, report=state["hosts"])
    except fetch_budget.BudgetExceeded as exc:
        state["open_issues"].append(str(exc)); save_state(); return 3
    save_state()
    if any(v["status"].startswith("approval_required") for v in state["hosts"].values()):
        return 3
    if args.dry_run:
        result = {"hosts": state["hosts"], "sources": list(recipe["sources"]),
                  "features": [f["name"] for f in recipe["features"]]}
        print(json.dumps(artifact_paths.PathSerializer(os.path.join(ws, "stdout.json")).portable(result, stdout=True),
                         ensure_ascii=False, indent=2))
        return 0
    approved_hosts = set(state["hosts"])  # every host passed the consent check above
    index = downloader.ProvenanceIndex(os.path.join(ws, "provenance-index.json"))
    files: dict[str, list[str]] = {}
    source_statuses: dict[str, dict] = {}
    aoi = recipe.get("aoi_wgs84")
    reuse = not args.no_reuse
    for name, src in recipe["sources"].items():
        status: dict = {}
        try:
            t = src["type"]
            if t == "esri_query":
                files[name] = [fetch_esri_query(name, src, query_bbox(aoi, src), raw_dir, budget, index,
                                                reuse=reuse, status=status, allowed_hosts=approved_hosts)]
            elif t == "wfs_getfeature":
                files[name] = [fetch_wfs(name, src, query_bbox(aoi, src), raw_dir, budget, index,
                                         reuse=reuse, status=status, allowed_hosts=approved_hosts)]
            elif t == "wcs_getcoverage":
                files[name] = [fetch_wcs(name, src, aoi, raw_dir, budget, index, reuse=reuse, status=status,
                                         allowed_hosts=approved_hosts)]
            elif t == "file":
                files[name] = fetch_file(name, src, raw_dir, budget, index, reuse=reuse, status=status,
                                         allowed_hosts=approved_hosts)
            elif t == "local_file":
                files[name] = local_file(name, src, raw_dir, index)
            else:
                raise ValueError(f"알 수 없는 source type: {t}")
            source_statuses[name] = status
            paging = status.get("paging")
            incomplete = paging is not None and paging.get("completeness") != "complete"
            state["downloads"][name] = {"files": files[name], "status": "partial" if incomplete else "ok",
                                        "reused": bool(status.get("reused")),
                                        "request_signature": status.get("request_signature"), "paging": paging}
            if incomplete:
                state["open_issues"].append(f"source {name}: {paging.get('warning') or 'paging completeness not established'}")
        except fetch_budget.BudgetExceeded as exc:
            state["downloads"][name] = {"files": [], "status": "stopped", "error": str(exc)}
            state["open_issues"].append(f"source {name}: {exc}")
            save_state()
            return 3
        except (downloader.DownloadError, FileNotFoundError, ValueError) as exc:
            log(f"{name}: FAILED {exc}")
            state["downloads"][name] = {"files": [], "status": "failed", "error": str(exc)}
            state["open_issues"].append(f"source {name}: {exc}")
            if isinstance(exc, downloader.DownloadError) and exc.status in (401, 403):
                save_state()
                return 3
        save_state()
    skipped = [f["name"] for f in recipe["features"] if not files.get(f["source"])]
    if skipped:
        state["open_issues"].append(f"source 실패로 제외한 feature: {skipped}")
        recipe = dict(recipe, features=[f for f in recipe["features"] if files.get(f["source"])])
        log(f"제외한 feature: {skipped}")
    if not recipe["features"]:
        state["open_issues"].append("사용 가능한 feature가 없다")
        state["result_status"] = "partial"
        save_state()
        return 2
    source_completeness = {name: data["paging"] for name, data in source_statuses.items()
                           if data.get("paging") is not None}
    summary, code = build_table(recipe, files, ws, index, source_completeness=source_completeness)
    if skipped:
        summary["validation"]["errors"].append(f"requested columns failed: {skipped}")
        summary["validation"]["ok"] = False
        code = 2
        with open(summary["metadata"], encoding="utf-8") as fh:
            meta = json.load(fh)
        meta["validation"] = summary["validation"]
        artifact_paths.dump_json(meta, summary["metadata"])
    summary["skipped_features"] = skipped
    state["table"] = {k: summary[k] for k in ("table", "metadata", "preview", "handoff")}
    state["domain"] = summary["domain"]
    state["validation"] = summary["validation"]
    state["record_columns"] = summary["record_columns"]
    incomplete_sources = {n: p for n, p in source_completeness.items() if p.get("completeness") != "complete"}
    state["source_completeness"] = source_completeness
    if incomplete_sources:
        state["result_status"] = "partial"
        code = max(code, 2)
        for source_name, paging in incomplete_sources.items():
            issue = f"source {source_name}: {paging.get('warning') or 'paging completeness not established'}"
            if issue not in state["open_issues"]:
                state["open_issues"].append(issue)
    else:
        state["result_status"] = "complete" if code == 0 else "partial"
    for d in summary.get("dropped_features", []):
        state["open_issues"].append(f"feature {d['feature']} dropped: {d['reason']}")
    save_state()
    output = {"result": state["result_status"], "table": summary["table"]["path"],
                      "handoff": (summary["handoff"] or {}).get("path"), "domain": summary["domain"],
                      "rows": summary["table"]["rows"], "n_value_columns": summary["n_value_columns"],
                      "n_diagnostics": summary["n_diagnostics"],
                      "reused_sources": [n for n, d in state["downloads"].items() if d.get("reused")],
                      "present_cells": summary["validation"]["summary"].get("present_cells"),
                      "warnings": summary["validation"]["warnings"], "errors": summary["validation"]["errors"],
                      "source_completeness": source_completeness,
                      "skipped_features": summary.get("skipped_features", []),
                      "dropped_features": summary.get("dropped_features", []),
                      "requests": budget.snapshot(), "state": state_path}
    print(json.dumps(artifact_paths.PathSerializer(os.path.join(ws, "stdout.json")).portable(output, stdout=True),
                     ensure_ascii=False, indent=2, default=str))
    return code


if __name__ == "__main__":
    raise SystemExit(main())
