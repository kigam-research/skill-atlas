"""Playwright 기반 실제 Chromium 세션 — headless/auto 기본, headed/CDP 연결 선택.

공개 API·OGC/ArcGIS 서비스·정적 파일로 자료나 metadata를 얻을 수 없을 때 쓰는 선택형 도구다. JS
렌더링 SPA처럼 브라우저가 필요한 포털에서 실제 브라우저의 네트워크 기록으로 백엔드 API·서비스 URL을
찾는다. 수집 스크립트는 찾은 URL을 승인 범위 안에서 직접 호출하거나(downloader.py) 같은 세션으로 받는다.
WebSocket은 모두 차단하므로 WebSocket이 필요한 포털은 지원 범위 밖이다.

환경변수:
- MPM_ACQ_BROWSER_EXECUTABLE : Chromium 실행 파일 경로(Playwright 기본 브라우저와 버전이 다를 때)
- MPM_ACQ_HEADLESS           : true/false/auto. auto는 headless로 시작하고 앱 셸 증상 후 표시 장치가 있으면 headed로 재시도
- MPM_ACQ_BROWSER_ARGS       : host 운영자가 지정하는 공백 구분 Chromium 실행 인자
- MPM_ACQ_CDP_URL            : 이미 실행 중인 Chrome의 CDP 주소(예: http://localhost:9222). 사용자가
                               headed로 띄워 로그인한 Chrome에 붙을 때 쓴다.
- MPM_ACQ_HEADED=1           : 호환용 headed 설정 (`MPM_ACQ_HEADLESS=false`로 대체 가능)
- MPM_ACQ_USER_DATA_DIR      : 전용 프로필 디렉터리(로그인 유지). 평소 쓰는 Chrome 프로필을 쓰지 않는다.
- HTTPS_PROXY                : 있으면 브라우저 프록시로 전달한다(localhost는 우회).
- 자격증명: MPM_ACQ_<HOST>_USER / MPM_ACQ_<HOST>_PASSWORD (HOST는 점·하이픈을 밑줄로, 대문자). host 전용
  변수만 읽으며 공통 계정 변수로 대신하지 않는다. 값은 코드·로그·파일·프로필 기록 어디에도 남기지 않는다.

TLS: 검증을 끄는 옵션(ignore_https_errors, --ignore-certificate-errors)은 제공하지 않는다.
프록시 CA를 신뢰해야 하면 브라우저/OS의 신뢰 저장소에 CA를 등록하는 방식으로 해결한다.
"""
from __future__ import annotations

import contextlib
import json
import os
import re
import shlex
import shutil
import tempfile
import time
from dataclasses import dataclass, field
from typing import Iterator
from urllib.parse import parse_qsl, urlencode, urljoin, urlsplit, urlunsplit

API_HINT = re.compile(r"/(api|rest|arcgis|geoserver|geonetwork|geocore|wfs|wcs|wms|ows|csw|opendata|search|catalog)",
                      re.IGNORECASE)


def _env_flag(name: str) -> bool:
    return os.environ.get(name, "").strip().lower() in {"1", "true", "yes", "on"}


@dataclass
class BrowserConfig:
    headless: bool | str = "auto"
    executable_path: str | None = None
    cdp_url: str | None = None
    proxy_server: str | None = None
    proxy_bypass: str = "localhost,127.0.0.1"
    user_data_dir: str | None = None
    downloads_dir: str | None = None
    slow_mo_ms: int = 0
    viewport: tuple[int, int] = (1280, 900)
    extra_args: list[str] = field(default_factory=list)
    block_service_workers: bool = True

    def __post_init__(self) -> None:
        if isinstance(self.headless, str):
            value = self.headless.strip().lower()
            if value not in {"true", "false", "auto"}:
                raise ValueError("headless는 true, false 또는 auto여야 한다")
            self.headless = {"true": True, "false": False}.get(value, "auto")
        elif not isinstance(self.headless, bool):
            raise ValueError("headless는 true, false 또는 auto여야 한다")

    @classmethod
    def from_env(cls, **overrides) -> "BrowserConfig":
        mode = os.environ.get("MPM_ACQ_HEADLESS", "auto").strip().lower() or "auto"
        if _env_flag("MPM_ACQ_HEADED"):
            mode = "false"
        cfg = cls(
            headless=mode,
            executable_path=os.environ.get("MPM_ACQ_BROWSER_EXECUTABLE") or None,
            cdp_url=os.environ.get("MPM_ACQ_CDP_URL") or None,
            proxy_server=os.environ.get("HTTPS_PROXY") or os.environ.get("https_proxy") or None,
            user_data_dir=os.environ.get("MPM_ACQ_USER_DATA_DIR") or None,
            extra_args=parse_browser_args(os.environ.get("MPM_ACQ_BROWSER_ARGS", "")),
        )
        for k, v in overrides.items():
            if not hasattr(cfg, k):
                raise TypeError(f"알 수 없는 설정: {k}")
            setattr(cfg, k, v)
        cfg.__post_init__()
        return cfg

    def describe(self) -> dict:
        d = self.__dict__.copy()
        d["mode"] = "cdp" if self.cdp_url else ("persistent" if self.user_data_dir else "launch")
        return d


def parse_browser_args(value: str | None) -> list[str]:
    """Parse operator-supplied Chromium args using shell-like quoting, without a shell."""
    if not value:
        return []
    try:
        return shlex.split(value)
    except ValueError as exc:
        raise ValueError(f"MPM_ACQ_BROWSER_ARGS 구문이 잘못됐다: {exc}") from exc


def app_shell_response(resource_type: str, content_type: str | None, x_cache: str | None = None) -> bool:
    """An app script/style answered with HTML: the app-shell symptom used for the one headed retry.

    Provider headers (for example an error-cache `X-Cache` value) are recorded by the caller as
    auxiliary evidence only; they do not establish the symptom without an HTML body type.
    """
    if resource_type not in {"script", "stylesheet"}:
        return False
    return "text/html" in (content_type or "").lower()


def has_display() -> bool:
    """A native display or an available Xvfb runner can host headed Chromium."""
    return bool(os.environ.get("DISPLAY") or shutil.which("xvfb-run"))


def should_retry_headed(headless_mode: str | bool, app_shell_detected: bool,
                         navigation_status: int | None = None) -> bool:
    """Auto mode retries only the app-shell symptom, never an access-denied navigation."""
    if navigation_status in {401, 403}:
        return False
    return headless_mode == "auto" and app_shell_detected and has_display()


def _local_sandbox_failure(exc: BaseException) -> bool:
    message = str(exc).lower()
    sandbox_denied = "sandbox/policy/linux/sandbox_linux.cc" in message and "permission denied" in message
    gpu_with_policy_denial = ("gpu process launch failed" in message and "error_code=1002" in message
                              and ("permission denied" in message or "landlock" in message))
    return sandbox_denied or gpu_with_policy_denial


def _launch_error(exc: BaseException) -> RuntimeError:
    if _local_sandbox_failure(exc):
        return RuntimeError(
            "Chromium이 로컬 실행 샌드박스(Landlock)에서 시작되지 않았습니다. "
            "Chromium 자체 sandbox가 허용 목록 밖 경로(/)에 접근하다 Permission denied(13)로 종료된 "
            "환경 오류입니다. 운영자에게 브라우저 실행 격리·허용 목록을 조정하거나 승인된 실행 래퍼를 "
            "제공해 달라고 요청하세요. 수집 스킬은 --no-sandbox를 자동 추가하지 않습니다."
        )
    return RuntimeError(f"Chromium launch failed: {exc}")


@contextlib.contextmanager
def _xvfb_executable(chromium, executable_path: str | None, use_xvfb: bool):
    """Wrap Chromium with xvfb-run only when headed mode has no existing DISPLAY."""
    if not use_xvfb or os.environ.get("DISPLAY") or os.name != "posix":
        yield executable_path
        return
    xvfb = shutil.which("xvfb-run")
    if not xvfb:
        yield executable_path
        return
    real_executable = executable_path or chromium.executable_path
    with tempfile.TemporaryDirectory(prefix="acq-xvfb-") as tmp:
        wrapper = os.path.join(tmp, "chromium-xvfb")
        with open(wrapper, "w", encoding="utf-8") as fh:
            fh.write("#!/bin/sh\nexec " + shlex.quote(xvfb) + " -a -- " +
                     shlex.quote(real_executable) + ' "$@"\n')
        os.chmod(wrapper, 0o755)
        yield wrapper


def _service_workers(config: BrowserConfig) -> str:
    return "block" if config.block_service_workers else "allow"


@dataclass
class Session:
    browser: object | None
    context: object
    page: object
    config: BrowserConfig
    mode: str


@contextlib.contextmanager
def open_session(config: BrowserConfig | None = None) -> Iterator[Session]:
    """세션을 열고 종료 시 우리가 만든 것만 닫는다(CDP로 붙은 브라우저는 닫지 않는다)."""
    from playwright.sync_api import sync_playwright

    config = config or BrowserConfig.from_env()
    proxy = {"server": config.proxy_server, "bypass": config.proxy_bypass} if config.proxy_server else None
    with sync_playwright() as pw:
        chromium = pw.chromium
        headless = True if config.headless == "auto" else bool(config.headless)
        if config.cdp_url:
            browser = chromium.connect_over_cdp(config.cdp_url)
            context = browser.contexts[0] if browser.contexts else browser.new_context()
            page = context.new_page()  # never navigate an existing user's tab
            try:
                yield Session(browser, context, page, config, "cdp")
            finally:
                page.close()
                browser.close()  # 연결만 끊는다; 원 Chrome 프로세스는 유지된다
            return
        launch_kwargs = dict(headless=headless, slow_mo=config.slow_mo_ms or 0, args=list(config.extra_args))
        if proxy:
            launch_kwargs["proxy"] = proxy
        if config.downloads_dir:
            launch_kwargs["downloads_path"] = config.downloads_dir
        with _xvfb_executable(chromium, config.executable_path, use_xvfb=not headless) as exe:
            if exe:
                launch_kwargs["executable_path"] = exe
            try:
                if config.user_data_dir:
                    context = chromium.launch_persistent_context(
                        config.user_data_dir,
                        viewport={"width": config.viewport[0], "height": config.viewport[1]},
                        accept_downloads=True, service_workers=_service_workers(config), **launch_kwargs)
                    page = context.pages[0] if context.pages else context.new_page()
                    try:
                        yield Session(None, context, page, config, "persistent")
                    finally:
                        context.close()
                    return
                browser = chromium.launch(**launch_kwargs)
            except Exception as exc:
                if _local_sandbox_failure(exc):
                    raise _launch_error(exc) from exc
                raise
            context = browser.new_context(viewport={"width": config.viewport[0], "height": config.viewport[1]},
                                          accept_downloads=True, service_workers=_service_workers(config))
            page = context.new_page()
            try:
                yield Session(browser, context, page, config, "launch")
            finally:
                context.close()
                browser.close()


class RequestGate:
    """Route every browser request through a host/path allow-list, a request budget and a resource filter.

    Install on the context before navigation. Each request the gate sends waits for the budget
    interval, so page loads are serialized and slower; set navigation timeouts accordingly.
    Requests to hosts or paths outside the approval and the blocked resource types are aborted and
    logged. Responses are reported to the budget, so repeated 429/503 back off and then stop.

    The gate fetches each allowed request itself and follows redirects one hop at a time: every hop
    is checked against the approval and the budget before it is requested, and a hop to an
    unapproved target is refused and recorded in `violations`. The browser receives the final
    response under the original URL. A redirect that happens outside routing is still detected
    afterwards (`prevented: False`); the caller must stop when `violations` is non-empty.
    WebSocket connections are closed without contacting the server.

    Playwright runs route handlers concurrently while a fetch is pending, so the gate lets one
    request through at a time and waits with Playwright's own timer; the previous response is
    counted before the next request is sent, and a stop applies from the next request on.

    Limits: Chromium's own favicon request is not routed, so it is sent to the page's origin
    without the interval. Service workers can bypass routing; open the context with service
    workers blocked (`BrowserConfig.block_service_workers`). A context reused over CDP keeps its
    own service-worker setting, so pass `service_workers_blocked=False` and report it.
    """

    DEFAULT_BLOCKED_TYPES = ("image", "media", "font")
    MAX_REDIRECT_HOPS = 5

    def __init__(self, allowed_hosts, budget=None, blocked_resource_types=DEFAULT_BLOCKED_TYPES,
                 credentials: Credentials | None = None, path_allowed=None,
                 service_workers_blocked: bool = True):
        self.allowed_hosts = {h.lower() for h in allowed_hosts}
        if not self.allowed_hosts:
            raise ValueError("allowed_hosts must list the hosts the user approved")
        self.budget = budget
        self.blocked_resource_types = set(blocked_resource_types or ())
        self.credentials = credentials
        self.path_allowed = path_allowed  # optional callable (host, path) -> bool from the approval record
        self.service_workers_blocked = service_workers_blocked
        self.log: list[dict] = []
        self.violations: list[dict] = []
        self.stopped: str | None = None
        self._in_flight = False

    def install(self, target) -> "RequestGate":
        target.route("**/*", self._handle)
        if hasattr(target, "route_web_socket"):
            target.route_web_socket("**/*", self._handle_web_socket)
        target.on("request", self._on_request)
        return self

    def _entry(self, request, action: str, url: str | None = None, **extra) -> dict:
        entry = {"ts": time.time(), "url": safe_url(url or request.url, self.credentials),
                 "method": request.method, "resource_type": request.resource_type, "action": action, **extra}
        self.log.append(entry)
        return entry

    def _refusal(self, url: str) -> str | None:
        parts = urlsplit(url)
        host = (parts.hostname or "").lower()
        if host not in self.allowed_hosts:
            return f"unapproved host {host}"
        if self.path_allowed is not None and not self.path_allowed(host, parts.path or "/"):
            return f"path {parts.path or '/'} is outside the approval for {host}"
        return None

    @staticmethod
    def _pause(request, seconds: float) -> None:
        """Sleep while letting Playwright process other events (responses of earlier requests)."""
        if seconds <= 0:
            return
        try:
            request.frame.page.wait_for_timeout(seconds * 1000)
        except Exception:  # no page (e.g. a worker request) or a closed page
            time.sleep(seconds)

    def _wait(self, request) -> float | None:
        """Wait for the budget; returns seconds waited, or None when the budget stops the session."""
        if self.budget is None:
            return 0.0
        before = time.monotonic()
        original = getattr(self.budget, "sleeper", None)
        if original is not None:
            self.budget.sleeper = lambda seconds: self._pause(request, seconds)
        try:
            self.budget.wait()
        except Exception as exc:  # BudgetExceeded
            self.stopped = str(exc)
            return None
        finally:
            if original is not None:
                self.budget.sleeper = original
        return time.monotonic() - before

    def _account(self, status: int | None) -> None:
        if self.budget is None:
            return
        try:
            if status is None or status in (429, 503):
                self.budget.failure(status)
            else:
                self.budget.success()
        except Exception as exc:  # repeated failures stop the session
            self.stopped = str(exc)

    def _handle_web_socket(self, ws) -> None:
        self.log.append({"ts": time.time(), "url": safe_url(ws.url, self.credentials), "method": "GET",
                         "resource_type": "websocket", "action": "aborted_websocket"})
        try:
            ws.close(code=1008, reason="blocked by request gate")
        except Exception:
            pass

    def _handle(self, route, request) -> None:
        scheme = urlsplit(request.url).scheme
        if scheme in {"data", "blob", "about"}:
            route.continue_()
            return
        if self.stopped:
            self._entry(request, "aborted_after_stop", reason=self.stopped)
            route.abort("blockedbyclient")
            return
        refusal = self._refusal(request.url)
        if refusal:
            self._entry(request, "aborted_unapproved_host" if refusal.startswith("unapproved host")
                        else "aborted_unapproved_path", reason=refusal)
            route.abort("blockedbyclient")
            return
        if request.resource_type in self.blocked_resource_types:
            self._entry(request, "aborted_resource_type")
            route.abort("blockedbyclient")
            return
        # One gated request at a time: wait (processing events) until the previous one is accounted.
        while self._in_flight and not self.stopped:
            self._pause(request, 0.05)
        if self.stopped:
            self._entry(request, "aborted_after_stop", reason=self.stopped)
            route.abort("blockedbyclient")
            return
        self._in_flight = True
        try:
            self._send(route, request)
        finally:
            self._in_flight = False

    def _send(self, route, request) -> None:
        current, method, action = request.url, request.method, "continued"
        for hop in range(self.MAX_REDIRECT_HOPS + 1):
            waited = self._wait(request)
            if waited is None:
                self._entry(request, "aborted_budget", url=current, reason=self.stopped)
                route.abort("blockedbyclient")
                return
            entry = self._entry(request, action, url=current, waited_s=round(waited, 3))
            try:
                if hop == 0:
                    response = route.fetch(max_redirects=0)
                else:
                    response = route.fetch(url=current, method=method, max_redirects=0)
            except Exception as exc:
                entry["fetch_error"] = type(exc).__name__
                self._account(None)
                route.abort("failed")
                return
            entry["status"] = response.status
            self._account(response.status)
            location = response.headers.get("location")
            if not (300 <= response.status < 400 and location):
                if self.stopped:
                    route.abort("blockedbyclient")
                    return
                route.fulfill(response=response)
                return
            target = urljoin(current, location)
            entry["redirect_to"] = safe_url(target, self.credentials)
            refusal = self._refusal(target)
            if refusal:
                self.violations.append({"url": safe_url(target, self.credentials),
                                        "host": (urlsplit(target).hostname or "").lower(),
                                        "redirected_from": safe_url(current, self.credentials),
                                        "reason": refusal, "prevented": True})
                self.stopped = f"redirect refused: {refusal} (not followed)"
                entry["action"] = "redirect_refused"
                route.abort("blockedbyclient")
                return
            if response.status == 303 or (response.status in (301, 302) and method != "GET"):
                method = "GET"
            current, action = target, "redirect_followed"
        self.stopped = f"more than {self.MAX_REDIRECT_HOPS} redirects from {safe_url(request.url, self.credentials)}"
        self._entry(request, "aborted_redirect_limit", url=current)
        route.abort("blockedbyclient")

    def _on_request(self, request) -> None:
        previous = request.redirected_from
        if previous is None:
            return
        host = (urlsplit(request.url).hostname or "").lower()
        if host not in self.allowed_hosts:
            violation = {"url": safe_url(request.url, self.credentials), "host": host,
                         "redirected_from": safe_url(previous.url, self.credentials), "prevented": False}
            self.violations.append(violation)
            self.stopped = f"redirect to unapproved host {host}"

    def summary(self) -> dict:
        counts: dict[str, int] = {}
        for entry in self.log:
            counts[entry["action"]] = counts.get(entry["action"], 0) + 1
        sent = sorted(e["ts"] for e in self.log
                      if e["action"] in ("continued", "redirect_followed", "redirect_refused"))
        gaps = [b - a for a, b in zip(sent, sent[1:])]
        return {"allowed_hosts": sorted(self.allowed_hosts), "actions": counts,
                "path_scope_enforced": self.path_allowed is not None,
                "service_workers_blocked": self.service_workers_blocked,
                "unrouted_known": ["Chromium favicon request to the page origin"],
                "min_gap_s_between_sent_requests": round(min(gaps), 3) if gaps else None,
                "blocked_resource_types": sorted(self.blocked_resource_types),
                "violations": self.violations, "stopped": self.stopped,
                "budget": self.budget.snapshot() if self.budget is not None and hasattr(self.budget, "snapshot") else None}

    def save(self, path: str) -> str:
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(json.dumps({"record_type": "manifest", **self.summary(),
                                 "paths_relative_to": "this file's directory"}, ensure_ascii=False) + "\n")
            for entry in self.log:
                fh.write(json.dumps(entry, ensure_ascii=False) + "\n")
        return os.path.abspath(path)


class NetworkRecorder:
    """page의 응답을 기록한다. 본문은 JSON/text에 한해 제한 크기까지 선택적으로 저장한다."""

    def __init__(self, page, capture_bodies: bool = False, body_limit: int = 200_000,
                 body_pattern: str | None = None, credentials: Credentials | None = None):
        self.page = page
        self.capture_bodies = capture_bodies
        self.body_limit = body_limit
        self.body_re = re.compile(body_pattern) if body_pattern else None
        self.credentials = credentials
        self.records: list[dict] = []
        self.app_shell_responses: list[dict] = []
        self.navigation_response_status: int | None = None
        page.on("response", self._on_response)

    def record_navigation_response(self, response) -> int | None:
        """Retain the navigation's own final HTTP status alongside subresource responses."""
        self.navigation_response_status = response.status if response is not None else None
        return self.navigation_response_status

    def _on_response(self, response) -> None:
        req = response.request
        headers = response.headers
        rec = {
            "ts": time.time(), "url": safe_url(response.url, self.credentials), "method": req.method, "status": response.status,
            "resource_type": req.resource_type, "content_type": headers.get("content-type"),
            "x_cache": headers.get("x-cache"),
            "content_length": headers.get("content-length"),
        }
        if app_shell_response(rec["resource_type"], rec["content_type"], rec["x_cache"]):
            self.app_shell_responses.append({k: rec[k] for k in (
                "url", "status", "resource_type", "content_type", "x_cache")})
        if self.capture_bodies and self._should_capture(rec):
            try:
                body = response.text()
                rec["body"] = redact(body[: self.body_limit], self.credentials)
                rec["body_truncated"] = len(body) > self.body_limit
            except Exception as exc:  # 리다이렉트·바이너리 등
                rec["body_error"] = type(exc).__name__
        self.records.append(rec)

    def _should_capture(self, rec: dict) -> bool:
        ctype = (rec.get("content_type") or "").lower()
        textual = any(t in ctype for t in ("json", "xml", "text", "javascript"))
        if self.body_re is not None:
            return textual and bool(self.body_re.search(rec["url"]))
        return textual and rec["resource_type"] in {"xhr", "fetch", "document"}

    def api_candidates(self) -> list[dict]:
        out = []
        for rec in self.records:
            ctype = (rec.get("content_type") or "").lower()
            if rec["resource_type"] in {"xhr", "fetch"} or "json" in ctype or "xml" in ctype or API_HINT.search(rec["url"]):
                out.append({k: rec[k] for k in ("url", "method", "status", "resource_type", "content_type")})
        return out

    def save(self, path: str) -> str:
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(json.dumps({"record_type": "manifest",
                                 "navigation_response_status": self.navigation_response_status,
                                 "paths_relative_to": "this file's directory"}, ensure_ascii=False) + "\n")
            for rec in self.records:
                fh.write(json.dumps(rec, ensure_ascii=False) + "\n")
        return os.path.abspath(path)


# ---------------------------------------------------------------------------
# 자격증명: 환경변수에서만 읽고, 어디에도 쓰지 않는다
# ---------------------------------------------------------------------------
def _host_key(host: str) -> str:
    return re.sub(r"[^A-Z0-9]", "_", host.upper())


def credential_env_names(host: str, prefix: str = "MPM_ACQ") -> dict[str, list[str]]:
    """사용자에게 안내할 환경변수 이름(값이 아니다)."""
    hk = _host_key(host)
    return {"username": [f"{prefix}_{hk}_USER"], "password": [f"{prefix}_{hk}_PASSWORD"]}


@dataclass
class Credentials:
    username: str
    password: str
    source: str

    def __repr__(self) -> str:  # 로그에 값이 새지 않게
        return f"Credentials(username=***, password=***, source={self.source!r})"

    __str__ = __repr__


def credentials_from_env(host: str, prefix: str = "MPM_ACQ", env: dict | None = None) -> Credentials | None:
    """그 host 전용 변수만 찾는다. 없으면 None, 한쪽만 있으면 오류. 공통 계정 변수는 읽지 않는다."""
    env = os.environ if env is None else env
    names = credential_env_names(host, prefix)
    for u_name, p_name in zip(names["username"], names["password"]):
        user = env.get(u_name)
        pw = env.get(p_name)
        if user and pw:
            return Credentials(user, pw, source=f"{u_name}/{p_name}")
        if bool(user) != bool(pw):
            raise ValueError(f"{u_name}와 {p_name} 중 하나만 설정되어 있다")
    return None


def redact(text: str, cred: Credentials | None) -> str:
    if not cred:
        return text
    out = text
    for secret in (cred.password, cred.username):
        if secret:
            out = out.replace(secret, "***")
    return out


def safe_url(url: str, cred: Credentials | None = None) -> str:
    """Keep API structure; omit userinfo, fragments and common secret query values."""
    parts = urlsplit(url)
    keys = re.compile(r"token|password|passwd|secret|authorization|credential|signature|api[-_]?key|^code$|^key$|^sig$", re.I)
    query = urlencode([(k, 'REDACTED' if keys.search(k) else redact(v, cred))
                       for k, v in parse_qsl(parts.query, keep_blank_values=True)])
    return redact(urlunsplit((parts.scheme, parts.netloc.rsplit('@', 1)[-1], parts.path, query, '')), cred)


def fill_login(page, cred: Credentials, user_selector: str, password_selector: str,
               submit_selector: str | None = None, wait_for_selector: str | None = None,
               wait_for_url: str | None = None, timeout_ms: int = 30_000) -> bool:
    """로그인 폼에 자격증명을 넣고 제출한다. 값을 출력하지 않는다. CAPTCHA/2FA는 사용자가 headed로 처리한다."""
    page.fill(user_selector, cred.username)
    page.fill(password_selector, cred.password)
    if submit_selector:
        page.click(submit_selector)
    else:
        page.press(password_selector, "Enter")
    if wait_for_url:
        page.wait_for_url(wait_for_url, timeout=timeout_ms)
    if wait_for_selector:
        page.wait_for_selector(wait_for_selector, timeout=timeout_ms)
    return True


def cookie_names(context, host_suffix: str | None = None) -> list[str]:
    """로그인 여부 확인용 쿠키 **이름** 목록(값은 돌려주지 않는다)."""
    names = []
    for c in context.cookies():
        domain = c.get("domain", "").lstrip('.').lower()
        suffix = host_suffix.lstrip('.').lower() if host_suffix else None
        if suffix is None or domain == suffix or domain.endswith('.' + suffix):
            names.append(c["name"])
    return sorted(set(names))


def save_storage_state(context, path: str) -> str:
    """세션 상태(쿠키 등)를 파일로 저장한다. 커밋 금지 대상이며 대상 도메인 작업에만 쓴다."""
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    # Open restrictively before writing; never create a world-readable cookie file.
    import tempfile
    fd, tmp = tempfile.mkstemp(dir=os.path.dirname(os.path.abspath(path)), prefix='.acq-state-')
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as fh:
            state = context.storage_state()
            state["paths_relative_to"] = "this file's directory"
            json.dump(state, fh)
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)
    return os.path.abspath(path)
