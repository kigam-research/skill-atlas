"""서비스 레이어 목록을 metadata 요청만으로 모은다(표준 라이브러리만 사용, pyproj는 있으면 사용).

자료군 목록을 사용자에게 보여주기 위한 선택형 예시다. 자료 본체는 받지 않는다.

- `inventory_arcgis`: ArcGIS REST 디렉터리·MapServer·FeatureServer·ImageServer의 레이어와
  자료 형태, 범위, 필드, 저작권 문구.
- `inventory_ogc`: WMS·WFS·WCS GetCapabilities의 레이어·범위·접근 조건.
- `service_error`: HTTP 200 본문에 담긴 서비스 오류(ArcGIS `error`, OGC ExceptionReport,
  JSON·XML 자리의 HTML)를 판정한다.
- `catalogue_markdown`: 에이전트가 증거군·권장 여부를 붙인 항목을 사용자에게 보여줄 표로 만든다.

모든 요청은 호출자가 명시한 host 안에서만 보내고, 요청 간격·총량은 호출자가 넘긴 `FetchBudget`
(총 요청 상한 필수)이 통제한다.
자료 형태(`kind`)는 서비스 선언에서 읽은 값이며, 숫자 값을 실제로 추출할 수 있는지는
자료를 받아 확인하기 전까지 보장하지 않는다.
"""
from __future__ import annotations

import hashlib
import json
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime, timezone

from downloader import DEFAULT_USER_AGENT, DownloadError, RedirectRefused, normalise_hosts, open_guarded
from fetch_budget import BudgetExceeded, FetchBudget

MAX_METADATA_BYTES = 20_000_000
MAX_FIELDS_SHOWN = 40


class HostNotApproved(RuntimeError):
    """승인 목록 밖 host로 요청하려 했다. 요청은 보내지 않았다."""


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _local(tag: str) -> str:
    return tag.rsplit("}", 1)[-1] if "}" in tag else tag


def service_error(body, content_type: str | None = None, expect: str | None = None) -> str | None:
    """HTTP 200 응답 본문이 실제로는 서비스 오류인지 판정해 오류 설명을 돌려준다. 정상이면 None.

    expect: "json" 또는 "xml". 그 형식 자리에 HTML이 오면 오류로 본다.
    """
    if isinstance(body, dict):
        err = body.get("error")
        if isinstance(err, dict):
            details = "; ".join(str(d) for d in err.get("details") or [] if d)
            return f"ArcGIS error {err.get('code')}: {err.get('message')}" + (f" ({details})" if details else "")
        if err:
            return f"service error: {err}"
        return None
    if isinstance(body, bytes):
        text = body.decode("utf-8", errors="replace")
    else:
        text = str(body)
    head = text.lstrip()[:500].lower()
    ctype = (content_type or "").lower()
    if expect in ("json", "xml") and ("text/html" in ctype or head.startswith("<!doctype html") or head.startswith("<html")):
        return f"expected {expect} but received HTML (content-type {content_type!r})"
    if head.startswith("{"):
        try:
            return service_error(json.loads(text), content_type)
        except json.JSONDecodeError:
            return "expected JSON but body is not valid JSON" if expect == "json" else None
    if head.startswith("<"):
        try:
            root = ET.fromstring(text)
        except ET.ParseError:
            return "expected XML but body is not valid XML" if expect == "xml" else None
        name = _local(root.tag)
        if name in ("ExceptionReport", "ServiceExceptionReport"):
            texts = [" ".join((el.text or "").split()) for el in root.iter()
                     if _local(el.tag) in ("ExceptionText", "ServiceException") and (el.text or "").strip()]
            codes = [el.attrib.get("exceptionCode") or el.attrib.get("code") for el in root.iter()
                     if _local(el.tag) in ("Exception", "ServiceException")]
            return f"OGC {name}: {'; '.join(t for t in texts if t) or 'no text'} (codes {[c for c in codes if c]})"
    elif expect == "json":
        return "expected JSON but body is not JSON"
    elif expect == "xml":
        return f"expected XML but body is not XML: {text.strip()[:120]!r}"
    return None


class MetadataClient:
    """승인 host 안에서만 metadata 요청을 보내고 요청마다 기록을 남긴다.

    redirect는 단계마다 host와 요청 예산을 먼저 확인한 뒤 따라간다(`downloader.open_guarded`).
    프록시 등은 `handlers`로 넘긴다.
    """

    def __init__(self, allowed_hosts, budget: FetchBudget, handlers=(),
                 user_agent: str = DEFAULT_USER_AGENT, timeout: float = 60.0,
                 max_bytes: int = MAX_METADATA_BYTES):
        try:
            self.allowed_hosts = normalise_hosts(allowed_hosts)
        except ValueError as exc:
            raise ValueError("allowed_hosts must name the hosts the user approved for metadata requests") from exc
        if not isinstance(budget, FetchBudget) or budget.max_requests is None:
            raise ValueError("budget must be a FetchBudget with max_requests set to the approved request limit")
        self.budget = budget
        self.handlers = tuple(handlers)
        self.user_agent = user_agent
        self.timeout = timeout
        self.max_bytes = max_bytes
        self.requests: list[dict] = []

    def _fail(self, record: dict, status: int | None = None) -> tuple[None, dict]:
        self.requests.append(record)
        self.budget.failure(status)  # may raise BudgetExceeded after repeated failures
        return None, record

    def get(self, url: str, expect: str) -> tuple[bytes | None, dict]:
        host = (urllib.parse.urlsplit(url).hostname or "").lower()
        if host not in self.allowed_hosts:
            raise HostNotApproved(f"{host} is not in the approved host list; request not sent: {url}")
        record = {"url": url, "requested_at": _now(), "user_agent": self.user_agent}
        try:
            resp, final_url, hops = open_guarded(url, self.allowed_hosts, budget=self.budget,
                                                 headers={"User-Agent": self.user_agent},
                                                 timeout=self.timeout, handlers=self.handlers)
            with resp:
                record.update({"http_status": resp.status, "content_type": resp.headers.get("Content-Type"),
                               "final_url": final_url, "redirects": hops})
                body = resp.read(self.max_bytes + 1)
        except urllib.error.HTTPError as exc:
            record.update({"http_status": exc.code, "error": f"HTTP {exc.code}"})
            return self._fail(record, exc.code)
        except (RedirectRefused, DownloadError) as exc:
            record["error"] = str(exc)
            return self._fail(record)
        except BudgetExceeded:
            raise
        except Exception as exc:  # 네트워크 오류는 기록하고 호출자가 판단한다
            record["error"] = f"{type(exc).__name__}: {exc}"
            return self._fail(record)
        if len(body) > self.max_bytes:
            record["error"] = f"metadata response larger than {self.max_bytes} bytes; not parsed"
            return self._fail(record)
        record["bytes"] = len(body)
        record["sha256"] = hashlib.sha256(body).hexdigest()
        problem = service_error(body, record.get("content_type"), expect)
        if problem:
            record["error"] = problem
            record["service_error_in_body"] = True
            return self._fail(record)
        self.budget.success()
        self.requests.append(record)
        return body, record


def _with_query(url: str, **params) -> str:
    parts = urllib.parse.urlsplit(url)
    query = dict(urllib.parse.parse_qsl(parts.query))
    query.update({k: v for k, v in params.items() if v is not None})
    return urllib.parse.urlunsplit(parts._replace(query=urllib.parse.urlencode(query)))


def _crs_of_spatial_reference(sr: dict):
    """pyproj CRS from an ArcGIS spatialReference (latestWkid/wkid as EPSG, then ESRI, then WKT)."""
    from pyproj import CRS

    for key in ("latestWkid", "wkid"):
        code = sr.get(key)
        if code:
            for authority in ("EPSG", "ESRI"):
                try:
                    return CRS.from_user_input(f"{authority}:{int(code)}")
                except Exception:
                    continue
    if sr.get("wkt"):
        return CRS.from_wkt(sr["wkt"])
    return None


def extent_to_wgs84(extent: dict | None, densify: int = 21) -> tuple[list[float] | None, str]:
    """ArcGIS extent를 WGS84(EPSG:4326) 경위도 bbox로 바꾼다. 바꿀 수 없으면 (None, 이유).

    WGS84가 아닌 모든 CRS(다른 datum의 경위도 포함)는 같은 절차로 pyproj 변환한다. 변환 경계는
    가장자리를 `densify` 점으로 나눈 근사이며 bbox_note에 적는다.
    """
    if not extent or any(extent.get(k) in (None, "NaN") for k in ("xmin", "ymin", "xmax", "ymax")):
        return None, "extent not declared"
    sr = extent.get("spatialReference") or {}
    xmin, ymin, xmax, ymax = (float(extent[k]) for k in ("xmin", "ymin", "xmax", "ymax"))
    try:
        from pyproj import CRS, Transformer
        source = _crs_of_spatial_reference(sr)
    except ImportError:
        return None, "pyproj unavailable; extent not converted"
    except Exception as exc:
        return None, f"spatial reference not interpreted ({type(exc).__name__})"
    if source is None:
        return None, "spatial reference not declared"
    name = source.to_string()
    if source == CRS.from_epsg(4326):
        return [xmin, ymin, xmax, ymax], f"{name} (WGS84) used as declared"
    try:
        tr = Transformer.from_crs(source, CRS.from_epsg(4326), always_xy=True)
        west, south, east, north = tr.transform_bounds(xmin, ymin, xmax, ymax, densify_pts=densify)
    except Exception as exc:
        return None, f"{name} not converted ({type(exc).__name__})"
    return [west, south, east, north], f"{name} converted to WGS84 with pyproj (edge densify {densify})"


def aoi_overlap(bbox: list[float] | None, aoi: list[float] | None) -> str:
    """bbox와 AOI(경위도 west,south,east,north)의 관계: inside·covers·partial·outside·unknown."""
    if bbox is None or aoi is None:
        return "unknown"
    w, s, e, n = bbox
    aw, as_, ae, an = aoi
    if e < aw or w > ae or n < as_ or s > an:
        return "outside"
    if w <= aw and s <= as_ and e >= ae and n >= an:
        return "covers"
    if w >= aw and s >= as_ and e <= ae and n <= an:
        return "inside"
    return "partial"


ARCGIS_GEOMETRY = {"esriGeometryPoint": "point", "esriGeometryMultipoint": "point",
                   "esriGeometryPolyline": "line", "esriGeometryPolygon": "polygon",
                   "esriGeometryEnvelope": "polygon"}


def _arcgis_kind(meta: dict, service_type: str) -> tuple[str, str | None]:
    layer_type = meta.get("type") or ""
    if service_type == "ImageServer":
        return "numeric_raster", None
    if layer_type == "Feature Layer":
        geom = ARCGIS_GEOMETRY.get(meta.get("geometryType"), "unknown")
        return f"vector_{geom}", geom
    if layer_type == "Table":
        return "table", None
    if layer_type in ("Raster Layer", "Mosaic Layer"):
        return "render_only_image", None
    if layer_type == "Group Layer":
        return "group", None
    return "unknown", None


def _short(text, limit: int = 300) -> str | None:
    if not text:
        return None
    text = " ".join(str(text).split())
    return text if len(text) <= limit else text[: limit - 1] + "…"


def _load_json(client: MetadataClient, url: str) -> tuple[dict | None, dict]:
    body, record = client.get(_with_query(url, f="json"), expect="json")
    if body is None:
        return None, record
    try:
        return json.loads(body), record
    except json.JSONDecodeError as exc:
        record["error"] = f"invalid JSON: {exc}"
        return None, record


def inventory_arcgis(url: str, client: MetadataClient, aoi: list[float] | None = None,
                     max_layers: int = 200, recurse_folders: bool = False) -> dict:
    """ArcGIS REST 주소(디렉터리·폴더·MapServer·FeatureServer·ImageServer)의 레이어 목록을 모은다.

    반환값의 `complete`가 False면 예산·상한·오류 때문에 일부만 본 것이다.
    """
    result = {"service_url": url, "service_family": "arcgis_rest", "checked_at": _now(),
              "aoi_wgs84": aoi, "entries": [], "services_found": [], "notes": [], "complete": True}
    base = url.rstrip("/")
    try:
        root, record = _load_json(client, base)
        if root is None:
            result["complete"] = False
            result["notes"].append(f"root request failed: {record.get('error')}")
            return _finish(result, client)
        service_type = next((t for t in ("MapServer", "FeatureServer", "ImageServer") if base.endswith(t)), None)
        if service_type is None:
            services = [{"name": s.get("name"), "type": s.get("type")} for s in root.get("services") or []]
            result["services_found"] = services
            result["folders"] = list(root.get("folders") or [])
            targets = [s for s in services if s["type"] in ("MapServer", "FeatureServer", "ImageServer")]
            if result["folders"] and recurse_folders:
                for folder in result["folders"]:
                    sub, rec = _load_json(client, f"{base}/{folder.split('/')[-1]}")
                    if sub is None:
                        result["complete"] = False
                        result["notes"].append(f"folder {folder} failed: {rec.get('error')}")
                        continue
                    for s in sub.get("services") or []:
                        item = {"name": s.get("name"), "type": s.get("type")}
                        result["services_found"].append(item)
                        if item["type"] in ("MapServer", "FeatureServer", "ImageServer"):
                            targets.append(item)
            elif result["folders"]:
                result["complete"] = False
                result["notes"].append(f"{len(result['folders'])} folder(s) not opened (recurse_folders=False); "
                                       "the inventory does not cover services inside them")
            directory_root = base
            for folder in ("/rest/services",):
                if folder in base:
                    directory_root = base[: base.index(folder) + len(folder)]
            for svc in targets:
                svc_url = f"{directory_root}/{svc['name']}/{svc['type']}"
                sub = inventory_arcgis(svc_url, client, aoi, max_layers - len(result["entries"]))
                result["entries"].extend(sub["entries"])
                result["notes"].extend(sub["notes"])
                result["complete"] = result["complete"] and sub["complete"]
                if len(result["entries"]) >= max_layers:
                    result["complete"] = False
                    result["notes"].append(f"stopped at max_layers={max_layers}")
                    break
            return _finish(result, client)
        licence = _short(root.get("copyrightText"))
        if service_type == "ImageServer":
            bbox, how = extent_to_wgs84(root.get("extent"))
            result["entries"].append({
                "service_url": base, "service_type": service_type, "id": None,
                "name": root.get("name") or base.rsplit("/", 2)[-2], "title": _short(root.get("description"), 120),
                "kind": "numeric_raster", "geometry_type": None,
                "pixel_type": root.get("pixelType"), "band_count": root.get("bandCount"),
                "pixel_size": [root.get("pixelSizeX"), root.get("pixelSizeY")],
                "bbox_wgs84": bbox, "bbox_note": how, "aoi_overlap": aoi_overlap(bbox, aoi),
                "abstract": _short(root.get("serviceDescription") or root.get("description")),
                "licence_hint": licence, "fields": [], "max_record_count": None,
            })
            return _finish(result, client)
        layers = list(root.get("layers") or []) + [dict(t, _table=True) for t in root.get("tables") or []]
        for layer in layers:
            if len(result["entries"]) >= max_layers:
                result["complete"] = False
                result["notes"].append(f"stopped at max_layers={max_layers}")
                break
            layer_url = f"{base}/{layer.get('id')}"
            meta, rec = _load_json(client, layer_url)
            if meta is None:
                result["complete"] = False
                result["entries"].append({"service_url": base, "service_type": service_type, "id": layer.get("id"),
                                          "name": layer.get("name"), "kind": "unknown",
                                          "aoi_overlap": "unknown", "error": rec.get("error")})
                continue
            kind, geom = _arcgis_kind(meta, service_type)
            if kind == "group":
                continue
            bbox, how = extent_to_wgs84(meta.get("extent"))
            result["entries"].append({
                "service_url": base, "service_type": service_type, "id": meta.get("id", layer.get("id")),
                "name": meta.get("name") or layer.get("name"), "title": meta.get("name") or layer.get("name"),
                "kind": kind, "geometry_type": geom,
                "bbox_wgs84": bbox, "bbox_note": how, "aoi_overlap": aoi_overlap(bbox, aoi),
                "abstract": _short(meta.get("description")),
                "licence_hint": _short(meta.get("copyrightText")) or licence,
                "fields": [f.get("name") for f in (meta.get("fields") or [])][:MAX_FIELDS_SHOWN],
                "n_fields": len(meta.get("fields") or []),
                "fields_truncated": len(meta.get("fields") or []) > MAX_FIELDS_SHOWN,
                "max_record_count": meta.get("maxRecordCount"),
                "queryable": "Query" in (meta.get("capabilities") or ""),
                "min_scale": meta.get("minScale"), "max_scale": meta.get("maxScale"),
            })
    except BudgetExceeded as exc:
        result["complete"] = False
        result["notes"].append(f"request budget stopped the inventory: {exc}")
    return _finish(result, client)


def _finish(result: dict, client: MetadataClient) -> dict:
    result["requests"] = list(client.requests)
    result["budget"] = client.budget.snapshot()
    result["n_entries"] = len(result["entries"])
    return result


def _find(el, name):
    for child in el:
        if _local(child.tag) == name:
            return child
    return None


def _text(el, name):
    child = _find(el, name) if el is not None else None
    return " ".join((child.text or "").split()) if child is not None and child.text else None


def _corner_bbox(el) -> list[float] | None:
    box = _find(el, "WGS84BoundingBox")
    if box is not None:
        try:
            lo = [float(v) for v in (_text(box, "LowerCorner") or "").split()]
            hi = [float(v) for v in (_text(box, "UpperCorner") or "").split()]
            return [lo[0], lo[1], hi[0], hi[1]]
        except (ValueError, IndexError):
            return None
    geo = _find(el, "EX_GeographicBoundingBox")
    if geo is not None:
        try:
            return [float(_text(geo, k)) for k in ("westBoundLongitude", "southBoundLatitude",
                                                   "eastBoundLongitude", "northBoundLatitude")]
        except (TypeError, ValueError):
            return None
    for name in ("LatLonBoundingBox", "LatLongBoundingBox"):
        box = _find(el, name)
        if box is not None:
            try:
                a = box.attrib
                return [float(a["minx"]), float(a["miny"]), float(a["maxx"]), float(a["maxy"])]
            except (KeyError, ValueError):
                return None
    env = _find(el, "lonLatEnvelope")
    if env is not None:
        pos = [p for p in env if _local(p.tag) == "pos"]
        try:
            lo = [float(v) for v in (pos[0].text or "").split()]
            hi = [float(v) for v in (pos[1].text or "").split()]
            return [lo[0], lo[1], hi[0], hi[1]]
        except (ValueError, IndexError):
            return None
    return None


OGC_DEFAULT_VERSION = {"WMS": "1.3.0", "WFS": "2.0.0", "WCS": "2.0.1"}
OGC_KIND = {"WMS": "render_only_image", "WFS": "vector", "WCS": "numeric_raster"}


def inventory_ogc(url: str, service: str, client: MetadataClient, aoi: list[float] | None = None,
                  version: str | None = None, max_layers: int = 500) -> dict:
    """OGC GetCapabilities 한 번으로 WMS·WFS·WCS 레이어 목록을 모은다.

    WFS 도형 종류와 WCS 단위는 capabilities에 없으므로 `unknown`으로 두며,
    필요하면 DescribeFeatureType·DescribeCoverage로 선택한 항목만 확인한다.
    """
    service = service.upper()
    if service not in OGC_KIND:
        raise ValueError("service must be WMS, WFS or WCS")
    result = {"service_url": url, "service_family": f"ogc_{service.lower()}", "checked_at": _now(),
              "aoi_wgs84": aoi, "entries": [], "notes": [], "complete": True}
    cap_url = _with_query(url, service=service, request="GetCapabilities",
                          version=version or OGC_DEFAULT_VERSION[service])
    try:
        body, record = client.get(cap_url, expect="xml")
    except BudgetExceeded as exc:
        result["complete"] = False
        result["notes"].append(f"request budget stopped the inventory: {exc}")
        return _finish(result, client)
    if body is None:
        result["complete"] = False
        result["notes"].append(f"GetCapabilities failed: {record.get('error')}")
        return _finish(result, client)
    try:
        root = ET.fromstring(body)
    except ET.ParseError as exc:
        result["complete"] = False
        result["notes"].append(f"GetCapabilities is not parseable XML: {exc}")
        return _finish(result, client)
    ident = next((el for el in root.iter() if _local(el.tag) in ("ServiceIdentification", "Service")), None)
    fees = _text(ident, "Fees") if ident is not None else None
    constraints = _text(ident, "AccessConstraints") if ident is not None else None
    result["service_title"] = _text(ident, "Title") if ident is not None else None
    result["licence_hint"] = "; ".join(x for x in (fees, constraints) if x) or None
    if service == "WMS":
        items = [el for el in root.iter() if _local(el.tag) == "Layer" and _find(el, "Name") is not None]
    elif service == "WFS":
        items = [el for el in root.iter() if _local(el.tag) == "FeatureType"]
    else:
        items = [el for el in root.iter() if _local(el.tag) in ("CoverageSummary", "CoverageOfferingBrief")]
    for el in items:
        if len(result["entries"]) >= max_layers:
            result["complete"] = False
            result["notes"].append(f"stopped at max_layers={max_layers}")
            break
        name = _text(el, "Name") or _text(el, "CoverageId") or _text(el, "name")
        bbox = _corner_bbox(el)
        result["entries"].append({
            "service_url": url, "service_type": service, "id": name, "name": name,
            "title": _text(el, "Title") or _text(el, "label"),
            "kind": OGC_KIND[service], "geometry_type": None,
            "bbox_wgs84": bbox, "bbox_note": "declared WGS84 bounding box" if bbox else "no WGS84 bounding box",
            "aoi_overlap": aoi_overlap(bbox, aoi),
            "abstract": _short(_text(el, "Abstract") or _text(el, "description")),
            "licence_hint": result["licence_hint"], "fields": [],
        })
    return _finish(result, client)


CATALOGUE_COLUMNS = [("no", "번호"), ("family", "증거군"), ("title", "자료명"), ("id", "식별자"),
                     ("kind", "자료 형태"), ("aoi_overlap", "AOI"), ("scale", "축척·해상도·시점"),
                     ("access", "접근·라이선스"), ("recommendation", "권장"), ("reason", "이유")]


def catalogue_markdown(entries: list[dict], columns=CATALOGUE_COLUMNS) -> str:
    """자료군 목록을 Markdown 표로 만든다. 없는 값은 '미확인'으로 쓴다."""
    def cell(value):
        if value is None or value == "":
            return "미확인"
        return str(value).replace("|", "/").replace("\n", " ")
    lines = ["| " + " | ".join(label for _, label in columns) + " |",
             "|" + "---|" * len(columns)]
    for entry in entries:
        lines.append("| " + " | ".join(cell(entry.get(key)) for key, _ in columns) + " |")
    return "\n".join(lines)
