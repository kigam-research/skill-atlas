"""격자 표 생성 — raster/vector 자료를 사용자가 정한 투영 격자에 표본화하여 셀 단위 표를 만든다.

지원 범위: 투영 CRS의 정규 격자, 한 행 = 한 셀, 셀 중심 x/y, 열마다 역할(`value` 자료 값,
`diagnostic` 진단, `record_derived` 점 기록에서 만든 있음 표시·건수, `mask` 영역 표시). 안정된
`cell_id`/`row`/`col`과 metadata(CRS·셀 크기·경계·열별 출처·라이선스·해시·검증 결과)를 함께 남긴다.
작은 함수들의 선택형 뼈대이며 전체 작업 runner나 특정 분석의 입력 형식이 아니다. 격자가 아닌
산출물(원자료 파일, 점·선·면 레이어, 시료 표)은 이 모듈 밖에서 만든다.

과학적 주의:
- 점 기록에서 만든 있음 표시의 0은 "이 자료·추출 범위에 기록 없음"이며 부재 확인이 아니다.
- 격자는 **투영 CRS**에서만 만든다. 지리 좌표(도)에 m 셀 크기를 적용하지 않는다.
- 셀은 투영 단위에서 동일 크기지만 실제 지상 면적은 투영 왜곡에 따라 다르다. equal-area 여부는
  CRS와 영역에 따라 판단하고 metadata에 근거를 적는다.
- raster 표본화 방식(mean/center/bilinear 등)은 변수의 물리적 의미에 따라 고르고 기록한다.
  범주 raster에는 평균이 아닌 범주 보존 방식(center 등)을 쓴다.
- 점 기록에서 만든 값은 카탈로그의 시점·필터·좌표 정밀도에 의존한다.
"""
from __future__ import annotations

import hashlib
import json
import math
import os
import warnings
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from typing import Callable, Iterable, Sequence

import numpy as np
import pandas as pd
import artifact_paths
import shapely
from pyproj import CRS, Transformer
from shapely.geometry import shape
from shapely.ops import transform as shp_transform
from shapely.strtree import STRtree

try:  # rasterio는 raster 표본화에만 필요하다
    import rasterio
    from rasterio.transform import from_origin
    from rasterio.warp import Resampling, reproject
except ImportError:  # pragma: no cover - 환경에 따라
    rasterio = None

RESAMPLING = {
    "mean": "average",
    "center": "nearest",
    "nearest": "nearest",
    "bilinear": "bilinear",
    "cubic": "cubic",
    "max": "max",
    "min": "min",
    "median": "med",
}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


# ---------------------------------------------------------------------------
# 격자 정의
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class GridSpec:
    """투영 CRS의 규칙 격자. 경계는 셀 크기의 정수 배로 확장된다(원점 = minx, miny)."""

    crs: str
    cell_size: float
    minx: float
    miny: float
    maxx: float
    maxy: float
    x_column: str = "x"
    y_column: str = "y"

    def __post_init__(self) -> None:
        crs = CRS.from_user_input(self.crs)
        if not crs.is_projected:
            raise ValueError(f"투영 CRS가 필요하다(지리 좌표계에 m 셀을 적용하지 않는다): {self.crs}")
        if not (self.cell_size > 0):
            raise ValueError("cell_size는 양수여야 한다")
        if not (self.maxx > self.minx and self.maxy > self.miny):
            raise ValueError("경계가 비었다: max는 min보다 커야 한다")
        if self.x_column == self.y_column:
            raise ValueError("x/y 열 이름이 같다")

    @property
    def crs_obj(self) -> CRS:
        return CRS.from_user_input(self.crs)

    @property
    def unit(self) -> str:
        info = self.crs_obj.axis_info
        return info[0].unit_name if info else "unknown"

    @property
    def ncols(self) -> int:
        return int(math.ceil((self.maxx - self.minx) / self.cell_size - 1e-9))

    @property
    def nrows(self) -> int:
        return int(math.ceil((self.maxy - self.miny) / self.cell_size - 1e-9))

    @property
    def n_cells(self) -> int:
        return self.ncols * self.nrows

    @property
    def right(self) -> float:
        return self.minx + self.ncols * self.cell_size

    @property
    def top(self) -> float:
        return self.miny + self.nrows * self.cell_size

    @property
    def bounds_used(self) -> tuple[float, float, float, float]:
        return (self.minx, self.miny, self.right, self.top)

    @property
    def transform(self):
        if rasterio is None:
            raise ImportError("rasterio가 필요하다")
        return from_origin(self.minx, self.top, self.cell_size, self.cell_size)

    def to_dict(self) -> dict:
        d = asdict(self)
        d.update({"ncols": self.ncols, "nrows": self.nrows, "n_cells": self.n_cells,
                  "bounds_requested": [self.minx, self.miny, self.maxx, self.maxy],
                  "bounds_used": list(self.bounds_used), "cell_id_column": "cell_id", "unit": self.unit,
                  "epsg": self.crs_obj.to_epsg()})
        return d

    @classmethod
    def from_dict(cls, d: dict) -> "GridSpec":
        keys = ("crs", "cell_size", "minx", "miny", "maxx", "maxy")
        kw = {k: d[k] for k in keys}
        for opt in ("x_column", "y_column"):
            if opt in d:
                kw[opt] = d[opt]
        return cls(**kw)


def build_grid(spec: GridSpec) -> pd.DataFrame:
    """row 0이 북쪽(top)인 row-major 셀 표. x/y는 셀 중심."""
    cols = np.arange(spec.ncols)
    rows = np.arange(spec.nrows)
    cc, rr = np.meshgrid(cols, rows)
    cc = cc.ravel()
    rr = rr.ravel()
    x = spec.minx + (cc + 0.5) * spec.cell_size
    y = spec.top - (rr + 0.5) * spec.cell_size
    return pd.DataFrame({"cell_id": rr * spec.ncols + cc, "row": rr, "col": cc,
                         spec.x_column: x, spec.y_column: y})


def cell_index(spec: GridSpec, x: np.ndarray, y: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """좌표 → (row, col, inside). 경계 밖은 inside=False."""
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    col = np.floor((x - spec.minx) / spec.cell_size).astype(int)
    row = np.floor((spec.top - y) / spec.cell_size).astype(int)
    inside = (col >= 0) & (col < spec.ncols) & (row >= 0) & (row < spec.nrows)
    return row, col, inside


# ---------------------------------------------------------------------------
# raster 표본화
# ---------------------------------------------------------------------------
def raster_info(path: str) -> dict:
    if rasterio is None:
        raise ImportError("rasterio가 필요하다")
    with rasterio.open(path) as src:
        return {
            "path": os.path.abspath(path), "driver": src.driver, "crs": src.crs.to_string() if src.crs else None,
            "width": src.width, "height": src.height, "count": src.count, "dtype": src.dtypes[0],
            "nodata": src.nodata, "res": list(src.res), "bounds": list(src.bounds),
        }


def sample_raster(spec: GridSpec, path: str, band: int = 1, method: str = "mean",
                  src_nodata: float | None = None) -> tuple[np.ndarray, dict]:
    """raster를 격자 CRS/해상도로 재투영·재표본화하여 셀 값(row-major, NaN=nodata)을 돌려준다."""
    if rasterio is None:
        raise ImportError("rasterio가 필요하다")
    if method not in RESAMPLING:
        raise ValueError(f"method는 {sorted(RESAMPLING)} 중 하나여야 한다")
    resampling = getattr(Resampling, RESAMPLING[method])
    dst = np.full((spec.nrows, spec.ncols), np.nan, dtype=np.float64)
    with rasterio.open(path) as src:
        if src.crs is None:
            raise ValueError(f"raster에 CRS가 없다: {path}")
        file_nodata = src.nodata
        if file_nodata is not None:
            nodata = file_nodata          # 파일 metadata가 있으면 그것을 신뢰한다
        else:
            nodata = src_nodata           # 없을 때만 호출자가 아는 값을 쓴다
        reproject(
            source=rasterio.band(src, band), destination=dst,
            src_transform=src.transform, src_crs=src.crs, src_nodata=nodata,
            dst_transform=spec.transform, dst_crs=spec.crs_obj, dst_nodata=np.nan,
            resampling=resampling,
        )
        info = {
            "source": os.path.abspath(path), "band": band, "method": method, "resampling": RESAMPLING[method],
            "source_crs": src.crs.to_string(), "source_res": list(src.res), "source_nodata": nodata,
            "file_nodata": file_nodata, "caller_nodata": src_nodata,
            "nodata_note": ("file nodata used" if file_nodata is not None else
                            ("caller nodata used (file had none)" if src_nodata is not None else "no nodata defined")),
            "source_dtype": src.dtypes[band - 1],
        }
    values = dst.ravel()
    if nodata is not None:
        values = np.where(np.isclose(values, nodata), np.nan, values)
    info["missing_fraction"] = float(np.isnan(values).mean())
    info["min"] = float(np.nanmin(values)) if np.isfinite(values).any() else None
    info["max"] = float(np.nanmax(values)) if np.isfinite(values).any() else None
    return values, info


# ---------------------------------------------------------------------------
# vector 읽기·변환
# ---------------------------------------------------------------------------
def read_geojson(obj: str | dict, source_crs: str | None = None) -> tuple[list, list[dict], str]:
    """GeoJSON(파일 경로 또는 dict) → (geoms, properties, crs). RFC 7946 기본 CRS는 EPSG:4326."""
    if isinstance(obj, str):
        with open(obj, encoding="utf-8") as fh:
            data = json.load(fh)
    else:
        data = obj
    crs = source_crs
    if crs is None:
        crs_member = data.get("crs") if isinstance(data, dict) else None
        if isinstance(crs_member, dict):
            name = (crs_member.get("properties") or {}).get("name")
            if name:
                crs = name.replace("urn:ogc:def:crs:EPSG::", "EPSG:")
        crs = crs or "EPSG:4326"
    geoms: list = []
    props: list[dict] = []
    gtype = data.get("type")
    if gtype == "FeatureCollection":
        feats = data.get("features", [])
    elif gtype == "Feature":
        feats = [data]
    else:
        feats = [{"type": "Feature", "geometry": data, "properties": {}}]
    for f in feats:
        geom = f.get("geometry")
        if geom is None:
            continue
        geoms.append(shape(geom))
        props.append(f.get("properties") or {})
    return geoms, props, crs


def read_vector(path: str, source_crs: str | None = None, layer: str | None = None) -> tuple[list, list[dict], str]:
    """GeoJSON은 표준 라이브러리로, 그 외 형식은 pyogrio가 설치된 경우에만 읽는다."""
    lower = path.lower()
    if lower.endswith((".json", ".geojson")):
        return read_geojson(path, source_crs)
    try:
        import pyogrio  # type: ignore
    except ImportError as exc:
        raise ImportError("GeoJSON 이외 형식은 pyogrio가 필요하다(또는 GeoJSON으로 변환한다)") from exc
    gdf = pyogrio.read_dataframe(path, layer=layer)
    crs = source_crs or (gdf.crs.to_string() if gdf.crs is not None else None)
    if crs is None:
        raise ValueError(f"vector에 CRS가 없다: {path}")
    props = gdf.drop(columns=[gdf.geometry.name]).to_dict("records")
    return list(gdf.geometry.values), props, crs


def to_grid_crs(geoms: Sequence, source_crs: str, spec: GridSpec) -> list:
    src = CRS.from_user_input(source_crs)
    if src == spec.crs_obj:
        return list(geoms)
    tr = Transformer.from_crs(src, spec.crs_obj, always_xy=True)
    return [shp_transform(tr.transform, g) for g in geoms]


def filter_features(geoms: Sequence, props: Sequence[dict], predicate: Callable[[dict], bool]) -> tuple[list, list[dict]]:
    keep = [(g, p) for g, p in zip(geoms, props) if predicate(p)]
    return [g for g, _ in keep], [p for _, p in keep]


def distance_to_features(spec: GridSpec, geoms_grid_crs: Sequence, grid: pd.DataFrame | None = None) -> np.ndarray:
    """셀 중심에서 가장 가까운 geometry까지의 거리(격자 CRS 단위). geometry가 없으면 NaN."""
    grid = build_grid(spec) if grid is None else grid
    pts = shapely.points(grid[spec.x_column].to_numpy(), grid[spec.y_column].to_numpy())
    if len(geoms_grid_crs) == 0:
        warnings.warn("거리 계산 대상 geometry가 없다: 모든 값을 NaN으로 둔다")
        return np.full(len(grid), np.nan)
    arr = np.array(list(geoms_grid_crs), dtype=object)
    tree = STRtree(arr)
    idx = tree.nearest(pts)
    return shapely.distance(pts, arr[idx]).astype(float)


def project_bbox_boundary(bbox: Sequence[float], crs: str, densify: int = 256,
                          bbox_crs: str = "EPSG:4326") -> dict:
    """Project a bbox boundary to `crs` as a densified ring and estimate the chord deviation.

    Each edge is split into `densify` segments. `deviation` is the largest distance between a
    segment (chord) and the exactly projected midpoint of that segment. It is an estimate from
    midpoints, not a proven maximum for every projection; raise `densify` when it is large relative
    to the cell size. Returns {"xs", "ys", "deviation", "densify", "finite"}.
    """
    from shapely.geometry import LineString, Point

    if densify < 1:
        raise ValueError("densify must be >= 1")
    west, south, east, north = map(float, bbox)
    if not (west < east and south < north):
        raise ValueError("bbox must satisfy west < east and south < north (antimeridian crossing unsupported)")
    corners = [(west, south), (east, south), (east, north), (west, north), (west, south)]
    tr = Transformer.from_crs(CRS.from_user_input(bbox_crs), CRS.from_user_input(crs), always_xy=True)
    lon, lat, mid_lon, mid_lat = [], [], [], []
    for (x0, y0), (x1, y1) in zip(corners, corners[1:]):
        for i in range(densify):
            t0, tm = i / densify, (i + 0.5) / densify
            lon.append(x0 + (x1 - x0) * t0)
            lat.append(y0 + (y1 - y0) * t0)
            mid_lon.append(x0 + (x1 - x0) * tm)
            mid_lat.append(y0 + (y1 - y0) * tm)
    xs, ys = (np.asarray(v, dtype=float) for v in tr.transform(lon, lat))
    mx, my = (np.asarray(v, dtype=float) for v in tr.transform(mid_lon, mid_lat))
    finite = bool(np.all(np.isfinite(xs)) and np.all(np.isfinite(ys))
                  and np.all(np.isfinite(mx)) and np.all(np.isfinite(my)))
    deviation = None
    if finite:
        ring = list(zip(xs, ys)) + [(xs[0], ys[0])]
        deviation = 0.0
        for k in range(len(xs)):
            deviation = max(deviation, LineString([ring[k], ring[k + 1]]).distance(Point(mx[k], my[k])))
    return {"xs": xs, "ys": ys, "deviation": deviation, "densify": int(densify), "finite": finite}


def bbox_bounds_in_crs(bbox: Sequence[float], crs: str, densify: int = 256,
                       bbox_crs: str = "EPSG:4326") -> tuple[tuple[float, float, float, float], dict]:
    """Bounds of a projected bbox from its densified boundary, widened by the estimated chord deviation.

    The extent of a continuous, one-to-one projection of a rectangle is reached on its boundary, so
    boundary samples approximate it; the widening by `deviation` is an estimate, not a guarantee.
    """
    ring = project_bbox_boundary(bbox, crs, densify=densify, bbox_crs=bbox_crs)
    if not ring["finite"]:
        raise ValueError(f"bbox boundary does not project to finite coordinates in {crs}")
    pad = float(ring["deviation"] or 0.0)
    bounds = (float(ring["xs"].min()) - pad, float(ring["ys"].min()) - pad,
              float(ring["xs"].max()) + pad, float(ring["ys"].max()) + pad)
    return bounds, {"method": "densified bbox boundary projected to the target CRS, widened by the chord deviation",
                    "densify_per_edge": ring["densify"], "chord_deviation": pad,
                    "note": "approximation; the deviation is estimated from segment midpoints"}


def distance_edge_limited(spec: GridSpec, distances: np.ndarray, query_bbox_wgs84: Sequence[float],
                          grid: pd.DataFrame | None = None, densify: int = 256) -> tuple[np.ndarray, dict]:
    """Flag cells whose nearest-feature distance may be overestimated because features were queried by a bbox.

    The true nearest distance is never larger than the observed one. A feature beyond the query
    boundary could be nearer only when the observed distance exceeds the distance from the cell
    centre to that boundary, so those cells are flagged. The projected boundary is a densified
    polyline (`project_bbox_boundary`); the distance to it is lowered by the estimated chord
    deviation to allow for the approximation. The deviation is estimated from segment midpoints,
    so it is an allowance, not a proof for every projection; raise `densify` when it is large.
    Cells outside the query area are flagged when their distance is positive. When the boundary
    cannot be projected to finite, valid geometry every cell with a finite distance is flagged.
    Returns (bool array, info).
    """
    from shapely.geometry import Polygon

    grid = build_grid(spec) if grid is None else grid
    west, south, east, north = map(float, query_bbox_wgs84)
    ring = project_bbox_boundary([west, south, east, north], spec.crs, densify=densify)
    xs, ys = ring["xs"], ring["ys"]
    dist = np.asarray(distances, dtype=float)
    info = {"query_bbox_wgs84": [west, south, east, north], "densify_per_edge": int(densify),
            "rule": "observed distance > (distance from cell centre to the projected query boundary - chord deviation)"}
    region = Polygon(list(zip(xs, ys))) if ring["finite"] else None
    if region is None or not region.is_valid or region.is_empty:
        flag = np.isfinite(dist)
        info.update({"n_cells_edge_limited": int(flag.sum()), "approximation_bound": None,
                     "note": "query boundary could not be projected to valid geometry; all cells flagged"})
        return flag, info
    bound = float(ring["deviation"])
    pts = shapely.points(grid[spec.x_column].to_numpy(), grid[spec.y_column].to_numpy())
    inside = shapely.contains(region, pts)
    to_edge = np.where(inside, shapely.distance(pts, region.exterior) - bound, 0.0)
    to_edge = np.maximum(to_edge, 0.0)
    flag = np.isfinite(dist) & (dist > to_edge)
    info.update({"n_cells_edge_limited": int(flag.sum()), "approximation_bound": float(bound),
                 "approximation_note": "chord deviation estimated from segment midpoints"})
    return flag, info


def _grid_cell_polygons(spec: GridSpec, grid: pd.DataFrame) -> list:
    """Build exact square cell polygons in row-major grid order."""
    from shapely.geometry import box

    rows = grid["row"].to_numpy(dtype=int)
    cols = grid["col"].to_numpy(dtype=int)
    left = spec.minx + cols * spec.cell_size
    right = left + spec.cell_size
    top = spec.top - rows * spec.cell_size
    bottom = top - spec.cell_size
    return [box(x0, y0, x1, y1) for x0, y0, x1, y1 in zip(left, bottom, right, top)]


def polygon_fraction(spec: GridSpec, polygons_grid_crs: Sequence,
                     grid: pd.DataFrame | None = None) -> tuple[np.ndarray, dict]:
    """Return the planar area fraction of each cell covered by the polygon union.

    Overlapping polygons are unioned per cell, so a covered fraction never
    exceeds one. Categorical class selection belongs in the recipe predicate.
    """
    if not spec.crs_obj.is_projected:
        raise ValueError("polygon_fraction은 투영 CRS에서만 계산한다")
    grid = build_grid(spec) if grid is None else grid
    out = np.zeros(len(grid), dtype=float)
    valid = [g for g in polygons_grid_crs if g is not None and not g.is_empty]
    if any(g.geom_type not in {"Polygon", "MultiPolygon"} for g in valid):
        raise ValueError("polygon_fraction은 Polygon/MultiPolygon만 받는다")
    info = {"method": "planar union area of matching polygons / cell area",
            "n_polygons": int(len(valid)), "n_cells_covered": 0,
            "cell_area_crs_units2": float(spec.cell_size ** 2)}
    if not valid:
        return out, info
    tree = STRtree(np.asarray(valid, dtype=object))
    cells = _grid_cell_polygons(spec, grid)
    cell_area = float(spec.cell_size ** 2)
    for i, cell in enumerate(cells):
        idx = tree.query(cell, predicate="intersects")
        if not len(idx):
            continue
        overlaps = shapely.intersection(np.asarray(valid, dtype=object)[idx], cell)
        covered = float(shapely.union_all(overlaps).area)
        out[i] = min(1.0, max(0.0, covered / cell_area))
    info["n_cells_covered"] = int((out > 0).sum())
    info["max_fraction"] = float(out.max()) if len(out) else 0.0
    return out, info


def line_density(spec: GridSpec, lines_grid_crs: Sequence,
                 grid: pd.DataFrame | None = None) -> tuple[np.ndarray, dict]:
    """Return summed in-cell line length per square kilometre.

    Length and cell area are converted using the projected CRS axis unit. The
    output unit is always km/km²; geographic CRSs are rejected.
    """
    crs = spec.crs_obj
    if not crs.is_projected:
        raise ValueError("line_density은 투영 CRS에서만 계산한다")
    axes = crs.axis_info
    metres_per_unit = axes[0].unit_conversion_factor if axes else None
    if not metres_per_unit or not math.isfinite(metres_per_unit):
        raise ValueError(f"투영 CRS의 선형 단위를 미터로 변환할 수 없다: {spec.crs}")
    grid = build_grid(spec) if grid is None else grid
    out = np.zeros(len(grid), dtype=float)
    valid = [g for g in lines_grid_crs if g is not None and not g.is_empty]
    if any(g.geom_type not in {"LineString", "MultiLineString"} for g in valid):
        raise ValueError("line_density은 LineString/MultiLineString만 받는다")
    info = {"method": "sum of clipped line lengths / cell area",
            "unit": "km/km2", "n_lines": int(len(valid)),
            "metres_per_crs_unit": float(metres_per_unit), "n_cells_with_lines": 0}
    if not valid:
        return out, info
    arr = np.asarray(valid, dtype=object)
    tree = STRtree(arr)
    cells = _grid_cell_polygons(spec, grid)
    area_km2 = (spec.cell_size * metres_per_unit) ** 2 / 1_000_000.0
    for i, cell in enumerate(cells):
        idx = tree.query(cell, predicate="intersects")
        if not len(idx):
            continue
        clipped = shapely.intersection(arr[idx], cell)
        length_km = float(shapely.length(clipped).sum()) * metres_per_unit / 1000.0
        out[i] = length_km / area_km2
    info["n_cells_with_lines"] = int((out > 0).sum())
    return out, info


def attribute_at_centers(spec: GridSpec, polygons_grid_crs: Sequence, values: Sequence,
                         grid: pd.DataFrame | None = None) -> tuple[np.ndarray, dict]:
    """셀 중심이 속한 polygon의 속성값(숫자)을 돌려준다. 겹치면 마지막 매칭, 없으면 NaN.

    범주형 속성은 여기서 숫자로 바꾸지 않는다. 호출자가 코드표를 정하고 metadata에 남긴다.
    """
    grid = build_grid(spec) if grid is None else grid
    out = np.full(len(grid), np.nan)
    info = {"n_polygons": int(len(polygons_grid_crs)), "n_cells_matched": 0, "n_cells_multi_match": 0}
    if len(polygons_grid_crs) == 0:
        return out, info
    pts = shapely.points(grid[spec.x_column].to_numpy(), grid[spec.y_column].to_numpy())
    arr = np.array(list(polygons_grid_crs), dtype=object)
    vals = np.array([np.nan if v is None else v for v in values], dtype=float)
    tree = STRtree(arr)
    pt_idx, poly_idx = tree.query(pts, predicate="within")
    if len(pt_idx):
        counts = np.bincount(pt_idx, minlength=len(grid))
        info["n_cells_multi_match"] = int((counts > 1).sum())
        out[pt_idx] = vals[poly_idx]
        info["n_cells_matched"] = int((counts > 0).sum())
    return out, info


def aoi_mask(spec: GridSpec, aoi, grid: pd.DataFrame | None = None, aoi_crs: str = "EPSG:4326") -> tuple[np.ndarray, dict]:
    """셀 중심의 정확한 AOI 소속. 셀 중심을 AOI CRS로 역변환해 bbox와 비교하거나 polygon 내부를 판정한다.

    투영된 사각 격자의 꼭짓점만 변환한 근사 polygon은 곡선 경계에서 셀을 오분류할 수 있다.
    셀 중심을 역변환해 원래 AOI 경계와 비교한다.
    aoi: [west, south, east, north] 또는 GeoJSON geometry dict / shapely geometry(aoi_crs 기준).
    """
    grid = build_grid(spec) if grid is None else grid
    tr = Transformer.from_crs(spec.crs_obj, CRS.from_user_input(aoi_crs), always_xy=True)
    ax, ay = tr.transform(grid[spec.x_column].to_numpy(), grid[spec.y_column].to_numpy())
    if isinstance(aoi, (list, tuple)) and len(aoi) == 4:
        west, south, east, north = map(float, aoi)
        inside = (ax >= west) & (ax <= east) & (ay >= south) & (ay <= north)
        method = "cell centre inverse-projected to AOI CRS; inclusive bbox comparison"
        aoi_desc = {"type": "bbox", "bounds": [west, south, east, north]}
    else:
        geom = shape(aoi) if isinstance(aoi, dict) else aoi
        inside = shapely.contains_xy(geom, ax, ay)
        method = "cell centre inverse-projected to AOI CRS; point-in-polygon"
        aoi_desc = {"type": geom.geom_type, "bounds": list(geom.bounds)}
    inside = np.asarray(inside, dtype=bool)
    info = {"method": method, "aoi_crs": aoi_crs, "aoi": aoi_desc, "n_cells": int(len(grid)),
            "n_inside": int(inside.sum()), "n_outside": int((~inside).sum())}
    return inside, info


def aoi_boundary_in_grid_crs(spec: GridSpec, aoi, aoi_crs: str = "EPSG:4326", densify: int = 64):
    """AOI 경계를 촘촘히 나눠 격자 CRS로 옮긴 polygon. 그림 표시용이며 포함 판정 근거로 쓰지 않는다
    (판정은 `aoi_mask`의 셀 중심 역변환)."""
    from shapely.geometry import Polygon
    if isinstance(aoi, (list, tuple)) and len(aoi) == 4:
        west, south, east, north = map(float, aoi)
        xs = np.linspace(west, east, densify)
        ys = np.linspace(south, north, densify)
        ring = ([(x, south) for x in xs] + [(east, y) for y in ys] + [(x, north) for x in xs[::-1]] +
                [(west, y) for y in ys[::-1]])
        geom = Polygon(ring)
    else:
        geom = shape(aoi) if isinstance(aoi, dict) else aoi
        geom = geom.segmentize(max(geom.length / (4 * densify), 1e-9)) if hasattr(geom, "segmentize") else geom
    tr = Transformer.from_crs(CRS.from_user_input(aoi_crs), spec.crs_obj, always_xy=True)
    return shp_transform(tr.transform, geom)


def point_statistic(spec: GridSpec, points_grid_crs: Sequence, values: Sequence, stat: str = "median",
                    grid: pd.DataFrame | None = None) -> tuple[np.ndarray, dict]:
    """셀 안 표본 point의 통계(median/mean/max/min/count). 표본이 없는 셀은 NaN(count는 0).

    관측 지지(support)를 보존한다. 결측이 많다는 것은 오류가 아니라 표본 밀도의 사실이다.
    """
    if stat not in {"median", "mean", "max", "min", "count"}:
        raise ValueError("stat은 median/mean/max/min/count 중 하나여야 한다")
    grid = build_grid(spec) if grid is None else grid
    out = np.full(len(grid), np.nan)
    vals = np.array([np.nan if v is None else v for v in values], dtype=float)
    info = {"stat": stat, "n_points_total": int(len(points_grid_crs)), "n_points_in_grid": 0,
            "n_valid_values": 0, "n_cells_with_samples": 0, "coverage_fraction": 0.0}
    if len(points_grid_crs) == 0:
        if stat == "count":
            out[:] = 0
        return out, info
    xs = np.array([g.x for g in points_grid_crs], dtype=float)
    ys = np.array([g.y for g in points_grid_crs], dtype=float)
    row, col, inside = cell_index(spec, xs, ys)
    valid = inside & np.isfinite(vals) if stat != "count" else inside
    ids = row[valid] * spec.ncols + col[valid]
    info["n_points_in_grid"] = int(inside.sum())
    info["n_valid_values"] = int((inside & np.isfinite(vals)).sum())
    if stat == "count":
        out[:] = 0
        np.add.at(out, ids, 1)
    elif len(ids):
        agg = pd.Series(vals[valid]).groupby(ids).agg(stat)
        out[agg.index.to_numpy()] = agg.to_numpy()
    with_samples = int(np.unique(ids).size)
    info["n_cells_with_samples"] = with_samples
    info["coverage_fraction"] = with_samples / len(grid) if len(grid) else 0.0
    return out, info


def nearest_fill(spec: GridSpec, cell_values: np.ndarray, points_grid_crs: Sequence, values: Sequence,
                 max_distance: float, grid: pd.DataFrame | None = None) -> tuple[np.ndarray, np.ndarray, dict]:
    """표본이 없는 셀을 max_distance 안의 최근접 표본값으로 채운다. 지지 거리 열을 함께 돌려준다.

    무제한 최근접 배정은 Voronoi식 복제와 원거리 외삽을 만든다. 상한을 명시하고
    채운 비율·최대 거리를 metadata에 남긴다. 반환한 support 거리(격자 CRS 단위)는 자료 값이 아니라 진단 열이다.
    """
    grid = build_grid(spec) if grid is None else grid
    vals = np.array([np.nan if v is None else v for v in values], dtype=float)
    keep = [g for g, v in zip(points_grid_crs, vals) if np.isfinite(v)]
    kv = vals[np.isfinite(vals)]
    filled = np.array(cell_values, dtype=float).copy()
    support = np.full(len(grid), np.nan)
    info = {"method": "nearest sample within max_distance", "max_distance": float(max_distance),
            "n_samples_valid": int(len(keep)), "n_filled": 0, "fill_fraction": 0.0, "max_fill_distance_used": None}
    if not keep:
        return filled, support, info
    pts = shapely.points(grid[spec.x_column].to_numpy(), grid[spec.y_column].to_numpy())
    arr = np.array(keep, dtype=object)
    tree = STRtree(arr)
    idx = tree.nearest(pts)
    support = shapely.distance(pts, arr[idx]).astype(float)
    missing = ~np.isfinite(filled)
    fill = missing & (support <= float(max_distance))
    filled[fill] = kv[idx[fill]]
    info["n_filled"] = int(fill.sum())
    info["fill_fraction"] = float(fill.mean()) if len(fill) else 0.0
    info["max_fill_distance_used"] = float(support[fill].max()) if fill.any() else None
    info["n_still_missing"] = int((~np.isfinite(filled)).sum())
    return filled, support, info


def presence_from_points(spec: GridSpec, points_grid_crs: Sequence, buffer: float = 0.0,
                         grid: pd.DataFrame | None = None) -> tuple[np.ndarray, np.ndarray, dict]:
    """점 기록 → (있음 0/1, 셀당 기록 수, 정의). buffer>0이면 셀 중심에서 buffer 안의 기록도 있음으로 본다.

    0은 이 자료·추출 범위에 선택된 기록이 없다는 뜻이며 부재 확인이 아니다.
    """
    grid = build_grid(spec) if grid is None else grid
    counts = np.zeros(len(grid), dtype=int)
    n_outside = 0
    if len(points_grid_crs):
        xs = np.array([g.x for g in points_grid_crs], dtype=float)
        ys = np.array([g.y for g in points_grid_crs], dtype=float)
        row, col, inside = cell_index(spec, xs, ys)
        n_outside = int((~inside).sum())
        ids = row[inside] * spec.ncols + col[inside]
        np.add.at(counts, ids, 1)
    presence = (counts > 0).astype(np.int8)
    definition = "cell contains >=1 selected record (no buffer)"
    if buffer > 0:
        dist = distance_to_features(spec, points_grid_crs, grid)
        presence = ((counts > 0) | (dist <= buffer)).astype(np.int8)
        definition = f"cell contains >=1 selected record OR cell centre within {buffer} {spec.unit} of one"
    meta = {"presence_definition": definition, "n_points_total": int(len(points_grid_crs)),
            "n_points_outside_grid": n_outside, "n_present_cells": int(presence.sum()),
            "absence_semantics": "0 = no selected record in this source extract; not verified absence"}
    return presence, counts, meta


# ---------------------------------------------------------------------------
# 표·검증·metadata
# ---------------------------------------------------------------------------
def assemble_table(spec: GridSpec, values: dict[str, np.ndarray], grid: pd.DataFrame | None = None,
                   extra: dict[str, np.ndarray] | None = None) -> pd.DataFrame:
    """셀 표에 열을 붙인다. `values`는 실수 열로, `extra`(있음 표시·건수·영역 표시 등)는 값 그대로 붙인다."""
    grid = build_grid(spec) if grid is None else grid
    df = grid.copy()
    reserved = set(df.columns)
    for name, column in [*values.items(), *(extra or {}).items()]:
        if name in reserved:
            raise ValueError(f"열 이름이 예약 열이나 앞의 열과 겹친다: {name}")
        if len(column) != len(df):
            raise ValueError(f"열 {name} 길이가 셀 수와 다르다")
        reserved.add(name)
    for name, column in values.items():
        df[name] = np.asarray(column, dtype=float)
    for name, column in (extra or {}).items():
        df[name] = column
    return df


def validate_table(df: pd.DataFrame, spec: GridSpec, value_columns: Sequence[str],
                   presence_columns: Sequence[str] = (), require_full_grid: bool = True,
                   max_missing_fraction: float | None = None) -> dict:
    """격자 표의 필요조건을 검사하고 건수를 보고한다(기록의 정확성·지질학적 타당성은 검사하지 못한다).

    - 행·식별자·좌표: 전체 격자면 행 수 = 셀 수, `cell_id` 고유, 좌표가 격자 경계 안.
    - `value_columns`: 숫자형이며 전부 결측이 아니다. 결측률은 항상 보고하고, `max_missing_fraction`을
      주면 그 값을 넘는 열을 경고한다(기준은 작업 목적에 따라 호출자가 정한다).
    - `presence_columns`: 결측 없는 0/1이며 있음 셀 수를 보고한다.
    require_full_grid=False는 AOI 선택 등으로 행을 골라낸 표에 쓴다(행 수 = 셀 수 검사 생략).
    """
    errors: list[str] = []
    warnings_: list[str] = []
    n = len(df)
    if require_full_grid and n != spec.n_cells:
        errors.append(f"rows {n} != n_cells {spec.n_cells}")
    elif not require_full_grid and n == 0:
        errors.append("rows 0")
    if df["cell_id"].duplicated().any():
        errors.append("cell_id 중복")
    for c in (spec.x_column, spec.y_column):
        if c not in df.columns:
            errors.append(f"좌표 열 없음: {c}")
    if not errors:
        minx, miny, maxx, maxy = spec.bounds_used
        if not (df[spec.x_column].between(minx, maxx).all() and df[spec.y_column].between(miny, maxy).all()):
            errors.append("좌표가 격자 경계 밖")
    summary: dict = {"rows": n, "n_value_columns": len(value_columns), "present_cells": {}}
    for c in presence_columns:
        if c not in df.columns:
            errors.append(f"있음 표시 열 없음: {c}")
            continue
        vals = set(pd.unique(df[c].dropna()))
        if not vals <= {0, 1}:
            errors.append(f"있음 표시 값이 0/1이 아니다: {c}: {sorted(vals)[:5]}")
        if df[c].isna().any():
            errors.append(f"있음 표시 결측: {c}")
        summary["present_cells"][c] = int((df[c] == 1).sum())
    missing: dict[str, float] = {}
    for c in value_columns:
        if c not in df.columns:
            errors.append(f"자료 값 열 없음: {c}")
            continue
        if not pd.api.types.is_numeric_dtype(df[c]):
            errors.append(f"자료 값 열이 숫자가 아니다: {c}")
            continue
        frac = float(df[c].isna().mean())
        missing[c] = frac
        if frac >= 1.0:
            errors.append(f"자료 값 열 전부 결측: {c}")
        elif max_missing_fraction is not None and frac > max_missing_fraction:
            warnings_.append(f"결측률 {frac:.1%} > 작업 기준 {max_missing_fraction:.1%}: {c}")
    for c in [*value_columns, *presence_columns]:
        if c in df.columns and df[c].nunique(dropna=True) <= 1:
            warnings_.append(f"열 값이 하나뿐이다: {c}")
    summary["missing_fraction"] = missing
    if max_missing_fraction is not None:
        summary["max_missing_fraction"] = max_missing_fraction
    return {"errors": errors, "warnings": warnings_, "summary": summary, "ok": not errors}


def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 16), b""):
            h.update(chunk)
    return h.hexdigest()


def write_table(df: pd.DataFrame, out_dir: str, name: str = "grid_table") -> dict:
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{name}.csv")
    df.to_csv(path, index=False)
    return {"path": os.path.abspath(path), "sha256": sha256_file(path), "rows": int(len(df)),
            "columns": list(df.columns)}


def build_metadata(spec: GridSpec, table: dict, columns: dict[str, dict], validation: dict,
                   provenance: Iterable[dict] = (), notes: Iterable[str] = (), project: str = "") -> dict:
    """열별 역할·정의·단위·출처·라이선스와 검증 결과를 하나의 metadata로 묶는다.

    columns: {열이름: {"role", "definition", "unit", "unit_basis", "source_sha256"|"source", "licence", "sampling"}}
    역할은 `value`, `diagnostic`, `record_derived`, `mask` 등 열이 무엇인지를 적는다. 자료를 어떻게
    변환·결합·해석할지는 이 metadata가 정하지 않는다.
    """
    column_roles = {name: details.get("role", "value") for name, details in columns.items()}
    return {
        "schema_version": 2,
        "created_at": _now(),
        "project": project,
        "grid": spec.to_dict(),
        "table": table,
        "columns": columns,
        "column_roles": column_roles,
        "validation": validation,
        "provenance": list(provenance),
        "scope_note": ("Acquisition records what each column is and where it came from. How the columns are "
                       "transformed, combined, modelled or interpreted is decided by the user or later work."),
        "notes": list(notes),
    }


def write_json(obj: dict, path: str) -> str:
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    artifact_paths.dump_json(obj, path)
    return os.path.abspath(path)


def _json_default(o):
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, (np.floating,)):
        return None if not np.isfinite(o) else float(o)
    if isinstance(o, np.ndarray):
        return o.tolist()
    raise TypeError(f"JSON 직렬화 불가: {type(o)}")


BINARY_TICKS = {"binary presence": ["absent class", "present class"],
                "record presence": ["no record", "record present"]}


def preview_figure(spec: GridSpec, df: pd.DataFrame, columns: Sequence[str], out_png: str,
                   marker_column: str | None = None, units: dict[str, str] | None = None,
                   title: str = "", mask: np.ndarray | None = None, boundary=None) -> str:
    """셀을 채우는 raster형 미리보기 + 선택한 있음 표시 열(`marker_column`=1)의 위치 marker.
    검증용 최소 그림이며 출판용이 아니다."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.colors import ListedColormap, BoundaryNorm

    units = units or {}
    ncol = min(3, len(columns))
    nrow = int(math.ceil(len(columns) / ncol)) if columns else 1
    fig, axes = plt.subplots(nrow, ncol, figsize=(4.2 * ncol, 4.0 * nrow), squeeze=False)
    extent = [spec.minx, spec.right, spec.miny, spec.top]
    pos = df[df[marker_column] == 1] if marker_column and marker_column in df.columns else None
    outside = None
    if mask is not None:
        outside = ~np.asarray(mask, dtype=bool).reshape(spec.nrows, spec.ncols)
    for ax, col in zip(axes.ravel(), columns):
        arr = df[col].to_numpy(dtype=float).reshape(spec.nrows, spec.ncols)
        if outside is not None:
            ax.imshow(np.ma.masked_where(~outside, np.zeros_like(arr)), extent=extent, origin="upper",
                      cmap=ListedColormap(["#f2f2f2"]), interpolation="nearest")
            arr = np.where(outside, np.nan, arr)
        if boundary is not None:
            bx, by = boundary.exterior.xy
            ax.plot(bx, by, color="black", linewidth=0.7, linestyle="--", label="AOI boundary")
        binary = units.get(col) in BINARY_TICKS
        cmap = ListedColormap(["#385c87", "#e0b44b"]) if binary else plt.get_cmap("viridis").copy()
        cmap.set_bad("#d9d9d9")
        norm = BoundaryNorm([-.5, .5, 1.5], cmap.N) if binary else None
        im = ax.imshow(np.ma.masked_invalid(arr), extent=extent, origin="upper", cmap=cmap, norm=norm, interpolation="nearest")
        if pos is not None and len(pos):
            ax.scatter(pos[spec.x_column], pos[spec.y_column], s=12, marker="^", facecolors="none",
                       edgecolors="red", linewidths=0.8, label=f"{marker_column}=1 (n={len(pos)})")
        if (pos is not None and len(pos)) or boundary is not None:
            ax.legend(loc="lower left", fontsize=7)
        ax.set_title(col, fontsize=9)
        ax.set_xlabel(f"{spec.x_column} [{spec.unit}] {spec.crs}", fontsize=7)
        ax.set_ylabel(f"{spec.y_column} [{spec.unit}]", fontsize=7)
        ax.tick_params(labelsize=6)
        cb = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.02)
        unit = units.get(col, "?")
        # Long qualification prose belongs in metadata, not a clipped colourbar.
        if len(unit) > 28:
            unit = unit.split(" (")[0] + " (provisional)"
        cb.set_label(f"{unit}; grey = nodata" + ("; light grey = outside AOI" if outside is not None else ""), fontsize=7)
        if binary:
            cb.set_ticks([0, 1], labels=BINARY_TICKS[units[col]])
        cb.ax.tick_params(labelsize=6)
    for ax in axes.ravel()[len(columns):]:
        ax.axis("off")
    if title:
        fig.suptitle(title, fontsize=10)
    fig.tight_layout()
    os.makedirs(os.path.dirname(os.path.abspath(out_png)), exist_ok=True)
    fig.savefig(out_png, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return os.path.abspath(out_png)
