"""속도 제한·해시·출처 기록을 갖춘 파일 다운로드(표준 라이브러리만 사용).

수집한 모든 파일은 옆에 `<파일>.provenance.json`을 남긴다: URL, 최종 URL, HTTP status,
content-type, 크기, sha256, 시각, User-Agent, 라이선스 문구/URL, 카탈로그 기록 id.
이 기록 없이 받은 파일은 분석 입력으로 쓰지 않는다. 프록시·CA는 환경 설정을 따른다.
"""
from __future__ import annotations

import hashlib
import json
import os
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone

import artifact_paths
from fetch_budget import BudgetExceeded, FetchBudget

DEFAULT_USER_AGENT = "geoscience-data-fetch/0.2 (research script; Python urllib)"
CHUNK = 1 << 16


class DownloadError(RuntimeError):
    def __init__(self, message: str, status: int | None = None):
        super().__init__(message)
        self.status = status


class RedirectRefused(DownloadError):
    """A redirect to a host outside the approved list was not followed."""


REDIRECT_CODES = (301, 302, 303, 307, 308)


class _ReturnRedirect(urllib.request.BaseHandler):
    """Return 3xx responses to the caller instead of following them."""

    handler_order = 100

    def _stop(self, req, fp, code, msg, headers):
        return fp

    http_error_301 = http_error_302 = http_error_303 = http_error_307 = http_error_308 = _stop


def normalise_hosts(allowed_hosts) -> set[str]:
    hosts = {str(h).lower() for h in allowed_hosts}
    if not hosts:
        raise ValueError("allowed_hosts is empty; pass None for no host restriction or list the approved hosts")
    return hosts


def open_guarded(url: str, allowed_hosts, *, budget: FetchBudget | None = None, headers: dict | None = None,
                 timeout: float = 120.0, handlers=(), max_hops: int = 5):
    """GET url and follow redirects one hop at a time, checking each target host and the budget first.

    Returns (response, final_url, hops). Every request, including each redirect hop, calls
    `budget.wait()` before it is sent. A target outside `allowed_hosts` raises RedirectRefused
    without being requested. `handlers` (for example a ProxyHandler) are added to a private opener.
    """
    allowed = normalise_hosts(allowed_hosts)
    opener = urllib.request.build_opener(_ReturnRedirect(), *handlers)
    current = url
    hops: list[dict] = []
    while True:
        host = (urllib.parse.urlsplit(current).hostname or "").lower()
        if host not in allowed:
            raise RedirectRefused(f"{host} is not an approved host; not requested: {current}")
        if budget is not None:
            budget.wait()
        resp = opener.open(urllib.request.Request(current, headers=headers or {}), timeout=timeout)
        if resp.status not in REDIRECT_CODES:
            return resp, current, hops
        location = resp.headers.get("Location")
        resp.close()
        if not location:
            raise DownloadError(f"HTTP {resp.status} without Location: {current}", status=resp.status)
        target = urllib.parse.urljoin(current, location)
        hops.append({"status": resp.status, "from": current, "to": target})
        target_host = (urllib.parse.urlsplit(target).hostname or "").lower()
        if target_host not in allowed:
            raise RedirectRefused(f"HTTP {resp.status} redirect to unapproved host {target_host}; not followed",
                                  status=resp.status)
        if len(hops) > max_hops:
            raise DownloadError(f"more than {max_hops} redirects: {url}")
        current = target


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def download(url: str, dest_path: str, *, budget: FetchBudget | None = None,
             user_agent: str = DEFAULT_USER_AGENT, timeout: float = 120.0,
             headers: dict | None = None, expected_sha256: str | None = None,
             max_bytes: int | None = None, licence: dict | None = None,
             source: dict | None = None, opener: urllib.request.OpenerDirector | None = None,
             overwrite: bool = False, request_signature: str | None = None,
             allowed_hosts=None, handlers=()) -> dict:
    """URL을 dest_path에 저장하고 provenance dict를 반환·기록한다.

    licence: {"name": ..., "url": ..., "statement": ...} 처럼 실제로 확인한 문구만 넣는다.
    source: {"catalogue": ..., "record_id": ..., "title": ...} 등 카탈로그 기록.
    request_signature: 같은 요청을 다시 보내지 않고 검증된 파일을 재사용하기 위한 요청 서명.
    allowed_hosts: 주면 요청 URL과 redirect의 모든 단계를 요청 전에 이 host 목록으로 검사하고, 단계마다
        요청 예산을 적용한다(`open_guarded`). 이때 opener 대신 `handlers`(예: ProxyHandler)를 넘긴다.
        빈 목록은 오류다. None이면 host를 검사하지 않고 urllib 기본 redirect를 따르므로, 승인 범위를
        지켜야 하는 호출자는 항상 승인 host 목록을 넘긴다(선택형 `acquire.py`는 그렇게 한다).
    """
    if os.path.exists(dest_path) and not overwrite:
        raise DownloadError(f"이미 존재한다(overwrite=False): {dest_path}")
    allowed = normalise_hosts(allowed_hosts) if allowed_hosts is not None else None
    if allowed is not None and opener is not None:
        raise ValueError("allowed_hosts cannot be enforced on a caller-supplied opener; pass handlers instead")
    req_headers = {"User-Agent": user_agent}
    if headers:
        req_headers.update(headers)
    hops: list[dict] = []
    os.makedirs(os.path.dirname(os.path.abspath(dest_path)), exist_ok=True)
    tmp = dest_path + ".part"
    digest = hashlib.sha256()
    size = 0
    status = None
    ctype = None
    final_url = url
    try:
        if allowed is not None:
            resp, final_url, hops = open_guarded(url, allowed, budget=budget, headers=req_headers,
                                                 timeout=timeout, handlers=handlers)
        else:
            if budget is not None:
                budget.wait()
            resp = (opener or urllib.request.build_opener(*handlers)).open(
                urllib.request.Request(url, headers=req_headers), timeout=timeout)
        with resp, open(tmp, "wb") as out:
            status = resp.status
            ctype = resp.headers.get("Content-Type")
            final_url = resp.geturl()
            declared = resp.headers.get("Content-Length")
            if max_bytes is not None and declared and declared.isdigit() and int(declared) > max_bytes:
                raise DownloadError(f"Content-Length {declared} > max_bytes {max_bytes}: {url}")
            while True:
                chunk = resp.read(CHUNK)
                if not chunk:
                    break
                size += len(chunk)
                if max_bytes is not None and size > max_bytes:
                    raise DownloadError(f"{size} bytes > max_bytes {max_bytes}: {url}")
                digest.update(chunk)
                out.write(chunk)
    except BudgetExceeded:
        _cleanup(tmp)  # the request was not sent; the caller stops and records the budget state
        raise
    except urllib.error.HTTPError as exc:
        _cleanup(tmp)
        if budget is not None:
            budget.failure(exc.code)
        raise DownloadError(f"HTTP {exc.code} for {url}", status=exc.code) from exc
    except DownloadError:
        _cleanup(tmp)
        if budget is not None:
            budget.failure(None)
        raise
    except Exception as exc:
        _cleanup(tmp)
        if budget is not None:
            budget.failure(None)
        raise DownloadError(f"{type(exc).__name__}: {exc} for {url}") from exc
    sha = digest.hexdigest()
    if expected_sha256 and sha.lower() != expected_sha256.lower():
        _cleanup(tmp)
        if budget is not None:
            budget.failure(None)
        raise DownloadError(f"sha256 불일치: expected {expected_sha256}, got {sha}: {url}")
    os.replace(tmp, dest_path)
    if budget is not None:
        budget.success()
    record = {
        "schema_version": 1,
        "url": url,
        "final_url": final_url,
        "http_status": status,
        "content_type": ctype,
        "bytes": size,
        "sha256": sha,
        "retrieved_at": _now(),
        "user_agent": user_agent,
        "path": os.path.abspath(dest_path),
        "licence": licence or {"name": None, "url": None, "statement": None, "verified": False},
        "source": source or {},
        "request_signature": request_signature,
        "redirects": hops,
    }
    write_provenance(record, dest_path + ".provenance.json")
    return record


def request_signature(kind: str, **params) -> str:
    """요청 종류와 매개변수의 정규화 JSON sha256. 같은 서명 = 같은 요청."""
    payload = json.dumps({"kind": kind, **params}, sort_keys=True, ensure_ascii=False, default=str)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _cleanup(tmp: str) -> None:
    try:
        if os.path.exists(tmp):
            os.remove(tmp)
    except OSError:  # pragma: no cover
        pass


def write_provenance(record: dict, path: str) -> None:
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    payload = artifact_paths.portable_payload(record, path)
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(payload, fh, ensure_ascii=False, indent=2)


def sha256_file(path: str) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(CHUNK), b""):
            digest.update(chunk)
    return digest.hexdigest()


class ProvenanceIndex:
    """수집 세션의 provenance 기록 묶음. 표 metadata가 이 목록을 참조한다."""

    def __init__(self, path: str):
        self.path = path
        self.records: list[dict] = []
        if os.path.exists(path):
            with open(path, encoding="utf-8") as fh:
                saved = json.load(fh)
            self.records = saved if isinstance(saved, list) else saved.get("records", [])

    def add(self, record: dict) -> None:
        """같은 path·sha256 기록은 갱신하고 새 기록만 추가한다(재실행 시 중복 방지)."""
        for i, existing in enumerate(self.records):
            existing_path = artifact_paths.resolve_path(existing.get("path"), self.path)
            record_path = artifact_paths.resolve_path(record.get("path"), self.path)
            if existing_path and existing_path == record_path and existing.get("sha256") == record.get("sha256"):
                self.records[i] = record
                break
        else:
            self.records.append(record)
        self.save()

    def by_signature(self, signature: str | None) -> dict | None:
        """요청 서명이 같은 가장 최근 기록."""
        if not signature:
            return None
        for rec in reversed(self.records):
            if rec.get("request_signature") == signature:
                return rec
        return None

    def verified_path(self, signature: str | None) -> str | None:
        """서명이 같고 파일이 존재하며 sha256이 일치할 때만 그 경로(재사용 가능)."""
        rec = self.by_signature(signature)
        if not rec:
            return None
        if rec.get("completeness") in {"partial", "unknown"} or (
                rec.get("merged_from_pages") and rec.get("completeness") != "complete"):
            return None
        path = artifact_paths.resolve_path(rec.get("path"), self.path)
        if not path or not os.path.exists(path):
            return None
        if sha256_file(path) != rec.get("sha256"):
            return None
        return path

    def save(self) -> None:
        os.makedirs(os.path.dirname(os.path.abspath(self.path)), exist_ok=True)
        payload = artifact_paths.portable_payload({"schema_version": 1, "updated_at": _now(),
                                                    "records": self.records}, self.path)
        with open(self.path, "w", encoding="utf-8") as fh:
            json.dump(payload, fh, ensure_ascii=False, indent=2)

    def by_sha(self, sha256: str) -> dict | None:
        for rec in self.records:
            if rec.get("sha256") == sha256:
                return rec
        return None
