"""Portable filesystem references for acquisition artifacts."""
from __future__ import annotations

import copy
import hashlib
import os
from pathlib import Path, PurePosixPath
from typing import Any


def sha256_file(path: str | os.PathLike[str]) -> str | None:
    try:
        digest = hashlib.sha256()
        with open(path, "rb") as stream:
            for chunk in iter(lambda: stream.read(1 << 16), b""):
                digest.update(chunk)
        return digest.hexdigest()
    except (OSError, IsADirectoryError):
        return None


def resolve_path(reference: str | None, artifact_file: str | os.PathLike[str]) -> str | None:
    """Resolve a path recorded by an artifact; retain compatibility with old absolute records."""
    if not reference or reference.startswith("external:"):
        return None
    if os.path.isabs(reference):
        return os.path.abspath(reference)
    return os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(artifact_file)), reference))


class PathSerializer:
    """Rebase path-valued fields to the directory containing one output artifact."""

    PATH_LIST_KEYS = {"files", "paths", "merged_from_pages", "source_files"}

    def __init__(self, artifact_file: str | os.PathLike[str]):
        self.artifact_file = os.path.abspath(artifact_file)
        self.base_dir = os.path.dirname(self.artifact_file)
        self.external_paths: dict[str, dict[str, str | None]] = {}

    @staticmethod
    def _is_file_path(value: str) -> bool:
        return os.path.isabs(value) and not value.startswith(("http://", "https://"))

    def reference(self, value: Any) -> Any:
        if not isinstance(value, str) or not value or value.startswith("external:"):
            return value
        if not os.path.isabs(value):
            return value.replace(os.sep, "/") if os.sep != "/" else value
        absolute = os.path.abspath(value)
        try:
            common = os.path.commonpath((self.base_dir, absolute))
        except ValueError:
            common = ""
        if common == self.base_dir:
            return PurePosixPath(os.path.relpath(absolute, self.base_dir)).as_posix()
        token = f"external:{os.path.basename(absolute) or 'unnamed'}"
        existing = self.external_paths.get(token)
        digest = sha256_file(absolute)
        if existing and existing.get("sha256") != digest:
            stem, suffix = os.path.splitext(token)
            token = f"{stem}-{(digest or 'missing')[:10]}{suffix}"
        self.external_paths[token] = {"sha256": digest}
        return token

    def _walk(self, value: Any, key: str | None = None) -> Any:
        if isinstance(value, dict):
            out = {}
            for child_key, child in value.items():
                if child_key == "skill":
                    continue
                if child_key in self.PATH_LIST_KEYS and isinstance(child, list):
                    out[child_key] = [self.reference(v) if isinstance(v, str) else self._walk(v)
                                      for v in child]
                elif (child_key in {"path", "recipe", "screenshot", "network_log", "aria_snapshot",
                                    "storage_state", "report_path", "csv_path", "table_path",
                                    "metadata_path", "preview_path", "handoff_path", "state",
                                    "resolved_path"}
                      or child_key.endswith("_path")) and isinstance(child, str):
                    out[child_key] = self.reference(child)
                elif child_key in {"table", "metadata", "report", "state", "preview", "handoff_table"} \
                        and isinstance(child, str) and os.path.isabs(child):
                    out[child_key] = self.reference(child)
                elif child_key == "source" and isinstance(child, str) and self._is_file_path(child):
                    out[child_key] = self.reference(child)
                else:
                    out[child_key] = self._walk(child, child_key)
            return out
        if isinstance(value, list):
            return [self._walk(item) for item in value]
        return value

    def portable(self, value: dict[str, Any], *, stdout: bool = False) -> dict[str, Any]:
        out = self._walk(copy.deepcopy(value))
        out["paths_relative_to"] = "not_applicable (stdout)" if stdout else "this file's directory"
        if self.external_paths:
            out["external_paths"] = self.external_paths
        return out


def portable_payload(value: dict[str, Any], artifact_file: str | os.PathLike[str]) -> dict[str, Any]:
    return PathSerializer(artifact_file).portable(value)


def dump_json(value: dict[str, Any], artifact_file: str | os.PathLike[str], *, indent: int = 2) -> None:
    import json

    path = os.path.abspath(artifact_file)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    payload = portable_payload(value, path)
    with open(path, "w", encoding="utf-8") as stream:
        json.dump(payload, stream, ensure_ascii=False, indent=indent, default=str)
