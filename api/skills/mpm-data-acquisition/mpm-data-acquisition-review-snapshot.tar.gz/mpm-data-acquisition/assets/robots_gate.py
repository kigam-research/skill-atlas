"""Scoped user consent and advisory robots observations.

Only reuse authorization recorded for the current user, task and reviewed paths.
Robots is not authentication, a connectivity probe, or a mandatory per-run network
dependency. Do not invent consent or treat a review-required legacy record as valid approval.
Observed states: present, absent, html_shell, error; not_checked means no request.
"""
from __future__ import annotations

import hashlib
import json
import ntpath
import os
import urllib.error
import urllib.request
import urllib.robotparser
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from typing import Iterable
from urllib.parse import urlsplit, urlunsplit

import artifact_paths

DEFAULT_USER_AGENT = "geoscience-data-fetch/0.2 (research script; Python urllib)"
MAX_ROBOTS_BYTES = 512 * 1024


@dataclass
class RobotsResult:
    host: str
    robots_url: str
    state: str
    http_status: int | None
    content_type: str | None
    text: str
    sha256: str
    note: str = ""
    fetched_at: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


def host_of(url: str) -> str:
    host = urlsplit(url).hostname
    if not host:
        raise ValueError(f"host를 알 수 없는 URL: {url!r}")
    return host.lower()


def robots_url_for(url: str) -> str:
    parts = urlsplit(url)
    scheme = parts.scheme or "https"
    return urlunsplit((scheme, parts.netloc, "/robots.txt", "", ""))


def classify_robots_response(status: int | None, content_type: str | None, body: str) -> str:
    if status is None:
        return "error"
    if status in (404, 410):
        return "absent"
    if status >= 400:
        return "error"
    ctype = (content_type or "").lower()
    stripped = body.lstrip()[:200].lower()
    if "html" in ctype or stripped.startswith("<!doctype") or stripped.startswith("<html") or stripped.startswith("<"):
        return "html_shell"
    return "present"


def _sha256(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8", errors="replace")).hexdigest()


def fetch_robots(url: str, user_agent: str = DEFAULT_USER_AGENT, timeout: float = 20.0,
                 opener: urllib.request.OpenerDirector | None = None) -> RobotsResult:
    """대상 URL의 host에서 robots.txt를 1회 읽는다. 프록시/CA는 환경 설정을 따른다."""
    host = host_of(url)
    robots_url = robots_url_for(url)
    opener = opener or urllib.request.build_opener()
    req = urllib.request.Request(robots_url, headers={"User-Agent": user_agent, "Accept": "text/plain,*/*;q=0.5"})
    status: int | None = None
    ctype: str | None = None
    body = ""
    note = ""
    try:
        with opener.open(req, timeout=timeout) as resp:
            status = resp.status
            ctype = resp.headers.get("Content-Type")
            raw = resp.read(MAX_ROBOTS_BYTES + 1)
            if len(raw) > MAX_ROBOTS_BYTES:
                note = f"본문이 {MAX_ROBOTS_BYTES} bytes를 넘어 잘렸다"
                raw = raw[:MAX_ROBOTS_BYTES]
            body = raw.decode("utf-8", errors="replace")
    except urllib.error.HTTPError as exc:
        status = exc.code
        ctype = exc.headers.get("Content-Type") if exc.headers else None
        try:
            body = exc.read(MAX_ROBOTS_BYTES).decode("utf-8", errors="replace")
        except Exception:  # pragma: no cover - 방어적
            body = ""
        note = f"HTTPError {exc.code}"
    except Exception as exc:  # URLError, timeout, ssl
        note = f"{type(exc).__name__}: {str(exc)[:200]}"
    state = classify_robots_response(status, ctype, body)
    if state == "html_shell":
        note = (note + "; " if note else "") + "200/HTML 응답: SPA catch-all로 보이며 robots 규칙이 없다고 본다"
    return RobotsResult(host=host, robots_url=robots_url, state=state, http_status=status,
                        content_type=ctype, text=body if state == "present" else body[:2000],
                        sha256=_sha256(body), note=note,
                        fetched_at=datetime.now(timezone.utc).isoformat(timespec="seconds"))


def _parser(result: RobotsResult) -> urllib.robotparser.RobotFileParser | None:
    if result.state != "present":
        return None
    rp = urllib.robotparser.RobotFileParser()
    rp.parse(result.text.splitlines())
    return rp


def evaluate_paths(result: RobotsResult, paths: Iterable[str], user_agent: str = DEFAULT_USER_AGENT) -> dict[str, bool | None]:
    """경로별 허용 여부. 규칙이 없으면(absent/html_shell/error) None."""
    rp = _parser(result)
    out: dict[str, bool | None] = {}
    for path in paths:
        if not path.startswith("/"):
            path = "/" + path
        out[path] = None if rp is None else rp.can_fetch(user_agent, f"https://{result.host}{path}")
    return out


def crawl_delay(result: RobotsResult, user_agent: str = DEFAULT_USER_AGENT) -> float | None:
    rp = _parser(result)
    if rp is None:
        return None
    try:
        delay = rp.crawl_delay(user_agent)
    except Exception:  # pragma: no cover
        return None
    return float(delay) if delay is not None else None


def summarize(result: RobotsResult, paths: Iterable[str] = (), user_agent: str = DEFAULT_USER_AGENT,
              max_lines: int = 25) -> str:
    """사용자 승인 요청에 그대로 보여 줄 요약. 판정하지 않고 사실을 나열한다."""
    lines = [
        f"host: {result.host}",
        f"robots.txt: {result.robots_url}",
        f"state: {result.state} (HTTP {result.http_status}, {result.content_type})",
    ]
    if result.note:
        lines.append(f"note: {result.note}")
    if result.state == "present":
        body = result.text.splitlines()
        lines.append(f"--- robots.txt 첫 {min(len(body), max_lines)}/{len(body)}줄 ---")
        lines.extend(body[:max_lines])
        delay = crawl_delay(result, user_agent)
        if delay is not None:
            lines.append(f"Crawl-delay for {user_agent!r}: {delay}s")
    verdicts = evaluate_paths(result, paths, user_agent)
    if verdicts:
        lines.append("--- 요청 경로 판정 ---")
        for path, allowed in verdicts.items():
            label = ("미확인" if result.state in {"error", "not_checked"} else "규칙 없음") if allowed is None else ("허용" if allowed else "차단")
            lines.append(f"{path}: {label}")
    lines.append("현재 사용자의 현재 작업 범위와 요청 경로에 대한 명시적 승인이 필요하다.")
    return "\n".join(lines)


class ApprovalRequired(RuntimeError):
    """승인 기록이 없는 host. 메시지에 사용자에게 보여 줄 요약이 들어 있다."""

    def __init__(self, host: str, summary: str):
        super().__init__(f"{host}: 사용자 승인이 필요하다\n{summary}")
        self.host = host
        self.summary = summary


class ConsentLedger:
    """host별 승인 원장(JSON). 현재 사용자·작업 범위·검토 경로만 승인으로 취급한다."""

    def __init__(self, path: str | os.PathLike):
        self.path = str(path)
        self._data: dict = {"schema_version": 1, "hosts": {}}
        if os.path.exists(self.path):
            with open(self.path, encoding="utf-8") as fh:
                loaded = json.load(fh)
            if not isinstance(loaded, dict) or "hosts" not in loaded:
                raise ValueError(f"원장 형식이 아니다: {self.path}")
            self._data = loaded

    def save(self) -> None:
        os.makedirs(os.path.dirname(os.path.abspath(self.path)), exist_ok=True)
        tmp = self.path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(artifact_paths.portable_payload(self._data, self.path), fh, ensure_ascii=False, indent=2)
        os.replace(tmp, self.path)

    def get(self, host: str) -> dict | None:
        return self._data["hosts"].get(host.lower())

    def status(self, host: str, result: RobotsResult | None = None) -> str:
        """'missing' | 'approved' | 'approved_changed'(승인 후 robots 내용이 바뀜)."""
        rec = self.get(host)
        if self._data.get("review_required") or (rec or {}).get("review_required"):
            return "review_required"
        if rec is None:
            return "missing"
        if result is not None and rec.get("robots_sha256") not in (None, result.sha256):
            return "approved_changed"
        return "approved"

    def disallowed_paths(self, host: str, result: RobotsResult, paths: Iterable[str]) -> list[str]:
        """A timeout must not erase previously observed restrictions."""
        paths = list(paths)
        previous = self.get(host) or {}
        if result.state in {"error", "not_checked"} and previous.get("last_present_robots"):
            result = RobotsResult(**previous["last_present_robots"])
        current = {p for p, ok in evaluate_paths(result, paths).items() if ok is False}
        if result.state in {"error", "not_checked"}:
            current.update(previous.get("robots_disallowed_paths", []))
        return sorted(current)

    def record(self, host: str, result: RobotsResult, approved_by: str, note: str = "",
               paths: Iterable[str] = (), evidence: str = "", *,
               approval_scope: str = "",
               approve_disallowed: bool = False, approve_unreadable: bool = False) -> dict:
        """사용자 승인 기록. 범위 생략 시 중립적인 workspace-task 기본값을 저장한다."""
        if not approved_by or approved_by.strip().lower() in {"agent", "auto", "code", "claude"}:
            raise ValueError("approved_by는 사용자를 가리켜야 한다. 코드나 에이전트가 승인을 대신하지 않는다.")
        approval_scope = (approval_scope or "current workspace task").strip() or "current workspace task"
        if os.path.isabs(approval_scope) or ntpath.isabs(approval_scope) or approval_scope.startswith(("\\\\", "//")):
            raise ValueError("approval_scope에는 절대 경로를 사용할 수 없다.")
        paths = list(paths)
        disallowed = self.disallowed_paths(host, result, paths)
        if self.status(host) == "review_required":
            raise ApprovalRequired(host, "review_required 원장은 증거로 보존하고, 사용자 결정 후 새 workspace에서 승인한다.")
        previous = self.get(host) or {}
        rec = {
            "host": host.lower(),
            "approved_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "approved_by": approved_by.strip(),
            "approval_scope": approval_scope,
            "evidence": evidence,
            "note": note,
            "authorization_policy": "user-approval-scoped-to-current-user-task-and-paths; robots advisory",
            "robots_state": result.state,
            "robots_http_status": result.http_status,
            "robots_sha256": result.sha256,
            "robots_url": result.robots_url,
            "paths_reviewed": list(paths),
            "robots_disallowed_paths": disallowed,
            "approve_disallowed": bool(approve_disallowed),
            "approve_unreadable": bool(approve_unreadable),
            "last_present_robots": result.to_dict() if result.state == "present" else previous.get("last_present_robots"),
        }
        if previous:
            self._data.setdefault("superseded_records", []).append(previous)
        self._data["hosts"][host.lower()] = rec
        self.save()
        return rec

    def require(self, host: str, result: RobotsResult | None = None, paths: Iterable[str] = (),
                user_agent: str = DEFAULT_USER_AGENT, *, approval_scope: str | None = None,
                approved_by: str | None = None) -> dict:
        """Workspace 기록을 재사용하고, 호출자가 밝힌 사용자·작업 범위가 다르면 거부한다."""
        state = self.status(host, result)
        paths = list(paths)
        rec = dict(self.get(host) or {})
        if state in {"missing", "review_required"}:
            summary = summarize(result, paths, user_agent) if result else "이 host에 대한 유효한 사용자 승인 기록이 없다."
            raise ApprovalRequired(host, summary)
        approval_scope = (approval_scope or "").strip()
        approved_by = (approved_by or "").strip()
        if approval_scope and rec.get("approval_scope") != approval_scope:
            raise ApprovalRequired(host, "승인 기록의 작업 범위가 현재 요청과 다르다.")
        if approved_by and rec.get("approved_by", "").casefold() != approved_by.casefold():
            raise ApprovalRequired(host, "승인 기록의 사용자가 현재 요청과 다르다.")
        def covers(approved: str, requested: str) -> bool:
            approved = "/" + approved.lstrip("/")
            requested = "/" + requested.lstrip("/")
            return approved == "/" or requested == approved or requested.startswith(approved.rstrip("/") + "/")
        reviewed = rec.get("paths_reviewed", [])
        if any(not any(covers(approved, requested) for approved in reviewed) for requested in paths):
            raise ApprovalRequired(host, "현재 요청 경로가 승인 당시 검토한 경로 범위 밖이다.")
        rec["status"] = state
        if state == "approved_changed":
            rec["warning"] = "robots 관측이 달라졌다. 사용자 승인은 유지하며 이 사실만 기록한다."
        return rec


def cached_observation(workspace: str, url: str) -> RobotsResult:
    """No network: keep an existing observation, or explicitly record not checked."""
    path = os.path.join(workspace, "recon", host_of(url), "robots.result.json")
    if os.path.exists(path):
        with open(path, encoding="utf-8") as fh:
            saved = json.load(fh)
        fields = RobotsResult.__dataclass_fields__
        result = RobotsResult(**{key: value for key, value in saved.items() if key in fields})
        if result.host != host_of(url):
            raise ValueError("cached robots host mismatch")
        return result
    return RobotsResult(host_of(url), robots_url_for(url), "not_checked", None, None, "", "",
                        note="User authorization does not require a robots request.")
