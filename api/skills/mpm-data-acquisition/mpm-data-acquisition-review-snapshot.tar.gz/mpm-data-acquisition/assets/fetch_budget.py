"""요청 속도·총량·시간·연속 실패 상한 — 상대 서버 부담을 사람 한 명 수준 이하로 유지한다.

선택형 뼈대다. 수집 코드는 모든 네트워크 호출 전에 `wait()`를, 성공 후 `success()`를,
실패 후 `failure(status)`를 호출한다. 429/503이 반복되면 상대가 거절하고 있다는 뜻이므로
더 기다리지 않고 `BudgetExceeded`로 멈춘다. 참조 web-crawler `scripts/utils.py`의
RateLimiter 개념을 다시 작성했다(references/source-map.md).
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Callable


class BudgetExceeded(RuntimeError):
    """총량 또는 연속 실패 상한 도달. 호출자는 수집을 멈추고 상태를 저장한다."""


@dataclass
class FetchBudget:
    delay: float = 1.0
    min_delay: float = 0.5
    max_requests: int | None = None
    max_seconds: float | None = None
    max_consecutive_errors: int = 3
    clock: Callable[[], float] = time.monotonic
    sleeper: Callable[[float], None] = time.sleep
    request_count: int = 0
    consecutive_errors: int = 0
    backoff_events: int = 0
    _last: float = field(default=float("-inf"), init=False, repr=False)
    _started: float | None = field(default=None, init=False, repr=False)
    _stopped: str | None = field(default=None, init=False, repr=False)

    def __post_init__(self) -> None:
        self.min_delay = max(float(self.min_delay), 0.0)
        self.delay = max(float(self.delay), self.min_delay)

    def remaining(self) -> int | None:
        if self.max_requests is None:
            return None
        return max(self.max_requests - self.request_count, 0)

    def wait(self) -> None:
        """다음 요청 전 호출. 상한에 닿았으면 요청을 보내지 않고 예외를 낸다."""
        if self._stopped:
            raise BudgetExceeded(self._stopped)
        if self.max_requests is not None and self.request_count >= self.max_requests:
            raise BudgetExceeded(
                f"총 요청 상한 {self.max_requests}건에 도달했다. 필요한 만큼만 받는 것이 원칙이며, "
                "정말 더 필요하면 max_requests를 명시적으로 올리고 이유를 기록한다."
            )
        if self._started is None:
            self._started = self.clock()
        if self.max_seconds is not None and self.clock() - self._started >= self.max_seconds:
            raise BudgetExceeded(
                f"작업 시간 상한 {self.max_seconds}초에 도달했다. 받은 결과와 남은 항목을 기록하고 멈춘다."
            )
        elapsed = self.clock() - self._last
        if elapsed < self.delay:
            self.sleeper(self.delay - elapsed)
        self._last = self.clock()
        self.request_count += 1

    def success(self) -> None:
        self.consecutive_errors = 0

    def failure(self, status: int | None = None) -> None:
        """실패 기록. 429/503은 대기 시간을 두 배로 늘린다. 연속 상한을 넘으면 중단."""
        self.consecutive_errors += 1
        if status in (429, 503):
            self.delay *= 2
            self.backoff_events += 1
        if self.consecutive_errors >= self.max_consecutive_errors:
            self._stopped = (
                f"연속 {self.consecutive_errors}회 실패(마지막 status={status}). "
                "상대가 거절하고 있거나 경로가 잘못됐다. 재시도 대신 원인을 기록하고 멈춘다."
            )
            raise BudgetExceeded(self._stopped)

    def snapshot(self) -> dict:
        return {
            "request_count": self.request_count,
            "max_requests": self.max_requests,
            "max_seconds": self.max_seconds,
            "elapsed_s": None if self._started is None else round(self.clock() - self._started, 3),
            "delay_s": self.delay,
            "consecutive_errors": self.consecutive_errors,
            "backoff_events": self.backoff_events,
            "stopped_reason": self._stopped,
        }
