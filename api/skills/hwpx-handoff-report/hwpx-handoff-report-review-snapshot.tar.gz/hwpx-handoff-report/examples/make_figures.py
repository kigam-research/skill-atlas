"""Figures of the example report, drawn at print size (6.5 in body width, 400 dpi) from the synthetic data.

    REPORT_FONT=/path/NanumGothic.ttf uv run --no-project --with matplotlib python make_figures.py

Text is at least 8.5 pt at print size; the script fails if any text is smaller or runs outside the figure.
"""
import csv
import os
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib import font_manager  # noqa: E402

from facts import DATA, screening  # noqa: E402

HERE = Path(__file__).resolve().parent
WIDTH_IN = 6.5
DPI = 400
MIN_PT = 8.5


def use_korean_font():
    path = os.environ.get('REPORT_FONT')
    if not path:
        raise SystemExit('set REPORT_FONT to a Korean TTF (for example NanumGothic.ttf)')
    font_manager.fontManager.addfont(path)
    plt.rcParams['font.family'] = font_manager.FontProperties(fname=path).get_name()
    plt.rcParams['axes.unicode_minus'] = False


def check(fig):
    fig.canvas.draw()
    box = fig.bbox
    for text in fig.findobj(matplotlib.text.Text):
        if not text.get_visible() or not text.get_text().strip():
            continue
        if text.get_fontsize() < MIN_PT:
            raise SystemExit(f'text below {MIN_PT} pt: {text.get_text()!r}')
        extent = text.get_window_extent()
        if extent.x0 < box.x0 - 1 or extent.x1 > box.x1 + 1 or extent.y0 < box.y0 - 1 or extent.y1 > box.y1 + 1:
            raise SystemExit(f'text outside the figure: {text.get_text()!r}')


def save(fig, name):
    check(fig)
    fig.savefig(HERE / 'figures' / name, dpi=DPI, facecolor='white')
    plt.close(fig)


def main():
    use_korean_font()
    plt.rcParams.update({'font.size': 9.5, 'axes.spines.top': False, 'axes.spines.right': False})
    rows = list(csv.DictReader(DATA.open()))
    out_of_range, robust = screening(rows)
    colors = {'상류': '#2f6f9f', '중류': '#6a9f3f', '하류': '#c0613a'}

    fig, ax = plt.subplots(figsize=(WIDTH_IN, 2.9), layout='constrained')
    for site, color in colors.items():
        kept = [r for r in rows if r['지점'] == site and r not in out_of_range]
        ax.plot([int(r['월']) for r in kept], [float(r['용존산소_mg_L']) for r in kept], marker='o', ms=3.5,
                color=color, label=site)
    ax.set_xlabel('측정 월')
    ax.set_ylabel('용존산소(mg/L)')
    ax.set_xticks(range(1, 13))
    ax.legend(title='측정 지점', frameon=False, loc='upper center', ncols=3)
    ax.set_ylim(4, 13)
    ax.set_yticks(range(4, 13, 2))
    save(fig, 'monthly-do.png')

    fig, ax = plt.subplots(figsize=(WIDTH_IN, 1.6), layout='constrained')
    labels = ['물리적 범위 기준', '지점별 중앙값 기준']
    counts = [len(out_of_range), len(robust)]
    ax.barh(labels, counts, color=['#5b7fa6', '#a6795b'], height=0.5)
    for y, value in enumerate(counts):
        ax.text(value + 0.05, y, f'{value}건', va='center')
    ax.set_xlabel('이상값으로 판정된 기록 수(전체 36건)')
    ax.set_xlim(0, 3)
    ax.set_xticks(range(0, 4))
    ax.invert_yaxis()
    save(fig, 'evidence.png')


if __name__ == '__main__':
    main()
