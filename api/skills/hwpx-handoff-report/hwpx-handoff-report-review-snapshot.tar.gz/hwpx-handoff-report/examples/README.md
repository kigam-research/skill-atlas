# 예시: 일반 연구보고서 양식

스킬의 전체 흐름을 보여 주는 **합성 예시**다. 자료(`measurements.csv`)는 형식 설명을 위해 만든 값이며 실제 조사 결과가 아니다.

| 파일 | 내용 |
|---|---|
| `report.json` | 보고서 설정(양식 `research-report`, 원고·초안·정본 경로) |
| `content/` | 원고 `10-overview.md`, `20-method.md`, `30-results.md`, 양식 칸 `form.json`(제목) |
| `facts.py` | 원고의 `{{이름}}` 수치를 자료 파일에서 계산 |
| `make_figures.py` | 그림을 인쇄 크기(본문 폭 6.5 in, 400 dpi)로 그리고, 8.5 pt보다 작은 글자와 그림 밖으로 나간 글자를 검사 |
| `figures/` | 그림 PNG |
| `achievements.md` | 성과 목록(성과 표와 그림 계획 표). 초안 도구가 원고와 대조한다 |
| `page-check.md` | 쪽별 확인 기록. 렌더한 쪽 이미지를 보고 쪽마다 적었다 |
| `draft.json`, `draft.preview.md` | 원고로 만든 초안과 승인용 미리보기(성과 대응 점검, 렌더 점검 포함) |
| `report.hwpx`, `report.hwpx.preview.pdf`, `report-journal.jsonl`, `drafts/` | `canonical.py regenerate`로 만든 보고서, rhwp 미리보기, 생성 기록(초안 경로·sha256 포함), 생성에 쓴 초안 사본 |

다시 만들기(스킬 폴더에서):

```bash
REPORT_FONT=<한글 TTF> uv run --no-project --with matplotlib python examples/make_figures.py
python3 tools/build_report.py --config examples/report.json --root examples --render /tmp/example-render
python3 tools/canonical.py regenerate --config examples/report.json --root examples   # rhwp CLI 필요
```

- 한컴오피스 표시는 확인하지 않았다(`references/process.md` 5절).
- 웹 검토실 시험은 `report.hwpx`를 기존 보고서 업로드 예시로, `figures/evidence.png`를 그림 예시로 쓴다.
