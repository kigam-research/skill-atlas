# 결과
> src: measurements.csv; facts.py; figures/evidence.png; figures/monthly-do.png

## 이상값 판정 결과
◯ 물리적 범위 기준으로는 {{n_out_of_range}}건, 지점별 중앙값 기준으로는 {{n_robust}}건이 이상값으로 판정되었음.
- 두 기준이 함께 잡아낸 기록은 용존산소가 범위를 크게 벗어난 1건이었으며, 탁도가 0으로 기록된 1건은 물리적 범위 기준만 잡아냈음
![이상값 판정 기준별로 이상값으로 판정된 기록 수](figures/evidence.png){cols=1}

## 지점별 계절 변화
◯ 물리적 범위 기준의 이상값을 뺀 자료에서 용존산소는 여름에 낮고 겨울에 높은 계절 변화를 보였으며, 연평균은 상류
  {{do_upstream}} mg/L, 하류 {{do_downstream}} mg/L로 하류로 갈수록 낮았음.
![지점별 월별 용존산소. 물리적 범위 기준으로 이상값으로 판정된 기록은 빼고 그렸음](figures/monthly-do.png){cols=1}
◯ 이 결과는 한 하천의 1년 자료에 대한 것이며, 두 기준의 차이가 다른 하천에서도 같은지는 확인하지 않았음.

# 향후 계획
> src: measurements.csv
◯ 다른 하천의 측정망 자료에 같은 두 기준을 적용하여 판정 결과의 차이가 반복되는지 확인할 계획임.
