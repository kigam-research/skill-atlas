# 연구보고서 초안 미리보기 (승인 전)

- 초안: [`draft.json`](draft.json), 양식 `research-report`, block 25개, 그림 2개, 표 1개. 원고는 `content`.
- 상태: **사용자 승인 전.** 승인 전에는 정본 HWPX(`report.hwpx`)를 만들지 않는다.

## 자동 점검

작업 기록 어휘·내부 표기·영문 약어·도구와 모델 이름은 후보다. 문맥상 필요한 것은 남기고 나머지는 고친다.

- 본문 표현 후보 없음

- 근거 경로 문제 없음

## 성과 대응 점검

- 성과 목록 `achievements.md`: 넣을 성과 6개, 뺀 성과 0개, 그림 계획 2개.
- 성과 목록의 성과·핵심 수치·그림이 모두 원고에 있음

## 렌더 점검

- 2쪽(양식 포함). 쪽 끝 고립·공백·그림 축소 후보 없음.

## 양식 칸

엔진이 초안의 `form`으로 양식의 칸을 채운다(비어 있을 때만).

**제목**: 소하천 수질 측정 자료의 이상값 판정 기준 비교 (합성 예시)

## 본문(엔진이 붙이는 번호 포함)

### 가. 연구 개요

#### 1) 연구 배경과 목표

◯ 소하천의 용존산소와 탁도는 수질 변화를 가장 먼저 보여 주는 지표이나, 측정망 자료에는 기록 오류가 섞여 있어 이상값을 먼저 걸러야 계절 변화와 지점 차이를 해석할 수 있음. <sub>[3]</sub>

&nbsp;&nbsp;- 기록 오류는 장비 고장이나 단위 착오로 생기며, 걸러내지 않으면 월평균과 지점 비교가 왜곡됨 <sub>[4]</sub>

◯ 이에 한 하천의 3개 지점에서 1년간 측정한 자료를 정리하고, 이상값을 판정하는 두 기준의 결과를 비교하였음. <sub>[5]</sub>

### 나. 자료와 방법

#### 1) 측정 자료

◯ 상류·중류·하류 3개 지점에서 매월 한 번 측정한 용존산소와 탁도 기록 36건을 사용하였음. <sub>[8]</sub>

&nbsp;&nbsp;- 용존산소는 물에 녹아 있는 산소의 농도(mg/L)이며, 탁도는 물이 흐린 정도(NTU)임 <sub>[9]</sub>

#### 2) 이상값 판정 기준

◯ 이상값은 서로 성격이 다른 두 기준으로 판정하였음. <sub>[11]</sub>

&nbsp;&nbsp;- 물리적 범위 기준은 용존산소가 0 이하이거나 15 mg/L를 넘는 기록과 탁도가 0 이하인 기록을 이상값으로 봄 <sub>[12]</sub>

&nbsp;&nbsp;- 지점별 중앙값 기준은 지점마다 용존산소 중앙값에서 벗어난 폭이 중앙값 절대편차에 1.4826(정규분포에서 표준편차와 같아지게 하는 계수)을 곱한 값의 3배를 넘는 기록을 이상값으로 봄 <sub>[13]</sub>

<p align="center">&lt;이상값 판정 기준의 비교&gt; <sub>[14]</sub></p>

| 기준 | 판정 방법 | 잡아내는 오류 |
|---|---|---|
| 물리적 범위 | 측정값이 가능한 범위를 벗어났는지 확인 | 장비 고장, 단위 착오 |
| 지점별 중앙값 | 같은 지점의 다른 달과 크게 다른지 확인 | 범위 안에 있는 기록 착오 |

### 다. 결과

#### 1) 이상값 판정 결과

◯ 물리적 범위 기준으로는 2건, 지점별 중앙값 기준으로는 1건이 이상값으로 판정되었음. <sub>[17]</sub>

&nbsp;&nbsp;- 두 기준이 함께 잡아낸 기록은 용존산소가 범위를 크게 벗어난 1건이었으며, 탁도가 0으로 기록된 1건은 물리적 범위 기준만 잡아냈음 <sub>[18]</sub>

`figures/evidence.png` 2600×640px, 400 dpi  
<img src="figures/evidence.png" width="560" alt="이상값 판정 기준별로 이상값으로 판정된 기록 수">
<p align="center">&lt;이상값 판정 기준별로 이상값으로 판정된 기록 수&gt; <sub>[19]</sub></p>

#### 2) 지점별 계절 변화

◯ 물리적 범위 기준의 이상값을 뺀 자료에서 용존산소는 여름에 낮고 겨울에 높은 계절 변화를 보였으며, 연평균은 상류 9.4 mg/L, 하류 7.0 mg/L로 하류로 갈수록 낮았음. <sub>[21]</sub>

`figures/monthly-do.png` 2600×1160px, 400 dpi  
<img src="figures/monthly-do.png" width="560" alt="지점별 월별 용존산소. 물리적 범위 기준으로 이상값으로">
<p align="center">&lt;지점별 월별 용존산소. 물리적 범위 기준으로 이상값으로 판정된 기록은 빼고 그렸음&gt; <sub>[22]</sub></p>

◯ 이 결과는 한 하천의 1년 자료에 대한 것이며, 두 기준의 차이가 다른 하천에서도 같은지는 확인하지 않았음. <sub>[23]</sub>

### 라. 향후 계획

◯ 다른 하천의 측정망 자료에 같은 두 기준을 적용하여 판정 결과의 차이가 반복되는지 확인할 계획임. <sub>[25]</sub>

## 근거 대응표

| block | 종류 | 근거 |
|---|---|---|
| 1 | heading1 | measurements.csv |
| 3 | statement | measurements.csv (제목에서 이어받음) |
| 4 | detail | measurements.csv (제목에서 이어받음) |
| 5 | statement | measurements.csv (제목에서 이어받음) |
| 6 | heading1 | measurements.csv; facts.py |
| 8 | statement | measurements.csv; facts.py (제목에서 이어받음) |
| 9 | detail | measurements.csv; facts.py (제목에서 이어받음) |
| 11 | statement | measurements.csv; facts.py (제목에서 이어받음) |
| 12 | detail | measurements.csv; facts.py (제목에서 이어받음) |
| 13 | detail | measurements.csv; facts.py (제목에서 이어받음) |
| 14 | table | measurements.csv; facts.py (제목에서 이어받음) |
| 15 | heading1 | measurements.csv; facts.py; figures/evidence.png; figures/monthly-do.png |
| 17 | statement | measurements.csv; facts.py; figures/evidence.png; figures/monthly-do.png (제목에서 이어받음) |
| 18 | detail | measurements.csv; facts.py; figures/evidence.png; figures/monthly-do.png (제목에서 이어받음) |
| 19 | figure_grid | measurements.csv; facts.py; figures/evidence.png; figures/monthly-do.png (제목에서 이어받음) |
| 21 | statement | measurements.csv; facts.py; figures/evidence.png; figures/monthly-do.png (제목에서 이어받음) |
| 22 | figure_grid | measurements.csv; facts.py; figures/evidence.png; figures/monthly-do.png (제목에서 이어받음) |
| 23 | statement | measurements.csv; facts.py; figures/evidence.png; figures/monthly-do.png (제목에서 이어받음) |
| 24 | heading1 | measurements.csv |
| 25 | statement | measurements.csv (제목에서 이어받음) |


<!-- build_report sha256:a557e22d90cbd55abc0a2e7876e847fd624bc7da3efc57850b95a3fd4aed4d57 -->
