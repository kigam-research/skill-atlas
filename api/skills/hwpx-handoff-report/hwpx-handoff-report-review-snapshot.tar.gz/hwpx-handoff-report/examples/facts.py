"""Numbers of the example report, computed from the synthetic data file (see README.md)."""
import csv
from pathlib import Path
from statistics import median

DATA = Path(__file__).resolve().parent / 'measurements.csv'


def screening(rows):
    """Records outside the physical range, and records farther than 3 x 1.4826 x MAD (median absolute deviation)
    from the site median (the text of 20-method.md states the same rule)."""
    out_of_range = [r for r in rows if not (0 < float(r['용존산소_mg_L']) <= 15) or float(r['탁도_NTU']) <= 0]
    robust = []
    for site in {r['지점'] for r in rows}:
        values = [float(r['용존산소_mg_L']) for r in rows if r['지점'] == site]
        m = median(values)
        mad = median(abs(v - m) for v in values)
        robust += [r for r in rows if r['지점'] == site and abs(float(r['용존산소_mg_L']) - m) > 3 * 1.4826 * mad]
    return out_of_range, robust


def facts():
    rows = list(csv.DictReader(DATA.open()))
    out_of_range, robust = screening(rows)
    sites = sorted({r['지점'] for r in rows})
    kept = [r for r in rows if r not in out_of_range]
    def mean_do(site):
        values = [float(r['용존산소_mg_L']) for r in kept if r['지점'] == site]
        return f'{sum(values) / len(values):.1f}'
    return {
        'n_records': len(rows),
        'n_sites': len(sites),
        'n_out_of_range': len(out_of_range),
        'n_robust': len(robust),
        'do_upstream': mean_do('상류'),
        'do_downstream': mean_do('하류'),
    }


if __name__ == '__main__':
    for key, value in facts().items():
        print(key, value)
