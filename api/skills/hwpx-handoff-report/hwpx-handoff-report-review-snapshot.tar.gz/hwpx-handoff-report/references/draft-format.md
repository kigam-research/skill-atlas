# 초안 JSON과 양식

엔진(`engine/append_report.mjs`)이 받는 초안의 형식이다. 원고 도구(`tools/build_report.py`)를 쓰면 원고에서 이 형식이 만들어진다. 직접 JSON을 쓸 때나 도구가 만든 초안을 확인할 때 본다.

## 1. 최상위

```json
{
  "session": { "date": "2026-09-29", "project": "과제-이름" },
  "template": "research-report",
  "form": { "title": "보고서 제목" },
  "blocks": [ … ]
}
```

| 키 | 뜻 |
|---|---|
| `session` | `date`(YYYY-MM-DD), `project`. journal에 남는다 |
| `template` | 선택. 새 보고서의 양식(`engine/forms/<id>`). 기본은 `research-report`다. 이어쓰기에서는 대상 문서의 양식을 자동으로 알아내며, 값을 주면 같아야 한다 |
| `form` | 선택. 양식의 칸을 채운다. 양식에 있는 칸만 쓸 수 있고, 칸이 비어 있을 때만 채운다(내용이 있으면 오류) |
| `blocks` | 본문 block 배열. 비어 있으면 안 된다 |

## 2. block

**체계는 두 가지이며 한 보고서 안에서 섞지 않는다.**

| 체계 | block | 캡션 |
|---|---|---|
| 연구보고서형(권장) | `heading1`(가.), `heading2`(1)), `heading3`((1)), `statement`(◯ 서술), `detail`(- 세부), `figure_grid`, `table` | 그림: `"captionStyle": "angle"`. 그림 아래 `<캡션>`, 번호 없음, 그림 표의 마지막 행에 들어감. 표: `table.caption`. 표 위 `<제목>` |
| 기본 실적서형 | `bullet1`(◎ 성과), `bullet2`(⚪ 사례), `bullet3`(상세 본문), `bullet4`(· 세부), `figure_grid`, `table` | 그림 아래 `그림 N. 설명`. 번호는 엔진이 매긴다 |

- **엔진이 붙이는 것:** 번호(가./1)/(1)), 마커(◎ ⚪ · ◯ -), `그림 N.`, 캡션의 `< >`. `text`·`caption`에 넣지 않는다. 손으로 번호를 붙인 제목은 거부된다.
- **제목:** 세 수준까지이고, `heading1`은 14개(가.–하.)까지다.
- **근거:** block마다 근거 경로를 `source`에 단다. 인쇄하지 않는다.

`figure_grid`
- `images`: project 기준 상대 경로의 PNG 1–6장. 2 MB, 4096 px 이하.
- `columns`: 1–3. **그림 수에 맞춰 명시한다**(엔진 기본값 2).
- `caption`, `captionStyle`(`number` | `angle`).

`table`
- `headers`(문자열 배열), `rows`(같은 길이의 문자열 배열들), `caption`(선택).
- `colWidthRatios`: 선택. 양수 배열이며 `headers`와 길이가 같고, 가장 큰 값과 작은 값의 차이는 20배 이내.
- `merges`: 선택. `[{row, col, rowSpan, colSpan}]`이며 row 0은 머리행이다. 병합에 가려지는 칸은 `""`로 둔다. 20개까지.

## 3. 양식

`node engine/append_report.mjs --list-forms`로 설치된 양식을 본다.

| 양식 | 본문 위치 | `form` 칸 |
|---|---|---|
| `research-report` | 제목 문단 다음부터 문서 끝까지 | `title` |
| `kigam-annual` | 기관 연차실적서의 "3-1 정성적 연구개발성과" 제목 다음부터 하단 요약표 앞까지 | `goals`(추진목표·달성내용·달성도, 행마다 3칸), `summary`(요약표, 행마다 4칸, 6행까지) |

- **알 수 없는 기존 문서:** 양식을 알 수 없는 HWPX에 이어 쓰면 `research-report` 방식으로 문서 끝에 이어 쓴다.
- **예전 문서:** 본문이 양식의 1×1 상자 안에 있는 예전 문서는 이어 쓰지 않고, 새 양식으로 다시 만들도록 오류를 낸다.

### 양식 추가

1. 기관 양식 HWPX에서 머리글(`Contents/header.xml`)은 그대로 두고 본문을 양식 부분만 남긴다. 그다음 `engine/forms/<id>/skeleton.hwpx`로 둔다.
   - 엔진은 기존 skeleton과 같은 스타일 번호(문단·글자 모양, 테두리)를 쓴다. 그러니 **다른 머리글을 가진 양식은 번호가 맞는지 먼저 확인한다**. 번호의 정의나 그것이 가리키는 글꼴·탭·테두리 정의가 다르면 엔진이 거부한다. 가장 쉬운 방법은 기존 skeleton에서 본문만 바꾸는 것이다.
2. `engine/forms/<id>/form.json`을 쓴다(`engine/lib/forms.js` 첫머리 설명). 아래는 기관 양식의 예다. 복사해 값을 바꾼다.

   ```json
   {
     "id": "my-institute",
     "name": "기관 성과보고서 2. 연구 내용",
     "description": "'2. 연구 내용' 제목 뒤, 하단 성과 표 앞에 본문을 쓴다.",
     "detect": ["연 구 목 표", "2. 연구 내용"],
     "body": {
       "startAfter": "2. 연구 내용",
       "end": { "table": { "rows": 5, "cols": 3, "header": ["구분", "내용", "비고"] } }
     },
     "tables": {
       "goals": { "header": "연 구 목 표", "columns": 3, "maxRows": 20, "align": ["left", "left", "center"],
                  "title": "연구목표·달성내용", "labels": ["연구목표", "달성내용", "달성도(%)"] },
       "summary": { "columns": 3, "maxRows": 4, "title": "하단 성과 표", "labels": ["구분", "내용", "비고"] }
     }
   }
   ```

   - `id`: 폴더 이름과 같아야 한다.
   - `detect`: 이 양식 문서에만 있는 문자열. 모두 있어야 이 양식으로 본다.
   - `body.startAfter`: 본문이 시작되는 제목 문자열. 이 문자열을 담은 첫 최상위 문단 다음부터 쓴다.
   - `body.end`: `"document"`(문서 끝까지) 또는 `{"table": {"rows", "cols", "header"}}`(본문 끝의 표. 행·열 수와 머리 문자열로 찾는다).
   - `title`: 제목 칸이 있는 양식만 쓴다. `{"paragraph": 0, "align": "center", "spacingAfter": 1000}`(`research-report` 참고).
   - `tables.goals`: 머리 문자열(`header`)로 찾는 목표 표. `tables.summary`: `body.end` 표를 채운다. `title`, `labels`는 미리보기용이다.
3. 엔진 시험을 더하고 새 양식으로 만든 보고서를 한컴에서 확인한다.
