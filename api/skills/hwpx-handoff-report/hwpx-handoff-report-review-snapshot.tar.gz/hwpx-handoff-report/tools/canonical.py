"""Canonical report file: full regeneration after approval, golden copy after the Hancom check, restore.

    python3 <skill>/tools/canonical.py regenerate --config docs/report/report.json [--expect-sha SHA]
    python3 <skill>/tools/canonical.py golden --config docs/report/report.json --confirmed "사용자 한컴 확인 2026-09-29"
    python3 <skill>/tools/canonical.py restore --config docs/report/report.json

regenerate  rebuilds the draft from the manuscript, keeps a copy of it as drafts/<name>-<UTC>.json and writes
            a new report from the form skeleton with the engine CLI (validation, rhwp verification, preview
            PDF) into a separate empty folder next to the target. Only when that succeeds, and the current
            target is still the file it found at the start (sha256, and --expect-sha if given), it backs the
            current target up to backup/<name>.bak-prerewrite-<UTC>.hwpx and moves the new report into place.
            A failed run changes nothing and keeps its folder (failed candidate, engine log) for diagnosis.
            If the report was replaced but the preview or journal step failed, it exits 5: do not run it
            again; make the preview with `rhwp export-pdf` and add the printed journal line by hand.
golden      after the user has checked the report in Hancom Office: finds the journal lines that built the
            current file (back to its creation, last rewrite or restore), checks that every draft they used
            is still available with the recorded sha256 (--draft adds places to look), and copies the report
            to <name>.golden-<UTC>.hwpx, its preview to <name>.golden-<UTC>.preview.pdf and the drafts to
            golden-draft-<name>-<UTC>[-NN].json (never overwritten). The report's own record
            <name>.golden.json, written last, lists each version, its drafts and who confirmed it.
restore     puts the last golden version back after checking its sha256 against the record (the current
            file is backed up first), restores its preview and adds a journal line; exit 5 if the report
            was replaced but the preview/journal step failed. Records of earlier versions in a shared
            golden.json are read when the report has no record of its own.

All three hold the target lock (<target>.lock) that the engine CLI uses, so they cannot run at the same
time as an engine append. The journal is report.json "journal", else report-journal.jsonl next to the target.
"""
import argparse
import datetime as dt
import hashlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

TOOLS = Path(__file__).resolve().parent
sys.path.insert(0, str(TOOLS))
import build_report as br  # noqa: E402

CLI = TOOLS.parent / 'engine' / 'append_report.mjs'
PARTIAL = 5  # the report was replaced but a later step failed (same meaning as the engine CLI's exit 5)


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def utc_stamp():
    return dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ')


def utc_now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


class Lock:
    """The engine's target lock (<target>.lock, {pid, utc}); an engine append waits on the same file."""

    def __init__(self, target):
        self.path = Path(f'{target}.lock')

    def __enter__(self):
        try:
            fd = os.open(self.path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        except FileExistsError:
            raise SystemExit(f'LockHeld: {self.path} exists (another append or regeneration is running, '
                             'or a stale lock needs a human to remove it)')
        with os.fdopen(fd, 'w') as f:
            json.dump({'pid': os.getpid(), 'utc': utc_now()}, f)
        return self

    def __exit__(self, *exc):
        self.path.unlink(missing_ok=True)


def copy_atomic(src, dst):
    """Copy through a temporary file in the destination folder, so dst is either old or complete."""
    dst = Path(dst)
    tmp = dst.with_name(f'.{dst.name}.{os.getpid()}.tmp')
    shutil.copy2(src, tmp)
    os.replace(tmp, dst)


def write_atomic(path, text):
    path = Path(path)
    tmp = path.with_name(f'.{path.name}.{os.getpid()}.tmp')
    tmp.write_text(text)
    os.replace(tmp, path)


def need_target(settings):
    if settings.target is None:
        raise SystemExit('the settings name no target')
    return settings.target


def journal_entries(settings):
    """This report's journal lines, oldest first. A line names its report by the project-relative path.
    Older engines wrote no name or only the file name; such lines are read as this report's only from the
    default journal next to the report, which no other report of that name can share."""
    path = settings.journal
    if not path or not path.exists():
        return []
    entries = [json.loads(line) for line in path.read_text().splitlines() if line.strip()]
    names = {settings.rel(settings.target)}
    if path.resolve() == (settings.target.parent / 'report-journal.jsonl').resolve():
        names |= {None, settings.target.name}
    return [e for e in entries if e.get('target') in names]


def append_journal(settings, entry):
    settings.journal.parent.mkdir(parents=True, exist_ok=True)
    with settings.journal.open('a') as f:
        f.write(json.dumps(entry, ensure_ascii=False) + '\n')


def preview_of(path):
    return Path(f'{path}.preview.pdf')


def golden_record(target):
    """Each report keeps its own golden record, so reports in one folder never write the same file."""
    return target.with_name(f'{target.stem}.golden.json')


def golden_history(settings):
    """This report's golden records, oldest first (the shared golden.json of earlier versions as fallback)."""
    record = golden_record(settings.target)
    if record.exists():
        return json.loads(record.read_text())
    legacy = settings.target.parent / 'golden.json'
    history = json.loads(legacy.read_text()) if legacy.exists() else []
    # records of that time name no report; they are this report's only when they point to its golden file
    own = settings.rel(settings.target.with_name(f'{settings.target.stem}.golden{settings.target.suffix}'))
    return [e for e in history if e.get('target') == settings.target.name
            or (e.get('target') is None and os.path.normpath(e.get('golden', '')) == own)]


def regenerate(settings, expect_sha=None, date=None, stamp=None):
    target = need_target(settings)
    stamp = stamp or utc_stamp()
    target.parent.mkdir(parents=True, exist_ok=True)
    with Lock(target):
        before = sha256(target) if target.exists() else None
        if expect_sha and before != expect_sha:
            raise SystemExit(f'the target is not the expected file (expected {expect_sha}, found {before})')
        if br.preview_intact(settings.preview) is False:
            raise SystemExit(f'{settings.rel(settings.preview)} was edited after build_report wrote it; the checks it '
                             'shows are no longer the tool\'s. Change the manuscript and build again')
        br.build(settings, date=date)
        snapshot = target.parent / 'drafts' / f'{target.stem}-{stamp}.json'
        snapshot.parent.mkdir(exist_ok=True)
        shutil.copy2(settings.draft, snapshot)
        work = target.parent / f'.regen-{stamp}'
        work.mkdir()
        candidate = work / target.name
        result = subprocess.run(['node', str(CLI), '--draft', str(snapshot), '--target', str(candidate),
                                 '--project-root', str(settings.root), '--journal', str(work / 'journal.jsonl')],
                                capture_output=True, text=True, env={**os.environ, 'HWPX_KEEP_FAILED': '1'})
        (work / 'engine.log').write_text(result.stdout + result.stderr)
        if result.returncode != 0:
            raise SystemExit(f'engine exit {result.returncode}; nothing replaced; see {work}\n{result.stderr.strip()}')
        now = sha256(target) if target.exists() else None
        if now != before:
            raise SystemExit(f'the target changed during the run; nothing replaced; the new report is in {work}')
        entry = json.loads((work / 'journal.jsonl').read_text().splitlines()[-1])
        entry.update({'target': settings.rel(target), 'rewrite': True, 'sha256Before': before})
        backup = None
        if before:
            backup = target.parent / 'backup' / f'{target.stem}.bak-prerewrite-{stamp}{target.suffix}'
            backup.parent.mkdir(exist_ok=True)
            shutil.copy2(target, backup)
        os.replace(candidate, target)
        # the report is replaced from here on: a failure must not look like "nothing changed"
        try:
            os.replace(preview_of(candidate), preview_of(target))
            append_journal(settings, entry)
            shutil.rmtree(work)
        except Exception as error:  # noqa: BLE001
            print(json.dumps({'ok': False, 'partial': True, 'target': settings.rel(target),
                              'sha256': entry['sha256After'], 'error': f'{type(error).__name__}: {error}',
                              'journalLine': entry, 'work': settings.rel(work)}, ensure_ascii=False))
            print(f'the report was replaced but the preview/journal step failed ({error}); do not run regenerate '
                  f'again; make the preview with rhwp export-pdf and add journalLine to {settings.journal}',
                  file=sys.stderr)
            raise SystemExit(PARTIAL)
        summary = {'ok': True, 'target': settings.rel(target), 'sha256': entry['sha256After'], 'replaced': before,
                   'backup': settings.rel(backup) if backup else None, 'draft': settings.rel(snapshot),
                   'layout': json.loads(result.stdout.strip().splitlines()[-1]).get('layout')}
        print(json.dumps(summary, ensure_ascii=False))
        return summary


def build_history(settings, current):
    """The journal lines that built the current file, oldest first, back to its creation, rewrite or restore."""
    entries = journal_entries(settings)
    if not entries or entries[-1].get('sha256After') != current:
        raise SystemExit('the report is not the last file the journal recorded for it (changed outside the '
                         'engine, or recorded by an older engine in a shared journal without the report path); '
                         'regenerate the report once to start a history this version can read')
    index = len(entries) - 1
    chain = [entries[index]]
    while True:
        entry = chain[0]
        if entry.get('rewrite') or entry.get('restore'):
            return chain
        if 'sha256Before' not in entry or 'draftSha256' not in entry:
            raise SystemExit('a journal line that built this report predates draft recording; regenerate the '
                             'report once with this skill version before making a golden copy')
        if entry['sha256Before'] is None:
            return chain
        index = next((i for i in range(index - 1, -1, -1)
                      if entries[i].get('sha256After') == entry['sha256Before']), None)
        if index is None:
            raise SystemExit(f"the journal has no line that made {entry['sha256Before']}, the file this report "
                             'was appended to; the history is incomplete')
        chain.insert(0, entries[index])


def history_drafts(settings, chain, extra):
    """(path, sha256) of every draft the chain used, found by sha among the recorded paths and extra files."""
    extra_by_sha = {sha256(p): Path(p) for p in extra}
    drafts, missing = [], []
    for entry in chain:
        wanted = entry.get('drafts') if entry.get('restore') else [
            {'path': entry.get('draft'), 'sha256': entry['draftSha256']}]
        for item in wanted or []:
            path = settings.root / item['path'] if item.get('path') else None
            if path and path.exists() and sha256(path) == item['sha256']:
                drafts.append((path, item['sha256']))
            elif item['sha256'] in extra_by_sha:
                drafts.append((extra_by_sha[item['sha256']], item['sha256']))
            else:
                missing.append(f"{item.get('path')} (sha256 {item['sha256']})")
    if missing:
        raise SystemExit('the drafts that made this report are not available as recorded: ' + '; '.join(missing)
                         + '. Pass the original files with --draft, or regenerate the report')
    return drafts


def golden(settings, confirmed, drafts=(), stamp=None):
    """Keep the confirmed report, its preview and its drafts as files of their own (never overwritten);
    the report's golden record points to them and is written last, so a failed run leaves the previous
    golden version intact."""
    target = need_target(settings)
    if not confirmed or not confirmed.strip():
        raise SystemExit('--confirmed is required: say who checked the report in Hancom Office and when')
    stamp = stamp or utc_stamp()
    with Lock(target):
        current = sha256(target)
        found = history_drafts(settings, build_history(settings, current), drafts)
        preview = preview_of(target)
        plan = [(target, target.with_name(f'{target.stem}.golden-{stamp}{target.suffix}'))]
        if preview.exists():
            plan.append((preview, target.with_name(f'{target.stem}.golden-{stamp}.preview.pdf')))
        for n, (path, _) in enumerate(found, 1):
            suffix = f'-{n:02d}' if len(found) > 1 else ''
            plan.append((path, target.parent / f'golden-draft-{target.stem}-{stamp}{suffix}.json'))
        taken = [str(dst) for _, dst in plan if dst.exists()]
        if taken:
            raise SystemExit(f'golden files are not overwritten: {", ".join(taken)} exist')
        written = []
        try:
            for src, dst in plan:
                copy_atomic(src, dst)
                written.append(dst)
            copies = [{'path': settings.rel(dst), 'sha256': digest}
                      for (_, dst), (_, digest) in zip(plan[-len(found):], found)]
            entry = {'utc': utc_now(), 'confirmed': confirmed.strip(), 'target': target.name,
                     'golden': settings.rel(plan[0][1]), 'sha256': current,
                     'preview': settings.rel(plan[1][1]) if preview.exists() else None, 'drafts': copies}
            history = golden_history(settings)
            write_atomic(golden_record(target), json.dumps(history + [entry], ensure_ascii=False, indent=1) + '\n')
        except BaseException:
            for path in written:
                path.unlink(missing_ok=True)
            raise
    print(json.dumps(entry, ensure_ascii=False))
    return entry


def restore(settings, stamp=None):
    """Put the last golden version back. Everything is read and checked under the target lock."""
    target = need_target(settings)
    stamp = stamp or utc_stamp()
    with Lock(target):
        records = golden_history(settings)
        if not records:
            raise SystemExit(f'no golden record for {target.name}')
        last = records[-1]
        golden_file = settings.root / last['golden']
        if not golden_file.exists() or sha256(golden_file) != last['sha256']:
            raise SystemExit(f'{golden_file} is missing or not the file the golden record names '
                             f'({last["sha256"]}); not restoring')
        golden_preview = settings.root / last['preview'] if last.get('preview') else None
        drafts = last.get('drafts') or ([{'path': last['draft'], 'sha256': last['draftSha256']}]
                                        if last.get('draft') else [])
        before = sha256(target) if target.exists() else None
        if before:
            backup = target.parent / 'backup' / f'{target.stem}.bak-restore-{stamp}{target.suffix}'
            backup.parent.mkdir(exist_ok=True)
            shutil.copy2(target, backup)
        entry = {'utc': utc_now(), 'project': settings.project, 'target': settings.rel(target), 'restore': True,
                 'from': last['golden'], 'sha256Before': before, 'sha256After': last['sha256'], 'drafts': drafts}
        copy_atomic(golden_file, target)
        # the report is replaced from here on: a failure must not look like "nothing changed"
        preview = preview_of(target)
        try:
            if golden_preview and golden_preview.exists():
                copy_atomic(golden_preview, preview)
            else:
                preview.unlink(missing_ok=True)  # a stale preview of the replaced file would mislead
            append_journal(settings, entry)
        except Exception as error:  # noqa: BLE001
            print(json.dumps({'ok': False, 'partial': True, 'target': settings.rel(target), 'sha256': last['sha256'],
                              'error': f'{type(error).__name__}: {error}', 'journalLine': entry}, ensure_ascii=False))
            print(f'the report was restored but the preview/journal step failed ({error}); add journalLine to '
                  f'{settings.journal} and check the preview', file=sys.stderr)
            raise SystemExit(PARTIAL)
    summary = {'ok': True, 'restored': last['golden'], 'sha256': last['sha256'],
               'preview': settings.rel(preview) if preview.exists() else None}
    print(json.dumps(summary, ensure_ascii=False))
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument('command', choices=['regenerate', 'golden', 'restore'])
    parser.add_argument('--config', type=Path, required=True)
    parser.add_argument('--root', type=Path)
    parser.add_argument('--expect-sha', help='regenerate: sha256 the current target must have')
    parser.add_argument('--confirmed', help='golden: who checked the report in Hancom Office, and when')
    parser.add_argument('--draft', action='append', default=[], type=Path,
                        help='golden: a draft file that made the report, if it is no longer where the journal says')
    parser.add_argument('--date', help='regenerate: draft date; default today')
    args = parser.parse_args()
    settings = br.Settings(args.config, args.root)
    if args.command == 'regenerate':
        regenerate(settings, args.expect_sha, args.date)
    elif args.command == 'golden':
        golden(settings, args.confirmed, args.draft)
    else:
        restore(settings)


if __name__ == '__main__':
    main()
