// Pre-approval layout preview: build a candidate HWPX from a draft with the engine library (no rhwp
// CLI) and render every page to SVG with @rhwp/core. The candidate starts from the draft's form
// skeleton, or from REPORT_BASE (an existing report the draft continues). It is a scratch file in
// <outDir>, never the report itself.
//
//   node <skill>/tools/render_preview.mjs <draft.json> <projectRoot> <outDir>
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const ENGINE = join(dirname(fileURLToPath(import.meta.url)), '../engine');
const { appendBlocks } = await import(join(ENGINE, 'lib/engine.js'));
const { validateDraft } = await import(join(ENGINE, 'lib/validate.js'));
const { DEFAULT_FORM, getForm } = await import(join(ENGINE, 'lib/forms.js'));
const core = await import(join(ENGINE, 'node_modules/@rhwp/core/rhwp.js'));

const [draftPath, projectRoot, outDir] = process.argv.slice(2);
if (!outDir) {
  console.error('usage: render_preview.mjs <draft.json> <projectRoot> <outDir>');
  process.exit(64);
}
const draft = JSON.parse(readFileSync(draftPath, 'utf8'));
const v = validateDraft(draft, projectRoot);
if (!v.ok) {
  console.error(v.errors.join('\n'));
  process.exit(2);
}
mkdirSync(outDir, { recursive: true });
const out = join(outDir, 'candidate.hwpx');
const base = process.env.REPORT_BASE || getForm(draft.template ?? DEFAULT_FORM).skeleton;
const res = await appendBlocks(base, out, draft, projectRoot);
writeFileSync(join(outDir, 'append-result.json'), JSON.stringify(res));
console.log('append', JSON.stringify(res).slice(0, 300));
// The engine has already initialised the wasm module (same module instance).
const doc = new core.HwpDocument(new Uint8Array(readFileSync(out)));
const n = doc.pageCount();
console.log('pages', n);
for (let i = 0; i < n; i++) {
  writeFileSync(join(outDir, `page-${String(i + 1).padStart(2, '0')}.svg`), doc.renderPageSvg(i));
}
