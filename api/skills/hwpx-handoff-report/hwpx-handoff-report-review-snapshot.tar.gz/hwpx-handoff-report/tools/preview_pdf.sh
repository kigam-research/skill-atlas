#!/usr/bin/env bash
# Layout preview of a report draft: page SVGs, page PNGs and one PDF, for review before the HWPX
# approval gate. Needs the engine's node_modules (npm ci in engine/) and a headless Chromium
# (CHROME=..., otherwise the first of: Playwright builds under /opt/pw-browsers or
# ~/.cache/ms-playwright, chromium, chromium-browser, google-chrome on PATH).
# REPORT_BASE=<report.hwpx> previews the draft appended to an existing report.
#
#   <skill>/tools/preview_pdf.sh <draft.json> <projectRoot> <outDir>
set -euo pipefail
here=$(cd "$(dirname "$0")" && pwd)
draft=$1
root=$2
out=$3
find_chrome() {
  for c in /opt/pw-browsers/chromium-*/chrome-linux*/chrome "$HOME"/.cache/ms-playwright/chromium-*/chrome-linux*/chrome; do
    [ -x "$c" ] && { echo "$c"; return; }
  done
  for c in chromium chromium-browser google-chrome; do
    command -v "$c" >/dev/null 2>&1 && { command -v "$c"; return; }
  done
}
chrome=${CHROME:-$(find_chrome)}
[ -n "$chrome" ] && [ -x "$chrome" ] || { echo "no chromium; set CHROME" >&2; exit 69; }
mkdir -p "$out"
rm -f "$out"/page-*.svg "$out"/page-*.png "$out"/page-*.html
node "$here/render_preview.mjs" "$draft" "$root" "$out"
out=$(cd "$out" && pwd)
{
  printf '<html><head><meta charset="utf-8"><style>@page{size:A4;margin:0}body{margin:0}'
  printf 'img{width:210mm;height:297mm;display:block;page-break-after:always}</style></head><body>\n'
  for s in "$out"/page-*.svg; do printf '<img src="%s">\n' "$(basename "$s")"; done
  printf '</body></html>\n'
} > "$out/all.html"
"$chrome" --headless=new --no-sandbox --disable-gpu --no-pdf-header-footer \
  --print-to-pdf="$out/preview.pdf" "file://$out/all.html" >/dev/null 2>&1
for s in "$out"/page-*.svg; do
  html="${s%.svg}.html"
  printf '<html><body style="margin:0;background:#fff"><img src="%s" style="width:1111px;height:1571px;display:block"></body></html>' \
    "$(basename "$s")" > "$html"
  "$chrome" --headless=new --no-sandbox --disable-gpu --hide-scrollbars --window-size=1111,1571 \
    --screenshot="${s%.svg}.png" "file://$html" >/dev/null 2>&1
  rm -f "$html"
done
echo "pages: $(ls "$out"/page-*.png | wc -l); pdf: $out/preview.pdf"
