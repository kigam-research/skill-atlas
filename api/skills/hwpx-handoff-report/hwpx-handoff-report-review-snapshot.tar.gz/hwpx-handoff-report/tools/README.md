# 보고서 초안 도구

원고 파일에서 초안 JSON과 승인용 미리보기를 만들고, 매번 같은 점검을 돌리는 도구다. 보고서 판본마다 빌더를 복사하지 않는다. 원고와 수치 계산만 프로젝트에 두고, 이 도구를 그대로 쓴다.

| 파일 | 용도 |
|---|---|
| `build_report.py` | 원고(`NN-이름.md`, `form.json`) → 초안 JSON과 미리보기 md. 엔진 검증, 문장 점검, 근거 점검을 한다. `--render <폴더>`를 주면 저장소 밖 폴더에 쪽 렌더·PDF를 만들고 렌더 점검도 한다. |
| `render_preview.mjs` | 엔진 라이브러리로 임시 후보 HWPX를 만들어 쪽마다 SVG로 렌더한다(rhwp CLI 불필요). |
| `preview_pdf.sh` | `render_preview.mjs`를 실행하고 쪽 PNG와 PDF 한 부를 만든다. |
| `canonical.py` | 정본 관리. `regenerate`(승인된 원고로 정본 전체를 새로 만들어 교체), `golden`(한컴 확인 뒤 golden 저장), `restore`(golden으로 되돌리기). 아래 "정본 관리" 참고 |
| `check_render.mjs` | 후보 HWPX를 rhwp로 배치해 쪽 끝 고립, 본문 영역 밖의 표·그림, 아래 여백에 걸린 글줄, 나뉜 짧은 표, 쪽 채움 비율, 본문 없는 쪽, 그림의 인쇄 폭을 JSON으로 낸다. |
| `tests/` | `python3 -m unittest discover skills/hwpx-handoff-report/tools/tests` |

필요한 것:
- Python 3.10 이상, Node.js 20 이상
- 엔진의 `node_modules`: `engine/`에서 `npm ci`
- 렌더할 때 headless Chromium: `CHROME` 환경변수, Playwright 설치본, 또는 PATH의 `chromium`·`google-chrome`

## 프로젝트 설정 (`report.json`)

경로는 모두 프로젝트 루트 기준이다. 루트는 `--root`로 주고, 주지 않으면 설정 파일이 있는 git 저장소의 최상위다.

```json
{
  "project": "과제-이름",
  "title": "연구보고서",
  "template": "research-report",
  "content": "docs/report/content",
  "draft": "docs/report/report-draft.json",
  "preview": "docs/report/report-draft.preview.md",
  "target": "docs/report/report.hwpx",
  "facts": "docs/report/report_facts.py",
  "checks": {
    "worklog": ["이 과제에서만 쓰는 작업 기록 어휘"],
    "internalTerms": ["(?<![A-Za-z0-9])S[0-9](?![A-Za-z0-9])"],
    "modelNames": ["이 과제에서 작업에 쓴 도구·모델 이름"],
    "allowTerms": ["AI", "PDF"],
    "legacySources": ["더 이상 현재 결과가 아닌 근거 경로"]
  },
  "achievements": "docs/report/achievements.md",
  "pageCheck": "docs/report/page-check.md",
  "evidence": ["results/**/summary.json", "docs/evals/*/README.md"]
}
```

| 항목 | 뜻 |
|---|---|
| `project` | 초안 `session.project` |
| `title` | 미리보기 제목에 쓰는 보고서 종류 |
| `template` | 보고서 양식: `engine/forms/<id>`. `node engine/append_report.mjs --list-forms`로 목록을 본다. 이어쓰기에서는 대상 문서의 양식과 같아야 한다 |
| `content` | 원고 폴더 |
| `draft`, `preview` | 쓸 초안 JSON, 미리보기 md |
| `target` | 정본 HWPX. 미리보기 안내, 이어쓰기 렌더, `canonical.py`가 쓴다 |
| `journal` | 선택. 엔진 journal 경로. 기본은 정본 옆 `report-journal.jsonl`. 바꾸면 엔진 CLI에도 `--journal`로 같은 경로를 준다 |
| `facts` | 선택. `facts()`가 `{이름: 값}`을 돌려주는 Python 파일. 원고의 `{{이름}}`을 이 값으로 바꾼다 |
| `checks` | 선택. 기본 점검에 과제 고유 항목을 더한다 |
| `achievements` | 성과 목록 파일(아래 "성과 목록"). 초안 도구가 원고와 대조한다. 없으면 성과 대응 점검에 그 사실을 적는다 |
| `pageCheck` | 쪽별 확인 기록 파일(아래 "쪽별 확인 기록"). `--render` 뒤 모든 쪽이 적혔는지 본다 |
| `evidence` | 선택. 도구가 스스로 찾는 기록 폴더(`evals/`, `results/`, `experiments/` 아래 README나 summary.json이 있는 폴더) 밖의 기록 경로(glob 목록) |
| `structure` | 구조 틀: `development`, `research`, `none`. 정의는 `structures.json` |

### 성과 목록

markdown 파일에 표 두 개를 둔다. 머리 이름이 같아야 도구가 읽는다.

```markdown
| 번호 | 작업 | 성과 | 구분 | 근거 | 기준일 | 절 | 핵심 수치 | 제외 이유 |
|---|---|---|---|---|---|---|---|---|
| 1 | 수질 선별 규칙 | 측정망 기록 오류 문제 | 배경 | results/screening | 2026-09-20 | 연구 배경 | 3개 지점 | |
| 2 | 수질 선별 규칙 | 두 선별 규칙 | 방법 | results/screening | 2026-09-20 | 선별 기준 | 1.4826 | |
| 3 | 수질 선별 규칙 | 규칙별 선별 결과 | 결과 | results/screening/summary.json | 2026-09-20 | 선별 결과 | 12건; 3.1% | |
| 4 | 수질 선별 규칙 | 예비 측정 | 결과 | results/pilot | 2026-03-02 | | | 장비 교정 전 측정이라 뺌 |

| 번호 | 작업 | 그림 | 역할 | 절 | 보여 주는 것 |
|---|---|---|---|---|---|
| 1 | 수질 선별 규칙 | figures/evidence.png | 결과 | 선별 결과 | 선별 전후 측정값 분포 |
```

- **작업과 구분:** `작업`은 결과물 하나(스킬, 시스템, 실험)다. `구분`은 구조 틀의 역할 중 하나만 적는다. 작업마다 틀이 요구하는 구분이 모두 있어야 하고, 각 행은 자기 소절(`절`)을 가진다. `범위` 행은 결과 절을 함께 쓸 수 있다.
- **성과 표:** `절`은 원고 제목에 들어 있는 문자열, `핵심 수치`는 `;`로 나눈 값들이다. 값은 원고에 쓴 그대로(공백 무시) 찾는다. 근거 경로가 있는지도 본다. `제외 이유`가 있는 행은 점검하지 않는다.
- **그림 계획 표:** `그림`의 경로가 초안의 그림 block에 있는지 본다. 역할은 `references/figures-tables.md` 2절에 있다.
- **그 밖의 점검:**
  - 도구가 찾은 기록 폴더와 `evidence`의 기록 중 성과 목록이 다루지 않은 것
  - 구조 틀: 작업마다 빠진 구분, 구분을 둘 이상 적은 행, 작업마다 빠진 방법·결과 그림
  - 한 절에 성과가 여럿인 것(성과마다 소절을 둔다)
  - 결과 수치가 있는 성과 절에 그림이 없는 것
  - facts 모듈이 값을 주지 않는데 원고에 수치가 다섯 개 이상인 것
  - 허용 목록(`allowTerms`)에 넣었지만 본문에서 한 번도 "풀이(약어)"로 설명하지 않은 약어. 일반 약어(AI, PDF, CPU 등)는 예외다
- 결과는 미리보기의 "성과 대응 점검"과 명령 출력의 `coverage findings`에 나온다.
- 미리보기 끝의 `<!-- build_report sha256:… -->`는 도구가 쓴 그대로인지 확인하는 해시다. 손으로 고친 미리보기가 있으면 `canonical.py regenerate`가 거부한다.

### 쪽별 확인 기록

렌더한 쪽 이미지를 열어 본 뒤 쪽마다 한 행을 적는다. `본 것`이 빈 쪽은 확인하지 않은 쪽으로 센다.

```markdown
| 쪽 | 본 것 | 조치 |
|---|---|---|
| 1 | 양식 표 5행, 첫 절 제목과 본문 시작 | 없음 |
| 2 | 그림 1 아래 캡션, 쪽 끝 제목 없음 | 없음 |
```

## 원고 형식

파일 이름 순서대로 읽는다(`10-배경.md`, `20-방법.md` …). 한 줄이 한 block이다.

| 줄 | block |
|---|---|
| `# 제목` / `## 제목` / `### 제목` | heading1/2/3. 번호(가./1)/(1))는 엔진이 붙인다 |
| `◯ 문장` | statement. 이어지는 줄은 공백 두 칸 이상 들여 쓴다 |
| `- 문장` | detail |
| `> src: 경로; 경로` | 바로 위 block의 근거. 제목의 근거는 근거 없는 하위 block이 이어받는다. 인쇄하지 않고 미리보기 근거 대응표에만 나온다 |
| `![캡션](그림.png, 그림.png){cols=2}` | 그림 묶음. 캡션은 `<캡션>`으로 그림 아래에 들어간다. `cols` 기본값은 그림 수 |
| `[표] 캡션 {ratios=20,60,20}{env}` | 표. 다음 줄부터 markdown 표를 쓴다. `{env}`는 도구·환경 표로, 작업 도구·모델 이름은 이 표에만 쓴다 |
| `%% 메모` | 작성자 메모. 인쇄하지 않는다 |

`form.json`(원고 폴더)은 양식 칸을 채운다. 양식마다 있는 칸만 쓸 수 있다.
- `title`: 일반 연구보고서의 제목
- `goals`: 기관 양식의 추진목표 표 행
- `summary`: 기관 양식의 하단 요약표 행

## 점검

미리보기의 "자동 점검"은 고칠 **후보**다. 문맥상 맞으면 남긴다.
- **문장:** 다음 표현을 찾는다.
  - 작업 기록 어휘: 재실행, 반영하였, 브랜치 등
  - 안내·평가 문장: 본 절, 의의가 크, 다음과 같음 등
  - commit·해시, 파일 이름, 경로, 코드 식별자, 영문 약어, 영문 상태값
  - 환경 표 밖의 작업 도구·모델 이름. 연구 대상인 모델·장비 이름은 `allowTerms`에 두면 점검하지 않는다
  - 검사 범위는 본문, 캡션, 표 칸, 양식 칸이다.
- **근거:** 근거 없는 block, 없는 경로, 옛 판본 근거를 찾는다.
- **렌더(`--render`):** 다음을 본다.
  - 쪽 끝 제목·표 제목
  - 본문 영역 밖의 표·그림
  - 미리보기에서 아래 여백에 걸린 글줄
  - 나뉜 짧은 표, 두 쪽에 걸친 양식 표
  - 75% 미만으로 찬 쪽 다음의 표·그림
  - 본문 없는 쪽
  - 그림 축소와 인쇄 해상도(300 dpi 미만)
- 렌더 점검은 rhwp 배치 기준이다. 한컴의 쪽 나눔은 따로 확인한다.
- "본문 없는 쪽"은 글자와 표가 하나도 없는 쪽만 잡는다. 그래서 모든 쪽을 눈으로도 본다.

## 명령

```bash
# 초안과 미리보기(문장·근거 점검)
python3 skills/hwpx-handoff-report/tools/build_report.py --config docs/report/report.json
# 쪽 렌더와 렌더 점검까지(출력은 저장소 밖)
python3 skills/hwpx-handoff-report/tools/build_report.py --config docs/report/report.json --render /tmp/report-render
# 이어쓰기: 새 절만 쓴 원고 폴더로 초안을 만들고 현재 정본에 붙인 모습을 렌더한다
python3 skills/hwpx-handoff-report/tools/build_report.py --config docs/report/report.json --continue --content docs/report/continue-2026-10 --render /tmp/r
```

- `--out-dir`는 초안과 미리보기를 다른 폴더에 쓴다(시험·검토용). `--date`는 초안 날짜를 정한다. `--base <HWPX>`는 렌더의 바탕 문서를 바꾼다.
- **`--continue`(이어쓰기):**
  - `--content`에는 **새 절만** 담은 원고 폴더를 준다. 전체 원고 폴더를 주면 거부한다.
  - 양식 칸(`form.json`)은 채우지 않는다. 초안은 `<초안 이름>.continue.json`, 미리보기는 `<미리보기 이름>.continue.md`에 쓰고, 전체 초안은 그대로 둔다.
  - 렌더 바탕은 현재 정본이다. 제목 번호는 엔진이 정본에 있는 번호에 이어서 매긴다(`가.`가 있으면 새 `heading1`은 `나.`).
  - 승인 뒤 `node engine/append_report.mjs --draft <….continue.json> --target <정본> --project-root <루트>`로 붙인다.

## 정본 관리 (`canonical.py`)

정본 HWPX를 만들거나 바꾸는 일은 사용자 승인 뒤에만 한다. 한 번 쓴 보고서에 새 절을 더하는 이어쓰기는 엔진 CLI(`engine/append_report.mjs`)로 한다. 보고서 구성을 바꿔 전체를 다시 쓸 때는 `regenerate`를 쓴다.

```bash
# 승인된 원고로 정본 전체를 새로 만든다(rhwp CLI 필요)
python3 skills/hwpx-handoff-report/tools/canonical.py regenerate --config docs/report/report.json [--expect-sha <현재 정본 sha256>]
# 사용자가 한컴오피스에서 확인한 뒤
python3 skills/hwpx-handoff-report/tools/canonical.py golden --config docs/report/report.json --confirmed "홍길동 한컴 확인 2026-09-29"
# 한컴에서 이상을 보고하면
python3 skills/hwpx-handoff-report/tools/canonical.py restore --config docs/report/report.json
```

세 명령 모두 정본 잠금(`<정본>.lock`)을 잡는다. 엔진의 이어쓰기와 같은 잠금이라 동시에 돌지 않는다.

**journal:** 엔진은 정본을 바꿀 때마다 한 줄을 쓴다. 담기는 것:
- `target`(정본 이름), `form`
- `draft`(프로젝트 기준 경로), `draftSha256`(엔진이 읽은 초안의 sha256)
- `sha256Before`(바꾸기 전 정본, 새 파일이면 null), `sha256After`
- 그 밖에 `blocks`, `figures`, `bytes`, `binDataCount`

`regenerate` 순서:
1. 원고로 초안을 다시 만들고, 그 사본을 `drafts/<이름>-<UTC>.json`으로 남긴다. 엔진은 이 사본으로 만든다.
2. 정본 옆 빈 폴더(`.regen-<UTC>/`)에 엔진 CLI로 새 보고서를 만든다. 이 단계에 검증, rhwp 왕복, 미리보기 PDF가 들어 있다.
3. 성공했고 정본이 시작 때와 같은 파일이면(`--expect-sha`도 확인) 다음을 한다.
   - 기존 정본을 `backup/<이름>.bak-prerewrite-<UTC>.hwpx`로 복사한다.
   - 새 보고서를 정본 자리로 옮긴다.
   - 미리보기를 옮기고 journal에 한 줄(`rewrite: true`)을 더한다.
4. 교체 전에 실패하면 아무것도 바꾸지 않는다. `.regen-<UTC>/`에 실패한 후보(`<이름>.failed.hwpx`), 엔진 기록을 남긴다.
5. 교체 뒤 미리보기·journal 단계가 실패하면 **종료 코드 5**다. 정본은 이미 새 파일이다. 다시 실행하지 않는다. 출력의 `journalLine`을 journal에 더하고 미리보기는 `rhwp export-pdf`로 만든다.

`golden`:
- 정본이 journal의 마지막 기록과 같은 파일일 때만 저장한다. 엔진 밖에서 고친 파일은 거부한다.
- journal을 거슬러 올라가 현재 정본을 만든 줄을 모두 찾는다. 새로 만든 줄, 마지막 `regenerate`, 마지막 `restore`까지 간다.
- 그 줄들이 쓴 초안이 기록된 sha256 그대로 남아 있어야 한다. 초안을 그 뒤에 고쳤으면 원래 파일을 `--draft <경로>`로 준다(여러 번 줄 수 있다). 찾지 못하면 거부한다.
- 확인 내용은 `--confirmed`에 필수로 적는다.
- 만드는 파일(판마다 새 이름이며 덮어쓰지 않는다):
  - `<이름>.golden-<UTC>.hwpx`, `<이름>.golden-<UTC>.preview.pdf`
  - 초안 사본 `golden-draft-<이름>-<UTC>.json`. 이어쓰기로 초안이 여럿이면 `-01`, `-02` …
- 기록 `<이름>.golden.json`: 보고서마다 따로 두고 판마다 한 줄(확인 내용, 파일 경로, 정본 sha256, 초안 사본 목록 `drafts`)을 더한다. 파일을 다 복사한 뒤 마지막에 쓴다. 중간에 실패하면 복사한 파일을 지우고 기록을 바꾸지 않아서, 이전 golden 판이 그대로 유효하다.
- journal의 `target`은 프로젝트 기준 경로다. 다른 폴더의 같은 이름 보고서가 journal을 함께 써도 섞이지 않는다.
- **예전 기록:** 2026-09-29 이전 엔진의 journal 줄(`target` 없음 또는 파일 이름만)은 정본 옆 기본 journal에 있을 때만 그 보고서의 기록으로 읽는다. 예전 공유 `golden.json`의 기록은 그 보고서의 예전 golden 파일(`<이름>.golden.hwpx`)을 가리킬 때만 읽는다. 초안 기록이 없는 예전 journal로 만든 정본은 한 번 `regenerate`한 뒤 golden을 만들 수 있다.

`restore`:
- 잠금 안에서 기록을 읽고, 마지막 golden 판의 sha256이 기록과 같을 때만 되돌린다. 자기 기록이 없는 보고서는 예전 방식의 공유 `golden.json`을 읽는다.
- 현재 정본을 `backup/<이름>.bak-restore-<UTC>.hwpx`로 복사하고 golden을 정본 자리에 놓는다.
- golden 미리보기가 있으면 함께 되돌리고, 없으면 옛 미리보기를 지운다(다른 파일의 미리보기가 남지 않게).
- journal에 한 줄(`restore: true`, 되돌린 golden 초안 목록)을 더한다. 그 뒤의 `golden`은 이 초안들과 짝을 짓는다.
- 정본을 바꾼 뒤 미리보기·journal 단계가 실패하면 종료 코드 5와 `journalLine`을 낸다.
