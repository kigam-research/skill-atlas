// Render checks of a candidate HWPX with the rhwp layout (the same renderer as the preview PDF):
// paragraphs that should keep with the next one but end a page, tables and figures below the body
// area, how far each page is filled, pages without body content, and the printed width of every
// image. The body is found from the document's form (engine/forms).
//
//   node <skill>/tools/check_render.mjs <candidate.hwpx>   -> JSON on stdout
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const ENGINE = join(dirname(fileURLToPath(import.meta.url)), '../engine');
const { inspectBodyFlow, SHORT_TABLE_SHARE } = await import(join(ENGINE, 'lib/engine.js'));
const core = await import(join(ENGINE, 'node_modules/@rhwp/core/rhwp.js'));

const file = process.argv[2];
if (!file) {
  console.error('usage: check_render.mjs <candidate.hwpx>');
  process.exit(64);
}
const bytes = readFileSync(file);
const { pages, lastPages, keep, texts, overflow, lineOverflow, unresolved, summary, endTable, tableHeights, bodyHeight } = await inspectBodyFlow(bytes); // also initialises the wasm module
const doc = new core.HwpDocument(new Uint8Array(bytes));

const keepViolations = [];
for (let i = 0; i + 1 < pages.length; i += 1) {
  if (keep[i] && pages[i + 1] > lastPages[i]) {
    keepViolations.push({ paragraph: i, page: pages[i] + 1 });
  }
}

const pageStats = [];
const images = [];
for (let p = 0; p < doc.pageCount(); p += 1) {
  const info = JSON.parse(doc.getPageInfo(p));
  const bodyTop = info.marginTop + (info.marginHeader ?? 0);
  const bodyBottom = info.height - info.marginBottom;
  let bottom = bodyTop;
  let firstItem = null;
  let text = 0;
  for (const run of JSON.parse(doc.getPageTextLayout(p)).runs ?? []) {
    if (!run.text?.trim()) continue;
    text += 1;
    bottom = Math.max(bottom, run.y + run.h);
    if (!firstItem || run.y < firstItem.y) firstItem = { kind: 'text', y: run.y, text: run.text.slice(0, 30) };
  }
  let controls = 0;
  for (const control of JSON.parse(doc.getPageControlLayout(p)).controls ?? []) {
    controls += 1;
    bottom = Math.max(bottom, control.y + control.h);
    if (control.type === 'image') {
      images.push({ page: p + 1, widthPx: control.w, heightPx: control.h });
    }
    if (!firstItem || control.y < firstItem.y - 1) {
      firstItem = { kind: control.type, y: control.y };
    }
  }
  pageStats.push({
    page: p + 1,
    fill: Number(((bottom - bodyTop) / (bodyBottom - bodyTop)).toFixed(3)),
    textRuns: text,
    controls,
    first: firstItem,
  });
}

console.log(JSON.stringify({ pages: doc.pageCount(), bodyParagraphs: pages.length, bodyPages: pages, bodyTexts: texts,
  keepViolations, overflow: overflow.flatMap((over, i) => (over ? [i] : [])),
  lineOverflow: lineOverflow.flatMap((over, i) => (over ? [i] : [])), unresolved, pageStats, images,
  summarySplit: endTable && pages[summary] < lastPages[summary],
  // body tables no taller than a page that are drawn over two pages
  splitTables: pages.flatMap((page, k) => (k < summary && page < lastPages[k] && tableHeights[k] > 0
    && tableHeights[k] <= bodyHeight * SHORT_TABLE_SHARE ? [k] : [])) }));
