"""Build a report draft JSON and its approval preview from a folder of manuscript files.

One builder for every revision of a report: the text lives in manuscript files, numbers come from
the project's facts module ({{name}} placeholders), and each build validates the draft with the
engine and runs the text and source checks. With --render it also renders a candidate HWPX outside
the repository (page SVG/PNG and a PDF) and runs the layout checks.

    python3 <skill>/tools/build_report.py --config docs/report/report.json            # draft + preview
    python3 <skill>/tools/build_report.py --config docs/report/report.json --render <dir>

The project settings file (JSON, paths relative to the project root = --root, default: the git top
level of the settings file) names the manuscript folder, the draft and preview files, the report
form (template) and optional checks; see tools/README.md.

Manuscript format (files named NN-name.md, read in file-name order; form.json in the same folder
holds the form parts: title, goals, summary):
    # 제목 / ## 제목 / ### 제목          heading1 / heading2 / heading3 (numbers are added by the engine)
    ◯ 문장                               statement; continuation lines are indented by two or more spaces
    - 문장                               detail
    > src: path; path                    source of the block above (heading sources apply to the blocks below
                                         them that have none)
    ![캡션](path, path){cols=2}           figure_grid with an angle caption; cols defaults to the image count
    [표] 캡션 {ratios=20,60,20}{env}      table; the markdown table follows on the next lines. {env} marks the
                                         tools/environment table, the only place tool and model names may appear
    %% ...                               author note, not printed
"""
import argparse
import datetime as dt
import importlib.util
import json
import os
import re
import struct
import subprocess
from pathlib import Path

TOOLS = Path(__file__).resolve().parent
ENGINE = TOOLS.parent / 'engine'

# ---------------------------------------------------------------- settings


class Settings:
    """The project's report settings (report.json) with paths resolved against the project root."""

    def __init__(self, path, root=None):
        self.path = Path(path).resolve()
        data = json.loads(self.path.read_text())
        self.root = Path(root).resolve() if root else git_root(self.path.parent)
        self.data = data
        self.project = data['project']
        self.template = data.get('template')
        self.content = self.root / data['content']
        self.draft = self.root / data['draft']
        self.preview = self.root / data['preview']
        self.target = self.root / data['target'] if data.get('target') else None
        # the engine's journal for this report: report.json "journal", else report-journal.jsonl next to the target
        self.journal = (self.root / data['journal'] if data.get('journal')
                        else self.target.parent / 'report-journal.jsonl' if self.target else None)
        self.facts = self.root / data['facts'] if data.get('facts') else None
        self.title = data.get('title', '보고서')
        checks = data.get('checks', {})
        self.worklog = WORKLOG + checks.get('worklog', [])
        self.internal = INTERNAL_RES + [(p, '내부 기호·영문 약어') for p in checks.get('internalTerms', [])]
        self.models = MODEL_NAMES + checks.get('modelNames', [])
        self.legacy = checks.get('legacySources', [])
        self.allow = set(checks.get('allowTerms', []))
        # the achievement list the manuscript is checked against, and the page-by-page render record
        self.achievements = self.root / data['achievements'] if data.get('achievements') else None
        self.page_check = self.root / data['pageCheck'] if data.get('pageCheck') else None
        # globs of result, evaluation and test records the achievement list has to account for, added to the
        # records the tool finds itself (evidence_records); and the structure template of the report
        self.evidence = data.get('evidence', [])
        self.structure = data.get('structure')

    def rel(self, path):
        return os.path.relpath(path, self.root)


def git_root(start):
    try:
        out = subprocess.run(['git', 'rev-parse', '--show-toplevel'], cwd=start, capture_output=True, text=True, check=True)
        return Path(out.stdout.strip())
    except (subprocess.CalledProcessError, FileNotFoundError):
        return Path(start).resolve()


def load_facts(settings):
    if not settings.facts:
        return {}
    spec = importlib.util.spec_from_file_location('report_facts', settings.facts)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.facts()


def load_form(path):
    """Form data from the content folder, if any. Old tooling wrote {"goals": ..., "summary": ...}."""
    return json.loads(path.read_text()) if path.exists() else {}


def form_spec(template):
    """The engine's form.json of a template (for the preview's form-table labels)."""
    if not template:
        return {}
    path = ENGINE / 'forms' / template / 'form.json'
    return json.loads(path.read_text()) if path.exists() else {}

# ---------------------------------------------------------------- content parsing


HEADINGS = {'#': 'heading1', '##': 'heading2', '###': 'heading3'}
FIGURE_RE = re.compile(r'^!\[(?P<caption>.+?)\]\((?P<images>[^)]+)\)(?P<opts>(?:\{[^}]*\})*)\s*$')
TABLE_RE = re.compile(r'^\[표\]\s*(?P<caption>.+?)\s*(?P<opts>(?:\{[^}]*\})*)\s*$')
PLACEHOLDER_RE = re.compile(r'\{\{(\w+)\}\}')


def _opts(text):
    opts = {}
    for item in re.findall(r'\{([^}]*)\}', text or ''):
        key, _, value = item.partition('=')
        opts[key.strip()] = value.strip() if value else True
    return opts


def _fill(text, facts, where):
    def sub(match):
        if match.group(1) not in facts:
            raise KeyError(f'{where}: unknown fact {{{{{match.group(1)}}}}}')
        return str(facts[match.group(1)])
    return PLACEHOLDER_RE.sub(sub, text)


def parse(path, facts):
    blocks = []
    lines = path.read_text().splitlines()
    i = 0
    while i < len(lines):
        raw = lines[i]
        where = f'{path.name}:{i + 1}'
        line = raw.strip()
        i += 1
        if not line or line.startswith('%%'):
            continue
        if raw.startswith('  ') and blocks and blocks[-1]['type'] in ('statement', 'detail'):
            blocks[-1]['text'] += ' ' + _fill(line, facts, where)
            continue
        marker, _, rest = line.partition(' ')
        if marker in HEADINGS:
            blocks.append({'type': HEADINGS[marker], 'text': _fill(rest.strip(), facts, where)})
        elif marker == '◯':
            blocks.append({'type': 'statement', 'text': _fill(rest.strip(), facts, where)})
        elif marker == '-':
            blocks.append({'type': 'detail', 'text': _fill(rest.strip(), facts, where)})
        elif line.startswith('> src:'):
            if not blocks:
                raise ValueError(f'{where}: source line before any block')
            blocks[-1]['source'] = line[len('> src:'):].strip()
        elif FIGURE_RE.match(line):
            m = FIGURE_RE.match(line)
            images = [p.strip() for p in m['images'].split(',')]
            opts = _opts(m['opts'])
            blocks.append({'type': 'figure_grid', 'images': images, 'columns': int(opts.get('cols', len(images))),
                           'caption': _fill(m['caption'], facts, where), 'captionStyle': 'angle'})
        elif TABLE_RE.match(line):
            m = TABLE_RE.match(line)
            opts = _opts(m['opts'])
            rows = []
            while i < len(lines) and lines[i].strip().startswith('|'):
                cells = [c.strip() for c in lines[i].strip().strip('|').split('|')]
                if not all(re.fullmatch(r':?-{3,}:?', c) for c in cells):
                    rows.append([_fill(c, facts, f'{path.name}:{i + 1}') for c in cells])
                i += 1
            if len(rows) < 2:
                raise ValueError(f'{where}: table needs a header row and at least one body row')
            block = {'type': 'table', 'caption': _fill(m['caption'], facts, where), 'headers': rows[0], 'rows': rows[1:]}
            if 'ratios' in opts:
                block['colWidthRatios'] = [float(x) for x in opts['ratios'].split(',')]
            if opts.get('env'):
                block['_env'] = True
            blocks.append(block)
        else:
            raise ValueError(f'{where}: unrecognised line: {line[:40]}')
    return blocks


def inherit_sources(blocks):
    current = {1: None, 2: None, 3: None}
    for block in blocks:
        if block['type'].startswith('heading'):
            level = int(block['type'][-1])
            current[level] = block.get('source')
            for deeper in range(level + 1, 4):
                current[deeper] = None
        elif 'source' not in block:
            inherited = current[3] or current[2] or current[1]
            if inherited:
                block['source'] = inherited
                block['_inherited'] = True
    return blocks

# ---------------------------------------------------------------- text checks

# Work-log and trial-and-error wording (report-writing.md §1). Candidates for a human look, not errors:
# a few can be right in context. Projects add their own words in report.json checks.worklog.
WORKLOG = ['재실행', '다시 실행', '교체하였', '세션', '권한', '회차', '브랜치', '커밋', '해시', '시행착오',
           '첫 실행', '처음 실행', '개발 담당', '작업 폴더', '반영하였', '고쳤', '수정하였', '오류가 발견',
           '재설계', '철회', '검토 지적', '에이전트가 스스로', '프롬프트']
INTERNAL_RES = [
    # ASCII boundaries: Korean particles glue to codes ("a25e327에서", "engine.js를")
    (r'(?<![0-9A-Za-z])[0-9a-f]{7,40}(?![0-9A-Za-z])', 'commit·해시 형태'),
    (r'[A-Za-z0-9_-]+\.(?:py|md|json|mjs|js|ts|png|jpg|csv|xlsx|hwpx|sh|ipynb|yaml|yml|toml)(?![A-Za-z0-9])', '파일 이름'),
    (r'(?<![\w가-힣])(?:[\w.-]+/)+[\w.-]+', '경로'),
    (r'(?<![A-Za-z0-9])[A-Za-z]+_[A-Za-z_]+(?![A-Za-z0-9])', '코드 식별자'),
    (r'(?<![A-Za-z0-9])[A-Z]{2,6}s?(?![A-Za-z0-9])', '영문 약어'),
    (r'(?<![A-Za-z])(?:complete|partial|unknown|not_checked|pass|fail|todo|wip)(?![A-Za-z])', '영문 상태값'),
]
# Names of the tools that helped do the work (AI assistants, editors) belong in the tools/environment table
# ({env}). A model or instrument that is itself studied is named in the text: list it in checks.allowTerms.
MODEL_NAMES = ['gpt', 'chatgpt', 'claude', 'opus', 'sonnet', 'haiku', 'gemini', 'llama', 'qwen', 'mistral',
               'deepseek', 'codex', 'copilot']
META = ['본 절', '본 보고서에서는', '본 연구에서는', '살펴보', '의의가 크', '중요한 의미', '다음과 같음', '아래와 같음']


UNIT_RE = re.compile(r'[A-Za-zµμ°%]{1,4}/[A-Za-z0-9²³µμ]{1,4}')


def is_unit(term):
    """A unit such as mg/L or km/h (Korean particles may follow), not a path."""
    ascii_part = re.match(r'[!-~µμ°²³]+', term)
    return bool(ascii_part and UNIT_RE.fullmatch(ascii_part.group(0)))


def block_text(block):
    parts = [block.get('text', ''), block.get('caption', '')]
    if block['type'] == 'table':
        parts += block['headers'] + [c for row in block['rows'] for c in row]
    return ' '.join(p for p in parts if p)


ACRONYM = re.compile(r'[A-Z][A-Z0-9/&-]{1,7}')
# abbreviations a general reader knows; any other allowed abbreviation is spelled out once in the text
COMMON_ACRONYMS = {'AI', 'PDF', 'CPU', 'GPU', 'UI', 'URL', 'CSV', 'API', 'GIS', 'GPS', 'HWPX', 'DB', 'PC', 'OS', 'IT'}


def text_checks(blocks, form=None, settings=None):
    """Wording candidates in every printed string: block text, captions, table cells and form parts."""
    worklog = settings.worklog if settings else WORKLOG
    internal = settings.internal if settings else INTERNAL_RES
    models = settings.models if settings else MODEL_NAMES
    allow = settings.allow if settings else set()
    model_re = re.compile(r'(?i)(?<![a-z])(?:' + '|'.join(map(re.escape, models)) + r')(?![a-z])')
    items = [(n, block_text(block), block.get('_env')) for n, block in enumerate(blocks, 1)]
    explained = squeeze(' '.join(body for _, body, _ in items))
    for key, value in (form or {}).items():
        rows = [[value]] if isinstance(value, str) else value
        items += [(f'양식 {key} {r}', ' '.join(row), False) for r, row in enumerate(rows, 1)]
    found = []
    for n, body, env in items:
        for term in worklog:
            if term in body:
                found.append((n, '작업 기록 어휘', term))
        for term in META:
            if term in body:
                found.append((n, '안내·평가 문장', term))
        if env:
            continue
        for pattern, label in internal:
            for m in re.finditer(pattern, body):
                term = m.group(0)
                if label == '경로' and is_unit(term):
                    continue
                if term not in allow:
                    found.append((n, label, term))
                elif ACRONYM.fullmatch(term) and term not in COMMON_ACRONYMS and f'({term})' not in explained:
                    # an allowed abbreviation still needs its Korean meaning once: "공간 교차검증(CV)"
                    found.append((n, '풀이 없는 약어(허용 목록에 있음)', term))
        allow_lower = {a.lower() for a in allow}
        for m in model_re.finditer(body):
            if m.group(0).lower() not in allow_lower:
                found.append((n, '작업 도구·모델 이름(환경 표 밖)', m.group(0)))
    return found


def source_checks(blocks, settings):
    issues = []
    for n, block in enumerate(blocks, 1):
        if block['type'].startswith('heading'):
            continue
        source = block.get('source')
        if not source:
            issues.append((n, '근거 없음', ''))
            continue
        for part in source.split(';'):
            path = part.strip().split(' ')[0]
            if not path:
                continue
            if any(path.startswith(p) or p in path for p in settings.legacy):
                issues.append((n, '옛 판본 근거', path))
            probe = path.split('#')[0]
            if '*' in probe:
                if not list(settings.root.glob(probe)):
                    issues.append((n, '근거 경로 없음', path))
            elif not (settings.root / probe).exists():
                issues.append((n, '근거 경로 없음', path))
    return issues


def markdown_tables(text):
    """Markdown tables of a file as lists of row dicts keyed by the header cells."""
    tables, rows = [], []
    for line in text.splitlines() + ['']:
        if line.strip().startswith('|'):
            rows.append([c.strip() for c in line.strip().strip('|').split('|')])
            continue
        if len(rows) >= 2 and set(''.join(rows[1])) <= set('-: '):
            tables.append([dict(zip(rows[0], r)) for r in rows[2:]])
        rows = []
    return tables


def squeeze(text):
    return re.sub(r'\s+', '', text)


def printed_text(blocks, form):
    parts = [block_text(b) for b in blocks]
    for value in (form or {}).values():
        parts += [value] if isinstance(value, str) else [c for row in value for c in row]
    return squeeze(' '.join(parts))


def achievement_checks(settings, blocks, form):
    """The achievement list against the manuscript: each listed result sits in its section with its key
    numbers, and each planned figure is in the draft. Returns (findings, counts)."""
    if not settings.achievements:
        return ['성과 목록 파일이 설정되지 않음(report.json "achievements"). 성과 목록을 먼저 만든다'], {}
    if not settings.achievements.exists():
        return [f'성과 목록 파일 없음: {settings.rel(settings.achievements)}'], {}
    tables = markdown_tables(settings.achievements.read_text())
    results = next((t for t in tables if t and '핵심 수치' in t[0]), None)
    figures = next((t for t in tables if t and '그림' in t[0] and '역할' in t[0]), None)
    found = []
    if results is None:
        return ['성과 목록에 성과 표(머리에 "핵심 수치")가 없음'], {}
    headings = [squeeze(b['text']) for b in blocks if b['type'].startswith('heading')]
    text = printed_text(blocks, form)
    used = {img for b in blocks if b['type'] == 'figure_grid' for img in b['images']}
    kept = [r for r in results if not r.get('제외 이유', '').strip()]
    for r in kept:
        name = f"성과 {r.get('번호', '?')} {r.get('성과', '')}"
        section = squeeze(r.get('절', ''))
        if section and not any(section in h for h in headings):
            found.append(f"{name}: 넣을 절 '{r.get('절')}'이 원고 제목에 없음")
        for value in [v.strip() for v in r.get('핵심 수치', '').split(';') if v.strip()]:
            if squeeze(value) not in text:
                found.append(f"{name}: 핵심 수치 '{value}'가 본문에 없음")
        for path in [v.strip().split(' ')[0] for v in r.get('근거', '').split(';') if v.strip()]:
            if not (settings.root / path.split('#')[0]).exists():
                found.append(f"{name}: 근거 경로 없음 {path}")
    # one achievement per section: several results under one heading become a summary paragraph
    by_section = {}
    for r in kept:
        # the interpretation scope closes its result section, so a 범위 row may share it
        if r.get('절', '').strip() and r.get('구분', '').strip() != '범위':
            by_section.setdefault(squeeze(r['절']), []).append(r.get('번호', '?'))
    for section, numbers in by_section.items():
        if len(numbers) > 1:
            found.append(f"절 '{section}'에 성과 {len(numbers)}개({', '.join(numbers)}): 성과마다 소절을 두고 "
                         '성과 목록의 절을 그 소절 제목으로 적는다')
    # every evaluation and test record is either reported or excluded with a reason. The tool finds the
    # records itself, so a short evidence list cannot hide one; a cited file or folder accounts for a record
    cited = [v.strip().split(' ')[0].split('#')[0].rstrip('/') for r in results for v in r.get('근거', '').split(';')
             if v.strip()]
    for rel in evidence_records(settings):
        if not any(rel == c or c.startswith(rel + '/') or rel.startswith(c + '/') for c in cited if c):
            found.append(f'성과 목록이 다루지 않은 근거 기록: {rel}(성과로 넣거나 제외 이유와 함께 적는다)')
    found += structure_findings(settings, kept, figures or [])
    # a section that reports measured results shows them in a figure
    for section in {squeeze(r['절']) for r in kept if r.get('절', '').strip() and r.get('핵심 수치', '').strip()
                    and '결과' in r.get('구분', '')}:
        span = section_blocks(blocks, section)
        if span is not None and not any(b['type'] == 'figure_grid' for b in span):
            found.append(f"결과 수치가 있는 절 '{section}'에 그림이 없음(결과를 보여 주는 그림을 두거나 이유를 성과 목록에 적는다)")
    for r in figures or []:
        path = r.get('그림', '').strip().strip('`')
        if path and not r.get('제외 이유', '').strip() and path not in used:
            found.append(f"그림 계획 {r.get('번호', '?')} {path}: 초안에 없음")
    if figures is None:
        found.append('성과 목록에 그림 계획 표(머리에 "그림", "역할")가 없음')
    return found, {'results': len(kept), 'excluded': len(results) - len(kept), 'figures': len(figures or [])}


RECORD_DIRS = ('evals', 'results', 'experiments')
SKIP_DIRS = {'node_modules', '.git', '.venv', '__pycache__'}


def evidence_records(settings):
    """Result, evaluation and test records, as project-relative paths: every folder directly under a folder
    named evals, results or experiments that holds a README.md or summary.json, plus report.json evidence."""
    report_dir = settings.target.parent if settings.target else None
    records = set()
    for name in RECORD_DIRS:
        for top in settings.root.rglob(name):
            if not top.is_dir() or SKIP_DIRS & set(top.relative_to(settings.root).parts):
                continue
            if report_dir and (top == report_dir or report_dir in top.parents):
                continue
            for record in top.iterdir():
                if record.is_dir() and ((record / 'README.md').exists() or (record / 'summary.json').exists()):
                    records.add(settings.rel(record))
    for pattern in settings.evidence:
        records.update(settings.rel(p) for p in settings.root.glob(pattern))
    return sorted(records)


STRUCTURES = json.loads((TOOLS / 'structures.json').read_text())


def structure_findings(settings, kept, figures):
    """The structure template: each work unit (작업) has a row, in its own section, for every required
    role, and the figures its method and results need."""
    if not settings.structure:
        return ['report.json "structure"가 없음: 보고서 유형을 고른다(' + ', '.join(k for k in STRUCTURES if k[0] != '_')
                + ', 또는 "none")']
    if settings.structure == 'none':
        return []
    spec = STRUCTURES.get(settings.structure)
    if spec is None:
        return [f'알 수 없는 구조 틀: {settings.structure}']
    found = []
    units = {}
    for r in kept:
        unit = r.get('작업', '').strip()
        roles = [role for role in spec['roles'] if role in r.get('구분', '')]
        if not unit:
            found.append(f"성과 {r.get('번호', '?')}: 작업 칸이 비어 있음")
            continue
        if len(roles) != 1:
            found.append(f"성과 {r.get('번호', '?')}: 구분은 {'/'.join(spec['roles'])} 중 하나만 적는다(지금 '{r.get('구분', '')}')")
        units.setdefault(unit, []).append((roles[0] if roles else None, r))
    for unit, rows in units.items():
        present = {role for role, _ in rows}
        missing = [role for role in spec['required'] if role not in present]
        if missing:
            found.append(f"작업 '{unit}'에 {', '.join(missing)} 성과가 없음(구조 틀 {settings.structure})")
        unit_figures = [f for f in figures if f.get('작업', '').strip() == unit and not f.get('제외 이유', '').strip()]
        roles = [f.get('역할', '') for f in unit_figures]
        if spec['figures']['method'] and not any(any(m in role for m in spec['figures']['method']) for role in roles):
            found.append(f"작업 '{unit}'에 {'·'.join(spec['figures']['method'])} 그림이 없음")
        measured = any(role == '결과' and r.get('핵심 수치', '').strip() for role, r in rows)
        if measured and not any(spec['figures']['result'] in role for role in roles):
            found.append(f"작업 '{unit}'에 결과 그림이 없음(결과 수치가 있는 작업)")
    return found


def section_blocks(blocks, section):
    """Blocks under the first heading whose text contains section, up to the next heading of the same or a
    higher level (None when no heading matches)."""
    for i, b in enumerate(blocks):
        if b['type'].startswith('heading') and section in squeeze(b['text']):
            level = b['type']
            end = next((j for j in range(i + 1, len(blocks)) if blocks[j]['type'].startswith('heading')
                        and blocks[j]['type'] <= level), len(blocks))
            return blocks[i + 1:end]
    return None


def page_check_findings(settings, pages):
    """Pages of the render that the page-by-page record (report.json "pageCheck") does not cover."""
    if not settings.page_check:
        return ['쪽별 확인 기록 파일이 설정되지 않음(report.json "pageCheck")']
    if not settings.page_check.exists():
        return [f'쪽별 확인 기록 없음: {settings.rel(settings.page_check)}(렌더한 쪽 이미지를 보고 쪽마다 적는다)']
    seen = set()
    for table in markdown_tables(settings.page_check.read_text()):
        for r in table:
            number = re.sub(r'\D', '', r.get('쪽', ''))
            if number and r.get('본 것', '').strip():
                seen.add(int(number))
    missing = [n for n in range(1, pages + 1) if n not in seen]
    return [f"쪽별 확인 기록에 없는 쪽: {', '.join(map(str, missing))}"] if missing else []


def image_info(path):
    """Pixels and the pHYs resolution of a PNG figure (the engine takes PNG only)."""
    data = Path(path).read_bytes()
    if not data.startswith(b'\x89PNG'):
        raise ValueError(f'{path}: not a PNG')
    width, height = struct.unpack('>II', data[16:24])
    dpi = None
    pos = 8
    while pos < len(data):
        length = struct.unpack('>I', data[pos:pos + 4])[0]
        kind = data[pos + 4:pos + 8]
        if kind == b'pHYs':
            ppu_x, _, unit = struct.unpack('>IIB', data[pos + 8:pos + 17])
            if unit == 1:
                dpi = ppu_x * 0.0254
            break
        if kind == b'IDAT':
            break
        pos += 12 + length
    return {'kind': 'png', 'width': width, 'height': height, 'bytes': len(data), 'dpi': dpi,
            'natural_px': width * 96 / dpi if dpi else None}


PRINT_DPI_MIN = 300

# ---------------------------------------------------------------- engine and render

VALIDATE_JS = ("import { validateDraft } from '%s';"
               "import { readFileSync } from 'node:fs';"
               "const r = validateDraft(JSON.parse(readFileSync(0, 'utf8')), process.argv[1]);"
               "process.stdout.write(JSON.stringify(r));")


def validate(draft, root):
    """The engine's own draft validator (same rules as the HWPX generation)."""
    engine = ENGINE / 'lib/validate.js'
    result = subprocess.run(['node', '--input-type=module', '-e', VALIDATE_JS % engine.as_uri(), str(root)],
                            input=json.dumps(draft, ensure_ascii=False), capture_output=True, text=True, check=True)
    return json.loads(result.stdout)['errors']


COUNTERS_JS = ("import { outlineCounters, readSectionXml } from '%s';"
               "import { detectForm } from '%s';"
               "const xml = readSectionXml(process.argv[1]);"
               "process.stdout.write(JSON.stringify(outlineCounters(xml, detectForm(xml))));")


def report_counters(hwpx):
    """The outline numbers already used in a report's body (the engine goes on from them)."""
    script = COUNTERS_JS % ((ENGINE / 'lib/hwpx-read.js').as_uri(), (ENGINE / 'lib/forms.js').as_uri())
    result = subprocess.run(['node', '--input-type=module', '-e', script, str(hwpx)],
                            capture_output=True, text=True, check=True)
    return json.loads(result.stdout)


def render(draft_path, out_dir, root, base=None):
    out_dir.mkdir(parents=True, exist_ok=True)
    env = {**os.environ, **({'REPORT_BASE': str(base)} if base else {})}
    subprocess.run([str(TOOLS / 'preview_pdf.sh'), str(draft_path), str(root), str(out_dir)], check=True, env=env)
    result = subprocess.run(['node', str(TOOLS / 'check_render.mjs'), str(out_dir / 'candidate.hwpx')],
                            check=True, capture_output=True, text=True)
    return json.loads(result.stdout)


def paragraph_map(blocks):
    """Block number (1-based) of each top-level body paragraph the engine writes, in order."""
    owners = []
    for n, block in enumerate(blocks, 1):
        if block['type'] == 'table':
            owners += [n, n] if block.get('caption') else [n]
        elif block['type'] == 'figure_grid' and block.get('captionStyle') != 'angle':
            owners += [n, n]
        else:
            owners.append(n)
    return owners


OUTLINE_LABEL = re.compile(r'^(?:[가-하]\.|\d+\)|\(\d+\))\s')


def layout_findings(blocks, checks, root):
    owners = paragraph_map(blocks)
    # the body may start with form paragraphs or an earlier report; the first block's text marks the draft.
    # Outline numbers are left out of the match: a continuation goes on from the report's numbers.
    unlabel = lambda t: OUTLINE_LABEL.sub('', t)  # noqa: E731
    first = unlabel(rendered_labels(blocks)[0] or '')[:12]
    texts = [unlabel(t.replace('&lt;', '<').replace('&gt;', '>').replace('&amp;', '&')) for t in checks['bodyTexts']]
    # the draft is the last thing in the body, so take the last match that leaves room for all its paragraphs
    offset = next((i for i in range(len(texts) - len(owners), -1, -1) if first and texts[i].startswith(first)), None)
    found = []
    if offset is None:
        found.append('렌더 문단과 초안 block을 맞추지 못해 쪽 끝 고립을 block 번호로 표시하지 못함')

    def owner(paragraph):
        k = paragraph - offset if offset is not None else -1
        return owners[k] if 0 <= k < len(owners) else '?'
    for v in checks['keepViolations']:
        found.append(f"{v['page']}쪽 끝에 다음 내용과 떨어진 제목·표 제목: block {owner(v['paragraph'])}")
    for paragraph in checks.get('overflow', []):
        found.append(f"쪽 아래 여백을 넘어 그려진 표·그림: block {owner(paragraph)}")
    for paragraph in checks.get('lineOverflow', []):
        found.append(f"미리보기에서 아래 여백에 걸린 글줄(rhwp 줄 배치, 한컴에서 확인): block {owner(paragraph)}")
    for paragraph in checks.get('splitTables', []):
        found.append(f"한 쪽에 들어가는 표가 두 쪽에 걸쳐 그려짐: block {owner(paragraph)}")
    if checks.get('summarySplit'):
        found.append('본문 끝의 양식 표가 두 쪽에 걸쳐 그려짐')
    for paragraph in checks.get('unresolved', []):
        found.append(f"렌더 결과에서 쪽을 판독하지 못한 문단: block {owner(paragraph)}")
    stats = checks['pageStats']
    for s, nxt in zip(stats, stats[1:]):
        if s['fill'] < 0.75 and nxt['first'] and nxt['first']['kind'] in ('table', 'image'):
            found.append(f"{s['page']}쪽이 {s['fill']:.0%}만 차고 다음 쪽이 표·그림으로 시작함")
    for s in stats:
        if s['fill'] > 1.005:
            found.append(f"{s['page']}쪽 내용이 아래 여백을 넘음(잘려 보일 수 있음)")
        if s['textRuns'] == 0 and s['controls'] == 0:
            found.append(f"{s['page']}쪽에 본문 없음(양식 표만 있거나 빈 쪽)")
    rendered_images = checks['images']
    ordered = [img for b in blocks if b['type'] == 'figure_grid' for img in b['images']]
    # a continued report also draws the earlier report's pictures: compare the last ones
    if len(rendered_images) >= len(ordered):
        for img, placed in zip(ordered, rendered_images[len(rendered_images) - len(ordered):]):
            info = image_info(root / img)
            # placed width in inches at print size (the layout reports 96 px per inch)
            printed_in = placed['widthPx'] / 96
            if info['natural_px']:
                scale = placed['widthPx'] / info['natural_px']
                if scale < 0.95:
                    found.append(f"{img}: 그린 크기의 {scale:.0%}로 축소되어 그림 글자가 작아짐. 8 pt로 그린 글자는 "
                                 f"약 {8 * scale:.1f} pt가 됨. 인쇄 폭으로 다시 그린다({placed['page']}쪽)")
            else:
                found.append(f'{img}: 그린 크기 정보가 없어 그림 글자 크기를 추정하지 못함({placed["page"]}쪽)')
            if info['width'] / printed_in < PRINT_DPI_MIN:
                found.append(f"{img}: 인쇄 해상도 약 {info['width'] / printed_in:.0f} dpi"
                             f"(권장 {PRINT_DPI_MIN} dpi 이상, {placed['page']}쪽)")
    else:
        found.append(f'렌더 이미지 {len(rendered_images)}개가 초안 이미지 {len(ordered)}개보다 적어 그림 크기 점검을 건너뜀')
    return found

# ---------------------------------------------------------------- preview


def rendered_labels(blocks, start=None):
    """Block text with the outline numbers the engine adds; start: numbers already used (continuation)."""
    counters = list(start or [0, 0, 0])
    ordinals = '가나다라마바사아자차카타파하'
    out = []
    for block in blocks:
        t = block['type']
        if t.startswith('heading'):
            level = int(t[-1]) - 1
            k = counters[level]
            counters[level] += 1
            for deeper in range(level + 1, 3):
                counters[deeper] = 0
            label = f'{ordinals[k]}.' if level == 0 else (f'{k + 1})' if level == 1 else f'({k + 1})')
            out.append(f"{label} {block['text']}")
        elif t == 'statement':
            out.append(f"◯ {block['text']}")
        elif t == 'detail':
            out.append(f"- {block['text']}")
        else:
            out.append(None)
    return out


def preview(settings, draft, blocks, text_found, source_found, form, layout, out_md, draft_path=None,
            content=None, continuation=False, start=None, coverage=(), counts=None):
    lines = []
    add = lines.append
    here = out_md.parent
    draft_path = draft_path or settings.draft
    nfig = sum(b['type'] == 'figure_grid' for b in blocks)
    ntab = sum(b['type'] == 'table' for b in blocks)
    draft_link = os.path.relpath(draft_path, here)
    add(f'# {settings.title} {"이어쓰기 " if continuation else ""}초안 미리보기 (승인 전)')
    add('')
    add(f'- 초안: [`{draft_path.name}`]({draft_link}), 양식 `{draft.get("template", "(대상 문서의 양식)")}`, '
        f'block {len(blocks)}개, 그림 {nfig}개, 표 {ntab}개. 원고는 `{settings.rel(content or settings.content)}`.')
    if continuation:
        add('- **이어쓰기:** 현재 정본의 본문 끝에 이 block들만 더한다. 양식 칸은 채우지 않는다. '
            f'제목 번호는 정본에 있는 번호에 이어서 매긴다(정본 끝의 번호 {start}).')
    if settings.target:
        add(f'- 상태: **사용자 승인 전.** 승인 전에는 정본 HWPX(`{settings.rel(settings.target)}`)를 만들지 않는다.')
    add('')
    add('## 자동 점검')
    add('')
    add('작업 기록 어휘·내부 표기·영문 약어·도구와 모델 이름은 후보다. 문맥상 필요한 것은 남기고 나머지는 고친다.')
    add('')
    if text_found:
        add('| block | 종류 | 찾은 표현 |')
        add('|---|---|---|')
        for n, kind, term in text_found:
            add(f'| {n} | {kind} | `{term}` |')
    else:
        add('- 본문 표현 후보 없음')
    add('')
    if source_found:
        add('| block | 근거 점검 | 경로 |')
        add('|---|---|---|')
        for n, kind, path in source_found:
            add(f'| {n} | {kind} | `{path}` |')
    else:
        add('- 근거 경로 문제 없음')
    add('')
    add('## 성과 대응 점검')
    add('')
    if counts:
        add(f"- 성과 목록 `{settings.rel(settings.achievements)}`: 넣을 성과 {counts['results']}개, "
            f"뺀 성과 {counts['excluded']}개, 그림 계획 {counts['figures']}개.")
    if coverage:
        for item in coverage:
            add(f'- {item}')
    else:
        add('- 성과 목록의 성과·핵심 수치·그림이 모두 원고에 있음')
    add('')
    add('## 렌더 점검')
    add('')
    if layout is None:
        add('- 이번 빌드에서는 렌더하지 않았다(`--render`로 실행).')
    elif layout['findings']:
        add(f"- {layout['pages']}쪽(양식 포함).")
        for item in layout['findings']:
            add(f'- {item}')
    else:
        add(f"- {layout['pages']}쪽(양식 포함). 쪽 끝 고립·공백·그림 축소 후보 없음.")
    add('')
    spec = form_spec(draft.get('template'))
    if form:
        add('## 양식 칸')
        add('')
        add('엔진이 초안의 `form`으로 양식의 칸을 채운다(비어 있을 때만).')
        add('')
        if form.get('title'):
            add(f"**제목**: {form['title']}")
            add('')
        for key in ('goals', 'summary'):
            rows = form.get(key)
            if not rows:
                continue
            table = spec.get('tables', {}).get(key, {})
            headers = table.get('labels') or [f'열 {i + 1}' for i in range(len(rows[0]))]
            add(f"**{table.get('title', key)}**")
            add('')
            add('| ' + ' | '.join(headers) + ' |')
            add('|' + '---|' * len(headers))
            for row in rows:
                add('| ' + ' | '.join(row) + ' |')
            add('')
    add('## 본문(엔진이 붙이는 번호 포함)')
    add('')
    for n, (block, label) in enumerate(zip(blocks, rendered_labels(blocks, start)), 1):
        t = block['type']
        if t == 'heading1':
            add(f'### {label}')
        elif t == 'heading2':
            add(f'#### {label}')
        elif t == 'heading3':
            add(f'**{label}**')
        elif t in ('statement', 'detail'):
            add(f"{'' if t == 'statement' else '&nbsp;&nbsp;'}{label} <sub>[{n}]</sub>")
        elif t == 'figure_grid':
            thumbs = []
            for img in block['images']:
                info = image_info(settings.root / img)
                rel = os.path.relpath(settings.root / img, here)
                thumbs.append(f'<img src="{rel}" width="{560 // len(block["images"])}" alt="{block["caption"][:30]}">')
                dpi = f", {info['dpi']:.0f} dpi" if info['dpi'] else ''
                add(f"`{img}` {info['width']}×{info['height']}px{dpi}  ")
            add(' '.join(thumbs))
            add(f'<p align="center">&lt;{block["caption"]}&gt; <sub>[{n}]</sub></p>')
        elif t == 'table':
            add(f'<p align="center">&lt;{block["caption"]}&gt; <sub>[{n}]</sub></p>')
            add('')
            add('| ' + ' | '.join(block['headers']) + ' |')
            add('|' + '---|' * len(block['headers']))
            for row in block['rows']:
                add('| ' + ' | '.join(c.replace('|', '/') for c in row) + ' |')
        add('')
    add('## 근거 대응표')
    add('')
    add('| block | 종류 | 근거 |')
    add('|---|---|---|')
    for n, block in enumerate(blocks, 1):
        if block.get('source'):
            note = ' (제목에서 이어받음)' if block.get('_inherited') else ''
            add(f"| {n} | {block['type']} | {block['source'].replace('|', '/')}{note} |")
    add('')
    return '\n'.join(lines) + '\n'


def continuation_paths(settings):
    """Draft and preview names of a continuation, next to the full draft (which stays untouched)."""
    return (settings.draft.with_name(f'{settings.draft.stem}.continue.json'),
            settings.preview.with_name(f'{settings.preview.stem}.continue.md'))


def build(settings, date=None, render_dir=None, out_dir=None, content=None, base=None, continuation=False):
    """continuation: a draft of new chapters only (content), to append to the current report. It fills no
    form parts, is written to <draft>.continue.json unless out_dir is given, and renders on the target."""
    if continuation:
        if content is None or Path(content).resolve() == settings.content.resolve():
            raise SystemExit('a continuation needs --content with the new chapters only (not the whole manuscript)')
        base = base or settings.target
        if base is None or not Path(base).exists():
            raise SystemExit(f'a continuation appends to an existing report; {base} does not exist')
        start = report_counters(base)
    else:
        start = None
    content = content or settings.content
    json_default, md_default = continuation_paths(settings) if continuation else (settings.draft, settings.preview)
    out_json = out_dir / json_default.name if out_dir else json_default
    out_md = out_dir / md_default.name if out_dir else md_default
    out_json.parent.mkdir(parents=True, exist_ok=True)

    facts = load_facts(settings)
    files = sorted(content.glob('[0-9][0-9]-*.md'))
    if not files:
        raise SystemExit(f'no manuscript files (NN-name.md) in {content}')
    blocks = inherit_sources([b for f in files for b in parse(f, facts)])
    form_file = content / 'form.json'
    raw_form = {} if continuation else load_form(form_file)
    form = {}
    for key, value in raw_form.items():
        if isinstance(value, str):
            form[key] = _fill(value, facts, f'{form_file.name}:{key}')
        else:
            form[key] = [[_fill(c, facts, f'{form_file.name}:{key}') for c in row] for row in value]

    session = {'date': date or dt.date.today().isoformat(), 'project': settings.project}
    clean = [{k: v for k, v in b.items() if not k.startswith('_')} for b in blocks]
    draft = {'session': session, **({'template': settings.template} if settings.template else {}),
             'blocks': clean, **({'form': form} if form else {})}
    errors = validate(draft, settings.root)
    if errors:
        raise SystemExit('draft validation failed (nothing written):\n' + '\n'.join(errors))
    out_json.write_text(json.dumps(draft, ensure_ascii=False, indent=1) + '\n')

    text_found = text_checks(blocks, form, settings)
    source_found = source_checks(blocks, settings)
    coverage, counts = achievement_checks(settings, blocks, form)
    coverage += form_cell_findings(form) + facts_findings(settings, facts, blocks)
    layout = None
    if render_dir:
        checks = render(out_json, render_dir, settings.root, base)
        findings = layout_findings(blocks, checks, settings.root) + page_check_findings(settings, checks['pages'])
        layout = {'pages': checks['pages'], 'findings': findings}
        (render_dir / 'layout-checks.json').write_text(json.dumps(checks, ensure_ascii=False, indent=1))
    out_md.write_text(stamped(preview(settings, draft, blocks, text_found, source_found, form, layout, out_md,
                                      out_json, content, continuation, start, coverage, counts)))
    return {'blocks': len(blocks), 'text': len(text_found), 'sources': len(source_found), 'layout': layout,
            'coverage': len(coverage), 'draft': out_json, 'preview': out_md}


STAMP = re.compile(r'\n<!-- build_report sha256:([0-9a-f]{64}) -->\n$')


def stamped(text):
    """The preview with a closing hash of its own text: the checks it reports are the tool's, not edited."""
    import hashlib
    return f"{text}\n<!-- build_report sha256:{hashlib.sha256(text.encode()).hexdigest()} -->\n"


def preview_intact(path):
    """True when the preview is as the tool wrote it, False when edited, None when there is none."""
    import hashlib
    path = Path(path)
    if not path.exists():
        return None
    text = path.read_text()
    m = STAMP.search(text)
    return bool(m) and hashlib.sha256(text[:m.start()].encode()).hexdigest() == m.group(1)


FORM_CELL_MAX = 40


NUMBER = re.compile(r'\d[\d,.]*\s*(?:%|개|건|셀|분|배|종|명|회|km|mg/L|pt|쪽)')


def facts_findings(settings, facts, blocks):
    """Measured numbers written by hand when the facts module gives nothing (or is missing)."""
    if facts:
        return []
    count = sum(len(NUMBER.findall(block_text(b))) for b in blocks if not b.get('_env'))
    if count >= 5:
        return [f'원고에 수치 {count}개가 있으나 facts 모듈이 값을 주지 않음. 결과 파일에서 계산해 {{{{이름}}}}으로 넣는다']
    return []


def form_cell_findings(form):
    """Form table cells long enough to wrap into many lines in a narrow column (keep them short)."""
    found = []
    for r, row in enumerate((form or {}).get('summary', []), 1):
        for c, text in enumerate(row, 1):
            if len(text) > FORM_CELL_MAX:
                found.append(f'양식 요약표 {r}행 {c}열이 {len(text)}자임({FORM_CELL_MAX}자 이하로 줄이고 설명은 본문으로)')
    return found


def main():
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument('--config', type=Path, required=True, help="the project's report settings (report.json)")
    parser.add_argument('--root', type=Path, help='project root (default: git top level of the settings file)')
    parser.add_argument('--render', type=Path, help='output folder outside the repository for the page render')
    parser.add_argument('--base', type=Path, help='render the draft appended to this HWPX (default: the form skeleton)')
    parser.add_argument('--date', default=None, help='session date (default: today)')
    parser.add_argument('--out-dir', type=Path, help='write the draft JSON and preview here instead')
    parser.add_argument('--content', type=Path, help='manuscript folder (default: from the settings)')
    parser.add_argument('--continue', dest='continuation', action='store_true',
                        help='draft only the new chapters in --content to append to the current report '
                             '(no form parts; written to <draft>.continue.json; renders on the target)')
    args = parser.parse_args()
    settings = Settings(args.config, args.root)
    result = build(settings, args.date, args.render, args.out_dir, args.content, args.base, args.continuation)
    layout = result['layout']
    print(f"{result['blocks']} blocks; text candidates {result['text']}; source issues {result['sources']}; "
          f"coverage findings {result['coverage']}"
          + (f"; pages {layout['pages']}; layout findings {len(layout['findings'])}" if layout else ''))


if __name__ == '__main__':
    main()
