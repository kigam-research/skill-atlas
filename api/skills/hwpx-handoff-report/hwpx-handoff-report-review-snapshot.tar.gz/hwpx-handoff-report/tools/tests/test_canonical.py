"""Canonical report commands: regenerate, golden, restore (rhwp verification replaced by a stub)."""
import json
import os
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

TOOLS = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(TOOLS))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import canonical  # noqa: E402
from test_build_report import project  # noqa: E402

APPEND = {'session': {'date': '2026-09-30', 'project': 'demo'},
          'blocks': [{'type': 'heading1', 'text': '추가 결과', 'source': 'data/results.csv'},
                     {'type': 'statement', 'text': '추가한 결과를 정리하였음.', 'source': 'data/results.csv'}]}


class CanonicalTest(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.tmp)
        self.settings = project(self.tmp, form={'title': '시험 보고서'})
        self.target = self.settings.target
        verifier = self.tmp / 'verify.sh'
        verifier.write_text('#!/usr/bin/env bash\nset -e\nprintf PDF > "$2"\n')
        verifier.chmod(0o755)
        saved = os.environ.get('HWPX_VERIFY_CMD')
        os.environ['HWPX_VERIFY_CMD'] = str(verifier)
        self.addCleanup(lambda: os.environ.pop('HWPX_VERIFY_CMD', None) if saved is None
                        else os.environ.__setitem__('HWPX_VERIFY_CMD', saved))

    def journal(self):
        return [json.loads(line) for line in self.settings.journal.read_text().splitlines()]

    def append(self, draft=APPEND, name='append.json'):
        """An engine CLI append, as a continuation would do it."""
        path = self.tmp / 'report' / name
        path.write_text(json.dumps(draft, ensure_ascii=False))
        subprocess.run(['node', str(canonical.CLI), '--draft', str(path), '--target', str(self.target),
                        '--project-root', str(self.tmp)], check=True, capture_output=True)
        return path

    def test_regenerate_creates_then_replaces_with_a_backup(self):
        first = canonical.regenerate(self.settings, date='2026-09-29', stamp='20260929T000000Z')
        self.assertTrue(self.target.exists())
        self.assertTrue(Path(f'{self.target}.preview.pdf').exists())
        self.assertIsNone(first['backup'])
        self.assertEqual(first['draft'], 'report/drafts/report-20260929T000000Z.json')
        (self.settings.content / '10-overview.md').write_text(
            (self.settings.content / '10-overview.md').read_text() + '◯ 추가한 문장임.\n> src: data/method.md\n')
        second = canonical.regenerate(self.settings, expect_sha=first['sha256'], date='2026-09-29',
                                      stamp='20260929T000100Z')
        self.assertEqual(second['replaced'], first['sha256'])
        self.assertTrue((self.target.parent / 'backup' / 'report.bak-prerewrite-20260929T000100Z.hwpx').exists())
        self.assertEqual(canonical.sha256(self.target), second['sha256'])
        lines = self.journal()
        self.assertEqual([line['rewrite'] for line in lines], [True, True])
        self.assertEqual(lines[1]['sha256Before'], first['sha256'])
        self.assertEqual(lines[1]['form'], 'research-report')
        self.assertEqual(lines[1]['target'], 'report/report.hwpx')
        self.assertEqual(lines[1]['draft'], 'report/drafts/report-20260929T000100Z.json')
        self.assertEqual(list(self.target.parent.glob('.regen-*')), [])

    def test_a_failed_run_replaces_nothing_and_keeps_the_failed_candidate(self):
        first = canonical.regenerate(self.settings, date='2026-09-29', stamp='20260929T000000Z')
        failing = self.tmp / 'fail.sh'
        failing.write_text('#!/usr/bin/env bash\nprintf PDF > "$2"\nexit 1\n')
        failing.chmod(0o755)
        os.environ['HWPX_VERIFY_CMD'] = str(failing)
        with self.assertRaises(SystemExit) as caught:
            canonical.regenerate(self.settings, date='2026-09-29', stamp='20260929T000200Z')
        self.assertIn('engine exit 4', str(caught.exception))
        self.assertEqual(canonical.sha256(self.target), first['sha256'])
        work = self.target.parent / '.regen-20260929T000200Z'
        self.assertIn('verify failed', (work / 'engine.log').read_text())
        self.assertTrue((work / 'report.hwpx.failed.hwpx').exists())
        self.assertEqual(len(self.journal()), 1)
        self.assertFalse(Path(f'{self.target}.lock').exists())

    def test_a_failure_after_the_replacement_exits_5_and_prints_the_journal_line(self):
        canonical.regenerate(self.settings, date='2026-09-29', stamp='20260929T000000Z')
        self.settings.journal = self.tmp / 'journal-is-a-folder'
        self.settings.journal.mkdir()
        with self.assertRaises(SystemExit) as caught:
            canonical.regenerate(self.settings, date='2026-09-29', stamp='20260929T000100Z')
        self.assertEqual(caught.exception.code, canonical.PARTIAL)
        self.assertTrue((self.target.parent / 'backup' / 'report.bak-prerewrite-20260929T000100Z.hwpx').exists())
        self.assertFalse(Path(f'{self.target}.lock').exists())

    def test_a_preview_edited_by_hand_stops_regeneration(self):
        canonical.regenerate(self.settings, date='2026-09-29', stamp='20260929T000000Z')
        preview = self.settings.preview
        preview.write_text(preview.read_text().replace('## 자동 점검', '## 자동 점검\n- 문제 없음', 1))
        with self.assertRaises(SystemExit) as caught:
            canonical.regenerate(self.settings, date='2026-09-29', stamp='20260929T000100Z')
        self.assertIn('was edited after build_report wrote it', str(caught.exception))
        self.assertFalse(Path(f'{self.target}.lock').exists())

    def test_wrong_expected_sha_and_held_lock_are_refused(self):
        canonical.regenerate(self.settings, date='2026-09-29', stamp='20260929T000000Z')
        with self.assertRaises(SystemExit):
            canonical.regenerate(self.settings, expect_sha='0' * 64, date='2026-09-29')
        Path(f'{self.target}.lock').write_text('{}')
        with self.assertRaises(SystemExit) as caught:
            canonical.regenerate(self.settings, date='2026-09-29')
        self.assertIn('LockHeld', str(caught.exception))
        with self.assertRaises(SystemExit) as caught:
            canonical.golden(self.settings, '확인')
        self.assertIn('LockHeld', str(caught.exception))

    def test_golden_pairs_the_report_with_every_draft_that_made_it(self):
        made = canonical.regenerate(self.settings, date='2026-09-29', stamp='20260929T000000Z')
        with self.assertRaises(SystemExit):
            canonical.golden(self.settings, '')
        added = self.append()
        entry = canonical.golden(self.settings, '사용자 한컴 확인 2026-09-30', stamp='20260930T000000Z')
        self.assertEqual([d['path'] for d in entry['drafts']],
                         ['report/golden-draft-report-20260930T000000Z-01.json',
                          'report/golden-draft-report-20260930T000000Z-02.json'])
        self.assertEqual(entry['drafts'][0]['sha256'], canonical.sha256(self.tmp / made['draft']))
        self.assertEqual(entry['drafts'][1]['sha256'], canonical.sha256(added))
        self.assertEqual(entry['golden'], 'report/report.golden-20260930T000000Z.hwpx')
        self.assertEqual(canonical.sha256(self.tmp / entry['golden']), canonical.sha256(self.target))
        self.assertEqual(entry['preview'], 'report/report.golden-20260930T000000Z.preview.pdf')
        self.assertTrue((self.tmp / entry['preview']).exists())
        # each report keeps its own record, so two reports in one folder never write the same file
        self.assertEqual(json.loads((self.target.parent / 'report.golden.json').read_text())[0]['confirmed'],
                         '사용자 한컴 확인 2026-09-30')
        with self.assertRaises(SystemExit):  # golden drafts are never overwritten
            canonical.golden(self.settings, '확인', stamp='20260930T000000Z')

    def test_golden_refuses_a_changed_draft_unless_the_original_is_given(self):
        canonical.regenerate(self.settings, date='2026-09-29', stamp='20260929T000000Z')
        added = self.append()
        original = self.tmp / 'kept.json'
        shutil.copy2(added, original)
        added.write_text(json.dumps({**APPEND, 'session': {'date': '2026-10-01', 'project': 'demo'}}))
        with self.assertRaises(SystemExit) as caught:
            canonical.golden(self.settings, '확인', stamp='20260930T000000Z')
        self.assertIn('report/append.json', str(caught.exception))
        entry = canonical.golden(self.settings, '확인', drafts=[original], stamp='20260930T000001Z')
        self.assertEqual(len(entry['drafts']), 2)

    def test_golden_refuses_a_file_changed_outside_the_engine(self):
        canonical.regenerate(self.settings, date='2026-09-29', stamp='20260929T000000Z')
        self.target.write_bytes(b'edited outside the engine')
        with self.assertRaises(SystemExit) as caught:
            canonical.golden(self.settings, '확인')
        self.assertIn('not the last file the journal recorded', str(caught.exception))

    def test_restore_checks_the_golden_copy_and_records_itself(self):
        made = canonical.regenerate(self.settings, date='2026-09-29', stamp='20260929T000000Z')
        canonical.golden(self.settings, '확인', stamp='20260929T000001Z')
        self.append()
        Path(f'{self.target}.preview.pdf').write_text('preview of the appended file')
        canonical.restore(self.settings, stamp='20260929T000300Z')
        self.assertEqual(canonical.sha256(self.target), made['sha256'])
        self.assertEqual(Path(f'{self.target}.preview.pdf').read_text(), 'PDF')
        self.assertTrue((self.target.parent / 'backup' / 'report.bak-restore-20260929T000300Z.hwpx').exists())
        last = self.journal()[-1]
        self.assertTrue(last['restore'])
        self.assertEqual(last['sha256After'], made['sha256'])
        # a golden copy after a restore pairs with the restored golden drafts
        again = canonical.golden(self.settings, '다시 확인', stamp='20260929T000400Z')
        self.assertEqual(len(again['drafts']), 1)
        (self.tmp / again['golden']).write_bytes(b'damaged')
        with self.assertRaises(SystemExit) as caught:
            canonical.restore(self.settings)
        self.assertIn('not the file the golden record names', str(caught.exception))

    def test_a_failed_golden_run_keeps_the_previous_golden_version(self):
        made = canonical.regenerate(self.settings, date='2026-09-29', stamp='20260929T000000Z')
        first = canonical.golden(self.settings, '확인', stamp='20260929T000001Z')
        self.append()
        saved = canonical.write_atomic

        def broken(path, text):
            raise OSError('disk full')
        canonical.write_atomic = broken
        self.addCleanup(setattr, canonical, 'write_atomic', saved)
        with self.assertRaises(OSError):
            canonical.golden(self.settings, '다시 확인', stamp='20260929T000002Z')
        canonical.write_atomic = saved
        self.assertEqual(sorted(p.name for p in self.target.parent.glob('*20260929T000002Z*')), [])
        self.assertFalse(Path(f'{self.target}.lock').exists())
        canonical.restore(self.settings, stamp='20260929T000003Z')  # the first golden version is intact
        self.assertEqual(canonical.sha256(self.target), made['sha256'])
        self.assertEqual(first['sha256'], made['sha256'])

    def test_a_restore_that_fails_after_the_replacement_exits_5(self):
        made = canonical.regenerate(self.settings, date='2026-09-29', stamp='20260929T000000Z')
        canonical.golden(self.settings, '확인', stamp='20260929T000001Z')
        self.append()
        self.settings.journal = self.tmp / 'journal-is-a-folder'
        self.settings.journal.mkdir()
        with self.assertRaises(SystemExit) as caught:
            canonical.restore(self.settings, stamp='20260929T000002Z')
        self.assertEqual(caught.exception.code, canonical.PARTIAL)
        self.assertEqual(canonical.sha256(self.target), made['sha256'])
        self.assertFalse(Path(f'{self.target}.lock').exists())

    def test_records_of_older_versions_are_read_only_where_they_cannot_be_another_reports(self):
        made = canonical.regenerate(self.settings, date='2026-09-29', stamp='20260929T000000Z')
        folder = self.target.parent
        # an older journal line with only the file name, in the default journal next to the report
        lines = self.settings.journal.read_text().splitlines()
        old = {**json.loads(lines[-1]), 'target': 'report.hwpx'}
        self.settings.journal.write_text(json.dumps(old) + '\n')
        self.assertEqual(len(canonical.journal_entries(self.settings)), 1)
        # the same line in a shared journal elsewhere could be another folder's report.hwpx
        self.settings.journal = self.tmp / 'shared-journal.jsonl'
        self.settings.journal.write_text(json.dumps(old) + '\n')
        self.assertEqual(canonical.journal_entries(self.settings), [])
        # a shared golden.json of that time names no report: only the record of this report's golden file counts
        shutil.copy2(self.target, folder / 'report.golden.hwpx')
        shutil.copy2(self.target, folder / 'other.golden.hwpx')
        (folder / 'golden.json').write_text(json.dumps([
            {'golden': 'report/report.golden.hwpx', 'sha256': made['sha256'], 'draft': made['draft'],
             'draftSha256': canonical.sha256(self.tmp / made['draft'])},
            {'golden': 'report/other.golden.hwpx', 'sha256': made['sha256']}]))
        self.assertEqual([e['golden'] for e in canonical.golden_history(self.settings)], ['report/report.golden.hwpx'])
        other = canonical.br.Settings(self.settings.path, self.tmp)
        other.target = folder / 'other.hwpx'
        self.assertEqual([e['golden'] for e in canonical.golden_history(other)], ['report/other.golden.hwpx'])
        third = canonical.br.Settings(self.settings.path, self.tmp)
        third.target = folder / 'third.hwpx'
        with self.assertRaises(SystemExit) as caught:
            canonical.restore(third)
        self.assertIn('no golden record for third.hwpx', str(caught.exception))


if __name__ == '__main__':
    unittest.main()
