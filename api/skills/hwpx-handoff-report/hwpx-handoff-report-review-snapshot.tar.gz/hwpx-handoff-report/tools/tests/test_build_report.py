"""Report builder: manuscript parsing, fact placeholders, text/source checks, layout mapping, settings.

    python3 -m unittest discover skills/hwpx-handoff-report/tools/tests
"""
import json
import shutil
import struct
import sys
import tempfile
import unittest
import zlib
from pathlib import Path

TOOLS = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(TOOLS))

import build_report as br  # noqa: E402

def _png(width, height):
    """A valid grey PNG (8-bit RGB) for figure blocks."""
    def chunk(kind, data):
        return struct.pack('>I', len(data)) + kind + data + struct.pack('>I', zlib.crc32(kind + data))
    raw = b''.join(b'\x00' + b'\x80\x80\x80' * width for _ in range(height))
    return (b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', width, height, 8, 2, 0, 0, 0))
            + chunk(b'IDAT', zlib.compress(raw)) + chunk(b'IEND', b''))


PNG = _png(40, 30)

MANUSCRIPT = """%% note, not printed
# 연구 개요
> src: data/results.csv
## 시험 방법
### 시편 제작
◯ 시편은 {{n_samples}}개를 제작하였음.
  이어지는 줄은 같은 문장에 붙음.
- 세부 문장임
> src: data/method.md
![시험 장치](fig/setup.png)
[표] 비교 {ratios=30,70}
| 항목 | 값 |
|---|---|
| 시편 | {{n_samples}}개 |
[표] 환경 {env}
| 구성 요소 | 도구 |
|---|---|
| 분석 | Python 3.12, gpt-5 |
"""


def project(tmp, template='research-report', form=None, extra_checks=None):
    """A synthetic project: settings, manuscript, facts, sources and one figure."""
    root = Path(tmp)
    (root / 'report/content').mkdir(parents=True)
    (root / 'data').mkdir()
    (root / 'fig').mkdir()
    (root / 'data/results.csv').write_text('a,b\n')
    (root / 'data/method.md').write_text('method\n')
    (root / 'fig/setup.png').write_bytes(PNG)
    (root / 'report/facts.py').write_text("def facts():\n    return {'n_samples': 24}\n")
    (root / 'report/content/10-overview.md').write_text(MANUSCRIPT)
    if form is not None:
        (root / 'report/content/form.json').write_text(json.dumps(form, ensure_ascii=False))
    settings = {'project': 'demo', 'title': '연구보고서', 'template': template, 'content': 'report/content',
                'draft': 'report/draft.json', 'preview': 'report/draft.preview.md', 'target': 'report/report.hwpx',
                'facts': 'report/facts.py', 'checks': extra_checks or {}}
    (root / 'report/report.json').write_text(json.dumps(settings, ensure_ascii=False))
    return br.Settings(root / 'report/report.json', root)


class BuilderTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.addCleanup(shutil.rmtree, self.tmp)

    def test_blocks_and_placeholders(self):
        settings = project(self.tmp)
        blocks = br.inherit_sources(br.parse(settings.content / '10-overview.md', br.load_facts(settings)))
        self.assertEqual([b['type'] for b in blocks],
                         ['heading1', 'heading2', 'heading3', 'statement', 'detail', 'figure_grid', 'table', 'table'])
        self.assertEqual(blocks[3]['text'], '시편은 24개를 제작하였음. 이어지는 줄은 같은 문장에 붙음.')
        self.assertEqual(blocks[5]['columns'], 1)
        self.assertEqual(blocks[6]['colWidthRatios'], [30.0, 70.0])
        self.assertEqual(blocks[6]['rows'], [['시편', '24개']])
        self.assertTrue(blocks[7].get('_env'))
        self.assertTrue(blocks[3]['_inherited'])
        self.assertNotIn('_inherited', blocks[4])

    def test_unknown_fact_and_bad_line_fail(self):
        bad = Path(self.tmp) / '20-bad.md'
        bad.write_text('◯ {{no_such_fact}}\n')
        with self.assertRaises(KeyError):
            br.parse(bad, {})
        bad.write_text('그냥 쓴 줄\n')
        with self.assertRaises(ValueError):
            br.parse(bad, {})

    def test_text_checks_generic_and_project_terms(self):
        settings = project(self.tmp, extra_checks={'worklog': ['묶음'], 'internalTerms': ['(?<![A-Za-z0-9])S[0-9](?![A-Za-z0-9])'],
                                                   'modelNames': ['luna'], 'allowTerms': ['AI']})
        blocks = br.inherit_sources(br.parse(settings.content / '10-overview.md', br.load_facts(settings)))
        blocks.append({'type': 'statement', 'text': '첫 실행에서 S3 묶음을 재실행하였음(a25e327에서 run_all.py, AI와 XRD, luna로 채점).'})
        found = {(kind, term) for _, kind, term in br.text_checks(blocks, None, settings)}
        for expected in [('작업 기록 어휘', '재실행'), ('작업 기록 어휘', '첫 실행'), ('작업 기록 어휘', '묶음'),
                         ('내부 기호·영문 약어', 'S3'), ('파일 이름', 'run_all.py'), ('commit·해시 형태', 'a25e327'),
                         ('영문 약어', 'XRD'), ('작업 도구·모델 이름(환경 표 밖)', 'luna')]:
            self.assertIn(expected, found)
        self.assertNotIn(('영문 약어', 'AI'), found, 'allowed term')
        units = br.text_checks([{'type': 'statement', 'text': '농도는 8.1 mg/L로, 유속은 2 m/s였음(자료는 data/raw/x에 둠).'}])
        self.assertEqual([term for _, kind, term in units if kind == '경로'], ['data/raw/x에'])
        # the environment table may name tools and models
        self.assertNotIn(('작업 도구·모델 이름(환경 표 밖)', 'gpt'), found)
        # a model that is itself studied is allowed in the text through allowTerms
        studied = project(Path(self.tmp) / 'studied', extra_checks={'allowTerms': ['Llama']})
        names = br.text_checks([{'type': 'statement', 'text': 'llama와 qwen을 비교하였음.'}], None, studied)
        self.assertEqual([term for _, _, term in names], ['qwen'])

    def test_form_parts_are_checked(self):
        found = br.text_checks([{'type': 'statement', 'text': '문장.'}], {'title': 'gpt로 만든 보고서'})
        self.assertTrue(any(str(n).startswith('양식 title') for n, _, _ in found))

    def test_source_checks(self):
        settings = project(self.tmp, extra_checks={'legacySources': ['data/old']})
        (Path(self.tmp) / 'data/old').mkdir()
        (Path(self.tmp) / 'data/old/x.csv').write_text('x')
        blocks = [{'type': 'statement', 'text': 'a', 'source': 'data/old/x.csv'},
                  {'type': 'statement', 'text': 'b', 'source': 'no/such/file.md'},
                  {'type': 'statement', 'text': 'c'}]
        self.assertEqual([kind for _, kind, _ in br.source_checks(blocks, settings)],
                         ['옛 판본 근거', '근거 경로 없음', '근거 없음'])

    def test_layout_findings_map_paragraphs_to_blocks(self):
        settings = project(self.tmp)
        blocks = br.inherit_sources(br.parse(settings.content / '10-overview.md', {'n_samples': 24}))
        texts = ['', '가. 연구 개요', '1) 시험 방법', '(1) 시편 제작', '◯ 시편은', '- 세부', '',
                 '&lt;비교&gt;', '', '&lt;환경&gt;', '']
        checks = {'bodyTexts': texts, 'keepViolations': [{'paragraph': 7, 'page': 1}], 'overflow': [8],
                  'lineOverflow': [4], 'unresolved': [], 'images': [], 'pageStats': [
                      {'page': 1, 'fill': 1.02, 'textRuns': 5, 'controls': 1, 'first': {'kind': 'text'}}]}
        found = br.layout_findings(blocks, checks, settings.root)
        self.assertIn('1쪽 끝에 다음 내용과 떨어진 제목·표 제목: block 7', found)
        self.assertIn('쪽 아래 여백을 넘어 그려진 표·그림: block 7', found)
        self.assertIn('미리보기에서 아래 여백에 걸린 글줄(rhwp 줄 배치, 한컴에서 확인): block 4', found)
        self.assertNotIn('본문 끝의 양식 표가 두 쪽에 걸쳐 그려짐', found)
        self.assertIn('본문 끝의 양식 표가 두 쪽에 걸쳐 그려짐',
                      br.layout_findings(blocks, {**checks, 'summarySplit': True}, settings.root))

    def test_build_writes_a_valid_draft_and_preview(self):
        settings = project(self.tmp, form={'title': '시편 {{n_samples}}개 시험 보고서'})
        result = br.build(settings, date='2026-09-29')
        draft = json.loads(settings.draft.read_text())
        self.assertEqual(draft['template'], 'research-report')
        self.assertEqual(draft['form'], {'title': '시편 24개 시험 보고서'})
        self.assertEqual(draft['session'], {'date': '2026-09-29', 'project': 'demo'})
        preview = settings.preview.read_text()
        self.assertIn('# 연구보고서 초안 미리보기 (승인 전)', preview)
        self.assertIn('**제목**: 시편 24개 시험 보고서', preview)
        self.assertIn('<img src="../fig/setup.png"', preview)
        self.assertEqual(result['blocks'], 8)

    def test_build_refuses_an_invalid_draft(self):
        settings = project(self.tmp, form={'goals': [['a', 'b', 'c']]})
        with self.assertRaises(SystemExit) as caught:
            br.build(settings, date='2026-09-29')
        self.assertIn('has no goals table', str(caught.exception))
        self.assertFalse(settings.draft.exists())

    def test_layout_findings_match_a_continuation_numbered_after_the_report(self):
        blocks = [{'type': 'heading1', 'text': '추가 결과'}, {'type': 'statement', 'text': '추가 문장임.'}]
        texts = ['가. 앞 절', '◯ 앞 문장임.', '나. 추가 결과', '◯ 추가 문장임.', '']
        checks = {'bodyTexts': texts, 'keepViolations': [{'paragraph': 2, 'page': 3}], 'overflow': [],
                  'lineOverflow': [], 'unresolved': [], 'images': [], 'pageStats': []}
        found = br.layout_findings(blocks, checks, Path(self.tmp))
        self.assertEqual(found, ['3쪽 끝에 다음 내용과 떨어진 제목·표 제목: block 1'])

    def test_continuation_drafts_new_chapters_only_without_form_parts(self):
        settings = project(self.tmp, form={'title': '제목'})
        new = Path(self.tmp) / 'report/continue'
        new.mkdir()
        (new / '40-added.md').write_text('# 추가 결과\n◯ 추가한 결과를 정리하였음.\n> src: data/results.csv\n')
        (new / 'form.json').write_text('{"title": "무시됨"}')
        with self.assertRaises(SystemExit):  # the whole manuscript is not a continuation
            br.build(settings, date='2026-09-30', content=settings.content, continuation=True)
        with self.assertRaises(SystemExit):  # nothing to continue yet
            br.build(settings, date='2026-09-30', content=new, continuation=True)
        # the example report has four 가.–라. sections, so the new heading1 is 마.
        settings.target.write_bytes((TOOLS.parent / 'examples/report.hwpx').read_bytes())
        result = br.build(settings, date='2026-09-30', content=new, continuation=True)
        self.assertEqual(result['draft'], settings.draft.with_name('draft.continue.json'))
        draft = json.loads(result['draft'].read_text())
        self.assertNotIn('form', draft)
        self.assertEqual([b['type'] for b in draft['blocks']], ['heading1', 'statement'])
        self.assertFalse(settings.draft.exists(), 'the full draft is left alone')
        self.assertIn('이어쓰기', result['preview'].read_text())
        self.assertIn('### 마. 추가 결과', result['preview'].read_text())

    def test_achievement_list_is_checked_against_the_manuscript(self):
        settings = project(self.tmp)
        blocks = br.inherit_sources(br.parse(settings.content / '10-overview.md', br.load_facts(settings)))
        found, _ = br.achievement_checks(settings, blocks, None)
        self.assertIn('report.json "achievements"', found[0])
        settings.achievements = Path(self.tmp) / 'report/achievements.md'
        settings.achievements.write_text("""# 성과 목록

| 번호 | 성과 | 구분 | 근거 | 절 | 핵심 수치 | 제외 이유 |
|---|---|---|---|---|---|---|
| 1 | 시편 제작 | 결과 | data/method.md | 시험 방법 | 24개 | |
| 2 | 강도 비교 | 결과 | data/results.csv | 시험 결과 | 18% 증가 | |
| 3 | 예비 시험 | 결과 | data/results.csv | 시험 방법 | | 예비 시험이라 뺌 |

| 번호 | 그림 | 역할 | 절 | 보여 주는 것 |
|---|---|---|---|---|
| 1 | fig/setup.png | 방법 | 시험 방법 | 시험 장치 |
| 2 | fig/strength.png | 결과 | 시험 결과 | 강도 비교 |
""")
        found, counts = br.achievement_checks(settings, blocks, None)
        self.assertEqual(counts, {'results': 2, 'excluded': 1, 'figures': 2})
        self.assertIn('report.json "structure"가 없음', found.pop(2))
        # the tool finds evaluation records itself; one the list does not cite or exclude is flagged
        (Path(self.tmp) / 'docs/evals/run-a').mkdir(parents=True)
        (Path(self.tmp) / 'docs/evals/run-a/README.md').write_text('# run a\n')
        (Path(self.tmp) / 'data/extra-test.csv').write_text('x\n')
        settings.evidence = ['data/extra-test.csv']
        evidence = [f for f in br.achievement_checks(settings, blocks, None)[0] if '근거 기록' in f]
        self.assertEqual(evidence, ['성과 목록이 다루지 않은 근거 기록: data/extra-test.csv(성과로 넣거나 제외 이유와 함께 적는다)',
                                    '성과 목록이 다루지 않은 근거 기록: docs/evals/run-a(성과로 넣거나 제외 이유와 함께 적는다)'])
        self.assertEqual(found, ["성과 2 강도 비교: 넣을 절 '시험 결과'이 원고 제목에 없음",
                                 "성과 2 강도 비교: 핵심 수치 '18% 증가'가 본문에 없음",
                                 '그림 계획 2 fig/strength.png: 초안에 없음'])

    def test_several_results_in_one_section_and_results_without_a_figure_are_flagged(self):
        settings = project(self.tmp)
        blocks = [{'type': 'heading1', 'text': '시험 결과'}, {'type': 'statement', 'text': '강도가 18% 증가하였고 파괴 형태는 3종이었음.'},
                  {'type': 'heading1', 'text': '향후 계획'}, {'type': 'statement', 'text': '확대할 계획임.'}]
        settings.achievements = Path(self.tmp) / 'report/achievements.md'
        settings.achievements.write_text("""| 번호 | 성과 | 구분 | 근거 | 절 | 핵심 수치 | 제외 이유 |
|---|---|---|---|---|---|---|
| 1 | 강도 비교 | 결과 | data/results.csv | 시험 결과 | 18% | |
| 2 | 파괴 형태 | 결과 | data/results.csv | 시험 결과 | 3종 | |

| 번호 | 그림 | 역할 | 절 | 보여 주는 것 |
|---|---|---|---|---|
""")
        settings.evidence = ['data/*']
        found, _ = br.achievement_checks(settings, blocks, None)
        self.assertIn("절 '시험결과'에 성과 2개(1, 2): 성과마다 소절을 두고 성과 목록의 절을 그 소절 제목으로 적는다", found)
        self.assertIn("결과 수치가 있는 절 '시험결과'에 그림이 없음(결과를 보여 주는 그림을 두거나 이유를 성과 목록에 적는다)", found)

    def test_allowed_uncommon_abbreviations_are_spelled_out_once(self):
        settings = project(self.tmp, extra_checks={'allowTerms': ['CV', 'AI']})
        loose = [{'type': 'statement', 'text': 'CV 점수와 AI 도구를 썼음.'}]
        self.assertEqual([(k, t) for _, k, t in br.text_checks(loose, None, settings)],
                         [('풀이 없는 약어(허용 목록에 있음)', 'CV')])
        spelled = [{'type': 'statement', 'text': '공간 교차검증(CV) 점수를 썼음.'}, {'type': 'detail', 'text': 'CV 점수는 0.7이었음'}]
        self.assertEqual(br.text_checks(spelled, None, settings), [])

    def test_page_check_record_must_cover_every_rendered_page(self):
        settings = project(self.tmp)
        self.assertIn('pageCheck', br.page_check_findings(settings, 2)[0])
        settings.page_check = Path(self.tmp) / 'report/page-check.md'
        settings.page_check.write_text('| 쪽 | 본 것 | 조치 |\n|---|---|---|\n| 1 | 표 제목과 표가 같은 쪽 | 없음 |\n| 2 | | |\n')
        self.assertEqual(br.page_check_findings(settings, 3), ['쪽별 확인 기록에 없는 쪽: 2, 3'])

    def test_structure_template_needs_every_role_and_figure_per_work_unit(self):
        settings = project(self.tmp)
        settings.structure = 'development'
        kept = [{'번호': '1', '작업': '도구 A', '구분': '개발', '절': '구성'},
                {'번호': '2', '작업': '도구 A', '구분': '결과', '절': '적용 결과', '핵심 수치': '18%'},
                {'번호': '3', '작업': '도구 A', '구분': '개발·결과', '절': '요약'},
                {'번호': '4', '작업': '', '구분': '방법', '절': '방법'}]
        figures = [{'번호': '1', '그림': 'fig/a.png', '역할': '결과', '작업': '도구 A'}]
        found = br.structure_findings(settings, kept, figures)
        self.assertEqual(found, ["성과 3: 구분은 배경/개발/방법/결과/범위 중 하나만 적는다(지금 '개발·결과')",
                                 '성과 4: 작업 칸이 비어 있음',
                                 "작업 '도구 A'에 배경, 방법 성과가 없음(구조 틀 development)",
                                 "작업 '도구 A'에 구성·절차·평가 설계 그림이 없음"])
        settings.structure = 'none'
        self.assertEqual(br.structure_findings(settings, kept, figures), [])

    def test_preview_carries_a_stamp_and_hand_edits_are_detected(self):
        settings = project(self.tmp, form={'title': '제목'})
        br.build(settings, date='2026-09-29')
        self.assertTrue(br.preview_intact(settings.preview))
        settings.preview.write_text(settings.preview.read_text().replace('## 렌더 점검', '## 렌더 점검\n- 모든 쪽 확인함', 1))
        self.assertFalse(br.preview_intact(settings.preview))

    def test_hand_written_numbers_without_facts_are_flagged(self):
        settings = project(self.tmp)
        blocks = [{'type': 'statement', 'text': f'시료 {n}개를 {n}회 측정하였음.'} for n in range(1, 4)]
        self.assertEqual(br.facts_findings(settings, {}, blocks),
                         ['원고에 수치 6개가 있으나 facts 모듈이 값을 주지 않음. 결과 파일에서 계산해 {{이름}}으로 넣는다'])
        self.assertEqual(br.facts_findings(settings, {'n': 3}, blocks), [])

    def test_long_form_summary_cells_are_flagged(self):
        found = br.form_cell_findings({'summary': [['짧음', '가' * 41, '', '']]})
        self.assertEqual(found, ['양식 요약표 1행 2열이 41자임(40자 이하로 줄이고 설명은 본문으로)'])

    def test_many_subheadings_get_labels(self):
        blocks = [{'type': 'heading1', 'text': '장'}] + [{'type': 'heading2', 'text': f'항 {i}'} for i in range(20)]
        self.assertEqual(br.rendered_labels(blocks)[-1], '20) 항 19')


if __name__ == '__main__':
    unittest.main()
