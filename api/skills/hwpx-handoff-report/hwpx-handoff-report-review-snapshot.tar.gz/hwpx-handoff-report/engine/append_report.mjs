#!/usr/bin/env node
import {
  copyFileSync,
  existsSync,
  mkdirSync,
  readFileSync,
  renameSync,
  rmSync,
  statSync,
} from 'node:fs';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { dirname, isAbsolute, join, relative, resolve } from 'node:path';
import { setTimeout as sleep } from 'node:timers/promises';
import { appendBlocks } from './lib/engine.js';
import { validateDraft } from './lib/validate.js';
import { binDataEntries } from './lib/hwpx-read.js';
import { DEFAULT_FORM, getForm, listForms } from './lib/forms.js';
import {
  acquireLock,
  appendJournal,
  backupRotate,
  CasMismatchError,
  commitCandidate,
  LockHeldError,
  sha256,
} from './lib/atomic.js';

const DEFAULT_VERIFY = new URL('./verify_report.sh', import.meta.url).pathname;

const code = await main();
process.exitCode = code;

async function main() {
  if (process.argv[2] === '--list-forms') {
    for (const form of listForms()) {
      console.log(`${form.id}\t${form.name}\n\t${form.description}`);
    }
    return 0;
  }
  let args;
  try {
    args = parseArgs(process.argv.slice(2));
  } catch (error) {
    console.error(error.message);
    return 2;
  }

  const projectRoot = resolve(args.projectRoot);
  const draftPath = resolveUnder(projectRoot, args.draft);
  const targetPath = resolveUnder(projectRoot, args.target);
  const candidatePath = `${targetPath}.tmp.hwpx`;
  const tmpPdfPath = `${targetPath}.tmp.pdf`;
  const previewPath = `${targetPath}.preview.pdf`;
  // one line per committed append, next to the report unless --journal says otherwise
  const journalPath = args.journal ? resolveUnder(projectRoot, args.journal) : join(dirname(targetPath), 'report-journal.jsonl');

  let draft;
  let draftSha256;
  try {
    const draftBytes = readFileSync(draftPath);
    // the sha of the bytes this run used, so a golden copy can be paired with the draft that made it
    draftSha256 = createHash('sha256').update(draftBytes).digest('hex');
    draft = JSON.parse(draftBytes.toString('utf8'));
  } catch (error) {
    console.error(`failed to read draft: ${errorMessage(error)}`);
    return 2;
  }

  const validation = validateDraft(draft, projectRoot);
  if (!validation.ok) {
    for (const error of validation.errors) {
      console.error(error);
    }
    return 2;
  }

  let skeleton;
  try {
    skeleton = getForm(draft.template ?? DEFAULT_FORM).skeleton;
  } catch (error) {
    console.error(errorMessage(error));
    return 2;
  }

  mkdirSync(dirname(targetPath), { recursive: true });

  let release;
  try {
    release = acquireLock(targetPath);
  } catch (error) {
    if (error instanceof LockHeldError) {
      console.error(error.message);
      return 3;
    }
    throw error;
  }

  let appendResult;
  let committed = false;
  try {
    const expectedSha = existsSync(targetPath) ? sha256(targetPath) : null;
    copyFileSync(existsSync(targetPath) ? targetPath : skeleton, candidatePath);

    appendResult = await appendBlocks(candidatePath, candidatePath, draft, projectRoot);
    try {
      runVerifier(candidatePath, tmpPdfPath);
    } catch (error) {
      console.error(`verify failed: ${commandError(error)}`);
      return 4;
    }
    if (!existsSync(tmpPdfPath)) {
      console.error(`verify failed: missing pdf output ${tmpPdfPath}`);
      return 4;
    }

    await sleepBeforeCommit();

    try {
      casPrecheckTarget(targetPath, expectedSha);
      backupRotate(targetPath);
      commitCandidate(candidatePath, targetPath, expectedSha);
      committed = true;
    } catch (error) {
      if (error instanceof CasMismatchError) {
        console.error(error.message);
        return 3;
      }
      throw error;
    }

    try {
      renameSync(tmpPdfPath, previewPath);
      const sha256After = sha256(targetPath);
      const bytes = statSync(targetPath).size;
      const binDataCount = binDataEntries(targetPath).length;
      const journal = {
        utc: new Date().toISOString(),
        project: draft.session.project,
        target: relative(projectRoot, targetPath),
        form: appendResult.form,
        draft: relative(projectRoot, draftPath),
        draftSha256,
        sha256Before: expectedSha,
        blocks: appendResult.blocks,
        figures: appendResult.figuresAdded,
        bytes,
        sha256After,
        binDataCount,
      };
      appendJournal(journalPath, journal);
      console.log(JSON.stringify({ ok: true, ...journal, target: targetPath, preview: previewPath,
        layout: appendResult.layout }));
      return 0;
    } catch (error) {
      console.error(`committed-but-postlude-failed: ${error?.name ?? 'Error'}: ${errorMessage(error)}`);
      return 5;
    }
  } catch (error) {
    if (committed) {
      console.error(`committed-but-postlude-failed: ${error?.name ?? 'Error'}: ${errorMessage(error)}`);
      return 5;
    }
    console.error(`${error?.name ?? 'Error'}: ${errorMessage(error)}`);
    return 4;
  } finally {
    cleanupQuietly('lock release', release);
    // HWPX_KEEP_FAILED=1 keeps a failed run's candidate and PDF (<target>.failed.hwpx/.pdf) for diagnosis
    const keep = !committed && process.env.HWPX_KEEP_FAILED === '1';
    cleanupQuietly(candidatePath, () => (keep && existsSync(candidatePath)
      ? renameSync(candidatePath, `${targetPath}.failed.hwpx`) : rmSync(candidatePath, { force: true })));
    cleanupQuietly(tmpPdfPath, () => (keep && existsSync(tmpPdfPath)
      ? renameSync(tmpPdfPath, `${targetPath}.failed.pdf`) : rmSync(tmpPdfPath, { force: true })));
  }
}

function parseArgs(argv) {
  const parsed = {};
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === '--draft' || arg === '--target' || arg === '--project-root' || arg === '--journal') {
      const value = argv[i + 1];
      if (!value || value.startsWith('--')) {
        throw new Error(`missing value for ${arg}`);
      }
      parsed[arg.slice(2).replace(/-([a-z])/g, (_, ch) => ch.toUpperCase())] = value;
      i += 1;
    } else {
      throw new Error(`unknown argument: ${arg}`);
    }
  }
  for (const key of ['draft', 'target', 'projectRoot']) {
    if (!parsed[key]) {
      throw new Error(`missing required argument --${key.replace(/[A-Z]/g, (ch) => `-${ch.toLowerCase()}`)}`);
    }
  }
  return parsed;
}

function resolveUnder(projectRoot, path) {
  return isAbsolute(path) ? path : resolve(projectRoot, path);
}

function runVerifier(candidatePath, tmpPdfPath) {
  const command = process.env.HWPX_VERIFY_CMD || DEFAULT_VERIFY;
  execFileSync(command, [candidatePath, tmpPdfPath], {
    cwd: dirname(command),
    encoding: 'utf8',
    stdio: ['ignore', 'pipe', 'pipe'],
  });
}

function casPrecheckTarget(targetPath, expectedSha) {
  if (expectedSha === null) {
    if (existsSync(targetPath)) {
      throw new CasMismatchError(`${targetPath} target exists (expected first-append)`);
    }
    return;
  }
  if (!existsSync(targetPath)) {
    throw new CasMismatchError(`${targetPath} target missing (expected sha ${expectedSha})`);
  }
  const actualSha = sha256(targetPath);
  if (actualSha !== expectedSha) {
    throw new CasMismatchError(`${targetPath} sha mismatch (expected ${expectedSha}, actual ${actualSha})`);
  }
}

async function sleepBeforeCommit() {
  if (!process.env.HWPX_TEST_SLEEP_BEFORE_COMMIT) {
    return;
  }
  const seconds = Number(process.env.HWPX_TEST_SLEEP_BEFORE_COMMIT);
  if (Number.isFinite(seconds) && seconds > 0) {
    await sleep(seconds * 1000);
  }
}

function commandError(error) {
  const stderr = error?.stderr?.toString()?.trim();
  const stdout = error?.stdout?.toString()?.trim();
  if (stderr) {
    return stderr;
  }
  if (stdout) {
    return stdout;
  }
  return errorMessage(error);
}

function errorMessage(error) {
  return error instanceof Error ? error.message : String(error);
}

function cleanupQuietly(label, fn) {
  try {
    fn();
  } catch (error) {
    console.error(`cleanup failed (${label}): ${errorMessage(error)}`);
  }
}
