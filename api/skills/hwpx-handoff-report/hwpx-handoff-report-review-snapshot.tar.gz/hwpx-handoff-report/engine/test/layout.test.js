import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, copyFileSync, writeFileSync, mkdirSync, readFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { strFromU8, unzipSync } from 'fflate';
import { appendBlocks, inspectBodyFlow } from '../lib/engine.js';
import * as core from '@rhwp/core';
import { anchorInfo, bodyLocation, outlineCounters, readHeaderXml, styleMismatches } from '../lib/hwpx-read.js';
import { getForm } from '../lib/forms.js';

const PNG_4x4 = Buffer.from(
  'iVBORw0KGgoAAAANSUhEUgAAAAQAAAAECAYAAACp8Z5+AAAAEklEQVR4nGP4z8DwHxkzkC4AADxAH+HggXe0AAAAAElFTkSuQmCC',
  'base64');
const SKEL = new URL('../forms/kigam-annual/skeleton.hwpx', import.meta.url).pathname;

function workspace() {
  const d = mkdtempSync(join(tmpdir(), 'hwpx-layout-'));
  mkdirSync(join(d, 'fig'));
  writeFileSync(join(d, 'fig/a.png'), PNG_4x4);
  copyFileSync(SKEL, join(d, 'in.hwpx'));
  return d;
}

async function build(blocks) {
  const d = workspace();
  const out = join(d, 'out.hwpx');
  await appendBlocks(join(d, 'in.hwpx'), out, { session: { date: '2026-09-29', project: 't' }, blocks }, d);
  const bytes = readFileSync(out);
  const entries = unzipSync(bytes);
  return {
    bytes,
    xml: strFromU8(entries['Contents/section0.xml']),
    header: strFromU8(entries['Contents/header.xml']),
  };
}

const unescape = (s) => s.replaceAll('&lt;', '<').replaceAll('&gt;', '>').replaceAll('&amp;', '&');

// Innermost paragraphs with their text and paraPr id.
function paragraphs(xml) {
  return [...xml.matchAll(/<hp:p\b[^>]*paraPrIDRef="(\d+)"[^>]*>((?:(?!<hp:p\b)[\s\S])*?)<\/hp:p>/g)]
    .map((m) => ({ paraPr: m[1], text: unescape([...m[2].matchAll(/<hp:t>([^<]*)<\/hp:t>/g)].map((t) => t[1]).join('')) }));
}

function paraPr(header, id) {
  return header.match(new RegExp(`<hh:paraPr id="${id}"[\\s\\S]*?</hh:paraPr>`))[0];
}

const alignOf = (header, id) => /<hh:align horizontal="(\w+)"/.exec(paraPr(header, id))[1];
const prevSpacing = (header, id) => {
  const block = paraPr(header, id);
  const deflt = block.match(/<hp:default>([\s\S]*?)<\/hp:default>/)?.[1] ?? block;
  return Number(/<hc:prev value="(-?\d+)"/.exec(deflt)[1]);
};

// Engine-generated tables sit in the body: after the 3-1 heading, before the summary table.
const bodyStart = (xml) => xml.indexOf('3-1 정성적 연구개발성과');
function nestedTables(xml) {
  const body = xml.slice(bodyStart(xml), anchorInfo(xml).summaryTableIndex);
  return [...body.matchAll(/<hp:tbl\b[^>]*>[\s\S]*?<\/hp:tbl>/g)].map((m) => m[0]);
}

// Top-level paragraphs (not inside a table cell) with their own text.
function topLevelTexts(xml) {
  const out = [];
  const stack = [];
  let depth = 0;
  for (const m of xml.matchAll(/<hp:tbl(?=[\s/>])[^>]*>|<\/hp:tbl>|<hp:p(?=[\s/>])[^>]*>|<\/hp:p>/g)) {
    const t = m[0];
    if (t.startsWith('<hp:tbl')) depth += 1;
    else if (t === '</hp:tbl>') depth -= 1;
    else if (t.startsWith('<hp:p')) stack.push({ start: m.index, depth });
    else {
      const open = stack.pop();
      if (open.depth === 0 && stack.length === 0) {
        const own = xml.slice(open.start, m.index).replace(/<hp:tbl\b[\s\S]*<\/hp:tbl>/g, '');
        out.push(unescape([...own.matchAll(/<hp:t>([^<]*)<\/hp:t>/g)].map((x) => x[1]).join('')));
      }
    }
  }
  return out;
}

test('content tables: padded cells, left-aligned sentence columns, repeated header row', async () => {
  const long = '여러 줄로 줄바꿈되는 긴 설명 문장이 들어가는 칸';
  const { xml, header } = await build([
    { type: 'heading1', text: '표' },
    { type: 'table', caption: '표 제목', headers: ['구분', '설명', '수치'],
      rows: [['가', long, '12.3'], ['나', '짧음', '4']] },
    { type: 'statement', text: '표 뒤 문장임.' },
  ]);
  const [table] = nestedTables(xml);
  assert.match(table, /<hp:tbl\b[^>]*repeatHeader="1"/);
  const margins = [...table.matchAll(/<hp:cellMargin\b[^>]*top="(\d+)"[^>]*bottom="(\d+)"/g)];
  assert.equal(margins.length, 9);
  for (const m of margins) {
    assert.deepEqual([Number(m[1]), Number(m[2])], [280, 280]);
  }
  const cells = paragraphs(table);
  const align = (text) => alignOf(header, cells.find((p) => p.text === text).paraPr);
  assert.equal(align(long), 'LEFT');
  assert.equal(align('짧음'), 'LEFT'); // same column as the long sentence
  assert.equal(align('가'), 'CENTER');
  assert.equal(align('12.3'), 'CENTER');
  assert.equal(align('설명'), 'CENTER'); // header row stays centred

  const after = paragraphs(xml).find((p) => p.text === '◯ 표 뒤 문장임.');
  assert.ok(prevSpacing(header, after.paraPr) > 0, 'paragraph after a table has space before it');
});

test('angle-caption figures carry the caption in an unsplittable figure table', async () => {
  const { xml } = await build([
    { type: 'heading1', text: '그림' },
    { type: 'figure_grid', images: ['fig/a.png', 'fig/a.png'], columns: 2, caption: '두 그림', captionStyle: 'angle' },
    { type: 'statement', text: '그림 뒤 문장임.' },
  ]);
  const [figure] = nestedTables(xml);
  assert.match(figure, /<hp:tbl\b[^>]*pageBreak="NONE"/);
  assert.match(figure, /<hp:tbl\b[^>]*rowCnt="2"/);
  assert.ok(paragraphs(figure).some((p) => p.text === '<두 그림>'), 'caption is inside the figure table');
  const outside = paragraphs(xml.replace(figure, ''));
  assert.ok(!outside.some((p) => p.text === '<두 그림>'), 'no separate caption paragraph');
});

test('numbered figure captions keep the original paragraph form', async () => {
  const { xml } = await build([
    { type: 'bullet1', text: '성과' },
    { type: 'figure_grid', images: ['fig/a.png'], columns: 1, caption: '그림 설명' },
  ]);
  const [figure] = nestedTables(xml);
  assert.doesNotMatch(figure, /그림 1\./);
  assert.ok(paragraphs(xml).some((p) => p.text === '그림 1. 그림 설명'));
});

function orphanDraft(lines) {
  const blocks = [{ type: 'heading1', text: '절' }];
  for (let i = 0; i < lines; i += 1) {
    blocks.push({ type: 'detail', text: `한 줄 문장 ${i}` });
  }
  blocks.push({ type: 'heading2', text: '항 제목' }, { type: 'heading3', text: '목 제목' },
    { type: 'statement', text: '본문 문장' });
  for (let i = 0; i < 8; i += 1) {
    blocks.push({ type: 'detail', text: `뒤 문장 ${i}` });
  }
  blocks.push({ type: 'table', caption: '표 제목', headers: ['a', 'b'], rows: [['1', '2'], ['3', '4']] });
  for (let i = 0; i < 30; i += 1) {
    blocks.push({ type: 'detail', text: `더 ${i}` });
  }
  return blocks;
}

// Filler lengths that put the heading chain at a page bottom in the rhwp layout (2026-09-29).
for (const lines of [28, 29]) {
  test(`keep-with-next headings move to the next page (filler ${lines})`, async () => {
    const { bytes } = await build(orphanDraft(lines));
    const { pages, keep } = await inspectBodyFlow(bytes);
    for (let i = 0; i + 1 < pages.length; i += 1) {
      assert.ok(!(keep[i] && pages[i + 1] > pages[i]),
        `paragraph ${i} keeps with next but ends page ${pages[i] + 1}`);
    }
  });
}

test('the body is ordinary text outside any table, between the 3-1 heading and the summary table', async () => {
  const { xml } = await build([
    { type: 'heading1', text: '가 절' },
    { type: 'statement', text: '본문 문장임.' },
    { type: 'table', caption: '표 제목', headers: ['a'], rows: [['1']] },
  ]);
  const texts = topLevelTexts(xml);
  const heading = texts.findIndex((t) => t.includes('3-1 정성적 연구개발성과'));
  assert.ok(heading >= 0);
  assert.deepEqual(texts.slice(heading + 1).filter(Boolean), ['가. 가 절', '◯ 본문 문장임.', '<표 제목>']);
  // no 1x1 box around the body: the only tables are the goal, content and summary tables
  const shapes = [...xml.matchAll(/<hp:tbl\b[^>]*rowCnt="(\d+)" colCnt="(\d+)"/g)].map((m) => `${m[1]}x${m[2]}`);
  assert.ok(!shapes.includes('1x1'), shapes.join(','));
});

test('a form that still keeps the body in the old 1x1 box is refused', () => {
  const box = '<hp:p><hp:run><hp:tbl numberingType="TABLE" rowCnt="1" colCnt="1"><hp:tr><hp:tc><hp:subList>'
    + '<hp:p><hp:run><hp:tbl numberingType="TABLE" rowCnt="7" colCnt="4"><hp:t>구분</hp:t><hp:t>주요 목록 및 내용</hp:t>'
    + '<hp:t>활용 목적</hp:t></hp:tbl></hp:run></hp:p></hp:subList></hp:tc></hp:tr></hp:tbl></hp:run></hp:p>';
  assert.throws(() => bodyLocation(box, getForm('kigam-annual')), /old 1x1 box/);
});

async function buildDraft(draft) {
  const d = workspace();
  const out = join(d, 'out.hwpx');
  await appendBlocks(join(d, 'in.hwpx'), out, { session: { date: '2026-09-29', project: 't' }, ...draft }, d);
  return { dir: d, out, bytes: readFileSync(out) };
}

test('form fills the goal table rows and the summary table, only while they are empty', async () => {
  const goals = [['목표 가', '내용 가', '100'], ['목표 나', '내용 나', '100'], ['목표 다', '내용 다', '100']];
  const summary = [['구분 가', '목록 가', '출처 가', '목적 가']];
  const { dir, out } = await buildDraft({ blocks: [{ type: 'statement', text: '본문.' }], form: { goals, summary } });
  const xml = strFromU8(unzipSync(readFileSync(out))['Contents/section0.xml']);
  const goalTable = xml.slice(xml.lastIndexOf('<hp:tbl', xml.indexOf('추 진 목 표')));
  assert.match(goalTable, /<hp:tbl\b[^>]*rowCnt="4"/);
  const summaryStart = anchorInfo(xml).summaryTableIndex;
  const filled = xml.slice(xml.lastIndexOf('<hp:tc', xml.indexOf('<hp:t>구분 가</hp:t>')));
  assert.equal([...filled.slice(0, filled.indexOf('</hp:tc>')).matchAll(/<hp:p\b/g)].length, 1, 'no blank guide lines under the text');
  for (const text of goals.flat()) {
    const at = xml.indexOf(`<hp:t>${text}</hp:t>`);
    assert.ok(at > 0 && at < bodyStart(xml), `${text} in the goal table`);
  }
  for (const text of summary.flat()) {
    assert.ok(xml.indexOf(`<hp:t>${text}</hp:t>`) > summaryStart, `${text} in the summary table`);
  }
  // a second append that brings form rows again must not overwrite the filled tables
  await assert.rejects(appendBlocks(out, join(dir, 'again.hwpx'),
    { session: { date: '2026-09-29', project: 't' }, blocks: [{ type: 'statement', text: '추가.' }], form: { goals } }, dir),
  /goal table already has content/);
});

test('goal rows grow to the height of their wrapped text', async () => {
  const long = '두 줄 이상으로 줄이 바뀌도록 달성 내용을 충분히 길게 적은 문장이며 칸의 폭을 넘음';
  const goals = [['목표 가', long, '100'], ['목표 나', long, '100'], ['목표 다', long, '100']];
  const { out } = await buildDraft({ blocks: [{ type: 'statement', text: '본문.' }], form: { goals } });
  const xml = strFromU8(unzipSync(readFileSync(out))['Contents/section0.xml']);
  const start = xml.lastIndexOf('<hp:tbl', xml.indexOf('추 진 목 표'));
  const table = xml.slice(start, xml.indexOf('</hp:tbl>', start));
  const rows = table.split(/<hp:tr\b/).slice(2);
  assert.equal(rows.length, goals.length);
  for (const row of rows) {
    const tc = row.split(/<hp:tc\b/).slice(1).find((c) => c.includes('두 줄 이상'));
    const bottoms = [...tc.matchAll(/vertpos="(\d+)"[^>]*vertsize="(\d+)"/g)].map((m) => Number(m[1]) + Number(m[2]));
    assert.ok(Math.max(...bottoms) > 1560, 'the long cell wraps');
    const [, top, bottom] = tc.match(/<hp:cellMargin\b[^>]*top="(\d+)"[^>]*bottom="(\d+)"/);
    const heights = [...row.matchAll(/<hp:cellSz\b[^>]*height="(\d+)"/g)].map((m) => Number(m[1]));
    assert.ok(heights.every((h) => h === heights[0]), 'one height per row');
    assert.ok(heights[0] >= Math.max(...bottoms) + Number(top) + Number(bottom), `row height ${heights[0]}`);
  }
});

// Top-level text is paginated by the renderer; a long content table splits over pages and a
// figure that does not fit moves to the next page, so nothing is drawn below the body area.
function overflowDraft(lines) {
  const goals = Array.from({ length: 6 }, (_, i) => [`목표 ${i}`, '달성 내용을 두 줄 정도로 길게 적은 문장임', '100']);
  const blocks = [{ type: 'heading1', text: '절' }];
  for (let i = 0; i < lines; i += 1) {
    blocks.push({ type: 'detail', text: `한 줄 문장 ${i}` });
  }
  blocks.push({ type: 'table', caption: '표 제목', headers: ['a', 'b'],
    rows: Array.from({ length: 6 }, (_, i) => [`${i}`, '값']) });
  blocks.push({ type: 'statement', text: '표 뒤 문장.' });
  return { blocks, form: { goals } };
}

test('nothing runs below the body area and no heading or table title ends a page', async () => {
  for (const lines of [14, 16, 18, 24, 26, 28]) {
    const { bytes } = await buildDraft(overflowDraft(lines));
    const { overflow, pages, keep } = await inspectBodyFlow(bytes);
    assert.deepEqual(overflow.flatMap((over, i) => (over ? [i] : [])), [], `filler ${lines}: overflow`);
    for (let i = 0; i + 1 < pages.length; i += 1) {
      assert.ok(!(keep[i] && pages[i + 1] > pages[i]), `filler ${lines}: paragraph ${i} left at a page end`);
    }
  }
});

test('a figure that does not fit the rest of a page moves whole to the next page', async () => {
  const d = workspace();
  // 40 x 30 px: drawn at the full text width it takes about three quarters of a page
  const wide = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAACgAAAAeCAIAAADRv8uKAAAAKUlEQVR4nO3NsQ0AAAgDoJ7ez/UMHUjYSTsnIhaLxWKxWCwWi8Xiv/ECAjZb2IjXz/cAAAAASUVORK5CYII=', 'base64');
  writeFileSync(join(d, 'fig/wide.png'), wide);
  const blocks = [{ type: 'heading1', text: '절' }];
  for (let i = 0; i < 20; i += 1) blocks.push({ type: 'detail', text: `한 줄 문장 ${i}` });
  blocks.push({ type: 'figure_grid', images: ['fig/wide.png'], columns: 1, caption: '넓은 그림', captionStyle: 'angle' });
  const out = join(d, 'out.hwpx');
  const res = await appendBlocks(join(d, 'in.hwpx'), out, { session: { date: '2026-09-29', project: 't' }, blocks }, d);
  assert.deepEqual(res.layout.overflow, []);
  const bytes = readFileSync(out);
  const { pages, lastPages } = await inspectBodyFlow(bytes);
  const figure = pages.length - 2; // the summary table follows the figure
  assert.equal(pages[figure], lastPages[figure], 'the figure is not split');
  const xml = strFromU8(unzipSync(bytes)['Contents/section0.xml']);
  const figureTable = xml.slice(xml.lastIndexOf('<hp:tbl', xml.indexOf('&lt;넓은 그림&gt;')));
  assert.match(figureTable, /^<hp:tbl\b[^>]*>[^]*?<hp:pos\b[^>]*treatAsChar="1"/, 'treated as a character so Hancom moves it whole');
  assert.ok(pages[figure] > pages[figure - 1], 'the figure starts a new page');
});

// Independent of inspectBodyFlow: the page on which the rendered text containing `needle` starts.
async function pageOfText(bytes, needle) {
  await inspectBodyFlow(bytes); // initialises the wasm module shared with the engine
  const doc = new core.HwpDocument(new Uint8Array(bytes));
  for (let page = 0; page < doc.pageCount(); page += 1) {
    const runs = JSON.parse(doc.getPageTextLayout(page)).runs ?? [];
    if (runs.map((r) => r.text).join('').includes(needle)) {
      return page;
    }
  }
  return -1;
}

test('rendered text: moved headings sit on the page of the text they introduce', async () => {
  for (const lines of [28, 29]) {
    const { bytes } = await build(orphanDraft(lines));
    const heading = await pageOfText(bytes, '항 제목');
    assert.ok(heading >= 0, 'heading text found in the render');
    assert.equal(await pageOfText(bytes, '목 제목'), heading, `filler ${lines}`);
    assert.equal(await pageOfText(bytes, '본문 문장'), heading, `filler ${lines}`);
  }
});

test('a table running over two pages splits by rows and adds no page start after it', async () => {
  // rhwp 0.8.6 sometimes starts the next paragraph on a new page after a split table on its own
  // (seen at some row counts, with or without cell margins), and draws a table only slightly taller
  // than the body area unsplit (reported as overflow); 60 rows is a length where neither happens
  const rows = Array.from({ length: 60 }, (_, i) => [`행 ${i}`, '값']);
  const { bytes, xml } = await build([
    { type: 'heading1', text: '긴 표' },
    { type: 'table', caption: '긴 표 제목', headers: ['a', 'b'], rows },
    { type: 'statement', text: '긴 표 뒤 문장.' },
  ]);
  const { pages, lastPages, texts } = await inspectBodyFlow(bytes);
  const table = texts.findIndex((t) => t.includes('긴 표 제목')) + 1;
  assert.ok(lastPages[table] > pages[table], 'the table spans pages');
  const long = xml.slice(xml.lastIndexOf('<hp:tbl', xml.indexOf('<hp:t>행 0</hp:t>')));
  assert.match(long, /^<hp:tbl\b[^>]*pageBreak="CELL"/);
  assert.match(long, /^<hp:tbl\b[^>]*>[^]*?<hp:pos\b[^>]*treatAsChar="0"/, 'a long table stays floating so it can split');
  assert.ok(!/<hp:p\b[^>]*pageBreak="1"/.test(xml.slice(xml.indexOf('긴 표 뒤 문장') - 2000, xml.indexOf('긴 표 뒤 문장'))
    .split('</hp:tbl>').pop()), 'no page break before the sentence');
  assert.equal(await pageOfText(bytes, '긴 표 뒤 문장'), lastPages[table]);
});

async function drawnTexts(bytes) {
  await inspectBodyFlow(bytes); // initialises the wasm module shared with the engine
  const doc = new core.HwpDocument(new Uint8Array(bytes));
  const texts = [];
  for (let page = 0; page < doc.pageCount(); page += 1) {
    texts.push(...(JSON.parse(doc.getPageTextLayout(page)).runs ?? []).map((r) => r.text));
  }
  return texts.join(''); // a cell text can come in several runs ('행 ', '0')
}

// Tables a little taller than a page: rhwp 0.8.6 once started the paragraph after the 70-row table
// on a new page by itself, and drew the 50-row table unsplit past the page bottom while it was
// marked not to split. The engine must not add breaks of its own there, must not lose rows, and
// must report what runs past the page bottom.
for (const [rows, note] of [[70, 'long table'], [50, 'a little taller than the body']]) {
  test(`known rhwp limit (${rows} rows, ${note}): no engine break after the table, rows kept, overflow reported`, async () => {
    const d = workspace();
    const out = join(d, 'out.hwpx');
    const res = await appendBlocks(join(d, 'in.hwpx'), out, { session: { date: '2026-09-29', project: 't' }, blocks: [
      { type: 'heading1', text: '긴 표' },
      { type: 'table', caption: '긴 표 제목', headers: ['a', 'b'], rows: Array.from({ length: rows }, (_, i) => [`행 ${i}`, '값']) },
      { type: 'statement', text: '긴 표 뒤 문장.' }] }, d);
    const bytes = readFileSync(out);
    const xml = strFromU8(unzipSync(bytes)['Contents/section0.xml']);
    const after = paragraphs(xml).find((p) => p.text === '◯ 긴 표 뒤 문장.');
    assert.ok(after, 'the sentence is there');
    assert.ok(!/<hp:p\b[^>]*pageBreak="1"[^>]*>(?:(?!<\/hp:p>)[\s\S])*긴 표 뒤 문장/.test(xml), 'no engine break before the sentence');
    const drawn = await drawnTexts(bytes);
    for (let i = 0; i < rows; i += 1) {
      assert.ok(drawn.includes(`행 ${i}값`), `row ${i} is drawn`);
    }
    // overflow read independently from the raw control layout: the table's box against the page bottom
    const doc = new core.HwpDocument(new Uint8Array(bytes));
    let tableBelow = false;
    for (let page = 0; page < doc.pageCount(); page += 1) {
      const info = JSON.parse(doc.getPageInfo(page));
      for (const c of JSON.parse(doc.getPageControlLayout(page)).controls ?? []) {
        if (c.type === 'table' && (c.stableIndex?.length ?? 0) === 3 && c.y + c.h > info.height - info.marginBottom + 1
          && c.h > 200) {
          tableBelow = true;
        }
      }
    }
    const { texts } = await inspectBodyFlow(bytes);
    const table = texts.findIndex((t) => t.includes('긴 표 제목')) + 1;
    assert.equal(res.layout.overflow.includes(table), tableBelow, 'the table is reported exactly when it runs past the page bottom');
  });
}

test('a table almost a page tall is kept whole on the next page', async () => {
  const blocks = [{ type: 'heading1', text: '절' }];
  for (let i = 0; i < 20; i += 1) blocks.push({ type: 'detail', text: `한 줄 문장 ${i}` });
  blocks.push({ type: 'table', caption: '거의 한 쪽인 표', headers: ['a', 'b'], rows: Array.from({ length: 42 }, (_, i) => [`행 ${i}`, '값']) });
  const d = workspace();
  const out = join(d, 'out.hwpx');
  const res = await appendBlocks(join(d, 'in.hwpx'), out, { session: { date: '2026-09-29', project: 't' }, blocks }, d);
  const bytes = readFileSync(out);
  const { pages, lastPages, texts, tableHeights, bodyHeight } = await inspectBodyFlow(bytes);
  const table = texts.findIndex((t) => t.includes('거의 한 쪽인 표')) + 1;
  assert.ok(tableHeights[table] > bodyHeight * 0.85, `the table is ${(tableHeights[table] / bodyHeight).toFixed(2)} of the body`);
  assert.equal(pages[table], lastPages[table], 'the table is on one page');
  assert.equal(pages[table - 1], pages[table], 'the title stays with the table');
  assert.deepEqual(res.layout.splitTables, []);
  const drawn = await drawnTexts(bytes);
  for (let i = 0; i < 42; i += 1) {
    assert.ok(drawn.includes(`행 ${i}값`), `row ${i} is drawn`);
  }
});

test('a short table is marked whole and moved to the next page instead of splitting', async () => {
  const blocks = [{ type: 'heading1', text: '절' }];
  for (let i = 0; i < 26; i += 1) blocks.push({ type: 'detail', text: `한 줄 문장 ${i}` });
  blocks.push({ type: 'table', caption: '짧은 표', headers: ['a', 'b'], rows: Array.from({ length: 8 }, (_, i) => [`${i}`, '값']) });
  blocks.push({ type: 'statement', text: '표 뒤 문장.' });
  const d = workspace();
  const out = join(d, 'out.hwpx');
  const res = await appendBlocks(join(d, 'in.hwpx'), out, { session: { date: '2026-09-29', project: 't' }, blocks }, d);
  assert.deepEqual(res.layout.splitTables, []);
  const bytes = readFileSync(out);
  const xml = strFromU8(unzipSync(bytes)['Contents/section0.xml']);
  const short = xml.slice(xml.lastIndexOf('<hp:tbl', xml.indexOf('<hp:t>0</hp:t>')));
  assert.match(short, /^<hp:tbl\b[^>]*pageBreak="NONE"/);
  assert.match(short, /^[^]*?<hp:pos\b[^>]*treatAsChar="1"/, 'treated as a character so Hancom moves it whole');
  const { pages, lastPages, texts } = await inspectBodyFlow(bytes);
  const table = texts.findIndex((t) => t.includes('짧은 표')) + 1;
  assert.equal(pages[table], lastPages[table], 'the table is on one page');
  assert.equal(pages[table - 1], pages[table], 'the title stays with the table');
  const rendered = [];
  const doc = new core.HwpDocument(new Uint8Array(bytes));
  for (let page = 0; page < doc.pageCount(); page += 1) {
    rendered.push(...(JSON.parse(doc.getPageTextLayout(page)).runs ?? []).map((r) => r.text));
  }
  for (let i = 0; i < 8; i += 1) {
    assert.ok(rendered.includes(`${i}`), `row ${i} is drawn`);
  }
});

test('the output keeps mimetype as the first, uncompressed zip entry', async () => {
  const { bytes } = await build([{ type: 'table', caption: '표', headers: ['a'], rows: [['1']] }]);
  assert.equal(bytes.readUInt32LE(0), 0x04034b50);
  assert.equal(bytes.readUInt16LE(8), 0, 'stored');
  assert.equal(bytes.subarray(30, 38).toString('ascii'), 'mimetype');
});

test('generated table cells use their own margins', async () => {
  const { xml } = await build([{ type: 'table', headers: ['a'], rows: [['1']] }]);
  const table = xml.slice(xml.lastIndexOf('<hp:tbl', xml.indexOf('<hp:t>a</hp:t>')));
  const cells = [...table.slice(0, table.indexOf('</hp:tbl>')).matchAll(/<hp:tc\b[^>]*>/g)];
  assert.equal(cells.length, 2);
  for (const [tc] of cells) {
    assert.match(tc, /hasMargin="1"/);
  }
});

test('an append that continues after a table keeps the space after it', async () => {
  const d = workspace();
  const first = join(d, 'first.hwpx');
  const second = join(d, 'second.hwpx');
  const session = { date: '2026-09-29', project: 't' };
  await appendBlocks(join(d, 'in.hwpx'), first,
    { session, blocks: [{ type: 'heading1', text: '표' }, { type: 'table', headers: ['a'], rows: [['1']] }] }, d);
  const res = await appendBlocks(first, second,
    { session, blocks: [{ type: 'statement', text: '이어 쓴 문장임.' }, { type: 'table', headers: ['b'], rows: [['2']] },
      { type: 'table', headers: ['c'], rows: [['3']] }] }, d);
  const entries = unzipSync(readFileSync(second));
  const xml = strFromU8(entries['Contents/section0.xml']);
  const header = strFromU8(entries['Contents/header.xml']);
  const continued = paragraphs(xml).find((p) => p.text === '◯ 이어 쓴 문장임.');
  assert.ok(prevSpacing(header, continued.paraPr) > 0, 'first paragraph of the append has space before it');
  // the untitled table right after another table carries the space on its own paragraph
  const carriers = [...xml.matchAll(/<hp:p\b[^>]*paraPrIDRef="(\d+)"[^>]*>(?:(?!<\/hp:p>)[\s\S])*?<hp:tbl\b[^>]*>(?:(?!<hp:tbl\b)[\s\S])*?<hp:t>3<\/hp:t>/g)];
  assert.equal(carriers.length, 1);
  assert.ok(prevSpacing(header, carriers[0][1]) > 0, 'second table in a row has space before it');
  assert.equal(res.layout.summarySplit, false);
  assert.deepEqual(res.layout.unresolved, []);
});

test('validateDraft accepts form rows of the right shape and rejects others', async () => {
  const { validateDraft } = await import('../lib/validate.js');
  const d = workspace();
  const base = { session: { date: '2026-09-29', project: 't' }, template: 'kigam-annual',
    blocks: [{ type: 'statement', text: '문장.' }] };
  assert.deepEqual(validateDraft({ ...base, form: { goals: [['a', 'b', '100']], summary: [['a', 'b', 'c', 'd']] } }, d),
    { ok: true, errors: [] });
  const bad = validateDraft({ ...base, form: { goals: [['a', 'b']], summary: Array(7).fill(['a', 'b', 'c', 'd']), x: [] } }, d);
  assert.equal(bad.ok, false);
  assert.ok(bad.errors.some((e) => e.includes('form.goals[0]')));
  assert.ok(bad.errors.some((e) => e.includes('form.summary must be')));
  assert.ok(bad.errors.some((e) => e.includes('form.x is not allowed')));
  const generic = validateDraft({ ...base, template: 'research-report', form: { title: '제목', goals: [['a', 'b', 'c']] } }, d);
  assert.ok(generic.errors.some((e) => e.includes('has no goals table')));
  assert.ok(validateDraft({ ...base, template: 'no-such-form' }, d).errors.some((e) => e.includes('unknown form')));
});

test('an institute-form figure taller than one page with its caption is rejected', async () => {
  const d = workspace();
  // 4 x 40 px: drawn at the full text width it is ten times taller than wide
  const tall = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAQAAAAoCAIAAABW/cxkAAAAEUlEQVR4nGNoQAIMo5yRygEA0EXwAUTo/IQAAAAASUVORK5CYII=', 'base64');
  writeFileSync(join(d, 'fig/tall.png'), tall);
  await assert.rejects(appendBlocks(join(d, 'in.hwpx'), join(d, 'out.hwpx'), { session: { date: '2026-09-29', project: 't' },
    blocks: [{ type: 'figure_grid', images: ['fig/tall.png'], columns: 1, caption: '긴 그림', captionStyle: 'angle' }] }, d),
  /taller than one page/);
});

const SVG = (extra = '') => Buffer.from('<?xml version="1.0"?>\n<svg xmlns="http://www.w3.org/2000/svg" '
  + `width="468pt" height="216pt" viewBox="0 0 468 216">${extra}<rect x="10" y="10" width="100" height="50" fill="#1f77b4"/></svg>`);

test('SVG figures are embedded as vector pictures in the figure table', async () => {
  const d = workspace();
  writeFileSync(join(d, 'fig/v.svg'), SVG());
  const out = join(d, 'out.hwpx');
  await appendBlocks(join(d, 'in.hwpx'), out, { session: { date: '2026-09-29', project: 't' },
    blocks: [{ type: 'figure_grid', images: ['fig/v.svg', 'fig/a.png'], columns: 2, caption: '벡터와 래스터', captionStyle: 'angle' }] }, d);
  const entries = unzipSync(readFileSync(out));
  const svgs = Object.keys(entries).filter((k) => k.startsWith('BinData/') && k.endsWith('.svg'));
  assert.equal(svgs.length, 1);
  assert.match(strFromU8(entries[svgs[0]]), /<rect x="10"/);
  const hpf = strFromU8(entries['Contents/content.hpf']);
  assert.match(hpf, new RegExp(`href="${svgs[0]}" media-type="image/svg\\+xml"`));
  const xml = strFromU8(entries['Contents/section0.xml']);
  const [figure] = nestedTables(xml);
  assert.equal([...figure.matchAll(/<hp:pic\b/g)].length, 2);
  for (const pos of figure.matchAll(/<hp:pic\b[\s\S]*?<hp:pos\b[^>]*>/g)) {
    assert.match(pos[0], /treatAsChar="1"/);
  }
});

test('drafts refuse SVG figures (Hancom does not show them) and the SVG guard refuses scripts and outside references', async () => {
  const { validateDraft } = await import('../lib/validate.js');
  const { svgInfo } = await import('../lib/svg.js');
  const d = workspace();
  writeFileSync(join(d, 'fig/ok.svg'), SVG('<image href="data:image/png;base64,AAAA" width="1" height="1"/>'));
  const draft = (img) => ({ session: { date: '2026-09-29', project: 't' },
    blocks: [{ type: 'figure_grid', images: [img], columns: 1, caption: 'c', captionStyle: 'angle' }] });
  assert.ok(validateDraft(draft('fig/ok.svg'), d).errors.some((e) => e.includes('not shown by Hancom')));
  assert.throws(() => svgInfo(SVG('<script>alert(1)</script>')), /script/);
  assert.throws(() => svgInfo(SVG('<image href="https://example.org/x.png" width="1" height="1"/>')), /outside resource/);
  assert.doesNotThrow(() => svgInfo(SVG('<image href="data:image/png;base64,AAAA" width="1" height="1"/>')));
});

test('SVG checks refuse DTD entities, foreign content and CSS references but keep the W3C doctype', async () => {
  const { svgInfo } = await import('../lib/svg.js');
  const svg = (body, prolog = '') => Buffer.from(`${prolog}<svg xmlns="http://www.w3.org/2000/svg" width="10" height="10">${body}</svg>`);
  const refused = {
    'entities or an external DTD': [svg('', '<!DOCTYPE svg [<!ENTITY x "y">]>'),
      svg('', '<!DOCTYPE svg SYSTEM "x.dtd">'),
      svg('', '<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://example.org/svg11.dtd">')],
    'foreign content': [svg('<foreignObject width="1" height="1"/>'),
      svg('<s:foreignObject xmlns:s="http://www.w3.org/2000/svg"/>')],
    'script or event handler': [svg('<s:script xmlns:s="http://www.w3.org/2000/svg">x()</s:script>'),
      svg('<rect o&#110;load="x()"/>'), svg('<&#115;cript>x()</&#115;cript>')],
    'outside resource': [svg('<rect style="fill:url(https://example.org/p)"/>'), svg('<style>@import "x.css";</style>'),
      svg('<rect style="fill:u\\72l(https://example.org/p)"/>'), svg('<a:image xmlns:a="http://www.w3.org/1999/xlink" a:href="https://example.org/x.png"/>'),
      svg('<image href="data:image/svg+xml;base64,AAAA"/>')],
  };
  for (const [message, buffers] of Object.entries(refused)) {
    for (const b of buffers) {
      assert.throws(() => svgInfo(b), new RegExp(message), b.toString());
    }
  }
  const sized = (attrs) => Buffer.from(`<svg xmlns="http://www.w3.org/2000/svg" ${attrs}/>`);
  for (const attrs of ['width="0.4" height="10"', 'viewBox="0 0 Infinity 10"', 'width="10"', 'width="1e9" height="1"', 'width="10%" height="10%"']) {
    assert.throws(() => svgInfo(sized(attrs)), /SVG/, attrs);
  }
  assert.deepEqual(svgInfo(sized('width="10.5pt" viewBox="0 0 1 1" height="3pt"')), { width: 14, height: 4 });
  const w3c = '<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN"\n  "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">';
  assert.deepEqual(svgInfo(svg('<rect clip-path="url(#c)"/>', w3c)), { width: 10, height: 10 });
});

test('the general research-report form: title, body to the end of the document, continuing appends', async () => {
  const d = workspace();
  const first = join(d, 'first.hwpx');
  const second = join(d, 'second.hwpx');
  const session = { date: '2026-09-29', project: 't' };
  const res = await appendBlocks(getForm('research-report').skeleton, first, { session, template: 'research-report',
    form: { title: '시험 연구보고서' },
    blocks: [{ type: 'heading1', text: '연구 배경' }, { type: 'statement', text: '첫 문장임.' },
      { type: 'table', caption: '표 제목', headers: ['a', 'b'], rows: [['1', '2']] }] }, d);
  assert.equal(res.form, 'research-report');
  assert.equal(res.layout.summarySplit, false);
  await appendBlocks(first, second, { session, blocks: [{ type: 'heading2', text: '이어 쓴 소절' },
    { type: 'statement', text: '이어 쓴 문장임.' }, { type: 'heading1', text: '새 절' }] }, d);
  const xml = strFromU8(unzipSync(readFileSync(second))['Contents/section0.xml']);
  const texts = paragraphs(xml).map((p) => p.text).filter(Boolean);
  assert.equal(texts[0], '시험 연구보고서');
  assert.deepEqual(texts.slice(1, 3), ['가. 연구 배경', '◯ 첫 문장임.']);
  // numbering goes on from the headings already in the body
  assert.deepEqual(texts.slice(-3), ['1) 이어 쓴 소절', '◯ 이어 쓴 문장임.', '나. 새 절'],
    'the append continues at the end');
  const location = bodyLocation(xml, getForm('research-report'));
  assert.equal(location.endEmpty, true, 'the document still ends in the empty paragraph the body is written before');
  const { overflow, keep, pages } = await inspectBodyFlow(readFileSync(second));
  assert.deepEqual(overflow.filter(Boolean), []);
  assert.equal(keep.length, pages.length);
});

test('a draft whose template differs from the target form is refused', async () => {
  const d = workspace();
  await assert.rejects(appendBlocks(join(d, 'in.hwpx'), join(d, 'out.hwpx'), { session: { date: '2026-09-29', project: 't' },
    template: 'research-report', blocks: [{ type: 'statement', text: '문장.' }] }, d), /target document is form "kigam-annual"/);
  await assert.rejects(appendBlocks(getForm('research-report').skeleton, join(d, 'out.hwpx'), { session: { date: '2026-09-29', project: 't' },
    form: { goals: [['a', 'b', 'c']] }, blocks: [{ type: 'statement', text: '문장.' }] }, d), /has no goals/);
});

test('a document whose styles differ from the engine forms is not continued', async () => {
  const d = workspace();
  const entries = unzipSync(readFileSync(join(d, 'in.hwpx')));
  const header = strFromU8(entries['Contents/header.xml']);
  const restyled = header.replace(/(<hh:charPr id="46" height=")\d+/, '$12400');
  assert.notEqual(restyled, header);
  const { zipSync, strToU8 } = await import('fflate');
  entries['Contents/header.xml'] = strToU8(restyled);
  writeFileSync(join(d, 'other.hwpx'), zipSync(entries));
  await assert.rejects(appendBlocks(join(d, 'other.hwpx'), join(d, 'out.hwpx'), { session: { date: '2026-09-29', project: 't' },
    blocks: [{ type: 'statement', text: '문장.' }] }, d), /styles differ from the engine's forms \(charPr 46\)/);
  // definitions the engine's styles point to count too: a font or tab changed under the same IDs
  const fontChanged = header.replace(/(<hh:fontface lang="HANGUL"[\s\S]*?<hh:font id="8" face=")[^"]*/, '$1Other Font');
  assert.notEqual(fontChanged, header);
  assert.deepEqual(styleMismatches(fontChanged), ['font:HANGUL 8']);
  const tabChanged = header.replace('<hh:tabPr id="1" autoTabLeft="1"', '<hh:tabPr id="1" autoTabLeft="0"');
  assert.notEqual(tabChanged, header);
  assert.deepEqual(styleMismatches(tabChanged), ['tabPr 1']);
  // engine output (bullet container restored after export) and the plain skeletons pass
  assert.deepEqual(styleMismatches(header), []);
  assert.deepEqual(styleMismatches(readHeaderXml(getForm('research-report').skeleton)), []);
});

test('continuation numbering reads the body up to its last paragraph, heading or not', () => {
  const p = (t) => `<hp:p id="0" paraPrIDRef="0" styleIDRef="0"><hp:run charPrIDRef="0"><hp:t>${t}</hp:t></hp:run></hp:p>`;
  const form = getForm('research-report');
  // a document that ends in a heading without the empty end paragraph
  assert.deepEqual(outlineCounters(`<hs:sec>${p('보고서')}${p('가. 앞 절')}${p('◯ 문장임.')}${p('나. 마지막 제목')}</hs:sec>`, form),
    [2, 0, 0]);
  assert.deepEqual(outlineCounters(`<hs:sec>${p('보고서')}${p('가. 앞 절')}${p('1) 소절')}${p('(2) 항')}${p('')}</hs:sec>`, form),
    [1, 1, 2]);
});

test('summary rows fit wrapped text plus the table inner margin their cells use', async () => {
  const long = '공개 지질·지구물리 자료의 출처·좌표·단위·영역을 관리하고 격자형 분석 입력으로 인계하는 수집 기능';
  const { out } = await buildDraft({ blocks: [{ type: 'statement', text: '본문.' }],
    form: { summary: [['구분', long, '출처', '목적']] } });
  const xml = strFromU8(unzipSync(readFileSync(out))['Contents/section0.xml']);
  const at = xml.indexOf(long.slice(0, 10));
  const tc = xml.slice(xml.lastIndexOf('<hp:tc', at), xml.indexOf('</hp:tc>', at));
  assert.match(tc, /hasMargin="0"/, 'the form cell takes the table inner margin');
  const table = xml.slice(xml.lastIndexOf('<hp:tbl', at));
  const [, top, bottom] = table.match(/<hp:inMargin\b[^>]*\btop="(\d+)"[^>]*\bbottom="(\d+)"/).map(Number);
  const lines = [...tc.matchAll(/<hp:lineseg\b[^>]*\bvertpos="(\d+)"[^>]*\bvertsize="(\d+)"/g)];
  assert.ok(lines.length >= 3, 'the long cell wraps');
  const content = Math.max(...lines.map((m) => Number(m[1]) + Number(m[2])));
  const height = Number(tc.match(/<hp:cellSz\b[^>]*\bheight="(\d+)"/)[1]);
  assert.ok(height >= content + top + bottom, `row height ${height} holds ${content} + margins ${top + bottom}`);
});
