import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, writeFileSync, readFileSync, existsSync, readdirSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { acquireLock, sha256, backupRotate, commitCandidate, appendJournal } from '../lib/atomic.js';

function setup() {
  const d = mkdtempSync(join(tmpdir(), 'hwpxatomic-'));
  const target = join(d, 'r.hwpx');
  writeFileSync(target, 'v1');
  return { d, target };
}
test('second lock acquisition throws with pid info, release frees', () => {
  const { target } = setup();
  const rel = acquireLock(target);
  assert.throws(() => acquireLock(target), /LockHeld/);
  const lockBody = JSON.parse(readFileSync(target + '.lock', 'utf8'));
  assert.equal(lockBody.pid, process.pid);
  rel();
  assert.equal(existsSync(target + '.lock'), false);
  acquireLock(target)();
});
test('release is idempotent and ignores an already removed lock file', () => {
  const { target } = setup();
  const rel = acquireLock(target);
  rel();
  assert.doesNotThrow(() => rel());

  const rel2 = acquireLock(target);
  rmSync(target + '.lock');
  assert.doesNotThrow(() => rel2());
});
test('backup rotation keeps 5, never deletes golden', () => {
  const { d, target } = setup();
  writeFileSync(join(d, 'r.golden.hwpx'), 'gold');
  for (let i = 0; i < 7; i++) backupRotate(target, 5, `2026070${i}T000000Z`);
  const baks = readdirSync(d).filter((f) => f.includes('.bak-'));
  assert.equal(baks.length, 5);
  assert.ok(existsSync(join(d, 'r.golden.hwpx')));
});
test('CAS mismatch aborts, target untouched', () => {
  const { d, target } = setup();
  const cand = join(d, 'r.tmp.hwpx');
  writeFileSync(cand, 'v2');
  assert.throws(() => commitCandidate(cand, target, 'deadbeef'), /CasMismatch/);
  assert.equal(readFileSync(target, 'utf8'), 'v1');
});
test('CAS match commits atomically', () => {
  const { d, target } = setup();
  const cand = join(d, 'r.tmp.hwpx');
  writeFileSync(cand, 'v2');
  commitCandidate(cand, target, sha256(target));
  assert.equal(readFileSync(target, 'utf8'), 'v2');
});
test('null expectedSha: first-append commits only when target absent', () => {
  const { d } = setup();
  const fresh = join(d, 'new.hwpx');
  const cand = join(d, 'new.tmp.hwpx');
  writeFileSync(cand, 'v1');
  commitCandidate(cand, fresh, null);                       // target absent → ok
  assert.equal(readFileSync(fresh, 'utf8'), 'v1');
  writeFileSync(cand, 'v2');
  assert.throws(() => commitCandidate(cand, fresh, null), /CasMismatch/); // now exists → throw
});
test('CAS mismatch messages distinguish missing, changed, and first-append races', () => {
  const { d, target } = setup();
  const cand = join(d, 'r.tmp.hwpx');
  writeFileSync(cand, 'v2');

  rmSync(target);
  assert.throws(
    () => commitCandidate(cand, target, 'expected-sha'),
    /target missing \(expected sha expected-sha\)/,
  );

  writeFileSync(target, 'changed');
  assert.throws(
    () => commitCandidate(cand, target, 'expected-sha'),
    /sha mismatch \(expected expected-sha, actual [a-f0-9]{64}\)/,
  );

  assert.throws(
    () => commitCandidate(cand, target, null),
    /target exists \(expected first-append\)/,
  );
});
test('journal appends one JSON line', () => {
  const { d } = setup();
  const j = join(d, 'journal.jsonl');
  appendJournal(j, { a: 1 });
  appendJournal(j, { a: 2 });
  assert.equal(readFileSync(j, 'utf8').trim().split('\n').length, 2);
});
