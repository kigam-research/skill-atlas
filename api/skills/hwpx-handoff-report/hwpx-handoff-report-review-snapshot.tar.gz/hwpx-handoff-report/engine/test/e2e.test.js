import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  chmodSync,
  copyFileSync,
  existsSync,
  mkdirSync,
  mkdtempSync,
  readdirSync,
  readFileSync,
  rmSync,
  symlinkSync,
  writeFileSync,
} from 'node:fs';
import { execFileSync, spawn } from 'node:child_process';
import { basename, dirname, join } from 'node:path';
import { tmpdir } from 'node:os';
import { setTimeout as sleep } from 'node:timers/promises';
import { anchorInfo, captionNumbers, readSectionXml } from '../lib/hwpx-read.js';

const SCRIPT = new URL('../append_report.mjs', import.meta.url).pathname;
const VERIFY_SCRIPT = new URL('../verify_report.sh', import.meta.url).pathname;
const SKELETON = new URL('../forms/kigam-annual/skeleton.hwpx', import.meta.url).pathname;
const PNG_4X4 = Buffer.from(
  readFileSync(new URL('./fixtures/png-4x4.b64', import.meta.url), 'utf8').replace(/\s+/g, ''),
  'base64',
);
const REL_TARGET = 'docs/report/annual-report-draft.hwpx';

test('E2E continuity preserves figure numbering, ignores inline decoy text, and appends in the body before the summary table', () => {
  const root = makeProject();
  writePng(root, 'fig/a.png');
  writePng(root, 'fig/b.png');
  writePng(root, 'fig/c.png');
  const target = join(root, REL_TARGET);
  const draftA = writeDraft(root, 'draft-a.json', {
    session: { date: '2026-07-09', project: 'tool_exp' },
    template: 'kigam-annual',
    blocks: [
      { type: 'bullet1', text: '연속성 E2E 성과' },
      { type: 'figure_grid', images: ['fig/a.png'], columns: 1, caption: '첫 번째 그림' },
      { type: 'bullet3', text: '그림 1에서 보듯이 경향이 확인되었다' },
      { type: 'figure_grid', images: ['fig/b.png'], columns: 1, caption: '두 번째 그림' },
    ],
  });
  const draftB = writeDraft(root, 'draft-b.json', {
    session: { date: '2026-07-10', project: 'tool_exp' },
    template: 'kigam-annual',
    blocks: [
      { type: 'bullet2', text: '두 번째 append 성과' },
      { type: 'figure_grid', images: ['fig/c.png'], columns: 1, caption: '세 번째 그림' },
    ],
  });

  const first = JSON.parse(runCli(root, ['--draft', draftA, '--target', REL_TARGET, '--project-root', root]).trim());
  assert.equal(first.ok, true);
  assert.deepEqual(captionNumbers(readSectionXml(target)), [1, 2]);

  const second = JSON.parse(runCli(root, ['--draft', draftB, '--target', REL_TARGET, '--project-root', root]).trim());
  assert.equal(second.ok, true);

  const xml = readSectionXml(target);
  assert.deepEqual(captionNumbers(xml), [1, 2, 3]);
  assert.equal(existsSync(`${target}.preview.pdf`), true);
  assertInsideAnchorWindow(xml, [
    '연속성 E2E 성과',
    '그림 1. 첫 번째 그림',
    '그림 1에서 보듯이 경향이 확인되었다',
    '그림 2. 두 번째 그림',
    '두 번째 append 성과',
    '그림 3. 세 번째 그림',
  ]);
});

test('E2E lock conflict exits 3 without touching target or backup ring', () => {
  const root = makeProject();
  const target = join(root, REL_TARGET);
  mkdirSync(dirname(target), { recursive: true });
  copyFileSync(SKELETON, target);
  writeFileSync(`${target}.bak-20260709T000000Z`, 'old backup');
  const targetBefore = readFileSync(target);
  const backupsBefore = backupNames(target);
  const lockBody = '{"pid":12345,"utc":"2026-07-09T00:00:00.000Z"}';
  writeFileSync(`${target}.lock`, lockBody);
  const draftPath = writeDraft(root, 'draft.json', validTextDraft());

  const result = runCliFail(root, 3, ['--draft', draftPath, '--target', REL_TARGET, '--project-root', root], {
    HWPX_VERIFY_CMD: writeFastVerifier(root),
  });

  assert.match(result.stderr, /LockHeld/);
  assert.deepEqual(readFileSync(target), targetBefore);
  assert.deepEqual(backupNames(target), backupsBefore);
  assert.equal(readFileSync(`${target}.lock`, 'utf8'), lockBody);
  assertNoTransients(target, { allowLock: true });
});

test('E2E direct target mutation during pre-commit sleep exits 3 without rotating backup', async () => {
  const root = makeProject();
  const target = join(root, REL_TARGET);
  mkdirSync(dirname(target), { recursive: true });
  copyFileSync(SKELETON, target);
  const backupsBefore = backupNames(target);
  const marker = join(root, 'verified.marker');
  const verifier = writeExecutable(root, 'verify-marker.sh', [
    '#!/usr/bin/env bash',
    'set -euo pipefail',
    'printf PDF > "$2"',
    ': > "$HWPX_MARKER"',
  ].join('\n'));
  const draftPath = writeDraft(root, 'draft.json', validTextDraft());

  const child = spawnCli(root, ['--draft', draftPath, '--target', REL_TARGET, '--project-root', root], {
    HWPX_VERIFY_CMD: verifier,
    HWPX_MARKER: marker,
    HWPX_TEST_SLEEP_BEFORE_COMMIT: '2',
  });
  await waitFor(() => existsSync(marker));

  const racedBytes = Buffer.concat([readFileSync(target), Buffer.from('!')]);
  writeFileSync(target, racedBytes);
  const result = await child.done;

  assert.equal(result.status, 3, result.stderr || result.stdout);
  assert.match(result.stderr, /CasMismatch/);
  assert.deepEqual(readFileSync(target), racedBytes);
  assert.deepEqual(backupNames(target), backupsBefore);
  assertNoTransients(target);
  assert.equal(existsSync(join(root, 'docs/report/report-journal.jsonl')), false);
});

test('E2E concurrent first append lets exactly one process commit and leaves a roundtrippable target', async () => {
  const root = makeProject();
  const target = join(root, REL_TARGET);
  const draftPath = writeDraft(root, 'draft.json', validTextDraft());
  const verifier = writeExecutable(root, 'verify-slow.sh', [
    '#!/usr/bin/env bash',
    'set -euo pipefail',
    'sleep 0.4',
    'printf PDF > "$2"',
  ].join('\n'));
  const args = ['--draft', draftPath, '--target', REL_TARGET, '--project-root', root];
  let spawned = 0;
  let exitBeforeBothSpawned = false;
  const spawnTracked = () => {
    const child = spawnCli(root, args, { HWPX_VERIFY_CMD: verifier });
    spawned += 1;
    child.process.once('exit', () => {
      if (spawned < 2) {
        exitBeforeBothSpawned = true;
      }
    });
    return child;
  };

  const first = spawnTracked();
  const second = spawnTracked();
  assert.equal(spawned, 2);
  const results = await Promise.all([first.done, second.done]);

  assert.equal(exitBeforeBothSpawned, false);
  assert.deepEqual(results.map((result) => result.status).sort(), [0, 3]);
  assert.equal(results.filter((result) => result.status === 0).length, 1);
  assert.ok(results.find((result) => result.status === 3).stderr.includes('LockHeld'));
  assert.equal(existsSync(target), true);
  assertNoTransients(target);
  assertRoundtripPass(target);
});

test('E2E CLI rejects unsafe image inputs before creating a target', () => {
  const cases = [
    {
      name: 'absolute image path',
      setup(root) {
        writePng(root, 'fig/a.png');
        return invalidFigureDraft(join(root, 'fig/a.png'));
      },
      pattern: /image path must be relative/,
    },
    {
      name: 'parent directory escape',
      setup() {
        return invalidFigureDraft('../outside.png');
      },
      pattern: /image path must not contain \.\./,
    },
    {
      name: 'symlink image component',
      setup(root) {
        writePng(root, 'fig/a.png');
        symlinkSync(join(root, 'fig/a.png'), join(root, 'fig/link.png'));
        return invalidFigureDraft('fig/link.png');
      },
      pattern: /symlink components/,
    },
    {
      name: 'fake PNG magic',
      setup(root) {
        mkdirSync(join(root, 'fig'), { recursive: true });
        writeFileSync(join(root, 'fig/fake.png'), Buffer.from('not a png'));
        return invalidFigureDraft('fig/fake.png');
      },
      pattern: /must be a PNG/,
    },
    {
      name: 'oversized PNG dimensions',
      setup(root) {
        const tooWide = Buffer.from(PNG_4X4);
        tooWide.writeUInt32BE(4097, 16);
        mkdirSync(join(root, 'fig'), { recursive: true });
        writeFileSync(join(root, 'fig/too-wide.png'), tooWide);
        return invalidFigureDraft('fig/too-wide.png');
      },
      pattern: /image dimensions exceed 4096px/,
    },
  ];

  for (const item of cases) {
    const root = makeProject();
    const target = join(root, REL_TARGET);
    const draftPath = writeDraft(root, `${item.name.replace(/\W+/g, '-')}.json`, item.setup(root));

    const result = runCliFail(root, 2, ['--draft', draftPath, '--target', REL_TARGET, '--project-root', root], {
      HWPX_VERIFY_CMD: writeFastVerifier(root),
    });

    assert.match(result.stderr, item.pattern, item.name);
    assert.equal(existsSync(target), false, item.name);
    assertNoTransients(target);
    assert.equal(existsSync(join(root, 'docs/report/report-journal.jsonl')), false, item.name);
  }
});

function makeProject() {
  return mkdtempSync(join(tmpdir(), 'hwpxe2e-'));
}

function validTextDraft() {
  return {
    session: { date: '2026-07-09', project: 'tool_exp' },
    template: 'kigam-annual',
    blocks: [{ type: 'bullet1', text: 'E2E smoke' }],
  };
}

function invalidFigureDraft(imagePath) {
  return {
    session: { date: '2026-07-09', project: 'tool_exp' },
    template: 'kigam-annual',
    blocks: [{ type: 'figure_grid', images: [imagePath], columns: 1, caption: 'invalid' }],
  };
}

function writePng(root, relPath) {
  const path = join(root, relPath);
  mkdirSync(dirname(path), { recursive: true });
  writeFileSync(path, PNG_4X4);
  return path;
}

function writeDraft(root, name, draft) {
  const path = join(root, name);
  writeFileSync(path, JSON.stringify(draft), 'utf8');
  return path;
}

function writeFastVerifier(root) {
  return writeExecutable(root, 'verify-ok.sh', [
    '#!/usr/bin/env bash',
    'set -euo pipefail',
    'printf PDF > "$2"',
  ].join('\n'));
}

function writeExecutable(root, name, content) {
  const path = join(root, name);
  writeFileSync(path, `${content}\n`, 'utf8');
  chmodSync(path, 0o755);
  return path;
}

function runCli(root, args, env = {}) {
  return execFileSync('node', [SCRIPT, ...args], {
    cwd: root,
    env: cliEnv(env),
    encoding: 'utf8',
    stdio: ['ignore', 'pipe', 'pipe'],
  });
}

function runCliFail(root, expectedStatus, args, env = {}) {
  try {
    runCli(root, args, env);
  } catch (error) {
    assert.equal(error.status, expectedStatus, error.stderr?.toString() || error.message);
    return {
      stdout: error.stdout?.toString() ?? '',
      stderr: error.stderr?.toString() ?? '',
    };
  }
  assert.fail(`expected exit ${expectedStatus}`);
}

function spawnCli(root, args, env = {}) {
  const child = spawn('node', [SCRIPT, ...args], {
    cwd: root,
    env: cliEnv(env),
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  let stdout = '';
  let stderr = '';
  child.stdout.setEncoding('utf8');
  child.stderr.setEncoding('utf8');
  child.stdout.on('data', (chunk) => { stdout += chunk; });
  child.stderr.on('data', (chunk) => { stderr += chunk; });
  return {
    process: child,
    done: new Promise((resolve, reject) => {
      child.on('error', reject);
      child.on('close', (status, signal) => resolve({ status, signal, stdout, stderr }));
    }),
  };
}

function cliEnv(env) {
  return {
    ...process.env,
    PATH: `${process.env.HOME}/.local/bin:${process.env.PATH}`,
    ...env,
  };
}

async function waitFor(predicate, timeoutMs = 5000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (predicate()) {
      return;
    }
    await sleep(20);
  }
  assert.fail(`timed out after ${timeoutMs}ms`);
}

function assertInsideAnchorWindow(xml, texts) {
  const anchor = anchorInfo(xml);
  for (const text of texts) {
    const pos = xml.indexOf(text);
    assert.ok(pos >= 0, `missing appended text: ${text}`);
    assert.ok(
      pos > xml.indexOf('3-1 정성적 연구개발성과') && pos < anchor.summaryTableIndex,
      `${text} at ${pos} is outside the body window (3-1 heading to summary table)`,
    );
  }
}

function assertNoTransients(target, options = {}) {
  const allowLock = options.allowLock === true;
  if (!allowLock) {
    assert.equal(existsSync(`${target}.lock`), false, 'lock should be removed');
  }
  assert.equal(existsSync(`${target}.tmp.hwpx`), false, 'candidate should be removed');
  assert.equal(existsSync(`${target}.tmp.pdf`), false, 'temp pdf should be removed');
  const dir = dirname(target);
  if (!existsSync(dir)) {
    return;
  }
  assert.deepEqual(
    readdirSync(dir).filter((name) => name.endsWith('.tmp.hwpx') || name.endsWith('.tmp.pdf')).sort(),
    [],
  );
}

function backupNames(target) {
  const dir = dirname(target);
  if (!existsSync(dir)) {
    return [];
  }
  return readdirSync(dir)
    .filter((name) => name.startsWith(`${basename(target)}.bak-`))
    .sort();
}

function assertRoundtripPass(target) {
  const outDir = join(dirname(target), 'rt-check');
  rmSync(outDir, { recursive: true, force: true });
  const output = execFileSync(process.env.HOME + '/.local/bin/rhwp', ['hwpx-roundtrip', target, '-o', outDir], {
    encoding: 'utf8',
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  assert.match(output, /PASS.*diff= *0\s+r2= *0(\s|$)/);
  rmSync(outDir, { recursive: true, force: true });
}
