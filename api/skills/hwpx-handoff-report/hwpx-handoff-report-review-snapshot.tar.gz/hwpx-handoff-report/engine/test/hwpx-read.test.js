import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readSectionXml, captionNumbers, nextFigureNumber, anchorInfo } from '../lib/hwpx-read.js';

// Portable fixture: use the distributed empty form, never a user's research report.
const SKELETON = new URL('../forms/kigam-annual/skeleton.hwpx', import.meta.url).pathname;

function sampleWithCaptions() {
  const captions = [1, 2, 3].map(number =>
    `<hp:p paraPrIDRef="57" styleIDRef="0"><hp:run charPrIDRef="50"><hp:t>그림 ${number}. 서식 예시</hp:t></hp:run></hp:p>`).join('');
  return readSectionXml(SKELETON).replace('</hs:sec>', `${captions}</hs:sec>`);
}

test('neutral skeleton has no captions and starts figure numbering at one', () => {
  const xml = readSectionXml(SKELETON);
  assert.deepEqual(captionNumbers(xml), []);
  assert.equal(nextFigureNumber(xml), 1);
});

test('sample captions are 1..3 (style-independent text match)', () => {
  const xml = sampleWithCaptions();
  assert.deepEqual(captionNumbers(xml), [1, 2, 3]);
  assert.equal(nextFigureNumber(xml), 4);
});
test('inline "그림 5에서" decoy (no period) not counted', () => {
  const xml = sampleWithCaptions().replace(
    '</hs:sec>',
    '<hp:p paraPrIDRef="5" styleIDRef="0"><hp:run charPrIDRef="53"><hp:t>그림 5에서 보듯이</hp:t></hp:run></hp:p></hs:sec>');
  assert.equal(nextFigureNumber(xml), 4);
});
test('duplicate caption number throws (plain style-0 caption)', () => {
  const xml = sampleWithCaptions();
  const dup = xml.replace('</hs:sec>',
    '<hp:p paraPrIDRef="57" styleIDRef="0"><hp:run charPrIDRef="50"><hp:t>그림 3. 중복</hp:t></hp:run></hp:p></hs:sec>');
  assert.throws(() => nextFigureNumber(dup));
});
test('sample anchor: unique top-level 7x4 summary table after the 3-1 heading', () => {
  const xml = readSectionXml(SKELETON);
  const a = anchorInfo(xml);
  assert.ok(a.summaryTableIndex > xml.indexOf('3-1 정성적 연구개발성과'));
  assert.ok(a.summaryTableEnd > a.summaryTableIndex);
  assert.ok(!/rowCnt="1" colCnt="1"/.test(xml), 'the form has no 1x1 box around the body');
});
test('missing summary table throws', () => {
  const xml = readSectionXml(SKELETON).replace('rowCnt="7" colCnt="4"', 'rowCnt="6" colCnt="4"');
  assert.throws(() => anchorInfo(xml));
});
test('a summary table nested in another table throws', () => {
  const xml = readSectionXml(SKELETON);
  const start = anchorInfo(xml).summaryTableIndex;
  const end = anchorInfo(xml).summaryTableEnd;
  const nested = `${xml.slice(0, start)}<hp:tbl rowCnt="2" colCnt="2"><hp:tr><hp:tc><hp:subList><hp:p><hp:run>`
    + `${xml.slice(start, end)}</hp:run></hp:p></hp:subList></hp:tc></hp:tr></hp:tbl>${xml.slice(end)}`;
  assert.throws(() => anchorInfo(nested), /top-level|1x1/);
});
