import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  chmodSync,
  copyFileSync,
  existsSync,
  mkdirSync,
  mkdtempSync,
  readdirSync,
  readFileSync,
  rmSync,
  writeFileSync,
} from 'node:fs';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { basename, dirname, join, relative } from 'node:path';
import { tmpdir } from 'node:os';

const SCRIPT = new URL('../append_report.mjs', import.meta.url).pathname;
const VERIFY_SCRIPT = new URL('../verify_report.sh', import.meta.url).pathname;
const SKELETON = new URL('../forms/kigam-annual/skeleton.hwpx', import.meta.url).pathname;
const REL_TARGET = 'docs/report/annual-report-draft.hwpx';
const CORRUPT_IDAT_PNG_4x4 = Buffer.from(
  'iVBORw0KGgoAAAANSUhEUgAAAAQAAAAECAYAAACp8Z5+AAAAEElEQVR4nGNgYGD4z4AGAA0ABv/BQGF2AAAAAElFTkSuQmCC',
  'base64');

test('CLI happy path initializes absent target, verifies with real rhwp, journals, and cleans transients', () => {
  const root = makeProject();
  const draftPath = writeDraft(root, validDraft());
  const target = join(root, REL_TARGET);

  const output = runCli(root, ['--draft', draftPath, '--target', REL_TARGET, '--project-root', root]);
  const summary = JSON.parse(output.trim());

  assert.equal(summary.ok, true);
  assert.equal(summary.target, target);
  assert.equal(summary.blocks, 1);
  assert.equal(existsSync(target), true);
  assert.equal(existsSync(`${target}.preview.pdf`), true);
  assertNoTransients(target);

  const journal = readJsonl(join(root, 'docs/report/report-journal.jsonl'));
  assert.equal(journal.length, 1);
  assert.equal(journal[0].project, 'tool_exp');
  assert.equal(journal[0].blocks, 1);
  assert.equal(journal[0].figures, null);
  assert.equal(journal[0].bytes, readFileSync(target).byteLength);
  assert.equal(journal[0].sha256After, fileSha(target));
  assert.equal(typeof journal[0].binDataCount, 'number');
  // what a golden copy needs to pair the report with the draft that made it
  assert.equal(journal[0].target, REL_TARGET);
  assert.equal(journal[0].draft, relative(root, draftPath));
  assert.equal(journal[0].draftSha256, fileSha(draftPath));
  assert.equal(journal[0].sha256Before, null);
});

test('CLI honors verifier override and pre-commit sleep hook on success', () => {
  const root = makeProject();
  const draftPath = writeDraft(root, validDraft());
  const target = join(root, REL_TARGET);
  const verifier = writeExecutable(root, 'verify-ok.sh', [
    '#!/usr/bin/env bash',
    'set -euo pipefail',
    'printf PDF > "$2"',
    'echo VERIFY_OK',
  ].join('\n'));

  const start = Date.now();
  const output = runCli(
    root,
    ['--draft', draftPath, '--target', REL_TARGET, '--project-root', root],
    { HWPX_VERIFY_CMD: verifier, HWPX_TEST_SLEEP_BEFORE_COMMIT: '0.1' },
  );
  const elapsedMs = Date.now() - start;
  const summary = JSON.parse(output.trim());

  assert.equal(summary.ok, true);
  assert.ok(elapsedMs >= 75, `sleep hook returned too quickly: ${elapsedMs}ms`);
  assert.equal(existsSync(target), true);
  assert.equal(existsSync(`${target}.preview.pdf`), true);
  assertNoTransients(target);
});

test('CLI validation reject exits 2 before creating target artifacts', () => {
  const root = makeProject();
  const target = join(root, REL_TARGET);
  const draftPath = writeDraft(root, { session: { date: 'bad', project: 'tool_exp' }, blocks: [] });

  const result = runCliFail(root, 2, ['--draft', draftPath, '--target', REL_TARGET, '--project-root', root]);

  assert.match(result.stderr, /session\.date|blocks must be a nonempty array/);
  assert.equal(existsSync(target), false);
  assertNoTransients(target);
  assertNoPdfArtifacts(target);
  assert.equal(existsSync(join(root, 'docs/report/report-journal.jsonl')), false);
});

test('CLI lock conflict exits 3 and leaves only the pre-existing lock', () => {
  const root = makeProject();
  const target = join(root, REL_TARGET);
  mkdirSync(dirname(target), { recursive: true });
  writeFileSync(`${target}.lock`, JSON.stringify({ pid: 12345, utc: '2026-07-09T00:00:00.000Z' }));
  const draftPath = writeDraft(root, validDraft());

  const result = runCliFail(root, 3, ['--draft', draftPath, '--target', REL_TARGET, '--project-root', root]);

  assert.match(result.stderr, /LockHeld/);
  assert.equal(readFileSync(`${target}.lock`, 'utf8'), '{"pid":12345,"utc":"2026-07-09T00:00:00.000Z"}');
  assert.equal(existsSync(target), false);
  assert.equal(existsSync(`${target}.tmp.hwpx`), false);
  assertNoPdfArtifacts(target);
  assert.equal(existsSync(join(root, 'docs/report/report-journal.jsonl')), false);
});

test('CLI verify failure exits 4, keeps target bytes, and removes lock, candidate, and temp pdf', () => {
  const root = makeProject();
  const target = join(root, REL_TARGET);
  mkdirSync(dirname(target), { recursive: true });
  copyFileSync(SKELETON, target);
  const backup = `${target}.bak-20260709T000000Z`;
  writeFileSync(backup, 'old backup');
  const backupsBefore = backupNames(target);
  const before = readFileSync(target);
  const draftPath = writeDraft(root, validDraft());

  const result = runCliFail(
    root,
    4,
    ['--draft', draftPath, '--target', REL_TARGET, '--project-root', root],
    { HWPX_VERIFY_CMD: '/bin/false' },
  );

  assert.match(result.stderr, /verify failed/);
  assert.deepEqual(readFileSync(target), before);
  assert.deepEqual(backupNames(target), backupsBefore);
  assertNoTransients(target);
  assertNoPdfArtifacts(target);
  assert.equal(existsSync(join(root, 'docs/report/report-journal.jsonl')), false);
});

test('CLI happy path against an existing target creates exactly one new backup', () => {
  const root = makeProject();
  const target = join(root, REL_TARGET);
  mkdirSync(dirname(target), { recursive: true });
  copyFileSync(SKELETON, target);
  const draftPath = writeDraft(root, validDraft());
  const verifier = writeExecutable(root, 'verify-ok.sh', [
    '#!/usr/bin/env bash',
    'set -euo pipefail',
    'printf PDF > "$2"',
  ].join('\n'));

  const before = backupNames(target);
  runCli(root, ['--draft', draftPath, '--target', REL_TARGET, '--project-root', root], {
    HWPX_VERIFY_CMD: verifier,
  });
  const after = backupNames(target);

  assert.equal(after.length, before.length + 1);
  assertNoTransients(target);
});

test('CLI CAS race exits 3 without overwriting the raced target and cleans transients', () => {
  const root = makeProject();
  const target = join(root, REL_TARGET);
  mkdirSync(dirname(target), { recursive: true });
  copyFileSync(SKELETON, target);
  const backupsBefore = backupNames(target);
  const draftPath = writeDraft(root, validDraft());
  const verifier = writeExecutable(root, 'race-verify.sh', [
    '#!/usr/bin/env bash',
    'set -euo pipefail',
    'printf PDF > "$2"',
    'printf raced > "$HWPX_RACE_TARGET"',
  ].join('\n'));

  const result = runCliFail(
    root,
    3,
    ['--draft', draftPath, '--target', REL_TARGET, '--project-root', root],
    { HWPX_VERIFY_CMD: verifier, HWPX_RACE_TARGET: target },
  );

  assert.match(result.stderr, /CasMismatch/);
  assert.equal(readFileSync(target, 'utf8'), 'raced');
  assert.deepEqual(backupNames(target), backupsBefore);
  assertNoTransients(target);
  assertNoPdfArtifacts(target);
  assert.equal(existsSync(join(root, 'docs/report/report-journal.jsonl')), false);
});

test('CLI append crash exits 4 and still releases lock and removes candidate', () => {
  const root = makeProject();
  mkdirSync(join(root, 'fig'), { recursive: true });
  writeFileSync(join(root, 'fig/corrupt.png'), CORRUPT_IDAT_PNG_4x4);
  const target = join(root, REL_TARGET);
  const draftPath = writeDraft(root, {
    session: { date: '2026-07-09', project: 'tool_exp' },
    blocks: [{ type: 'figure_grid', images: ['fig/corrupt.png'], columns: 1, caption: 'broken' }],
  });

  const result = runCliFail(root, 4, ['--draft', draftPath, '--target', REL_TARGET, '--project-root', root]);

  assert.match(result.stderr, /ImageDecodeError|failed to decode image/);
  assert.equal(existsSync(target), false);
  assertNoTransients(target);
  assertNoPdfArtifacts(target);
  assert.equal(existsSync(join(root, 'docs/report/report-journal.jsonl')), false);
});

test('CLI post-commit journal failure exits 5 after updating target and cleaning transients', () => {
  const root = makeProject();
  const target = join(root, REL_TARGET);
  mkdirSync(dirname(target), { recursive: true });
  copyFileSync(SKELETON, target);
  const before = readFileSync(target);
  const draftPath = writeDraft(root, validDraft());
  mkdirSync(join(root, 'docs/report/report-journal.jsonl'), { recursive: true });
  const verifier = writeExecutable(root, 'verify-ok.sh', [
    '#!/usr/bin/env bash',
    'set -euo pipefail',
    'printf PDF > "$2"',
  ].join('\n'));

  const result = runCliFail(
    root,
    5,
    ['--draft', draftPath, '--target', REL_TARGET, '--project-root', root],
    { HWPX_VERIFY_CMD: verifier },
  );

  assert.match(result.stderr, /committed-but-postlude-failed/);
  assert.notDeepEqual(readFileSync(target), before);
  assertNoTransients(target);
});

test('CLI cleanup failure still preserves the primary exit code and releases lock', () => {
  const root = makeProject();
  const target = join(root, REL_TARGET);
  const candidatePath = `${target}.tmp.hwpx`;
  mkdirSync(candidatePath, { recursive: true });
  const draftPath = writeDraft(root, validDraft());

  const result = runCliFail(root, 4, ['--draft', draftPath, '--target', REL_TARGET, '--project-root', root]);

  assert.match(result.stderr, /EISDIR|illegal operation|cleanup failed/);
  assert.equal(existsSync(`${target}.lock`), false);
  rmSync(candidatePath, { recursive: true, force: true });
});

test('verify_report.sh rejects roundtrip output unless diff and r2 are both zero', () => {
  const root = makeProject();
  mkdirSync(join(root, 'bin'), { recursive: true });
  const fakeRhwp = writeExecutable(root, 'bin/rhwp', [
    '#!/usr/bin/env bash',
    'set -euo pipefail',
    'case "$1" in',
    '  info) exit 0 ;;',
    '  hwpx-roundtrip) echo "[          PASS] diff=  0 r2=  01    1ms  $2"; exit 0 ;;',
    '  export-pdf) printf PDF > "$4"; exit 0 ;;',
    '  *) exit 64 ;;',
    'esac',
  ].join('\n'));

  assert.ok(existsSync(fakeRhwp));
  assert.throws(() => execFileSync(VERIFY_SCRIPT, [join(root, 'candidate.hwpx'), join(root, 'out.pdf')], {
    cwd: root,
    env: { ...process.env, PATH: `${join(root, 'bin')}:${process.env.PATH}` },
    stdio: ['ignore', 'pipe', 'pipe'],
  }));
});

function makeProject() {
  return mkdtempSync(join(tmpdir(), 'hwpxpipe-'));
}

function validDraft() {
  return {
    session: { date: '2026-07-09', project: 'tool_exp' },
    blocks: [{ type: 'bullet1', text: 'pipeline smoke' }],
  };
}

function writeDraft(root, draft) {
  const path = join(root, 'draft.json');
  writeFileSync(path, JSON.stringify(draft), 'utf8');
  return path;
}

function writeExecutable(root, name, content) {
  const path = join(root, name);
  writeFileSync(path, `${content}\n`, 'utf8');
  chmodSync(path, 0o755);
  return path;
}

function runCli(root, args, env = {}) {
  return execFileSync('node', [SCRIPT, ...args], {
    cwd: root,
    env: cliEnv(env),
    encoding: 'utf8',
    stdio: ['ignore', 'pipe', 'pipe'],
  });
}

function runCliFail(root, expectedStatus, args, env = {}) {
  try {
    runCli(root, args, env);
  } catch (error) {
    assert.equal(error.status, expectedStatus, error.stderr?.toString() || error.message);
    return {
      stdout: error.stdout?.toString() ?? '',
      stderr: error.stderr?.toString() ?? '',
    };
  }
  assert.fail(`expected exit ${expectedStatus}`);
}

function cliEnv(env) {
  return {
    ...process.env,
    PATH: `${process.env.HOME}/.local/bin:${process.env.PATH}`,
    ...env,
  };
}

function assertNoTransients(target) {
  assert.equal(existsSync(`${target}.lock`), false, 'lock should be removed');
  assert.equal(existsSync(`${target}.tmp.hwpx`), false, 'candidate should be removed');
  assert.equal(existsSync(`${target}.tmp.pdf`), false, 'temp pdf should be removed');
}

function assertNoPdfArtifacts(target) {
  const dir = dirname(target);
  if (!existsSync(dir)) {
    return;
  }
  const pdfs = readdirSync(dir).filter((name) => name.endsWith('.pdf'));
  assert.deepEqual(pdfs, []);
}

function backupNames(target) {
  const dir = dirname(target);
  if (!existsSync(dir)) {
    return [];
  }
  return readdirSync(dir)
    .filter((name) => name.startsWith(`${basename(target)}.bak-`))
    .sort();
}

function readJsonl(path) {
  return readFileSync(path, 'utf8')
    .trim()
    .split('\n')
    .filter(Boolean)
    .map((line) => JSON.parse(line));
}

function fileSha(path) {
  return createHash('sha256').update(readFileSync(path)).digest('hex');
}
