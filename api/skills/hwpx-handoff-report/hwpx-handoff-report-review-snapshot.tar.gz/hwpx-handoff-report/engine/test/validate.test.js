import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, writeFileSync, mkdirSync, symlinkSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { validateDraft } from '../lib/validate.js';

// genuine 4x4 PNG (IHDR width=4 height=4)
const PNG_4x4 = Buffer.from(
  'iVBORw0KGgoAAAANSUhEUgAAAAQAAAAECAYAAACp8Z5+AAAAEklEQVR4nGP4z8DwHxkzkC4AADxAH+HggXe0AAAAAElFTkSuQmCC',
  'base64');

function root() {
  const r = mkdtempSync(join(tmpdir(), 'hwpxval-'));
  mkdirSync(join(r, 'fig'));
  writeFileSync(join(r, 'fig/a.png'), PNG_4x4);
  return r;
}
const base = (blocks) => ({ session: { date: '2026-07-09', project: 'tool_exp' }, blocks });

test('valid draft passes', () => {
  const r = root();
  const d = base([
    { type: 'bullet1', text: '◎성과' },
    { type: 'figure_grid', images: ['fig/a.png'], columns: 1, caption: '설명 (출처, 2026)' },
    { type: 'table', headers: ['구분', '내용'], rows: [['a', 'b']] },
  ]);
  assert.equal(validateDraft(d, r).ok, true);
});
test('table colWidthRatios and merges validate', () => {
  const r = root();
  const good = base([{
    type: 'table',
    headers: ['구분', '내용', '비고', ''],
    colWidthRatios: [2, 3, 1, 1],
    merges: [
      { row: 0, col: 2, rowSpan: 1, colSpan: 2 },
      { row: 1, col: 0, rowSpan: 2, colSpan: 1 },
    ],
    rows: [['zone', 'a', 'b', 'c'], ['', 'd', 'e', 'f']],
  }]);
  assert.equal(validateDraft(good, r).ok, true);

  const badLen = base([{ type: 'table', headers: ['a', 'b'], colWidthRatios: [1], rows: [] }]);
  assert.equal(validateDraft(badLen, r).ok, false);
  const badNeg = base([{ type: 'table', headers: ['a', 'b'], colWidthRatios: [1, -2], rows: [] }]);
  assert.equal(validateDraft(badNeg, r).ok, false);
  const badSpread = base([{ type: 'table', headers: ['a', 'b'], colWidthRatios: [1, 1000], rows: [] }]);
  assert.equal(validateDraft(badSpread, r).ok, false);

  const outOfBounds = base([{ type: 'table', headers: ['a', 'b'],
    merges: [{ row: 0, col: 1, rowSpan: 1, colSpan: 2 }], rows: [['x', 'y']] }]);
  assert.equal(validateDraft(outOfBounds, r).ok, false);
  const trivialMerge = base([{ type: 'table', headers: ['a', 'b'],
    merges: [{ row: 0, col: 0, rowSpan: 1, colSpan: 1 }], rows: [['x', 'y']] }]);
  assert.equal(validateDraft(trivialMerge, r).ok, false);
  const overlapping = base([{ type: 'table', headers: ['a', 'b', ''],
    merges: [
      { row: 0, col: 0, rowSpan: 1, colSpan: 2 },
      { row: 0, col: 1, rowSpan: 1, colSpan: 2 },
    ], rows: [] }]);
  assert.equal(validateDraft(overlapping, r).ok, false);
  const coveredNotEmpty = base([{ type: 'table', headers: ['a', 'b'],
    merges: [{ row: 1, col: 0, rowSpan: 1, colSpan: 2 }], rows: [['x', 'y']] }]);
  assert.equal(validateDraft(coveredNotEmpty, r).ok, false);
  // header covered by a merge may be empty; uncovered empty header still rejected:
  const emptyHeaderUncovered = base([{ type: 'table', headers: ['a', ''], rows: [] }]);
  assert.equal(validateDraft(emptyHeaderUncovered, r).ok, false);
});

test('unknown block type rejected', () => {
  assert.equal(validateDraft(base([{ type: 'h1', text: 'x' }]), root()).ok, false);
});
test('unknown field rejected (strict)', () => {
  assert.equal(validateDraft(base([{ type: 'bullet1', text: 'x', evil: 1 }]), root()).ok, false);
});
test('absolute image path rejected', () => {
  const r = root();
  const d = base([{ type: 'figure_grid', images: [join(r, 'fig/a.png')], caption: 'c' }]);
  assert.equal(validateDraft(d, r).ok, false);
});
test('parent-escape path rejected', () => {
  assert.equal(validateDraft(base([{ type: 'figure_grid', images: ['../x.png'], caption: 'c' }]), root()).ok, false);
});
test('ANY symlink component rejected — even pointing inside root', () => {
  const r = root();
  // symlink to a file INSIDE the root: still rejected (lstat rule, TOCTOU guard)
  symlinkSync(join(r, 'fig/a.png'), join(r, 'fig/link-in.png'));
  assert.equal(validateDraft(base([{ type: 'figure_grid', images: ['fig/link-in.png'], caption: 'c' }]), r).ok, false);
  // symlinked DIRECTORY component also rejected
  symlinkSync(join(r, 'fig'), join(r, 'figlink'));
  assert.equal(validateDraft(base([{ type: 'figure_grid', images: ['figlink/a.png'], caption: 'c' }]), r).ok, false);
});
test('non-PNG magic rejected', () => {
  const r = root();
  writeFileSync(join(r, 'fig/fake.png'), Buffer.from('BM6\x00\x00'));
  assert.equal(validateDraft(base([{ type: 'figure_grid', images: ['fig/fake.png'], caption: 'c' }]), r).ok, false);
});
test('table row width mismatch rejected', () => {
  assert.equal(validateDraft(base([{ type: 'table', headers: ['a', 'b'], rows: [['only-one']] }]), root()).ok, false);
});
test('columns out of range rejected', () => {
  const r = root();
  assert.equal(validateDraft(base([{ type: 'figure_grid', images: ['fig/a.png'], columns: 4, caption: 'c' }]), r).ok, false);
});

test('draft top-level unknown key rejected', () => {
  const result = validateDraft({ ...base([{ type: 'bullet1', text: 'x' }]), extra: true }, root());
  assert.equal(result.ok, false);
  assert.match(result.errors.join('\n'), /draft\.extra is not allowed/);
});

test('session unknown key rejected', () => {
  const result = validateDraft({
    session: { date: '2026-07-09', project: 'tool_exp', extra: true },
    blocks: [{ type: 'bullet1', text: 'x' }],
  }, root());
  assert.equal(result.ok, false);
  assert.match(result.errors.join('\n'), /session\.extra is not allowed/);
});

test('oversized-dimension PNG rejected', () => {
  const r = root();
  const tooWide = Buffer.from(PNG_4x4);
  tooWide.writeUInt32BE(4097, 16);
  writeFileSync(join(r, 'fig/too-wide.png'), tooWide);

  const result = validateDraft(base([{ type: 'figure_grid', images: ['fig/too-wide.png'], caption: 'c' }]), r);
  assert.equal(result.ok, false);
  assert.match(result.errors.join('\n'), /image dimensions exceed 4096px/);
});

test('image over 2MB rejected', () => {
  const r = root();
  writeFileSync(join(r, 'fig/huge.png'), Buffer.concat([PNG_4x4.subarray(0, 8), Buffer.alloc((2 * 1024 * 1024) + 1)]));

  const result = validateDraft(base([{ type: 'figure_grid', images: ['fig/huge.png'], caption: 'c' }]), r);
  assert.equal(result.ok, false);
  assert.match(result.errors.join('\n'), /image file exceeds 2MB/);
});

test('truncated PNG rejected cleanly', () => {
  const r = root();
  writeFileSync(join(r, 'fig/truncated.png'), PNG_4x4.subarray(0, 16));

  const result = validateDraft(base([{ type: 'figure_grid', images: ['fig/truncated.png'], caption: 'c' }]), r);
  assert.equal(result.ok, false);
  assert.match(result.errors.join('\n'), /image file is missing IHDR dimensions/);
});

test('non-integer columns rejected', () => {
  const r = root();
  const result = validateDraft(base([{ type: 'figure_grid', images: ['fig/a.png'], columns: 2.5, caption: 'c' }]), r);
  assert.equal(result.ok, false);
  assert.match(result.errors.join('\n'), /columns must be an integer from 1 to 3/);
});
