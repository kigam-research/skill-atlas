import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, copyFileSync, writeFileSync, mkdirSync, readFileSync, existsSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { execFileSync } from 'node:child_process';
import { strFromU8, unzipSync } from 'fflate';
import { appendBlocks, OUTLINE_STYLES, outlineLabel } from '../lib/engine.js';
import { readSectionXml, captionNumbers } from '../lib/hwpx-read.js';
import { validateDraft } from '../lib/validate.js';

const PNG_4x4 = Buffer.from(
  'iVBORw0KGgoAAAANSUhEUgAAAAQAAAAECAYAAACp8Z5+AAAAEklEQVR4nGP4z8DwHxkzkC4AADxAH+HggXe0AAAAAElFTkSuQmCC',
  'base64');
const SKEL = new URL('../forms/kigam-annual/skeleton.hwpx', import.meta.url).pathname;
const RHWP = `${process.env.HOME}/.local/bin/rhwp`;

function workspace() {
  const d = mkdtempSync(join(tmpdir(), 'hwpx-outline-'));
  mkdirSync(join(d, 'fig'));
  writeFileSync(join(d, 'fig/a.png'), PNG_4x4);
  copyFileSync(SKEL, join(d, 'in.hwpx'));
  return d;
}

// Text of every paragraph with its paraPrIDRef, in document order.
function paragraphs(xml) {
  const out = [];
  for (const m of xml.matchAll(/<hp:p\b[^>]*paraPrIDRef="(\d+)"[^>]*>([\s\S]*?)<\/hp:p>/g)) {
    const text = [...m[2].matchAll(/<hp:t>([^<]*)<\/hp:t>/g)].map((t) => t[1]).join('');
    if (text) out.push({ paraPr: Number(m[1]), text });
  }
  return out;
}

function paraMargins(header, id) {
  const block = header.match(new RegExp(`<hh:paraPr id="${id}"[\\s\\S]*?</hh:paraPr>`))[0];
  const deflt = block.match(/<hp:default>([\s\S]*?)<\/hp:default>/)?.[1] ?? block;
  const value = (name) => Number(deflt.match(new RegExp(`<hc:${name} value="(-?\\d+)"`))[1]);
  return { left: value('left'), intent: value('intent'), heading: block.match(/<hh:heading type="(\w+)"/)[1] };
}

const unescape = (s) => s.replaceAll('&lt;', '<').replaceAll('&gt;', '>').replaceAll('&amp;', '&');

test('validateDraft accepts outline blocks, angle captions and table captions', () => {
  const d = workspace();
  const draft = { session: { date: '2026-09-28', project: 't' }, blocks: [
    { type: 'heading1', text: '스킬 개발' },
    { type: 'heading2', text: '스킬화 방법', source: 'SKILL.md' },
    { type: 'heading3', text: '구성' },
    { type: 'statement', text: '서술하였음.' },
    { type: 'detail', text: '세부 내용' },
    { type: 'figure_grid', images: ['fig/a.png'], columns: 1, caption: '구성도', captionStyle: 'angle' },
    { type: 'table', caption: '비교', headers: ['a'], rows: [['b']] },
  ] };
  assert.deepEqual(validateDraft(draft, d), { ok: true, errors: [] });
});

test('validateDraft rejects hand-numbered headings and unknown caption styles', () => {
  const d = workspace();
  const bad = { session: { date: '2026-09-28', project: 't' }, blocks: [
    { type: 'heading1', text: '가. 스킬 개발' },
    { type: 'heading2', text: '1) 스킬화 방법' },
    { type: 'heading3', text: '(1) 구성' },
    { type: 'statement', text: '' },
    { type: 'figure_grid', images: ['fig/a.png'], columns: 1, caption: 'x', captionStyle: 'box' },
    { type: 'table', caption: ' ', headers: ['a'], rows: [['b']] },
    { type: 'detail', text: 'x', number: 3 },
  ] };
  const { ok, errors } = validateDraft(bad, d);
  assert.equal(ok, false);
  for (const i of [0, 1, 2]) {
    assert.ok(errors.some((e) => e.startsWith(`blocks[${i}].text must not start with a number label`)), `blocks[${i}]`);
  }
  assert.ok(errors.includes('blocks[3].text must be a nonempty string'));
  assert.ok(errors.includes('blocks[4].captionStyle must be "number" or "angle"'));
  assert.ok(errors.includes('blocks[5].caption must be a nonempty string when present'));
  assert.ok(errors.includes('blocks[6].number is not allowed'));
});

test('outlineLabel numbers each level and restarts lower levels', () => {
  const c = [0, 0, 0];
  const seq = ['heading1', 'heading2', 'heading3', 'heading3', 'heading2', 'heading3', 'heading1', 'heading2',
    'statement', 'detail'].map((t) => outlineLabel(c, t));
  assert.deepEqual(seq, ['가. ', '1) ', '(1) ', '(2) ', '2) ', '(1) ', '나. ', '1) ', '◯ ', '- ']);
  const full = [14, 0, 0];
  assert.throws(() => outlineLabel(full, 'heading1'), /at most 14 sections/);
});

test('appendBlocks writes numbered headings, ◯/- markers and hanging-indent paragraphs', async () => {
  const d = workspace();
  const out = join(d, 'out.hwpx');
  const draft = { session: { date: '2026-09-28', project: 't' }, blocks: [
    { type: 'heading1', text: '스킬 개발' },
    { type: 'heading2', text: '스킬화 방법' },
    { type: 'heading3', text: '구성' },
    { type: 'statement', text: '◯ 중복 표시가 한 번만 남음.' },
    { type: 'detail', text: '- 세부 하나' },
    { type: 'heading3', text: '절차' },
    { type: 'heading2', text: '분석 스킬' },
    { type: 'heading3', text: '단계' },
    { type: 'heading1', text: '플랫폼 구축' },
    { type: 'heading2', text: '구성' },
    { type: 'bullet3', text: '기존 본문 호환' },
  ] };
  await appendBlocks(join(d, 'in.hwpx'), out, draft, d);
  const xml = readSectionXml(out);
  const texts = paragraphs(xml).map((p) => p.text);
  for (const expected of ['가. 스킬 개발', '1) 스킬화 방법', '(1) 구성', '◯ 중복 표시가 한 번만 남음.', '- 세부 하나',
    '(2) 절차', '2) 분석 스킬', '(1) 단계', '나. 플랫폼 구축', '1) 구성', '기존 본문 호환']) {
    assert.ok(texts.includes(expected), `missing paragraph: ${expected}`);
  }
  assert.ok(texts.indexOf('가. 스킬 개발') < texts.indexOf('나. 플랫폼 구축'));

  const header = strFromU8(unzipSync(new Uint8Array(readFileSync(out)))['Contents/header.xml']);
  const byText = Object.fromEntries(paragraphs(xml).map((p) => [p.text, p.paraPr]));
  const expect = {
    '가. 스킬 개발': OUTLINE_STYLES.heading1.format,
    '1) 스킬화 방법': OUTLINE_STYLES.heading2.format,
    '(1) 구성': OUTLINE_STYLES.heading3.format,
    '◯ 중복 표시가 한 번만 남음.': OUTLINE_STYLES.statement.format,
    '- 세부 하나': OUTLINE_STYLES.detail.format,
  };
  for (const [text, format] of Object.entries(expect)) {
    const m = paraMargins(header, byText[text]);
    assert.equal(m.left, format.marginLeft, `${text} left`);
    assert.equal(m.intent, format.indent, `${text} indent`);
    assert.equal(m.heading, 'NONE', `${text} must not carry a bullet heading`);
  }
  // The same format reuses one paraPr rather than creating one per paragraph.
  assert.equal(byText['(1) 구성'], byText['(2) 절차']);
  if (existsSync(RHWP)) {
    execFileSync(RHWP, ['hwpx-roundtrip', out, '-o', join(d, 'rt')], { stdio: 'pipe' });
  }
});

test('angle captions do not consume figure numbers; table captions precede the table', async () => {
  const d = workspace();
  const out = join(d, 'out.hwpx');
  const draft = { session: { date: '2026-09-28', project: 't' }, blocks: [
    { type: 'figure_grid', images: ['fig/a.png'], columns: 1, caption: '번호 그림' },
    { type: 'figure_grid', images: ['fig/a.png'], columns: 1, caption: '구성도(좌) 및 화면(우)', captionStyle: 'angle' },
    { type: 'figure_grid', images: ['fig/a.png'], columns: 1, caption: '다음 번호 그림', captionStyle: 'number' },
    { type: 'statement', text: '표 앞 문장.' },
    { type: 'table', caption: '비교 표', headers: ['구분', '내용'], rows: [['a', 'b']] },
  ] };
  const res = await appendBlocks(join(d, 'in.hwpx'), out, draft, d);
  const xml = readSectionXml(out);
  const texts = paragraphs(xml).map((p) => unescape(p.text));
  assert.ok(texts.includes('<구성도(좌) 및 화면(우)>'));
  assert.deepEqual(captionNumbers(xml), [1, 2]);
  assert.deepEqual(res.figuresAdded, [1, 2]);
  const caption = xml.indexOf('&lt;비교 표&gt;');
  const cell = xml.indexOf('<hp:t>구분</hp:t>');
  assert.ok(caption > 0 && cell > caption, 'table caption must come before the table');
  const header = strFromU8(unzipSync(new Uint8Array(readFileSync(out)))['Contents/header.xml']);
  const captionPara = paragraphs(xml).find((p) => unescape(p.text) === '<비교 표>');
  const block = header.match(new RegExp(`<hh:paraPr id="${captionPara.paraPr}"[\\s\\S]*?</hh:paraPr>`))[0];
  assert.match(block, /keepWithNext="1"/, 'table caption keeps with the table');
  assert.match(block, /<hh:align horizontal="CENTER"/, 'table caption stays centred');
  if (existsSync(RHWP)) {
    execFileSync(RHWP, ['hwpx-roundtrip', out, '-o', join(d, 'rt')], { stdio: 'pipe' });
  }
});
