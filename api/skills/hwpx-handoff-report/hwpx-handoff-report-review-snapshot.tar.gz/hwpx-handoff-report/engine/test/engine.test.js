import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, copyFileSync, existsSync, writeFileSync, mkdirSync, readFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { execFileSync } from 'node:child_process';
import { strFromU8, unzipSync } from 'fflate';
import { appendBlocks, stripLeadingBulletMarkers } from '../lib/engine.js';
import { readSectionXml, captionNumbers, anchorInfo } from '../lib/hwpx-read.js';

const PNG_4x4 = Buffer.from(
  'iVBORw0KGgoAAAANSUhEUgAAAAQAAAAECAYAAACp8Z5+AAAAEklEQVR4nGP4z8DwHxkzkC4AADxAH+HggXe0AAAAAElFTkSuQmCC',
  'base64');
const PNG_4x2 = Buffer.from(
  'iVBORw0KGgoAAAANSUhEUgAAAAQAAAACCAYAAAB/qH1jAAAAI0lEQVR4nAXBAQEAMAyDMORMzuVULF54gpBHPnKELG/5llsfJHUSmXu7UO0AAAAASUVORK5CYII=',
  'base64');
const CORRUPT_IDAT_PNG_4x4 = Buffer.from(
  'iVBORw0KGgoAAAANSUhEUgAAAAQAAAAECAYAAACp8Z5+AAAAEElEQVR4nGNgYGD4z4AGAA0ABv/BQGF2AAAAAElFTkSuQmCC',
  'base64');
const SKEL = new URL('../forms/kigam-annual/skeleton.hwpx', import.meta.url).pathname;

test('appendBlocks inserts styled blocks in the body, before the summary table, numbers figures', async () => {
  const d = mkdtempSync(join(tmpdir(), 'hwpxeng-'));
  mkdirSync(join(d, 'fig'));
  writeFileSync(join(d, 'fig/a.png'), PNG_4x4);
  const input = join(d, 'in.hwpx'); copyFileSync(SKEL, input);
  const out = join(d, 'out.hwpx');
  const draft = { session: { date: '2026-07-09', project: 't' }, blocks: [
    { type: 'bullet1', text: '엔진 테스트 성과' },
    { type: 'bullet3', text: '상세 서술이다' },
    { type: 'figure_grid', images: ['fig/a.png'], columns: 1, caption: '테스트 (test, 2026)' },
    { type: 'table', headers: ['구분', '내용'], rows: [['a', 'b']] },
  ]};
  const res = await appendBlocks(input, out, draft, d);
  const xml = readSectionXml(out);
  const a = anchorInfo(xml);
  // paraPr heading BULLET renders the marker; text must NOT carry a literal one:
  const p1 = xml.indexOf('<hp:t>엔진 테스트 성과</hp:t>');
  const p3 = xml.indexOf('<hp:t>상세 서술이다</hp:t>');
  assert.equal(xml.includes('◎'), false, 'literal ◎ must not be inserted');
  assert.equal(xml.includes('­상세'), false, 'literal soft hyphen must not be inserted');
  // after the 3-1 heading AND before the summary table:
  for (const p of [p1, p3]) {
    assert.ok(p > xml.indexOf('3-1 정성적 연구개발성과') && p < a.summaryTableIndex, `pos ${p} outside anchor window`);
  }
  // exportHwpx drops <hh:bullets>; engine must restore it so paraPr idRef 1..3 resolve:
  const header = strFromU8(unzipSync(new Uint8Array(readFileSync(out)))['Contents/header.xml']);
  const bullets = header.match(/<hh:bullets itemCnt="3">.*?<\/hh:bullets>/s);
  assert.ok(bullets, 'output header.xml must contain restored <hh:bullets> definitions');
  for (const ch of ['char="◎"', 'char="⚪"', 'char="­"']) {
    assert.ok(bullets[0].includes(ch), `bullets container missing ${ch}`);
  }
  assert.ok(
    header.indexOf('</hh:numberings>') < header.indexOf('<hh:bullets'),
    'bullets container must follow numberings (sample refList order)',
  );
  // OCF-style zip contract: mimetype must stay the first (stored) entry:
  assert.equal(readFileSync(out).subarray(30, 38).toString('ascii'), 'mimetype');
  assert.equal(readFileSync(out).readUInt16LE(8), 0, 'mimetype is stored, not deflated');
  assert.deepEqual(captionNumbers(xml), [1]);            // skeleton had none → 그림 1
  assert.deepEqual(res.figuresAdded, [1, 1]);
  execFileSync(process.env.HOME + '/.local/bin/rhwp',
    ['hwpx-roundtrip', out, '-o', join(d, 'rt')], { stdio: 'pipe' });
});

test('appendBlocks strips author-supplied bullet markers and keeps level-4 literal', async () => {
  const d = mkdtempSync(join(tmpdir(), 'hwpxeng-'));
  const input = join(d, 'in.hwpx'); copyFileSync(SKEL, input);
  const out = join(d, 'out.hwpx');
  const draft = { session: { date: '2026-07-10', project: 't' }, blocks: [
    { type: 'bullet1', text: '◎ 중복 마커 성과' },
    { type: 'bullet2', text: 'ㅇ 한글 마커 성과' },
    { type: 'bullet2', text: 'ㅇㅇ연구원 협력 성과' },
    { type: 'bullet3', text: '­소프트하이픈 서술' },
    { type: 'bullet4', text: '· 세부 항목' },
    { type: 'bullet4', text: '세부 항목 둘' },
  ]};
  await appendBlocks(input, out, draft, d);
  const xml = readSectionXml(out);
  assert.ok(xml.includes('<hp:t>중복 마커 성과</hp:t>'), 'bullet1 marker not stripped');
  assert.ok(xml.includes('<hp:t>한글 마커 성과</hp:t>'), 'bullet2 ㅇ marker not stripped');
  assert.ok(xml.includes('<hp:t>ㅇㅇ연구원 협력 성과</hp:t>'), 'ㅇㅇ placeholder must be preserved');
  assert.ok(xml.includes('<hp:t>소프트하이픈 서술</hp:t>'), 'bullet3 soft-hyphen marker not stripped');
  // level 4 has heading NONE in the form; the sample carries a literal "  ·" in text:
  assert.ok(xml.includes('<hp:t>  ·세부 항목</hp:t>'), 'bullet4 must carry literal "  ·" prefix');
  assert.ok(xml.includes('<hp:t>  ·세부 항목 둘</hp:t>'), 'bullet4 plain text must gain "  ·" prefix');
  assert.equal(xml.includes('◎'), false);
});

test('appendBlocks rejects bullet text that is only a marker', async () => {
  const d = mkdtempSync(join(tmpdir(), 'hwpxeng-'));
  const input = join(d, 'in.hwpx'); copyFileSync(SKEL, input);
  const out = join(d, 'out.hwpx');
  const draft = { session: { date: '2026-07-10', project: 't' }, blocks: [
    { type: 'bullet2', text: 'ㅇ ' },
  ]};
  await assert.rejects(appendBlocks(input, out, draft, d), /marker/);
  assert.equal(existsSync(out), false);
});

test('appendBlocks rejects corrupt PNG IDAT without producing output', async () => {
  const d = mkdtempSync(join(tmpdir(), 'hwpxeng-'));
  mkdirSync(join(d, 'fig'));
  writeFileSync(join(d, 'fig/corrupt.png'), CORRUPT_IDAT_PNG_4x4);
  const input = join(d, 'in.hwpx'); copyFileSync(SKEL, input);
  const out = join(d, 'out.hwpx');
  const draft = { session: { date: '2026-07-09', project: 't' }, blocks: [
    { type: 'figure_grid', images: ['fig/corrupt.png'], columns: 1, caption: '깨진 PNG' },
  ]};

  await assert.rejects(
    appendBlocks(input, out, draft, d),
    (error) => error.name === 'ImageDecodeError'
      && /fig\/corrupt\.png/.test(error.message),
  );
  assert.equal(existsSync(out), false);
});

test('appendBlocks sizes generated tables to the body width and fits figure row height', async () => {
  const d = mkdtempSync(join(tmpdir(), 'hwpxeng-'));
  mkdirSync(join(d, 'fig'));
  writeFileSync(join(d, 'fig/a.png'), PNG_4x2);
  writeFileSync(join(d, 'fig/b.png'), PNG_4x2);
  const input = join(d, 'in.hwpx'); copyFileSync(SKEL, input);
  const out = join(d, 'out.hwpx');
  const draft = { session: { date: '2026-07-09', project: 't' }, blocks: [
    { type: 'figure_grid', images: ['fig/a.png', 'fig/b.png'], columns: 2, caption: '크기 테스트' },
    { type: 'table', headers: ['구분', '내용', '비고'], rows: [['a', 'b', 'c']] },
  ]};

  await appendBlocks(input, out, draft, d);
  const xml = readSectionXml(out);
  const anchor = anchorInfo(xml);
  const bodyWidth = Number(/<hp:pagePr[^>]*width="(\d+)"/.exec(xml)[1])
    - Number(/<hp:margin[^>]*left="(\d+)"/.exec(xml)[1]) - Number(/<hp:margin[^>]*right="(\d+)"/.exec(xml)[1]);
  const generatedTables = tableRanges(xml)
    .filter((table) => table.start > xml.indexOf('3-1 정성적 연구개발성과') && table.end < anchor.summaryTableIndex);

  assert.equal(generatedTables.length, 2);
  for (const table of generatedTables) {
    const width = firstRowWidth(table.xml);
    assert.ok(
      width <= bodyWidth,
      `generated ${table.attrs.rowCnt}x${table.attrs.colCnt} table width ${width} exceeds the body width ${bodyWidth}`,
    );
  }

  // every generated table anchors PARA-relative like the sample:
  for (const table of generatedTables) {
    const pos = parseAttrs(requireMatch(table.xml, /<hp:pos\b[^>]*\/>/u)[0]);
    assert.equal(pos.vertRelTo, 'PARA', `generated table vertRelTo must be PARA, got ${pos.vertRelTo}`);
    assert.equal(pos.horzRelTo, 'PARA', `generated table horzRelTo must be PARA, got ${pos.horzRelTo}`);
  }

  const figureTable = generatedTables.find((table) => table.xml.includes('<hp:pic'));
  assert.ok(figureTable, 'missing generated figure table');
  assert.equal(figureTable.attrs.borderFillIDRef, '4');
  for (const cell of tableCells(figureTable.xml).filter((candidate) => candidate.includes('<hp:pic'))) {
    assert.equal(parseAttrs(requireMatch(cell, /^<hp:tc(?=[\s/>])[^>]*>/u)[0]).borderFillIDRef, '15');
    const pictureSize = parseAttrs(requireMatch(cell, /<hp:pic\b[\s\S]*?<hp:sz\b[^>]*\/>/u)[0]);
    const picturePosition = parseAttrs(requireMatch(cell, /<hp:pic\b[\s\S]*?<hp:pos\b[^>]*\/>/u)[0]);
    const pictureWidth = Number(pictureSize.width);
    const pictureHeight = Number(pictureSize.height);
    assert.equal(pictureHeight, Math.round(pictureWidth * 2 / 4));
    assert.equal(picturePosition.treatAsChar, '1');
    const cellHeight = Number(requireMatch(cell, /<hp:cellSz\b[^>]*\bheight="(\d+)"/u)[1]);
    assert.ok(
      cellHeight >= pictureHeight,
      `figure cell height ${cellHeight} is smaller than picture height ${pictureHeight}`,
    );
  }
});

test('stripLeadingBulletMarkers rules', () => {
  const cases = [
    ['◎ 성과', '성과'],
    ['⚪겹침', '겹침'],                        // strong glyphs strip even when glued
    ['­소프트하이픈', '소프트하이픈'],
    ['· 세부', '세부'],
    ['ㅇ 마커', '마커'],
    ['ㅇ연구 성과', '연구 성과'],              // ㅇ glued to a syllable is a marker
    ['ㅇㅇ연구원 협력', 'ㅇㅇ연구원 협력'],     // masked-name placeholder preserved
    ['ㅇ123 코드', 'ㅇ123 코드'],              // ㅇ before digit/Latin NOT stripped (by design)
    ['- 항목', '항목'],
    ['-5% 감소', '-5% 감소'],                  // dash without following space = negative number
    ['–2도 상승', '–2도 상승'],
    ['· ◎ 이중 마커', '이중 마커'],            // repeated markers all consumed
  ];
  for (const [input, expected] of cases) {
    assert.equal(stripLeadingBulletMarkers(input), expected, `strip(${JSON.stringify(input)})`);
  }
});

test('normalizeExport repairs are idempotent across sequential appends', async () => {
  const d = mkdtempSync(join(tmpdir(), 'hwpxeng-'));
  const first = join(d, 'first.hwpx');
  const second = join(d, 'second.hwpx');
  await appendBlocks(SKEL, first, { session: { date: '2026-07-10', project: 't' }, blocks: [
    { type: 'bullet1', text: '첫 append 성과' },
    { type: 'table', headers: ['구분', '내용'], rows: [['a', 'b']] },
  ]}, d);
  await appendBlocks(first, second, { session: { date: '2026-07-10', project: 't' }, blocks: [
    { type: 'bullet2', text: '둘째 append 성과' },
    { type: 'table', headers: ['항목', '값'], rows: [['c', 'd']] },
  ]}, d);
  for (const out of [first, second]) {
    const entries = unzipSync(new Uint8Array(readFileSync(out)));
    const header = strFromU8(entries['Contents/header.xml']);
    const section = strFromU8(entries['Contents/section0.xml']);
    assert.equal([...header.matchAll(/<hh:bullets /g)].length, 1, `${out}: exactly one bullets container`);
    assert.equal(section.includes('vertRelTo="PAGE"'), false, `${out}: no PAGE anchors remain`);
    assert.equal(readFileSync(out).subarray(30, 38).toString('ascii'), 'mimetype', `${out}: mimetype first`);
  }
});

test('appendBlocks tolerates content tables shaped like the 7x4 summary table', async () => {
  const d = mkdtempSync(join(tmpdir(), 'hwpxeng-'));
  const input = join(d, 'in.hwpx'); copyFileSync(SKEL, input);
  const out = join(d, 'out.hwpx');
  const rows6 = Array.from({ length: 6 }, (_, i) => [`케이스 ${i + 1}`, `내용 ${i + 1}`, `수치 ${i + 1}`, `비고 ${i + 1}`]);
  const draft = { session: { date: '2026-07-10', project: 't' }, blocks: [
    { type: 'bullet1', text: '요약표와 같은 7x4 모양의 내용 표' },
    { type: 'table', headers: ['항목', '설명', '값', '비고'], rows: rows6 },  // 7 rows x 4 cols
    { type: 'bullet2', text: '표 이후에도 앵커가 유지되어야 한다' },
  ]};
  await appendBlocks(input, out, draft, d);
  const xml = readSectionXml(out);
  const a = anchorInfo(xml);
  const after = xml.indexOf('<hp:t>표 이후에도 앵커가 유지되어야 한다</hp:t>');
  assert.ok(after > xml.indexOf('3-1 정성적 연구개발성과') && after < a.summaryTableIndex, 'post-table block outside anchor window');
});

test('appendBlocks supports colWidthRatios and cell merges in tables', async () => {
  const d = mkdtempSync(join(tmpdir(), 'hwpxeng-'));
  const input = join(d, 'in.hwpx'); copyFileSync(SKEL, input);
  const out = join(d, 'out.hwpx');
  const draft = { session: { date: '2026-07-10', project: 't' }, blocks: [
    { type: 'table',
      headers: ['추진 목표', '달성 내용', '달성도(%)'],
      colWidthRatios: [34, 52, 14],
      rows: [['목표 A', '내용 A', '100'], ['목표 B', '내용 B', '95']] },
    { type: 'table',
      headers: ['구분', '내용', '비고', ''],
      merges: [
        { row: 0, col: 2, rowSpan: 1, colSpan: 2 },
        { row: 1, col: 0, rowSpan: 2, colSpan: 1 },
      ],
      rows: [['zone', 'a', 'b', 'c'], ['', 'd', 'e', 'f']] },
  ]};
  await appendBlocks(input, out, draft, d);
  const xml = readSectionXml(out);
  const anchor = anchorInfo(xml);
  const generated = tableRanges(xml)
    .filter((table) => table.start > xml.indexOf('3-1 정성적 연구개발성과') && table.end < anchor.summaryTableIndex);
  assert.equal(generated.length, 2);

  const [ratioTable, mergeTable] = generated;
  const widths = [...ratioTable.xml.slice(0, ratioTable.xml.indexOf('</hp:tr>'))
    .matchAll(/<hp:cellSz\b[^>]*\bwidth="(\d+)"/gu)].map((m) => Number(m[1]));
  assert.equal(widths.length, 3);
  const total = widths.reduce((a, b) => a + b, 0);
  assert.ok(Math.abs(widths[0] / total - 0.34) < 0.02, `col0 ratio off: ${widths}`);
  assert.ok(Math.abs(widths[1] / total - 0.52) < 0.02, `col1 ratio off: ${widths}`);

  assert.ok(mergeTable.xml.includes('colSpan="2"'), 'missing colSpan=2 merge');
  assert.ok(mergeTable.xml.includes('rowSpan="2"'), 'missing rowSpan=2 merge');
  const cellCount = [...mergeTable.xml.matchAll(/<hp:tc(?=[\s/>])/g)].length;
  assert.equal(cellCount, 10, '4x3 grid with two merges must have 10 cells');
  execFileSync(process.env.HOME + '/.local/bin/rhwp',
    ['hwpx-roundtrip', out, '-o', join(d, 'rt')], { stdio: 'pipe' });
});

function tableRanges(xml) {
  const ranges = [];
  const headerRe = /<hp:tbl(?=[\s/>])[^>]*>/g;
  let match;
  while ((match = headerRe.exec(xml)) !== null) {
    const end = tagEnd(xml, 'hp:tbl', match.index);
    ranges.push({
      start: match.index,
      end,
      attrs: parseAttrs(match[0]),
      xml: xml.slice(match.index, end),
    });
  }
  return ranges;
}

function tableRangeAt(xml, start) {
  const header = requireMatch(xml.slice(start), /^<hp:tbl(?=[\s/>])[^>]*>/u)[0];
  const end = tagEnd(xml, 'hp:tbl', start);
  return {
    start,
    end,
    attrs: parseAttrs(header),
    xml: xml.slice(start, end),
  };
}

function firstRowWidth(tableXml) {
  const rowStart = tableXml.indexOf('<hp:tr>');
  const rowXml = tableXml.slice(rowStart, tagEnd(tableXml, 'hp:tr', rowStart));
  return [...rowXml.matchAll(/<hp:cellSz\b[^>]*\bwidth="(\d+)"/gu)]
    .reduce((sum, match) => sum + Number(match[1]), 0);
}

function tableCells(tableXml) {
  const cells = [];
  const cellRe = /<hp:tc(?=[\s/>])[^>]*>/g;
  let match;
  while ((match = cellRe.exec(tableXml)) !== null) {
    const end = tagEnd(tableXml, 'hp:tc', match.index);
    cells.push(tableXml.slice(match.index, end));
  }
  return cells;
}

function tagEnd(xml, tagName, start) {
  const tokenRe = new RegExp(`<${tagName}(?=[\\s/>])[^>]*>|</${tagName}>`, 'g');
  tokenRe.lastIndex = start;
  let depth = 0;
  let match;
  while ((match = tokenRe.exec(xml)) !== null) {
    if (match[0].startsWith('</')) {
      depth -= 1;
      if (depth === 0) {
        return tokenRe.lastIndex;
      }
    } else if (match[0].endsWith('/>')) {
      if (depth === 0) {
        return tokenRe.lastIndex;
      }
    } else {
      depth += 1;
    }
  }
  throw new Error(`unclosed ${tagName} at ${start}`);
}

function parseAttrs(header) {
  const attrs = {};
  for (const match of header.matchAll(/([\w:-]+)="([^"]*)"/g)) {
    attrs[match[1]] = match[2];
  }
  return attrs;
}

function requireMatch(text, re) {
  const match = re.exec(text);
  if (!match) {
    throw new Error(`missing ${re}`);
  }
  return match;
}
