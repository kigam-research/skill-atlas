#!/usr/bin/env bash
set -euo pipefail
f="$1"; pdf_out="$2"; rt=$(mktemp -d)
cleanup() {
  rm -rf "$rt"
}
trap cleanup EXIT
rhwp info "$f" > /dev/null
rhwp hwpx-roundtrip "$f" -o "$rt" | grep -E 'PASS.*diff= *0[[:space:]]+r2= *0([[:space:]]|$)' > /dev/null
rhwp export-pdf "$f" -o "$pdf_out" > /dev/null
echo VERIFY_OK
