# HWPX Research Report

연구 과제의 결과를 한글(HWPX) 연구보고서로 만드는 스킬이다. 주제는 가리지 않는다. 작성 지침, 원고에서 초안과 미리보기를 만드는 도구, HWPX 생성 엔진, 정본 관리 명령을 함께 담는다.

## 구성

| 경로 | 내용 |
|---|---|
| `SKILL.md` | 작성 절차(목차 승인 → 원고 → 초안·점검 → 전 쪽 렌더 → 교차 검토 → 승인 → 정본 → 한컴 확인·golden) |
| `references/report-writing.md` | 서술 규칙: 쓰는 것과 쓰지 않는 것, 독자, 문장 단위, 구조, 수치·비교·한계, 주장 범위, 점검 목록, 여러 분야의 예시 |
| `references/figures-tables.md` | 그림 파일·내용·화면 캡처·배치·표 기준 |
| `references/process.md` | 단계별 승인, 정본 생성·이어쓰기·재작성, 교차 검토, 한컴 확인과 golden, 한컴에서 확인된 동작 |
| `references/draft-format.md` | 초안 JSON 형식, block, 양식과 양식 추가 방법 |
| `tools/` | 원고 → 초안 JSON·미리보기(`build_report.py`), 쪽 렌더와 렌더 점검, 정본 관리(`canonical.py`). 설명은 `tools/README.md` |
| `engine/` | HWPX 생성 엔진(`append_report.mjs`), 양식(`engine/forms/<id>/`), 시험 |
| `examples/` | 일반 연구보고서 양식의 합성 예시 한 벌(원고, 수치 계산, 그림 스크립트, 초안, 미리보기, HWPX) |
| `provenance.json` | 원본(71pc 배포본)과의 차이, 파일별 해시 |

## 준비

- Node.js 20 이상과 Python 3.10 이상이 필요하다.
- rhwp CLI 0.8.6이 필요하다. 정본 생성 때의 구조 왕복 검증과 PDF 미리보기에 쓰며, 이 패키지에는 포함되지 않는다.
- 쪽 렌더 미리보기에는 headless Chromium이 필요하다.

```bash
cd engine && npm ci --ignore-scripts && cd ..
rhwp --version
node engine/append_report.mjs --list-forms
```

rhwp가 없으면 정본 생성과 검증을 했다고 말하지 않는다. 원고·초안·쪽 렌더 미리보기(`tools/build_report.py --render`)는 rhwp CLI 없이 된다.

## 빠른 시작

```bash
# 과제에 report.json과 원고 폴더를 만든다(형식: tools/README.md, 예: examples/)
python3 tools/build_report.py --config <과제>/docs/report/report.json --render /tmp/report-render
# 사용자 승인 뒤
node engine/append_report.mjs --draft <초안.json> --target <정본.hwpx> --project-root <과제 루트>
# 사용자 한컴 확인 뒤
python3 tools/canonical.py golden --config <report.json> --confirmed "<누가> 한컴 확인 <날짜>"
```

## 엔진

`engine/append_report.mjs --draft <초안> --target <정본> --project-root <루트> [--journal <경로>]`

흐름:
1. 초안을 검증한다.
2. 정본을 잠근다(`<정본>.lock`).
3. 후보를 만든다. 정본이 없으면 초안 `template`의 skeleton에서 시작한다.
4. rhwp로 검증한다(`info`, `hwpx-roundtrip` diff 0, `export-pdf`).
5. 시작 때의 정본 sha256과 비교한 뒤 교체한다. 기존 정본은 `.bak-<UTC>`로 5개까지 남긴다.
6. 미리보기 PDF를 두고 journal에 한 줄을 쓴다. 이 줄에는 초안 경로와 sha256, 바꾸기 전후 정본 sha256이 들어간다. journal은 기본으로 정본 옆 `report-journal.jsonl`이다.

`HWPX_KEEP_FAILED=1`이면 실패한 후보와 PDF를 `<정본>.failed.hwpx`·`.failed.pdf`로 남긴다(진단용).

종료 코드는 `references/process.md` 2절에 있다. 검증 명령은 `HWPX_VERIFY_CMD`로 바꿀 수 있다(시험용).

### 양식

양식은 `engine/forms/<id>/`의 `skeleton.hwpx`와 `form.json`이다(`references/draft-format.md` 3절).
- 기존 문서의 양식은 `detect` 문자열로 알아낸다. 어느 양식에도 맞지 않으면 일반 연구보고서 방식으로 문서 끝에 이어 쓴다.
- 기관 연차실적서 양식(`kigam-annual`)은 "3-1" 제목 뒤, 하단 요약표 앞에 표 밖 일반 문단으로 본문을 쓴다.
- 예전의 1×1 상자 안에 본문이 있는 문서는 거부한다.
- 엔진이 쓰는 스타일 번호의 정의가 기본 양식과 다른 문서도 거부한다. 그 정의가 가리키는 글꼴·탭·테두리·번호 정의까지 비교한다(웹 검토실 업로드도 같다).

### 연구보고서형 문단

| block | 표시 | 글자 | 문단(왼쪽 여백 / 내어쓰기, HWPUNIT) |
|---|---|---|---|
| `heading1` | `가.` `나.` … | 12 pt 굵게 | 0, 앞 간격 1200 |
| `heading2` | `1)` `2)` … | 11 pt | 2600, 앞 간격 600 |
| `heading3` | `(1)` `(2)` … | 11 pt | 4800, 앞 간격 300 |
| `statement` | `◯` 서술 | 11 pt | 6600 / −3200 |
| `detail` | `-` 세부 | 11 pt | 8600 / −1200 |

- **번호:** 수준별로 매기고, 상위 수준이 바뀌면 하위 번호를 1부터 다시 매긴다. 이어쓰기에서는 문서 본문에 이미 있는 번호에 이어서 매긴다.
- **제목:** 다음 문단과 같은 쪽에 놓이도록 `keepWithNext`를 켠다.
- **음수 내어쓰기:** 첫 줄을 왼쪽 여백에 두고 다음 줄을 |내어쓰기|만큼 들여 쓴다.

### 조판과 쪽 나눔

- **내용 표**
  - 칸 위아래 여백 280 HWPUNIT(칸마다 자체 여백, `hasMargin="1"`), 머리행 반복.
  - 15자 이상 문장이 있는 열은 왼쪽 정렬, 셀 글자는 장평 95·자간 −5.
  - 표 다음 문단 앞에 간격을 둔다.
- **그림 표·짧은 표**
  - 그림 표와 본문 높이의 95% 이하인 내용 표는 **글자처럼 취급**한다. 한컴은 이런 개체가 남은 공간에 들어가지 않으면 다음 쪽으로 옮긴다.
  - 떠 있는 표에 쪽 나눔 금지를 주면 한컴이 쪽 아래에서 잘라 그렸다(2026-09-29 사용자 확인).
- **긴 표**
  - 더 긴 표만 떠 있는 표로 두고 행 단위로 나눈다(`pageBreak="CELL"`).
  - 표 높이는 rhwp 렌더에서 읽는다. 반복 머리행은 한 번만 센다.
  - 글자처럼 취급하기 전에 행 높이를 글과 칸 여백에 맞춰 기록한다.
- **쪽 나누기:** 생성 뒤 rhwp 렌더에서 문단마다 시작·끝 쪽을 읽고, 다음 앞에 문단 쪽 나누기를 넣는다. 앞에 붙어야 할 제목·표 제목도 함께 옮기고, 최대 6회 반복한다.
  - 본문 영역 밖으로 그려진 표·그림 중 옮길 수 있는 첫 개체
  - 쪽 끝에 남은 제목·표 제목
  - 한 쪽에 들어가는데 나뉜 표
- **글줄:** 본문 글줄이 아래 여백에 조금 걸리는 것은 rhwp 줄 배치다. 쪽 나누기를 넣지 않고 `lineOverflow`로만 보고한다.
- **결과 보고:** 엔진은 `layout`을 돌려준다. 항목은 `pageBreaks`, `keepViolations`, `overflow`, `lineOverflow`, `unresolved`, `summarySplit`, `splitTables`다.
- **알려진 한계(rhwp 0.8.6):** 행 수에 따라 긴 표 뒤 문단을 새 쪽에서 시작하거나(시험의 70행 표), 본문보다 조금 높은 표를 나누지 않고 그린다(50행 표). 행은 빠지지 않고 넘침은 보고된다. 두 경우 모두 시험에 알려진 한계 사례로 남겼다.
- **그림 형식:** PNG만 받는다. SVG 삽입 코드(`lib/svg.js`)는 남아 있지만 초안 검증이 거부한다. 한컴이 표시하지 않았고, rhwp도 SVG 안의 래스터를 빠뜨렸기 때문이다.
- **export 보정:** 엔진은 export 뒤 다음을 보정한다.
  - rhwp가 빠뜨리는 `<hh:bullets>`를 복원한다.
  - 글자처럼 취급한 개체의 `vertRelTo`를 PAGE에서 PARA로 바꾼다.
  - `mimetype`을 비압축 첫 항목으로 저장한다.

### 시험

```bash
cd engine && node --test test/*.test.js            # rhwp CLI가 없으면 5개가 실패한다
python3 -m unittest discover tools/tests           # 초안 도구와 정본 명령
```

## 출처와 수정

- `SKILL.md`와 엔진 실행 파일은 71pc 배포본에서 복사해 이 저장소에서 고쳤다. 이력과 해시는 `provenance.json`의 `localModifications`에 있다. 원본 연구보고서나 과제 자료는 포함하지 않는다.
- 2026-09-29에 다음을 스킬로 옮겼다. 한 연차실적서(v1–v6)를 쓰며 사용자와 정한 서술·그림·절차 기준, 그 보고서를 만든 초안 도구, 양식 설정이다. 과제 고유의 내용, 수치 계산, 금지 주장은 각 과제에 둔다.
